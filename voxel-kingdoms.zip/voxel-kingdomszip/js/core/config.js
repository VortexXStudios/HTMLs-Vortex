/**
 * @file config.js
 * Creates the global `VK` namespace and holds every tunable constant.
 *
 * All modules of Voxel Kingdoms are plain scripts that attach themselves to
 * `window.VK`. This keeps the game runnable straight from the file system
 * (double-click index.html) while still separating code into modules.
 */
window.VK = window.VK || {};

(function (VK) {
  'use strict';

  VK.VERSION = '1.0.0';

  VK.Config = {
    // ------------------------------------------------------------------ World
    CHUNK_SIZE: 16,          // blocks per chunk side (x/z)
    WORLD_HEIGHT: 128,       // blocks per chunk column (y)
    SEA_LEVEL: 40,           // water fills every air block at or below this y

    // --------------------------------------------------- Streaming/rendering
    RENDER_DISTANCE: 7,      // chunk radius that gets meshed around the camera
    LOD_DISTANCE: 4,         // chunks farther than this use half-resolution meshes
    MAX_DATA_CHUNKS: 1400,   // soft cap of chunk voxel data kept in memory
    GEN_BUDGET_MS: 5,        // per-frame time budget for terrain generation
    MESH_BUDGET_MS: 6,       // per-frame time budget for chunk meshing
    NPC_RENDER_DISTANCE: 110,// NPC models beyond this are hidden
    NPC_DETAIL_DISTANCE: 44, // NPC models beyond this use a single low-poly mesh

    // ------------------------------------------------------------------- Time
    DAY_LENGTH: 900,         // real seconds per full day/night cycle

    // ---------------------------------------------------------------- Physics
    GRAVITY: 28,

    // ---------------------------------------------------- Faction simulation
    CAPITAL_DISTANCE: 118,         // capitals start at about +/- this x
    CAPITAL_FLATTEN_RADIUS: 38,    // terrain around capitals is levelled
    MAX_NPCS_PER_FACTION: 90,
    MAX_SETTLEMENTS_PER_FACTION: 4,
    REVIVE_TIME: 200,              // seconds before a defeated kingdom rises again
    FIRST_CAMPAIGN_DELAY: 330,     // seconds of peace before the first invasion
    CAMPAIGN_COOLDOWN: 150,
    FOOD_UPKEEP_INTERVAL: 60,      // each NPC eats one food per interval
    WAR_ZONE: { minX: -300, maxX: 300, minZ: -190, maxZ: 190 },

    // ----------------------------------------------------------------- Saving
    SAVE_KEY: 'voxelKingdoms.save.v1',
    SETTINGS_KEY: 'voxelKingdoms.settings.v1',
    AUTOSAVE_INTERVAL: 240
  };

  /** Default user settings; persisted separately from the world save. */
  VK.DefaultSettings = {
    renderDistance: 7,
    mouseSensitivity: 1.0,
    fov: 75,
    volume: 0.6,
    viewBobbing: true,
    showMinimap: true,
    worldSpeed: 1,
    invertY: false
  };
})(window.VK);
