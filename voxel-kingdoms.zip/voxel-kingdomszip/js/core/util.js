/**
 * @file util.js
 * Small math, hashing, random number and event helpers shared by every module.
 */
(function (VK) {
  'use strict';

  const U = {};

  // ------------------------------------------------------------------ Math

  U.clamp = function (v, a, b) { return v < a ? a : (v > b ? b : v); };
  U.lerp = function (a, b, t) { return a + (b - a) * t; };
  U.smoothstep = function (e0, e1, x) {
    const t = U.clamp((x - e0) / (e1 - e0), 0, 1);
    return t * t * (3 - 2 * t);
  };
  U.dist2 = function (ax, az, bx, bz) {
    const dx = ax - bx, dz = az - bz;
    return Math.sqrt(dx * dx + dz * dz);
  };
  U.dist3 = function (a, b) {
    const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  };
  U.distSq3 = function (a, b) {
    const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
    return dx * dx + dy * dy + dz * dz;
  };
  /** Wraps an angle to the range [-PI, PI]. */
  U.wrapAngle = function (a) {
    while (a > Math.PI) a -= Math.PI * 2;
    while (a < -Math.PI) a += Math.PI * 2;
    return a;
  };
  /** Rotates `current` toward `target` by at most `maxStep` radians. */
  U.turnToward = function (current, target, maxStep) {
    const d = U.wrapAngle(target - current);
    if (Math.abs(d) <= maxStep) return target;
    return current + Math.sign(d) * maxStep;
  };

  // --------------------------------------------------------------- Hashing

  /**
   * Deterministic integer hash of a 3D lattice point, returns [0, 1).
   * Used for ore placement, tree placement, texture noise and so on.
   */
  U.hash3 = function (x, y, z, seed) {
    let h = (seed | 0) + Math.imul(x | 0, 0x27d4eb2d) + Math.imul(y | 0, 0x165667b1) + Math.imul(z | 0, 0x1b873593);
    h = Math.imul(h ^ (h >>> 15), 0x85ebca6b);
    h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  };
  U.hash2 = function (x, z, seed) { return U.hash3(x, 7919, z, seed); };

  /** Converts any string into a 32-bit integer seed. */
  U.hashString = function (str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  };

  // --------------------------------------------------------------- Random

  /** Mulberry32 PRNG factory: fast, seeded, good enough for games. */
  U.mulberry32 = function (a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };

  /** Seeded random generator object with convenience helpers. */
  class RNG {
    constructor(seed) { this.next = U.mulberry32(seed >>> 0); }
    float() { return this.next(); }
    range(a, b) { return a + (b - a) * this.next(); }
    int(a, b) { return a + Math.floor(this.next() * (b - a + 1)); }
    pick(arr) { return arr[Math.floor(this.next() * arr.length)]; }
    chance(p) { return this.next() < p; }
  }
  U.RNG = RNG;

  // Unseeded helpers for gameplay randomness (combat spread, idle wander...).
  U.rand = function (a, b) { return a + (b - a) * Math.random(); };
  U.randInt = function (a, b) { return a + Math.floor(Math.random() * (b - a + 1)); };
  U.pick = function (arr) { return arr[Math.floor(Math.random() * arr.length)]; };
  U.chance = function (p) { return Math.random() < p; };
  U.shuffle = function (arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }
    return arr;
  };

  // ------------------------------------------------------------------ Keys

  /**
   * Packs chunk coordinates (|c| < 16384) into one small integer. Values stay
   * below 2^30 so JavaScript engines keep them as fast "small integers",
   * which makes Map lookups cheaper and avoids garbage.
   */
  U.chunkKey = function (cx, cz) { return (cx + 16384) * 32768 + (cz + 16384); };
  U.chunkFromKey = function (key) {
    const cz = (key % 32768) - 16384;
    const cx = Math.floor(key / 32768) - 16384;
    return [cx, cz];
  };

  /** Packs a world block position into a single number (y in [0,127]). */
  U.posKey = function (x, y, z) {
    return ((x + 131072) * 262144 + (z + 131072)) * 128 + y;
  };
  U.unpackPosKey = function (k) {
    const y = k % 128;
    const rest = (k - y) / 128;
    const z = (rest % 262144) - 131072;
    const x = Math.floor(rest / 262144) - 131072;
    return { x: x, y: y, z: z };
  };

  // ------------------------------------------------------------ Formatting

  /** Converts a day fraction (0 = 06:00 sunrise) to a HH:MM clock string. */
  U.formatClock = function (t) {
    const hours = (t * 24 + 6) % 24;
    const h = Math.floor(hours);
    const m = Math.floor((hours - h) * 60);
    return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
  };
  U.escapeHtml = function (s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  U.capitalize = function (s) { return s.charAt(0).toUpperCase() + s.slice(1); };

  let uidCounter = 1;
  U.uid = function () { return uidCounter++; };
  U.setUidFloor = function (v) { if (v >= uidCounter) uidCounter = v + 1; };

  /**
   * Resolves on the next animation frame so loading screens can repaint.
   * Falls back to a timeout because background tabs do not run animation
   * frames, and loading should still progress there.
   */
  U.nextFrame = function () {
    return new Promise(function (resolve) {
      let done = false;
      const finish = function () { if (!done) { done = true; resolve(); } };
      requestAnimationFrame(finish);
      setTimeout(finish, 60);
    });
  };

  VK.Util = U;

  // ------------------------------------------------------------ Event bus

  /** Minimal publish/subscribe hub used for game-wide notifications. */
  class EventBus {
    constructor() { this.handlers = new Map(); }
    on(type, fn) {
      if (!this.handlers.has(type)) this.handlers.set(type, []);
      this.handlers.get(type).push(fn);
      return fn;
    }
    off(type, fn) {
      const list = this.handlers.get(type);
      if (!list) return;
      const i = list.indexOf(fn);
      if (i >= 0) list.splice(i, 1);
    }
    emit(type, data) {
      const list = this.handlers.get(type);
      if (!list) return;
      for (let i = 0; i < list.length; i++) list[i](data);
    }
  }
  VK.EventBus = EventBus;
})(window.VK);
