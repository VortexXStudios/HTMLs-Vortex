/**
 * @file hud.js
 * Heads-up display: crosshair, hotbar, hearts, hunger, stamina, air,
 * location/time panel, minimap + compass, kingdom summary, targeted NPC
 * info, event log, centre messages, toasts, damage flash, underwater tint,
 * break/bow progress and the F3 debug overlay.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;

  function el(tag, attrs, parent) {
    const e = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      if (k === 'text') e.textContent = attrs[k];
      else if (k === 'html') e.innerHTML = attrs[k];
      else e.setAttribute(k, attrs[k]);
    });
    if (parent) parent.appendChild(e);
    return e;
  }

  /** HTML for an inventory slot's content. */
  function slotContent(stack) {
    if (!stack) return '';
    let h = '<img src="' + VK.Icons.url(stack.id) + '" alt="">';
    if (stack.count > 1) h += '<span class="count">' + stack.count + '</span>';
    const def = VK.Items.get(stack.id);
    if (def && def.durability && stack.dur !== undefined && stack.dur < def.durability) {
      const f = stack.dur / def.durability;
      const col = 'hsl(' + Math.round(f * 120) + ',90%,50%)';
      h += '<span class="dur"><div style="width:' + Math.round(f * 100) + '%;background:' + col + '"></div></span>';
    }
    return h;
  }

  class HUD {
    constructor(game) {
      this.game = game;
      this.root = document.getElementById('hud');
      this.hidden = false;
      this.debug = false;
      this.last = {};
      this.logEls = [];
      this.toastT = 0;
      this.centerT = 0;
      this.build();
    }

    build() {
      const r = this.root;
      r.innerHTML = '';
      this.damageEl = el('div', { id: 'damage-flash' }, r);
      this.waterEl = el('div', { id: 'underwater', class: 'hidden' }, r);
      el('div', { id: 'crosshair' }, r);
      this.breakEl = el('div', { id: 'break-progress', class: 'hidden' }, r);
      this.breakFill = el('div', null, this.breakEl);
      this.bowEl = el('div', { id: 'bow-charge', class: 'hidden' }, r);
      this.bowFill = el('div', null, this.bowEl);
      this.hintEl = el('div', { id: 'action-hint' }, r);
      this.info = el('div', { id: 'info-panel' }, r);
      this.warEl = el('div', { id: 'war-banner' }, r);
      const mm = el('div', { id: 'minimap-wrap' }, r);
      this.minimap = el('canvas', { id: 'minimap', width: 180, height: 180 }, mm);
      this.compass = el('div', { id: 'compass' }, r);
      this.logEl = el('div', { id: 'event-log' }, r);
      this.center = el('div', { id: 'center-message' }, r);
      this.center.style.opacity = 0;
      this.heldName = el('div', { id: 'held-name' }, r);
      this.heldName.style.opacity = 0;
      this.debugEl = el('div', { id: 'debug-overlay', class: 'hidden' }, r);

      const wrap = el('div', { id: 'hotbar-wrap' }, r);
      const status = el('div', { id: 'status-row' }, wrap);
      this.hearts = el('div', { id: 'hearts-row', class: 'icon-row' }, status);
      this.food = el('div', { id: 'hunger-row', class: 'icon-row' }, status);
      this.airRow = el('div', { id: 'air-row', class: 'icon-row' }, wrap);
      this.airRow.style.alignSelf = 'flex-end';
      this.airRow.style.marginRight = '12px';
      const sb = el('div', { id: 'stamina-bar' }, wrap);
      this.staminaFill = el('div', { id: 'stamina-fill' }, sb);
      this.hotbar = el('div', { id: 'hotbar' }, wrap);
      this.hotSlots = [];
      for (let i = 0; i < 9; i++) this.hotSlots.push(el('div', { class: 'slot' }, this.hotbar));
      this.heartEls = []; this.foodEls = []; this.airEls = [];
      for (let i = 0; i < 10; i++) {
        this.heartEls.push(el('div', { class: 'ico' }, this.hearts));
        this.foodEls.push(el('div', { class: 'ico' }, this.food));
        this.airEls.push(el('div', { class: 'ico' }, this.airRow));
      }
    }

    setVisible(v) { this.root.classList.toggle('hidden', !v); }

    toggleHidden() {
      this.hidden = !this.hidden;
      this.root.style.visibility = this.hidden ? 'hidden' : 'visible';
    }

    // --------------------------------------------------------- Messages

    centerMessage(title, sub, dur) {
      this.center.innerHTML = U.escapeHtml(title) + (sub ? '<div class="sub">' + U.escapeHtml(sub) + '</div>' : '');
      this.center.style.opacity = 1;
      this.centerT = dur || 3;
    }

    toast(msg) {
      this.hintEl.textContent = msg;
      this.hintEl.style.opacity = 1;
      this.toastT = 3;
    }

    damageFlash() {
      // Restart the CSS animation (forcing a reflow between class changes).
      this.damageEl.classList.remove('flash');
      void this.damageEl.offsetWidth;
      this.damageEl.classList.add('flash');
    }

    flashItem(id) {
      this.heldName.textContent = VK.Items.name(id);
      this.heldName.style.opacity = 1;
      this.heldNameT = 1.5;
    }

    addLog(entry) {
      const e = el('div', { class: 'entry ' + (entry.cls || '') + (entry.kind === 'war' ? ' war' : '') });
      e.textContent = entry.text;
      this.logEl.insertBefore(e, this.logEl.firstChild);
      this.logEls.unshift({ el: e, t: 12 });
      while (this.logEls.length > 7) {
        const old = this.logEls.pop();
        old.el.remove();
      }
    }

    // ----------------------------------------------------------- Update

    update(dt) {
      const g = this.game;
      const p = g.player;
      if (!p) return;
      const hudIcons = VK.Icons.hud();

      // Hotbar
      const inv = p.inventory;
      if (this.last.invVersion !== inv.version || this.last.selected !== p.selected) {
        this.last.invVersion = inv.version;
        if (this.last.selected !== p.selected) {
          const s = inv.slots[p.selected];
          if (s) this.flashItem(s.id); else this.heldName.style.opacity = 0;
        }
        this.last.selected = p.selected;
        for (let i = 0; i < 9; i++) {
          this.hotSlots[i].innerHTML = slotContent(inv.slots[i]);
          this.hotSlots[i].classList.toggle('selected', i === p.selected);
        }
      }
      if (this.heldNameT > 0) { this.heldNameT -= dt; if (this.heldNameT <= 0) this.heldName.style.opacity = 0; }

      // Hearts / hunger
      const hp = Math.ceil(p.health), food = Math.ceil(p.hunger);
      if (this.last.hp !== hp) {
        this.last.hp = hp;
        for (let i = 0; i < 10; i++) {
          const v = hp - i * 2;
          this.heartEls[i].style.backgroundImage = 'url(' + (v >= 2 ? hudIcons.heartFull : (v === 1 ? hudIcons.heartHalf : hudIcons.heartEmpty)) + ')';
        }
        this.hearts.style.animation = hp <= 4 ? 'none' : '';
      }
      if (this.last.food !== food) {
        this.last.food = food;
        for (let i = 0; i < 10; i++) {
          const v = food - i * 2;
          this.foodEls[i].style.backgroundImage = 'url(' + (v >= 2 ? hudIcons.foodFull : (v === 1 ? hudIcons.foodHalf : hudIcons.foodEmpty)) + ')';
        }
      }
      const air = p.eyeInWater || p.air < 10 ? Math.ceil(p.air) : -1;
      if (this.last.air !== air) {
        this.last.air = air;
        this.airRow.style.visibility = air < 0 ? 'hidden' : 'visible';
        for (let i = 0; i < 10; i++) this.airEls[i].style.backgroundImage = i < air ? 'url(' + hudIcons.bubble + ')' : 'none';
      }
      const st = Math.round(p.stamina);
      if (this.last.st !== st) {
        this.last.st = st;
        this.staminaFill.style.width = st + '%';
        this.staminaFill.classList.toggle('low', st < 25);
      }
      const survival = !p.spectator;
      this.hearts.style.visibility = this.food.style.visibility = survival ? 'visible' : 'hidden';

      this.waterEl.classList.toggle('hidden', !p.eyeInWater);

      // Break / bow progress
      if (p.breaking && p.breaking.progress > 0.02) {
        this.breakEl.classList.remove('hidden');
        this.breakFill.style.width = Math.round(Math.min(1, p.breaking.progress) * 100) + '%';
      } else this.breakEl.classList.add('hidden');
      if (p.bowCharge >= 0) {
        this.bowEl.classList.remove('hidden');
        this.bowFill.style.width = Math.round(Math.min(1, p.bowCharge) * 100) + '%';
      } else if (p.eatT >= 0) {
        this.bowEl.classList.remove('hidden');
        this.bowFill.style.width = Math.round(Math.min(1, p.eatT / 1.6) * 100) + '%';
      } else this.bowEl.classList.add('hidden');

      // Timers
      if (this.centerT > 0) { this.centerT -= dt; if (this.centerT <= 0) this.center.style.opacity = 0; }
      if (this.toastT > 0) { this.toastT -= dt; if (this.toastT <= 0) this.hintEl.style.opacity = 0; }
      for (let i = 0; i < this.logEls.length; i++) {
        const e = this.logEls[i];
        e.t -= dt;
        if (e.t <= 0) e.el.classList.add('fade');
      }

      // Slow updates
      this.slowT = (this.slowT || 0) - dt;
      if (this.slowT <= 0) {
        this.slowT = 0.25;
        this.updateInfo();
        this.updateWarBanner();
        if (g.settings.showMinimap) {
          this.minimap.parentElement.classList.remove('hidden');
          g.ui.map.drawMinimap(this.minimap);
        } else this.minimap.parentElement.classList.add('hidden');
        if (this.debug) this.updateDebug();
      }
      this.updateTargetHint();
      this.updateCompass();
    }

    updateInfo() {
      const g = this.game;
      const p = g.player;
      const x = Math.floor(p.pos.x), y = Math.floor(p.pos.y), z = Math.floor(p.pos.z);
      const biome = VK.TerrainGenerator.BIOME_NAMES[g.world.terrain.sample(x, z).biome];
      const s = g.kingdoms.settlementAt(x, z);
      let terr = '<span class="muted">Wilderness</span>';
      if (s) terr = '<span class="territory-' + s.faction.id + '">' + U.escapeHtml(s.name) + ' (' + s.faction.shortName + ')</span>';
      const t = g.time;
      const night = g.isNight();
      let html = 'Day ' + t.day + ' &middot; ' + U.formatClock(t.t) + (night ? ' &#9790;' : ' &#9788;') + '<br>' +
        terr + '<br><span class="muted">' + biome + ' &middot; ' + x + ', ' + y + ', ' + z + '</span>';
      if (p.faction) {
        const f = g.kingdoms.factions[p.faction];
        html += '<br>Sworn to <span class="territory-' + f.id + '">' + f.shortName + '</span>';
      }
      if (p.followers && p.followers.size) html += '<br>Followers: ' + p.followers.size;
      if (p.spectator) html += '<br><span style="color:#ffd84a">Spectator (F4)</span>';
      if (g.settings.worldSpeed > 1) html += '<br><span style="color:#ffd84a">World speed x' + g.settings.worldSpeed + '</span>';
      if (html !== this.last.info) { this.info.innerHTML = html; this.last.info = html; }
    }

    updateWarBanner() {
      const g = this.game;
      const parts = g.kingdoms.list.map(function (f) {
        const sol = f.npcs.filter(function (n) { return n.isSoldier; }).length;
        let status;
        if (f.defeated) status = 'In exile (' + Math.ceil(f.reviveT) + 's)';
        else status = f.settlements.length + ' towns &middot; ' + f.npcs.length + ' people &middot; ' + sol + ' soldiers';
        let camp = '';
        if (f.campaign) camp = '<br><span style="color:#ffd0a0">' + U.capitalize(f.campaign.stage) + ': ' + U.escapeHtml(f.campaign.target.name) + '</span>';
        return '<div class="fside ' + f.id + '">' + f.shortName + '<br><span style="font-size:17px">' + status + '</span>' + camp + '</div>';
      });
      const html = parts[0] + '<div class="vs">vs</div>' + parts[1];
      if (html !== this.last.war) { this.warEl.innerHTML = html; this.last.war = html; }
    }

    updateTargetHint() {
      const p = this.game.player;
      if (this.toastT > 0) return;
      const t = p.target.entity || p.target.talk;
      let text = '';
      if (t && !t.dead && !this.game.ui.isOpen()) {
        const hostile = VK.Diplomacy.isHostile(p, t);
        text = t.displayName + ' • ' + t.faction.shortName + ' • ' + Math.ceil(t.hp) + '/' + t.maxHp + ' HP' + (hostile ? ' • HOSTILE' : ' • right-click to talk');
      }
      if (text !== this.last.hint) {
        this.last.hint = text;
        this.hintEl.textContent = text;
        this.hintEl.style.opacity = text ? 1 : 0;
        this.hintEl.style.color = t && VK.Diplomacy.isHostile(p, t) ? '#ff9a9a' : '#ffffff';
      }
    }

    updateCompass() {
      const yaw = this.game.player.yaw;
      // Heading in degrees clockwise from north (-z).
      let deg = (-yaw * 180 / Math.PI) % 360;
      if (deg < 0) deg += 360;
      const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
      const txt = dirs[Math.round(deg / 45) % 8] + ' ' + Math.round(deg) + '°';
      if (txt !== this.last.compass) { this.compass.textContent = txt; this.last.compass = txt; }
    }

    updateDebug() {
      const g = this.game;
      const w = g.world;
      const p = g.player;
      const k = g.kingdoms;
      const lines = [
        'Voxel Kingdoms ' + VK.VERSION + '  ' + Math.round(g.fps) + ' fps',
        'Chunks: ' + w.chunks.size + ' loaded, gen queue ' + w.genQueue.length + ', mesh queue ' + w.meshQueue.length,
        'Last mesh: ' + w.stats.meshMs.toFixed(1) + ' ms, meshed ' + w.stats.meshed,
        'Draw calls: ' + g.renderer.info.render.calls + ', triangles: ' + g.renderer.info.render.triangles,
        'NPCs: ' + g.entities.npcs.length + ', projectiles: ' + g.entities.projectiles.list.length + ', drops: ' + g.entities.drops.list.length,
        'Paths: queue ' + g.paths.stats.queued + ', solved ' + g.paths.stats.solved + ', last ' + g.paths.stats.lastMs.toFixed(1) + ' ms',
        'Pos: ' + p.pos.x.toFixed(1) + ' ' + p.pos.y.toFixed(1) + ' ' + p.pos.z.toFixed(1) + '  vel ' + p.vel.length().toFixed(1),
        'Rep: Ironhold ' + Math.round(p.rep.ironhold) + '  Redmoor ' + Math.round(p.rep.redmoor)
      ];
      k.list.forEach(function (f) {
        const r = f.resources;
        lines.push(f.shortName + ': ' + f.priority + ' | wood ' + Math.floor(r.wood) + ' stone ' + Math.floor(r.stone) + ' food ' + Math.floor(r.food) + ' iron ' + Math.floor(r.iron) + ' gold ' + Math.floor(r.gold) + ' | ready ' + f.leader.readiness.toFixed(2));
      });
      this.debugEl.textContent = lines.join('\n');
    }

    toggleDebug() {
      this.debug = !this.debug;
      this.debugEl.classList.toggle('hidden', !this.debug);
    }
  }

  HUD.slotContent = slotContent;
  HUD.el = el;
  VK.HUD = HUD;
})(window.VK);
