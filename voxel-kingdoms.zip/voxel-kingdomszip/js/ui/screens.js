/**
 * @file screens.js
 * In-game screens and the UI controller:
 *   - inventory with 2x2 crafting, crafting table (3x3), furnace, chests
 *     (Minecraft-style slot clicks: pick/place/swap, split, shift-move)
 *   - recipe book with search and categories (click to craft)
 *   - NPC dialogue (join a kingdom, news, command soldiers)
 *   - trading with villagers (prices depend on reputation)
 *   - kingdom overview (map, faction statistics, reputation, chronicle)
 */
(function (VK) {
  'use strict';

  const U = VK.Util;
  const Items = VK.Items;
  const Recipes = VK.Recipes;
  const el = VK.HUD.el;
  const slotContent = VK.HUD.slotContent;

  // --------------------------------------------------------- Trade data

  const BUY = [
    { item: 'bread', count: 3, price: 2, res: { food: 4 } },
    { item: 'cooked_meat', count: 2, price: 3, res: { food: 5 } },
    { item: 'cheese', count: 1, price: 2, res: { food: 3 } },
    { item: 'apple', count: 4, price: 2, res: { food: 3 } },
    { item: 'torch', count: 8, price: 1, res: { wood: 1 } },
    { item: 'arrow', count: 12, price: 3, res: { wood: 2 } },
    { item: 'bow', count: 1, price: 6, res: { wood: 3 } },
    { item: 'shield', count: 1, price: 8, res: { wood: 3, iron: 1 } },
    { item: 'spear', count: 1, price: 7, res: { wood: 2, iron: 1 } },
    { item: 'iron_sword', count: 1, price: 10, res: { iron: 3 } },
    { item: 'iron_pickaxe', count: 1, price: 11, res: { iron: 3 } },
    { item: 'iron_axe', count: 1, price: 10, res: { iron: 3 } },
    { item: 'iron_ingot', count: 2, price: 6, res: { iron: 2 } },
    { item: 'glass', count: 8, price: 3, res: { stone: 2 } },
    { item: 'wool', count: 4, price: 2, res: { food: 2 } },
    { item: 'wheat_seeds', count: 8, price: 1, res: {} },
    { item: 'sapling', count: 4, price: 1, res: {} }
  ];
  const SELL = [
    { item: '#log', count: 16, price: 3, res: { wood: 24 } },
    { item: 'cobblestone', count: 32, price: 3, res: { stone: 32 } },
    { item: 'wheat', count: 12, price: 3, res: { food: 15 } },
    { item: 'bread', count: 4, price: 2, res: { food: 6 } },
    { item: 'berries', count: 12, price: 2, res: { food: 8 } },
    { item: 'coal', count: 8, price: 2, res: { stone: 4 } },
    { item: 'iron_ore', count: 4, price: 4, res: { iron: 3 } },
    { item: 'iron_ingot', count: 2, price: 4, res: { iron: 2 } },
    { item: 'gold_ingot', count: 1, price: 6, res: { gold: 1 } },
    { item: 'diamond', count: 1, price: 15, res: { gold: 3 } },
    { item: 'arrow', count: 16, price: 2, res: { wood: 2 } }
  ];

  const FUEL_ORDER = ['coal', 'oak_log', 'birch_log', 'spruce_log', 'planks', 'spruce_planks', 'stick', 'sapling'];

  class UI {
    constructor(game) {
      this.game = game;
      this.hud = new VK.HUD(game);
      this.map = new VK.MapRenderer(game);
      this.root = document.getElementById('screens');
      this.screen = null;
      this.cursor = null;
      this.refs = [];
      this.grid = [];
      this.gridSize = 2;
      this.cursorEl = el('div', { id: 'cursor-stack', class: 'hidden' }, document.body);
      this.tooltip = el('div', { id: 'tooltip', class: 'hidden' }, document.body);
      this.menus = new VK.Menus(game, this);
      this.mouseX = 0; this.mouseY = 0;
      document.addEventListener('mousemove', (e) => {
        this.mouseX = e.clientX; this.mouseY = e.clientY;
        this.cursorEl.style.left = (e.clientX - 20) + 'px';
        this.cursorEl.style.top = (e.clientY - 20) + 'px';
        this.tooltip.style.left = (e.clientX + 16) + 'px';
        this.tooltip.style.top = (e.clientY - 8) + 'px';
      });
    }

    isOpen() { return !!this.screen || this.menus.blocking(); }

    // -------------------------------------------------------- Lifecycle

    open(screen) {
      if (this.screen) this.close(true);
      this.screen = screen;
      this.root.appendChild(screen.el);
      this.game.input.exitLock();
      this.game.audio.play('click');
    }

    /** Closes the current screen; items in hand/grid go back to the inventory. */
    close(keepUnlocked) {
      const s = this.screen;
      if (!s) return;
      if (s.onClose) s.onClose();
      s.el.remove();
      this.screen = null;
      this.returnItems();
      this.tooltip.classList.add('hidden');
      if (!keepUnlocked && this.game.state === 'playing') this.game.input.requestLock();
    }

    returnItems() {
      const p = this.game.player;
      const give = (st) => {
        if (!st) return;
        const left = p.inventory.add(st.id, st.count, st.dur);
        if (left > 0) this.game.entities.drops.spawn({ id: st.id, count: left, dur: st.dur }, p.pos.x, p.pos.y + 1.2, p.pos.z);
      };
      give(this.cursor);
      this.cursor = null;
      this.grid.forEach(give);
      this.grid = [];
      this.renderCursor();
    }

    /** Per-frame UI logic: keyboard shortcuts and screen refreshes. */
    update(dt) {
      const g = this.game;
      const input = g.input;
      if (g.state !== 'playing') return;
      this.hud.update(dt);
      if (this.screen) {
        if (input.wasPressed('Escape') || (input.wasPressed('KeyE') && this.screen.closeOnE)) { this.close(); return; }
        if (this.screen.kind === 'kingdoms' && (input.wasPressed('KeyK') || input.wasPressed('Tab'))) { this.close(); return; }
        if (this.screen.update) this.screen.update(dt);
        if (this.screen && this.screen.inventoryBound && this.lastInvVersion !== g.player.inventory.version) this.renderSlots();
        return;
      }
      if (this.menus.blocking() || g.player.dead) return;
      if (input.wasPressed('KeyE')) this.openInventory();
      else if (input.wasPressed('KeyK') || input.wasPressed('Tab')) this.openKingdoms();
      else if (input.wasPressed('F1')) this.hud.toggleHidden();
      else if (input.wasPressed('F3')) this.hud.toggleDebug();
      else if (input.wasPressed('KeyH')) this.menus.showHelp(true);
    }

    // ---------------------------------------------------- Slot handling

    invRef(inv, i, area) {
      return { get: function () { return inv.slots[i]; }, set: function (s) { inv.set(i, s); }, area: area, inv: inv, index: i };
    }

    gridRef(i) {
      const self = this;
      return { get: function () { return self.grid[i] || null; }, set: function (s) { self.grid[i] = s && s.count > 0 ? s : null; self.updateOutput(); }, area: 'grid', index: i };
    }

    slotEl(parent, ref, extraClass) {
      const idx = this.refs.length;
      this.refs.push(ref);
      const e = el('div', { class: 'slot' + (extraClass ? ' ' + extraClass : ''), 'data-ref': idx }, parent);
      ref.el = e;
      return e;
    }

    renderSlots() {
      this.refs.forEach(function (r) { r.el.innerHTML = slotContent(r.get()); });
      this.lastInvVersion = this.game.player.inventory.version;
      if (this.screen && this.screen.onSlotsRendered) this.screen.onSlotsRendered();
    }

    renderCursor() {
      const c = this.cursor;
      this.cursorEl.classList.toggle('hidden', !c);
      this.cursorEl.innerHTML = c ? slotContent(c) : '';
    }

    bindSlots(root) {
      root.addEventListener('mousedown', (e) => {
        const s = e.target.closest('.slot');
        if (s && s.dataset.ref !== undefined) {
          e.preventDefault();
          this.clickSlot(this.refs[Number(s.dataset.ref)], e.button, e.shiftKey);
          return;
        }
        // Clicking outside any panel throws the held stack.
        if (e.target === root && this.cursor) {
          const p = this.game.player;
          const d = p.lookDir();
          const drop = this.game.entities.drops.spawn(this.cursor, p.pos.x + d.x * 0.5, p.pos.y + 1.3, p.pos.z + d.z * 0.5, d.x * 4, 2, d.z * 4);
          if (drop) drop.pickupDelay = 1.5;
          this.cursor = null;
          this.renderCursor();
        }
      });
      root.addEventListener('contextmenu', function (e) { e.preventDefault(); });
      root.addEventListener('mouseover', (e) => {
        const s = e.target.closest('.slot');
        if (!s || s.dataset.ref === undefined) { this.tooltip.classList.add('hidden'); return; }
        const st = this.refs[Number(s.dataset.ref)].get();
        if (!st) { this.tooltip.classList.add('hidden'); return; }
        const def = Items.get(st.id);
        let html = U.escapeHtml(Items.name(st.id));
        if (def && def.durability && st.dur !== undefined) html += '<div class="sub">Durability ' + st.dur + ' / ' + def.durability + '</div>';
        if (def && def.food) html += '<div class="sub">Restores ' + def.food.hunger + ' hunger</div>';
        if (def && def.weapon) html += '<div class="sub">' + def.weapon.damage + ' attack damage</div>';
        this.tooltip.innerHTML = html;
        this.tooltip.classList.remove('hidden');
      });
      root.addEventListener('mouseleave', () => this.tooltip.classList.add('hidden'));
    }

    clickSlot(ref, button, shift) {
      if (ref.output) { this.clickOutput(shift); return; }
      const slot = ref.get();
      const cur = this.cursor;
      if (shift && button === 0) { if (slot) this.quickMove(ref); this.afterClick(); return; }
      const max = function (id) { return Items.maxStack(id); };
      if (button === 0) {
        if (!cur) { if (slot) { this.cursor = slot; ref.set(null); } }
        else if (!slot) { ref.set(cur); this.cursor = null; }
        else if (slot.id === cur.id && slot.dur === undefined && cur.dur === undefined && slot.count < max(slot.id)) {
          const take = Math.min(max(slot.id) - slot.count, cur.count);
          slot.count += take; cur.count -= take;
          ref.set(slot);
          if (cur.count <= 0) this.cursor = null;
        } else { ref.set(cur); this.cursor = slot; }
      } else if (button === 2) {
        if (!cur) {
          if (slot) {
            const half = Math.ceil(slot.count / 2);
            this.cursor = { id: slot.id, count: half, dur: slot.dur };
            slot.count -= half;
            ref.set(slot.count > 0 ? slot : null);
          }
        } else if (!slot) {
          ref.set({ id: cur.id, count: 1, dur: cur.dur });
          cur.count--;
          if (cur.count <= 0) this.cursor = null;
        } else if (slot.id === cur.id && slot.dur === undefined && slot.count < max(slot.id)) {
          slot.count++; cur.count--;
          ref.set(slot);
          if (cur.count <= 0) this.cursor = null;
        } else { ref.set(cur); this.cursor = slot; }
      }
      this.afterClick();
    }

    afterClick() {
      if (this.cursor && this.cursor.dur === undefined) delete this.cursor.dur;
      this.renderSlots();
      this.renderCursor();
      this.game.audio.play('click');
    }

    /** Shift-click: move a stack to the "other" section. */
    quickMove(ref) {
      const p = this.game.player;
      const st = ref.get();
      let left = st.count;
      const addTo = (inv, from, to) => {
        const max = Items.maxStack(st.id);
        for (let i = from; i < to && left > 0; i++) {
          const s = inv.slots[i];
          if (s && s.id === st.id && s.dur === undefined && st.dur === undefined && s.count < max) {
            const take = Math.min(max - s.count, left);
            s.count += take; left -= take;
          }
        }
        for (let i = from; i < to && left > 0; i++) {
          if (!inv.slots[i]) {
            const take = Math.min(max, left);
            inv.slots[i] = { id: st.id, count: take };
            if (st.dur !== undefined) inv.slots[i].dur = st.dur;
            left -= take;
          }
        }
        inv.changed();
      };
      if (ref.area === 'grid' || ref.area === 'chest') addTo(p.inventory, 0, 36);
      else if (this.chestInv) addTo(this.chestInv, 0, 27);
      else if (ref.area === 'hotbar') addTo(p.inventory, 9, 36);
      else addTo(p.inventory, 0, 9);
      if (left <= 0) ref.set(null);
      else { st.count = left; ref.set(st); }
    }

    updateOutput() {
      const size = this.gridSize;
      const ids = [];
      for (let i = 0; i < size * size; i++) ids.push(this.grid[i] ? this.grid[i].id : null);
      this.recipe = Recipes.matchGrid(ids, size);
      if (this.recipe && this.recipe.station === 'table' && size < 3) this.recipe = null;
      if (this.outputRef) this.outputRef.el.innerHTML = this.recipe ? slotContent(Items.stack(this.recipe.out, this.recipe.count)) : '';
    }

    clickOutput(shift) {
      if (!this.recipe) return;
      const p = this.game.player;
      const craftOnce = () => {
        const r = this.recipe;
        if (!r) return false;
        const out = Items.stack(r.out, r.count);
        if (shift) {
          if (!p.inventory.canFit(out.id, out.count)) return false;
          p.inventory.add(out.id, out.count, out.dur);
        } else {
          if (!this.cursor) this.cursor = out;
          else if (this.cursor.id === out.id && out.dur === undefined && this.cursor.count + out.count <= Items.maxStack(out.id)) this.cursor.count += out.count;
          else return false;
        }
        for (let i = 0; i < this.grid.length; i++) {
          const s = this.grid[i];
          if (!s) continue;
          s.count--;
          if (s.count <= 0) this.grid[i] = null;
        }
        this.updateOutput();
        return true;
      };
      if (shift) { let n = 0; while (n < 64 && craftOnce()) n++; }
      else craftOnce();
      this.afterClick();
    }

    // ---------------------------------------------------- Recipe book

    buildRecipeBook(parent, mode) {
      const book = el('div', { class: 'panel recipe-book' }, parent);
      el('h2', { text: mode === 'furnace' ? 'Smelting' : 'Recipe Book' }, book);
      const search = el('input', { type: 'text', placeholder: 'Search...' }, book);
      const tabs = el('div', { class: 'recipe-tabs' }, book);
      const list = el('div', { class: 'recipe-list' }, book);
      const cats = mode === 'furnace' ? ['smelting'] : ['all', 'basic', 'tools', 'combat', 'food', 'building'];
      let cat = cats[0];
      if (mode === 'furnace') {
        this.fuelInfo = el('div', { class: 'menu-note' }, book);
        this.fuelInfo.style.color = '#333';
        this.fuelInfo.style.textShadow = 'none';
      }
      cats.forEach((c) => {
        if (cats.length === 1) return;
        const b = el('button', { text: U.capitalize(c) }, tabs);
        b.addEventListener('click', () => { cat = c; render(); });
      });
      const render = () => {
        const p = this.game.player;
        const q = search.value.toLowerCase();
        list.innerHTML = '';
        Recipes.list.forEach((r, idx) => {
          if (mode === 'furnace' ? !r.smelt : r.smelt) return;
          if (cat !== 'all' && cat !== 'smelting' && r.category !== cat) return;
          const name = Items.name(r.out);
          if (q && name.toLowerCase().indexOf(q) < 0) return;
          const stationOk = mode === 'furnace' || !r.station || (r.station === 'table' && mode === 'table');
          const can = Recipes.canCraft(p.inventory, r);
          const row = el('div', { class: 'recipe-row ' + (!stationOk ? 'station' : (can ? 'craftable' : 'uncraftable')), 'data-idx': idx }, list);
          row.innerHTML = '<img src="' + VK.Icons.url(r.out) + '"><span class="rname">' + U.escapeHtml(name) + (r.count > 1 ? ' x' + r.count : '') +
            (!stationOk ? '<br><small>Needs a crafting table</small>' : '') + '</span><span class="ingr">' +
            Recipes.requirements(r).map(function (q2) { return '<img title="' + U.escapeHtml(Recipes.ingredientName(q2.ing)) + ' x' + q2.count + '" src="' + VK.Icons.url(Recipes.ingredientIcon(q2.ing)) + '">' + (q2.count > 1 ? '<small>' + q2.count + '</small>' : ''); }).join('') + '</span>';
        });
        if (this.fuelInfo) this.fuelInfo.textContent = 'Fuel stored: ' + p.fuelPoints.toFixed(1) + ' smelts. Coal, logs, planks and sticks are used as fuel.';
      };
      list.addEventListener('mousedown', (e) => {
        const row = e.target.closest('.recipe-row');
        if (!row) return;
        e.preventDefault();
        const r = Recipes.list[Number(row.dataset.idx)];
        const times = e.shiftKey ? 16 : 1;
        for (let i = 0; i < times; i++) if (!this.craftFromBook(r, mode)) break;
        this.renderSlots();
        render();
      });
      search.addEventListener('input', render);
      this.refreshBook = render;
      render();
      return book;
    }

    /** Crafts directly from inventory materials. */
    craftFromBook(r, mode) {
      const g = this.game;
      const p = g.player;
      if (r.station === 'table' && mode !== 'table') return false;
      if (r.smelt && mode !== 'furnace') return false;
      if (!Recipes.canCraft(p.inventory, r)) return false;
      if (r.smelt && !this.useFuel()) { g.ui.hud.toast('No fuel! Bring coal, logs, planks or sticks.'); return false; }
      Recipes.consume(p.inventory, r);
      const out = Items.stack(r.out, r.count);
      const left = p.inventory.add(out.id, out.count, out.dur);
      if (left > 0) g.entities.drops.spawn({ id: out.id, count: left, dur: out.dur }, p.pos.x, p.pos.y + 1.2, p.pos.z);
      g.audio.play(r.smelt ? 'dig' : 'click');
      return true;
    }

    useFuel() {
      const p = this.game.player;
      if (p.fuelPoints >= 1) { p.fuelPoints -= 1; return true; }
      for (let i = 0; i < FUEL_ORDER.length; i++) {
        const id = FUEL_ORDER[i];
        if (p.inventory.has(id)) {
          p.inventory.remove(id, 1);
          p.fuelPoints += Items.get(id).fuel;
          if (p.fuelPoints >= 1) { p.fuelPoints -= 1; return true; }
        }
      }
      return false;
    }

    // ------------------------------------------------ Inventory screens

    buildInventorySection(panel) {
      const p = this.game.player;
      el('h3', { text: 'Inventory' }, panel);
      const main = el('div', { class: 'grid grid-9' }, panel);
      for (let i = 9; i < 36; i++) this.slotEl(main, this.invRef(p.inventory, i, 'main'));
      const hot = el('div', { class: 'grid grid-9 hotbar-grid' }, panel);
      for (let i = 0; i < 9; i++) this.slotEl(hot, this.invRef(p.inventory, i, 'hotbar'));
    }

    makeScreen(kind) {
      this.refs = [];
      this.chestInv = null;
      this.outputRef = null;
      this.recipe = null;
      const backdrop = el('div', { class: 'screen-backdrop' });
      const layout = el('div', { class: 'inv-layout' }, backdrop);
      this.bindSlots(backdrop);
      return { el: backdrop, layout: layout, kind: kind, closeOnE: true, inventoryBound: true };
    }

    openInventory() { this.openCrafting(2); }

    /** Inventory (2x2 grid) or crafting table (3x3 grid). */
    openCrafting(size) {
      const s = this.makeScreen(size === 3 ? 'table' : 'inventory');
      this.gridSize = size;
      this.grid = new Array(size * size).fill(null);
      const panel = el('div', { class: 'panel inv-main' }, s.layout);
      el('h2', { text: size === 3 ? 'Crafting Table' : 'Inventory' }, panel);
      const area = el('div', { class: 'craft-area' }, panel);
      const grid = el('div', { class: 'grid grid-' + size }, area);
      for (let i = 0; i < size * size; i++) this.slotEl(grid, this.gridRef(i));
      el('div', { class: 'craft-arrow', text: '➜' }, area);
      this.outputRef = { output: true, get: () => null, set: function () {} };
      this.slotEl(area, this.outputRef, 'output');
      this.buildInventorySection(panel);
      this.buildRecipeBook(s.layout, size === 3 ? 'table' : 'inventory');
      s.onSlotsRendered = () => { this.updateOutput(); if (this.refreshBook) this.refreshBook(); };
      this.open(s);
      this.renderSlots();
    }

    openFurnace() {
      const s = this.makeScreen('furnace');
      this.grid = [];
      const panel = el('div', { class: 'panel inv-main' }, s.layout);
      el('h2', { text: 'Furnace' }, panel);
      el('div', { class: 'menu-note', text: 'Click a recipe to smelt it (shift-click for up to 16).', style: 'color:#333;text-shadow:none;text-align:left' }, panel);
      this.buildInventorySection(panel);
      this.buildRecipeBook(s.layout, 'furnace');
      s.onSlotsRendered = () => { if (this.refreshBook) this.refreshBook(); };
      this.open(s);
      this.renderSlots();
    }

    openChest(x, y, z) {
      const world = this.game.world;
      const k = U.posKey(x, y, z);
      let inv = world.chests.get(k);
      if (!inv) { inv = new VK.Inventory(27); world.chests.set(k, inv); }
      const s = this.makeScreen('chest');
      this.grid = [];
      const panel = el('div', { class: 'panel inv-main' }, s.layout);
      el('h2', { text: 'Chest' }, panel);
      const grid = el('div', { class: 'grid grid-9' }, panel);
      for (let i = 0; i < 27; i++) this.slotEl(grid, this.invRef(inv, i, 'chest'));
      this.buildInventorySection(panel);
      this.open(s);
      this.chestInv = inv;
      this.renderSlots();
    }

    // ------------------------------------------------- NPC dialogue

    openNPC(npc) {
      const g = this.game;
      const p = g.player;
      if (npc.isSiege) { this.hud.toast('A ' + npc.faction.shortName + ' trebuchet. It does not talk.'); return; }
      const hostile = VK.Diplomacy.isHostile(p, npc);
      npc.talkingTo = p;
      const f = npc.faction;
      const screen = { el: el('div', { class: 'screen-backdrop' }), kind: 'dialog', closeOnE: true, onClose: function () { npc.talkingTo = null; } };
      const panel = el('div', { class: 'dialog-panel' }, screen.el);
      const render = (text, options) => {
        panel.innerHTML = '';
        el('div', { class: 'speaker ' + f.id, text: npc.displayName }, panel);
        el('div', { class: 'role', text: npc.title + ' of the ' + f.name + ' • Your standing: ' + VK.Diplomacy.standing(f.id) + ' (' + Math.round(p.rep[f.id]) + ')' }, panel);
        el('div', { class: 'text', text: text }, panel);
        const opts = el('div', { class: 'dialog-options' }, panel);
        options.forEach((o) => {
          const b = el('button', { text: o.label }, opts);
          if (o.disabled) b.disabled = true;
          b.addEventListener('click', o.fn);
        });
      };
      const leave = { label: 'Farewell.', fn: () => this.close() };
      const main = () => {
        if (hostile) {
          render(npc.isVillager ? 'Stay away from me! Guards! Guards!' : 'You dare approach me, enemy of ' + f.shortName + '? Draw your blade!', [leave]);
          return;
        }
        const standing = VK.Diplomacy.standing(f.id);
        let greet;
        if (p.faction === f.id) greet = 'Hail, sworn friend! ' + f.motto;
        else if (standing === 'Honored' || standing === 'Friendly') greet = 'Good to see you again, friend of ' + f.shortName + '.';
        else if (standing === 'Unfriendly') greet = 'What do you want, stranger? Make it quick.';
        else greet = 'Greetings, traveller. You stand in the lands of the ' + f.name + '.';
        const options = [];
        if (npc.isVillager) options.push({ label: 'Let us trade.', fn: () => this.openTrade(npc) });
        options.push({ label: npc.isVillager ? 'How fares the kingdom?' : 'Any news from the front?', fn: news });
        if (p.faction !== f.id) {
          const canJoin = p.rep[f.id] >= 0 || p.faction;
          options.push({ label: p.faction ? 'I wish to abandon ' + g.kingdoms.factions[p.faction].shortName + ' and serve ' + f.shortName + '.' : 'I wish to swear fealty to ' + f.ruler + '.', disabled: !canJoin, fn: join });
        } else if (npc.isSoldier) {
          options.push({ label: p.followers && p.followers.size ? 'Return to your posts.' : 'Soldiers, follow me!', fn: () => { this.close(); p.toggleFollowers(); } });
          options.push({ label: 'I renounce my oath.', fn: () => { VK.Diplomacy.leaveFaction(); main(); } });
        }
        options.push(leave);
        render(greet, options);
      };
      const news = () => {
        const enemy = g.kingdoms.enemyOf(f);
        let t = 'Our ruler, ' + f.ruler + ', holds ' + f.settlements.length + ' settlement' + (f.settlements.length === 1 ? '' : 's') + ' and ' + f.soldiers().length + ' soldiers. ';
        t += 'The crown\'s priority is ' + f.priority.toLowerCase() + '. ';
        if (f.campaign) t += 'Our army is ' + (f.campaign.stage === 'muster' ? 'mustering to attack ' : 'fighting at ') + f.campaign.target.name + '. ';
        if (enemy.campaign) t += 'Beware: the forces of ' + enemy.shortName + ' march on ' + enemy.campaign.target.name + '! ';
        if (enemy.defeated) t += enemy.shortName + ' lies broken; its people are in exile. ';
        else t += 'Our spies count ' + enemy.soldiers().length + ' ' + enemy.shortName + ' soldiers. ';
        const r = f.resources;
        t += 'Stores: ' + Math.floor(r.wood) + ' wood, ' + Math.floor(r.stone) + ' stone, ' + Math.floor(r.food) + ' food, ' + Math.floor(r.iron) + ' iron.';
        render(t, [{ label: 'Tell me something else.', fn: main }, leave]);
      };
      const join = () => {
        render('Kneel, then, and swear to serve ' + f.ruler + ' of the ' + f.name + '. Our enemies will become yours, and ' +
          g.kingdoms.enemyOf(f).shortName + ' will hunt you on sight. You will be paid a bounty for every enemy soldier you slay.', [
          { label: 'I swear it.', fn: () => { VK.Diplomacy.joinFaction(f.id); main(); } },
          { label: 'Not yet.', fn: main }
        ]);
      };
      main();
      this.open(screen);
    }

    // -------------------------------------------------------- Trading

    openTrade(npc) {
      const g = this.game;
      const p = g.player;
      const f = npc.faction;
      const talking = npc.talkingTo;
      if (this.screen) { this.screen.onClose = null; this.close(true); }
      npc.talkingTo = talking || p;
      const screen = { el: el('div', { class: 'screen-backdrop' }), kind: 'trade', closeOnE: true, inventoryBound: true, onClose: function () { npc.talkingTo = null; } };
      const panel = el('div', { class: 'dialog-panel' }, screen.el);
      panel.style.width = '760px';
      const woolId = f.id === 'ironhold' ? 'blue_wool' : 'red_wool';
      const countOf = function (item) {
        if (item === '#log') return VK.Recipes.countIngredient(p.inventory, '#log');
        return p.inventory.count(item);
      };
      const removeItems = function (item, n) {
        if (item !== '#log') return p.inventory.remove(item, n);
        let left = n;
        VK.Recipes.TAGS['#log'].forEach(function (id) { const t = Math.min(left, p.inventory.count(id)); if (t) { p.inventory.remove(id, t); left -= t; } });
        return left === 0;
      };
      const render = () => {
        const factor = VK.Diplomacy.priceFactor(f.id);
        const coins = p.inventory.count('coin');
        panel.innerHTML = '';
        el('div', { class: 'speaker ' + f.id, text: 'Trading with ' + npc.displayName }, panel);
        el('div', { class: 'role', html: 'Your purse: <span class="coins">' + coins + ' gold coins</span> • ' + f.shortName + ' treasury: ' + Math.floor(f.resources.gold) + ' gold • Price factor x' + factor.toFixed(2) }, panel);
        const cols = el('div', { style: 'display:flex;gap:14px' }, panel);
        const mk = (title, offers, buying) => {
          const col = el('div', { style: 'flex:1' }, cols);
          el('div', { text: title, style: 'font-size:24px' }, col);
          const list = el('div', { class: 'trade-list' }, col);
          offers.forEach((o) => {
            const item = o.item === 'wool' ? woolId : o.item;
            const price = buying ? Math.ceil(o.price * factor) : Math.max(1, Math.floor(o.price / factor));
            const row = el('div', { class: 'trade-row' }, list);
            const icon = item === '#log' ? 'oak_log' : item;
            const name = item === '#log' ? 'Any Logs' : Items.name(item);
            row.innerHTML = '<img src="' + VK.Icons.url(icon) + '"><span class="tname">' + U.escapeHtml(name) + ' x' + o.count + '</span><span class="price coins">' + price + ' coin' + (price > 1 ? 's' : '') + '</span>';
            const btn = el('button', { text: buying ? 'Buy' : 'Sell' }, row);
            let ok;
            if (buying) ok = coins >= price && p.inventory.canFit(item, o.count);
            else ok = countOf(item) >= o.count && f.resources.gold >= price;
            btn.disabled = !ok;
            btn.addEventListener('click', () => {
              if (buying) {
                if (!p.inventory.remove('coin', price)) return;
                p.inventory.add(item, o.count);
                f.resources.gold += price;
                Object.keys(o.res).forEach(function (k) { f.resources[k] = Math.max(0, f.resources[k] - o.res[k]); });
              } else {
                if (!removeItems(item, o.count)) return;
                p.inventory.add('coin', price);
                f.resources.gold -= price;
                Object.keys(o.res).forEach(function (k) { f.resources[k] += o.res[k]; });
              }
              VK.Diplomacy.onTrade(f.id);
              g.audio.play('coin');
              render();
            });
          });
        };
        mk('Buy', BUY, true);
        mk('Sell', SELL, false);
        const back = el('button', { text: 'Back' }, panel);
        back.addEventListener('click', () => { this.close(true); this.openNPC(npc); });
        const done = el('button', { text: 'Done', style: 'margin-left:8px' }, panel);
        done.addEventListener('click', () => this.close());
      };
      screen.update = () => {
        if (this.lastTradeVersion !== p.inventory.version) { this.lastTradeVersion = p.inventory.version; render(); }
      };
      this.refs = [];
      render();
      this.open(screen);
    }

    // ------------------------------------------------ Kingdom overview

    openKingdoms() {
      const g = this.game;
      const screen = { el: el('div', { class: 'screen-backdrop' }), kind: 'kingdoms', closeOnE: true };
      const panel = el('div', { class: 'panel kingdom-panel' }, screen.el);
      el('h2', { text: 'The Realm — Day ' + g.time.day }, panel);
      const body = el('div', { class: 'kingdom-body' }, panel);
      const mapWrap = el('div', { class: 'kingdom-map-wrap' }, body);
      const canvas = el('canvas', { id: 'kingdom-map', width: 620, height: 470 }, mapWrap);
      const legend = el('div', { class: 'map-legend' }, mapWrap);
      legend.innerHTML = '<span class="l-iron">Ironhold</span><span class="l-red">Redmoor</span><span class="l-you">You</span><span>Dashed border = under attack</span>';
      const stats = el('div', { class: 'kingdom-stats' }, body);
      const logEl = el('div', { class: 'kingdom-log' }, panel);
      const close = el('button', { text: 'Close (K)' }, panel);
      close.addEventListener('click', () => this.close());
      const p = g.player;
      const render = () => {
        this.map.drawWorldMap(canvas);
        stats.innerHTML = '';
        g.kingdoms.list.forEach(function (f) {
          const c = el('div', { class: 'faction-card ' + f.id + (f.defeated ? ' defeated' : '') }, stats);
          const r = f.resources;
          const rep = p.rep[f.id];
          const repPct = (rep + 100) / 2;
          const sol = f.soldiers().length, vil = f.villagers().length, treb = f.npcs.filter(function (n) { return n.isSiege; }).length;
          let camp = f.campaign ? U.capitalize(f.campaign.stage) + ' against ' + f.campaign.target.name : 'None';
          if (f.defeated) camp = 'In exile, returning in ' + Math.ceil(f.reviveT) + 's';
          c.innerHTML =
            '<div class="fname">' + U.escapeHtml(f.name) + '</div>' +
            '<div class="row"><span>Ruler</span><span>' + U.escapeHtml(f.ruler) + '</span></div>' +
            '<div class="row"><span>Priority</span><span>' + f.priority + '</span></div>' +
            '<div class="row"><span>Settlements</span><span>' + f.settlements.map(function (s) { return U.escapeHtml(s.name) + (s.isCapital ? '★' : ''); }).join(', ') + '</span></div>' +
            '<div class="row"><span>People</span><span>' + vil + ' villagers, ' + sol + ' soldiers, ' + treb + ' trebuchets</span></div>' +
            '<div class="row"><span>Stores</span><span>W' + Math.floor(r.wood) + ' S' + Math.floor(r.stone) + ' F' + Math.floor(r.food) + ' I' + Math.floor(r.iron) + ' G' + Math.floor(r.gold) + '</span></div>' +
            '<div class="row"><span>Campaign</span><span>' + U.escapeHtml(camp) + '</span></div>' +
            '<div class="row"><span>War record</span><span>' + f.stats.kills + ' kills / ' + f.stats.losses + ' losses, ' + f.stats.captured + ' captured, ' + f.stats.lost + ' lost</span></div>' +
            '<div class="row"><span>Your standing</span><span>' + VK.Diplomacy.standing(f.id) + ' (' + Math.round(rep) + ')</span></div>' +
            '<div class="rep-bar"><div class="fill" style="left:' + Math.min(50, repPct) + '%;width:' + Math.abs(repPct - 50) + '%;background:' + (rep >= 0 ? '#57d65a' : '#ff5c5c') + '"></div><div class="mid"></div></div>';
        });
        const tip = el('div', { class: 'menu-note' }, stats);
        tip.style.color = '#333'; tip.style.textShadow = 'none'; tip.style.textAlign = 'left';
        tip.textContent = 'Talk to any villager or soldier (right-click) to trade, hear news or swear fealty. Sworn members can call soldiers to follow them with G.';
        logEl.innerHTML = g.logEntries.slice(-60).reverse().map(function (e) {
          return '<div class="' + (e.cls || '') + '">[Day ' + e.day + ' ' + e.clock + '] ' + U.escapeHtml(e.text) + '</div>';
        }).join('');
      };
      let t = 0;
      screen.update = function (dt) { t -= dt; if (t <= 0) { t = 1; render(); } };
      render();
      this.open(screen);
    }

    // -------------------------------------------------------- Menus

    showDeath(cause) { this.close(true); this.menus.showDeath(cause); }
  }

  VK.UI = UI;
})(window.VK);
