/**
 * @file icons.js
 * Procedural inventory icons:
 *   - blocks are drawn as small isometric cubes from the texture atlas
 *   - plants/torches use their flat texture
 *   - tools, weapons, food and materials are pixel-painted on 16x16 grids
 * Also paints the HUD sprites (hearts, hunger drumsticks, air bubbles).
 */
(function (VK) {
  'use strict';

  const B = VK.Blocks;
  const cache = new Map();
  const urls = new Map();

  const MAT = {
    wooden: ['#a4804a', '#c9a066', '#6d5230'],
    stone: ['#8c8c8c', '#b0b0b0', '#5a5a5a'],
    iron: ['#d8d8d8', '#ffffff', '#8a8a8a'],
    diamond: ['#5ee6de', '#b8fff8', '#1f8f8a']
  };
  const WOOD = '#7a5a32', WOOD_D = '#4e391f';

  function mk(size) {
    const c = document.createElement('canvas');
    c.width = c.height = size;
    const ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    return { c: c, ctx: ctx };
  }

  // ------------------------------------------------------ Pixel helpers

  function P(ctx) {
    return {
      px: function (x, y, col) { ctx.fillStyle = col; ctx.fillRect(x, y, 1, 1); },
      rect: function (x, y, w, h, col) { ctx.fillStyle = col; ctx.fillRect(x, y, w, h); },
      line: function (x0, y0, x1, y1, col) {
        ctx.fillStyle = col;
        const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
        const sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
        let err = dx + dy;
        for (;;) {
          ctx.fillRect(x0, y0, 1, 1);
          if (x0 === x1 && y0 === y1) break;
          const e2 = 2 * err;
          if (e2 >= dy) { err += dy; x0 += sx; }
          if (e2 <= dx) { err += dx; y0 += sy; }
        }
      },
      disc: function (cx, cy, r, col) {
        ctx.fillStyle = col;
        for (let y = -r; y <= r; y++) for (let x = -r; x <= r; x++) if (x * x + y * y <= r * r + r * 0.6) ctx.fillRect(cx + x, cy + y, 1, 1);
      }
    };
  }

  function handle(p, x0, y0, x1, y1) {
    p.line(x0, y0, x1, y1, WOOD);
    p.line(x0 + 1, y0, x1 + 1, y1, WOOD_D);
  }

  const PAINT = {
    sword: function (p, m) {
      for (let i = 0; i < 9; i++) { p.px(13 - i, 2 + i, m[0]); p.px(14 - i, 2 + i, m[1]); p.px(13 - i, 3 + i, m[2]); }
      p.px(14, 1, m[1]);
      p.line(3, 9, 7, 13, '#5a4a3a');
      p.line(4, 11, 2, 13, WOOD);
      p.px(1, 14, WOOD_D);
    },
    pickaxe: function (p, m) {
      handle(p, 3, 13, 10, 6);
      p.line(5, 2, 13, 10, m[0]);
      p.line(6, 2, 13, 9, m[1]);
      p.px(4, 3, m[2]); p.px(13, 11, m[2]);
    },
    axe: function (p, m) {
      handle(p, 3, 13, 11, 5);
      p.rect(7, 2, 4, 5, m[0]);
      p.rect(7, 2, 1, 5, m[1]);
      p.rect(11, 3, 1, 3, m[2]);
    },
    shovel: function (p, m) {
      handle(p, 3, 13, 9, 7);
      for (let y = -2; y <= 2; y++) for (let x = -2; x <= 2; x++) if (Math.abs(x) + Math.abs(y) <= 2) p.px(11 + x, 5 + y, m[0]);
      p.px(10, 4, m[1]); p.px(11, 3, m[1]);
    },
    hoe: function (p, m) {
      handle(p, 3, 13, 11, 5);
      p.line(8, 3, 11, 3, m[0]);
      p.line(8, 4, 12, 4, m[1]);
      p.px(8, 5, m[2]);
    },
    stick: function (p) { p.line(4, 12, 11, 5, WOOD); p.line(5, 12, 12, 5, WOOD_D); },
    bow: function (p) {
      for (let a = 0; a <= 90; a += 3) {
        const r = a * Math.PI / 180;
        p.px(Math.round(2 + Math.sin(r) * 11), Math.round(13 - Math.cos(r) * 11), a % 12 === 0 ? WOOD_D : '#8a6538');
      }
      p.line(2, 2, 13, 13, '#e8e8e8');
    },
    arrow: function (p) {
      p.line(3, 12, 12, 3, WOOD);
      p.rect(12, 2, 2, 2, '#c8c8c8'); p.px(14, 1, '#e0e0e0'); p.px(11, 2, '#9a9a9a'); p.px(13, 4, '#9a9a9a');
      p.px(2, 12, '#f0f0f0'); p.px(3, 13, '#f0f0f0'); p.px(1, 13, '#d0d0d0'); p.px(2, 14, '#d0d0d0'); p.px(1, 11, '#f0f0f0'); p.px(4, 14, '#f0f0f0');
    },
    spear: function (p) {
      p.line(2, 14, 11, 5, WOOD);
      p.line(3, 14, 12, 5, WOOD_D);
      p.rect(12, 2, 2, 3, '#d8d8d8'); p.px(14, 1, '#ffffff'); p.px(11, 4, '#9a9a9a');
    },
    shield: function (p) {
      p.rect(3, 2, 10, 8, '#8a6538');
      p.rect(4, 10, 8, 2, '#8a6538');
      p.rect(5, 12, 6, 1, '#8a6538');
      p.rect(6, 13, 4, 1, '#8a6538');
      p.rect(7, 14, 2, 1, '#8a6538');
      p.rect(7, 2, 2, 12, '#b8b8b8');
      p.rect(3, 5, 10, 2, '#b8b8b8');
      p.rect(3, 2, 10, 1, '#d8d8d8');
      p.rect(7, 5, 2, 2, '#ffffff');
    },
    coal: function (p) { p.rect(4, 5, 8, 6, '#2a2a2a'); p.rect(5, 4, 5, 8, '#2a2a2a'); p.px(6, 6, '#555'); p.px(9, 8, '#444'); },
    iron_ingot: function (p) { p.rect(3, 7, 10, 4, '#b8b8b8'); p.rect(4, 6, 10, 1, '#e8e8e8'); p.rect(3, 11, 10, 1, '#7a7a7a'); },
    gold_ingot: function (p) { p.rect(3, 7, 10, 4, '#e8c040'); p.rect(4, 6, 10, 1, '#fff08a'); p.rect(3, 11, 10, 1, '#a07a18'); },
    diamond: function (p) {
      p.rect(5, 4, 6, 2, '#b8fff8'); p.rect(4, 6, 8, 2, '#5ee6de'); p.rect(5, 8, 6, 2, '#3cc8c0'); p.rect(6, 10, 4, 1, '#2aa8a0'); p.rect(7, 11, 2, 1, '#1f8f8a');
    },
    flint: function (p) { p.rect(6, 4, 4, 2, '#555'); p.rect(5, 6, 6, 4, '#3a3a3a'); p.rect(6, 10, 3, 2, '#2a2a2a'); p.px(7, 5, '#888'); },
    string: function (p) { for (let x = 2; x < 14; x++) p.px(x, 8 + Math.round(Math.sin(x * 0.9) * 2), '#f0f0f0'); },
    plant_fiber: function (p) { p.line(4, 13, 7, 3, '#5a9a3a'); p.line(7, 13, 9, 4, '#6aaa46'); p.line(10, 13, 11, 3, '#4a8a2e'); },
    wheat: function (p) {
      p.line(5, 14, 9, 4, '#c8a040'); p.line(8, 14, 11, 3, '#b89030');
      [[9, 3], [8, 5], [10, 5], [11, 2], [10, 3], [12, 4]].forEach(function (c) { p.px(c[0], c[1], '#e8c860'); });
    },
    wheat_seeds: function (p) { [[5, 8], [8, 6], [10, 9], [7, 10], [11, 6], [6, 12]].forEach(function (c) { p.rect(c[0], c[1], 2, 1, '#5aa03a'); }); },
    coin: function (p) { p.disc(8, 8, 5, '#c89a20'); p.disc(8, 8, 4, '#f0c840'); p.rect(7, 5, 2, 6, '#c89a20'); p.px(6, 5, '#fff4b0'); },
    apple: function (p) { p.disc(8, 9, 5, '#d02828'); p.px(6, 6, '#ff8080'); p.line(8, 4, 9, 2, WOOD); p.rect(10, 2, 2, 2, '#4aa030'); },
    bread: function (p) { p.rect(3, 7, 10, 5, '#c08840'); p.rect(4, 6, 8, 1, '#d8a058'); p.rect(3, 12, 10, 1, '#8a5a24'); p.px(6, 8, '#e8c080'); p.px(9, 8, '#e8c080'); },
    berries: function (p) { [[5, 7], [8, 5], [10, 8], [7, 10], [11, 11]].forEach(function (c) { p.rect(c[0], c[1], 2, 2, '#c8203a'); p.px(c[0], c[1], '#ff7080'); }); p.line(6, 3, 9, 5, '#4a8a2e'); },
    cooked_meat: function (p) { p.disc(7, 7, 4, '#8a4a24'); p.disc(7, 7, 3, '#a85a30'); p.line(10, 10, 13, 13, '#f0e8d8'); p.px(13, 14, '#f0e8d8'); p.px(14, 13, '#f0e8d8'); },
    cheese: function (p) { p.rect(3, 7, 10, 5, '#f0c840'); p.rect(3, 6, 6, 1, '#f8dc70'); p.px(6, 9, '#c89a20'); p.px(10, 10, '#c89a20'); }
  };

  function paintItem(id) {
    const { c, ctx } = mk(16);
    const p = P(ctx);
    const m = /^(wooden|stone|iron|diamond)_(sword|pickaxe|axe|shovel|hoe)$/.exec(id);
    if (m) PAINT[m[2]](p, MAT[m[1]]);
    else if (PAINT[id]) PAINT[id](p);
    else { p.rect(3, 3, 10, 10, '#a0a0a0'); p.rect(5, 5, 6, 6, '#707070'); }
    return c;
  }

  /** Isometric cube icon from the block's face textures. */
  function paintBlock(blockId) {
    const { c, ctx } = mk(32);
    const atlas = VK.Textures.canvas;
    const T = VK.Textures.TILE;
    const tileXY = function (face) {
      const i = B.faceTile[blockId * 6 + face];
      return [(i % VK.Textures.COLS) * T, Math.floor(i / VK.Textures.COLS) * T];
    };
    const s = 14 / 16;
    const faces = [
      { t: tileXY(2), m: [s, s / 2, -s, s / 2, 16, 2], shade: 0 },
      { t: tileXY(4), m: [s, s / 2, 0, s, 2, 9], shade: 0.18 },
      { t: tileXY(0), m: [s, -s / 2, 0, s, 16, 16], shade: 0.38 }
    ];
    faces.forEach(function (f) {
      ctx.setTransform(f.m[0], f.m[1], f.m[2], f.m[3], f.m[4], f.m[5]);
      ctx.drawImage(atlas, f.t[0], f.t[1], T, T, 0, 0, 16, 16);
      if (f.shade) {
        ctx.fillStyle = 'rgba(0,0,0,' + f.shade + ')';
        ctx.fillRect(0, 0, 16, 16);
      }
    });
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    return c;
  }

  const Icons = {
    /** Canvas icon for an item id. */
    canvas: function (id) {
      if (cache.has(id)) return cache.get(id);
      const def = VK.Items.get(id);
      let c;
      if (def && def.block !== null && def.block !== undefined && id !== 'wheat_seeds' && id !== 'berries') {
        const bd = B.defs[def.block];
        if (B.CROSS[def.block] || !bd.tex) {
          const src = VK.Textures.tileCanvas(typeof bd.tex === 'string' ? bd.tex : bd.tex.side);
          c = mk(16).c;
          c.getContext('2d').drawImage(src, 0, 0);
        } else c = paintBlock(def.block);
      } else c = paintItem(id);
      cache.set(id, c);
      return c;
    },

    /** Data URL for <img> tags. */
    url: function (id) {
      if (urls.has(id)) return urls.get(id);
      const u = Icons.canvas(id).toDataURL();
      urls.set(id, u);
      return u;
    },

    /** HUD sprite data URLs. */
    hud: function () {
      if (Icons._hud) return Icons._hud;
      const draw = function (fn) { const { c, ctx } = mk(9); fn(P(ctx), ctx); return c.toDataURL(); };
      const heart = function (p, fill, half) {
        const shape = ['.XX.XX...', 'XXXXXXX..', 'XXXXXXX..', '.XXXXX...', '..XXX....', '...X.....'];
        shape.forEach(function (row, y) {
          for (let x = 0; x < row.length; x++) {
            if (row[x] !== 'X') continue;
            let col = '#3a1010';
            if (fill && (!half || x < 4)) col = y < 2 && x < 3 ? '#ff9090' : '#e02020';
            p.px(x + 1, y + 1, col);
          }
        });
      };
      const drum = function (p, fill, half) {
        const meat = fill ? '#b8642a' : '#3a2a1a';
        const meatHi = fill ? '#e08a48' : '#3a2a1a';
        p.rect(4, 1, 4, 4, meat);
        p.rect(5, 1, 2, 1, meatHi);
        p.rect(3, 2, 1, 3, meat);
        if (half) { p.rect(4, 1, 2, 4, '#3a2a1a'); p.rect(3, 2, 1, 3, '#3a2a1a'); }
        p.line(3, 5, 1, 7, fill ? '#f0e8d8' : '#555');
        p.px(0, 7, fill ? '#f0e8d8' : '#555'); p.px(1, 8, fill ? '#f0e8d8' : '#555');
      };
      Icons._hud = {
        heartFull: draw(function (p) { heart(p, true, false); }),
        heartHalf: draw(function (p) { heart(p, true, true); }),
        heartEmpty: draw(function (p) { heart(p, false, false); }),
        foodFull: draw(function (p) { drum(p, true, false); }),
        foodHalf: draw(function (p) { drum(p, true, true); }),
        foodEmpty: draw(function (p) { drum(p, false, false); }),
        bubble: draw(function (p) { p.disc(4, 4, 3, '#4aa0ff'); p.disc(4, 4, 2, '#9ad0ff'); p.px(3, 3, '#ffffff'); })
      };
      return Icons._hud;
    }
  };

  VK.Icons = Icons;
})(window.VK);
