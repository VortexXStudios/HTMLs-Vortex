/**
 * @file menus.js
 * Full-screen menus: title screen (new world / continue), loading screen,
 * pause menu, settings, controls help, death screen and the
 * "click to play" overlay used to (re)acquire pointer lock.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;
  const el = VK.HUD.el;

  const CONTROLS = [
    ['W A S D', 'Move'],
    ['Mouse', 'Look around'],
    ['Space', 'Jump / swim up'],
    ['Shift', 'Sneak (no falling off edges)'],
    ['Double-tap W or hold R', 'Sprint (uses stamina)'],
    ['Left click', 'Break blocks / attack (hold to mine)'],
    ['Right click', 'Place blocks, use items, eat, draw bow, block with shield, talk / trade with NPCs'],
    ['1 - 9 / Mouse wheel', 'Select hotbar slot'],
    ['E', 'Inventory and crafting'],
    ['Q (Shift+Q)', 'Drop item (stack)'],
    ['K or Tab', 'Kingdoms: map, war status, reputation, chronicle'],
    ['G', 'Command nearby soldiers to follow you (sworn members)'],
    ['F5', 'Toggle first / third person view'],
    ['F4', 'Spectator mode (fly and watch the war)'],
    ['F3', 'Debug information'],
    ['F1', 'Hide the HUD'],
    ['H', 'This help'],
    ['Esc', 'Pause menu (save, settings)']
  ];

  class Menus {
    constructor(game, ui) {
      this.game = game;
      this.ui = ui;
      this.root = document.getElementById('menus');
      this.current = null;
    }

    blocking() { return this.current !== null; }

    clear() {
      this.root.innerHTML = '';
      this.current = null;
    }

    screen(name, cls) {
      this.root.innerHTML = '';
      this.current = name;
      return el('div', { class: 'menu-screen ' + (cls || '') }, this.root);
    }

    button(parent, label, fn, cls) {
      const b = el('button', { text: label, class: 'wide ' + (cls || '') }, parent);
      b.addEventListener('click', (e) => { this.game.audio.unlock(); this.game.audio.play('click'); fn(e); });
      return b;
    }

    // ---------------------------------------------------------- Title

    showMain() {
      const g = this.game;
      const s = this.screen('main', 'title-bg');
      el('div', { class: 'game-title', html: 'VOXEL <span class="blue">KING</span><span class="red">DOMS</span>' }, s);
      el('div', { class: 'subtitle', text: 'Two crowns. One world. Endless war.' }, s);
      const col = el('div', { class: 'menu-col' }, s);
      const meta = VK.Save.meta();
      if (meta) {
        this.button(col, 'Continue World', () => g.loadWorld());
        el('div', { class: 'menu-note', text: 'Saved: day ' + meta.day + ', seed ' + meta.seed + ' (' + new Date(meta.time).toLocaleString() + ')' }, col);
      }
      el('div', { class: 'menu-label', text: 'World seed (leave empty for random)' }, col);
      const seed = el('input', { class: 'menu-input', type: 'text', placeholder: 'e.g. ironhold' }, col);
      this.button(col, meta ? 'Create New World (overwrites save)' : 'Create New World', () => g.newWorld(seed.value.trim()));
      const row = el('div', { class: 'menu-row' }, col);
      this.button(row, 'Controls', () => this.showHelp(false));
      this.button(row, 'Settings', () => this.showSettings(() => this.showMain()));
      el('div', { class: 'menu-note', html: 'The Kingdoms of <b style="color:#8fa9ff">Ironhold</b> and <b style="color:#ff8f8f">Redmoor</b> gather resources, build castles, train armies and wage war on their own. Join a side, trade, fight - or just watch history unfold.' }, s);
      el('div', { class: 'menu-note', text: 'v' + VK.VERSION + ' - built with three.js' }, s);
    }

    // -------------------------------------------------------- Loading

    showLoading(text) {
      const s = this.screen('loading', 'title-bg');
      el('div', { class: 'game-title', html: 'VOXEL <span class="blue">KING</span><span class="red">DOMS</span>' }, s);
      const box = el('div', { class: 'loading-box' }, s);
      this.loadText = el('div', { class: 'loading-text', text: text }, box);
      const bar = el('div', { class: 'loading-bar' }, box);
      this.loadFill = el('div', null, bar);
    }

    setProgress(p, text) {
      if (this.current !== 'loading') return;
      if (text) this.loadText.textContent = text;
      this.loadFill.style.width = Math.round(U.clamp(p, 0, 1) * 100) + '%';
    }

    // ------------------------------------------------ Click to play

    showClickToPlay(text) {
      const s = this.screen('click', 'dim');
      el('div', { class: 'game-title', text: text || 'Ready' }, s).style.fontSize = '64px';
      el('div', { class: 'subtitle', text: 'Click to play' }, s);
      el('div', { class: 'menu-note', text: 'Press H at any time for controls. Press K to see the kingdoms at war.' }, s);
      s.addEventListener('click', () => {
        this.game.audio.unlock();
        this.clear();
        this.game.paused = false;
        this.game.input.requestLock();
      });
    }

    // ---------------------------------------------------------- Pause

    showPause() {
      const g = this.game;
      g.paused = true;
      const s = this.screen('pause', 'dim');
      el('div', { class: 'game-title', text: 'Game Paused' }, s).style.fontSize = '64px';
      const col = el('div', { class: 'menu-col' }, s);
      this.button(col, 'Back to Game', () => { this.clear(); g.paused = false; g.input.requestLock(); });
      const status = el('div', { class: 'menu-note' }, col);
      this.button(col, 'Save Game', async () => {
        status.textContent = 'Saving...';
        const r = await g.save();
        status.textContent = r.ok ? 'Game saved (' + Math.round(r.size / 1024) + ' KB).' : 'Save failed: ' + r.error;
      });
      this.button(col, 'Load Last Save', () => { if (VK.Save.meta()) g.loadWorld(); else status.textContent = 'No saved game found.'; });
      const row = el('div', { class: 'menu-row' }, col);
      this.button(row, 'Settings', () => this.showSettings(() => this.showPause()));
      this.button(row, 'Controls', () => this.showHelp(true));
      this.button(col, 'Kingdoms Overview', () => { this.clear(); g.paused = false; this.ui.openKingdoms(); });
      this.button(col, 'Save and Quit to Title', async () => {
        await g.save();
        g.quitToTitle();
      });
    }

    // ------------------------------------------------------- Settings

    showSettings(back) {
      const g = this.game;
      const st = g.settings;
      const s = this.screen('settings', this.game.state === 'playing' ? 'dim' : 'title-bg');
      el('div', { class: 'game-title', text: 'Settings' }, s).style.fontSize = '64px';
      const grid = el('div', { class: 'settings-grid' }, s);
      const slider = (label, key, min, max, step, fmt, apply) => {
        el('div', { text: label }, grid);
        const inp = el('input', { type: 'range', min: min, max: max, step: step, value: st[key] }, grid);
        const val = el('div', { text: fmt(st[key]) }, grid);
        inp.addEventListener('input', () => {
          st[key] = Number(inp.value);
          val.textContent = fmt(st[key]);
          if (apply) apply(st[key]);
          g.saveSettings();
        });
      };
      const toggle = (label, key, apply) => {
        el('div', { text: label }, grid);
        const b = el('button', { text: st[key] ? 'On' : 'Off' }, grid);
        el('div', null, grid);
        b.addEventListener('click', () => {
          st[key] = !st[key];
          b.textContent = st[key] ? 'On' : 'Off';
          if (apply) apply(st[key]);
          g.saveSettings();
        });
      };
      slider('Render distance', 'renderDistance', 3, 12, 1, function (v) { return v + ' chunks'; }, function (v) { g.applyRenderDistance(v); });
      slider('Field of view', 'fov', 55, 100, 1, function (v) { return v + '°'; });
      slider('Mouse sensitivity', 'mouseSensitivity', 0.2, 3, 0.05, function (v) { return Math.round(v * 100) + '%'; });
      slider('Volume', 'volume', 0, 1, 0.05, function (v) { return Math.round(v * 100) + '%'; }, function (v) { g.audio.setVolume(v); });
      slider('World speed', 'worldSpeed', 1, 4, 1, function (v) { return 'x' + v; });
      toggle('View bobbing', 'viewBobbing');
      toggle('Minimap', 'showMinimap');
      toggle('Invert mouse Y', 'invertY');
      const col = el('div', { class: 'menu-col' }, s);
      el('div', { class: 'menu-note', text: 'World speed accelerates the kingdoms’ simulation (economy, building and war). Lower render distance if the game stutters.' }, col);
      this.button(col, 'Done', back);
    }

    // ---------------------------------------------------------- Help

    showHelp(inGame) {
      const g = this.game;
      const prev = this.current;
      if (inGame) g.input.exitLock();
      const s = this.screen('help', inGame ? 'dim' : 'title-bg');
      el('div', { class: 'game-title', text: 'Controls' }, s).style.fontSize = '64px';
      const t = el('div', { class: 'controls-table' }, s);
      CONTROLS.forEach(function (c) {
        el('div', { class: 'key', text: c[0] }, t);
        el('div', { text: c[1] }, t);
      });
      el('div', { class: 'menu-note', html: 'Tips: punch trees for logs, craft planks and a crafting table, then tools. Villagers trade for gold coins. Swear fealty to a kingdom by talking to its people; you will earn bounties for slaying its enemies. The kingdoms fight on without you - watch sieges from spectator mode (F4).' }, s);
      const col = el('div', { class: 'menu-col' }, s);
      this.button(col, 'Back', () => {
        if (!inGame) this.showMain();
        else if (prev === 'pause') this.showPause();
        else { this.clear(); g.paused = false; g.input.requestLock(); }
      });
    }

    // --------------------------------------------------------- Death

    showDeath(cause) {
      const g = this.game;
      g.input.exitLock();
      const s = this.screen('death', 'death');
      el('div', { class: 'game-title', text: 'You Died!' }, s);
      el('div', { class: 'subtitle', text: cause }, s);
      const col = el('div', { class: 'menu-col' }, s);
      this.button(col, 'Respawn', () => {
        g.player.respawn();
        this.clear();
        g.input.requestLock();
      });
      this.button(col, 'Title Screen', async () => { g.player.respawn(); await g.save(); g.quitToTitle(); });
    }
  }

  VK.Menus = Menus;
})(window.VK);
