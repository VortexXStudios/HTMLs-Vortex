/**
 * @file map.js
 * Top-down maps drawn from loaded chunk data: the HUD minimap (1 pixel per
 * block around the player) and the large kingdom map showing territories,
 * buildings, armies, campaigns and the player.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;

  class MapRenderer {
    constructor(game) {
      this.game = game;
    }

    /**
     * Paints terrain into an ImageData.
     * @param {number} x0 world x of the left edge
     * @param {number} z0 world z of the top edge
     * @param {number} scale blocks per pixel
     */
    paintTerrain(img, x0, z0, scale) {
      const world = this.game.world;
      const w = img.width, h = img.height, d = img.data;
      let lastKey = null, lastChunk = null;
      for (let py = 0; py < h; py++) {
        const wz = Math.floor(z0 + py * scale);
        for (let px = 0; px < w; px++) {
          const wx = Math.floor(x0 + px * scale);
          const key = U.chunkKey(wx >> 4, wz >> 4);
          if (key !== lastKey) {
            lastKey = key;
            lastChunk = world.chunks.get(key) || null;
            if (lastChunk && lastChunk.mapDirty) lastChunk.buildMapColors();
          }
          const o = (py * w + px) * 4;
          if (!lastChunk) { d[o] = 18; d[o + 1] = 16; d[o + 2] = 14; d[o + 3] = 255; continue; }
          const ci = ((wx & 15) | ((wz & 15) << 4)) * 4;
          const mc = lastChunk.mapColors;
          if (mc[ci + 3] === 0) { d[o] = 0; d[o + 1] = 0; d[o + 2] = 0; d[o + 3] = 255; continue; }
          d[o] = mc[ci]; d[o + 1] = mc[ci + 1]; d[o + 2] = mc[ci + 2]; d[o + 3] = 255;
        }
      }
    }

    /** Territories, buildings, units and the player on top of the terrain. */
    paintOverlay(ctx, x0, z0, scale, opts) {
      const g = this.game;
      const toPx = function (x, z) { return [(x - x0) / scale, (z - z0) / scale]; };
      const small = opts.small;
      g.kingdoms.list.forEach(function (f) {
        f.settlements.forEach(function (s) {
          const c = toPx(s.center.x, s.center.z);
          ctx.beginPath();
          ctx.arc(c[0], c[1], s.radius / scale, 0, Math.PI * 2);
          ctx.fillStyle = f.id === 'ironhold' ? 'rgba(59,91,214,0.13)' : 'rgba(200,50,50,0.13)';
          ctx.fill();
          ctx.lineWidth = small ? 1 : 2;
          ctx.setLineDash(s.underAttack ? [4, 3] : []);
          ctx.strokeStyle = f.css;
          ctx.stroke();
          ctx.setLineDash([]);
          s.buildings.forEach(function (b) {
            if (b.removed) return;
            const p = toPx(b.origin.x, b.origin.z);
            ctx.fillStyle = b.functional ? (f.id === 'ironhold' ? '#9fb2ff' : '#ffb0a0') : (b.hasWork() ? 'rgba(255,220,120,0.7)' : 'rgba(80,80,80,0.8)');
            ctx.fillRect(p[0], p[1], Math.max(1, b.rw / scale), Math.max(1, b.rd / scale));
          });
          if (!small) {
            ctx.font = '16px VT323, monospace';
            ctx.textAlign = 'center';
            ctx.fillStyle = '#000';
            ctx.fillText(s.name + (s.isCapital ? ' ★' : ''), c[0] + 1, c[1] - s.radius / scale - 3);
            ctx.fillStyle = '#fff';
            ctx.fillText(s.name + (s.isCapital ? ' ★' : ''), c[0], c[1] - s.radius / scale - 4);
            if (s.captureProgress > 0) {
              ctx.fillStyle = '#ffd84a';
              ctx.fillText('Capture ' + Math.round(s.captureProgress / 45 * 100) + '%', c[0], c[1] + s.radius / scale + 14);
            }
          }
        });
        // Units
        f.npcs.forEach(function (n) {
          if (n.dead || n.asleep) return;
          const p = toPx(n.pos.x, n.pos.z);
          if (n.isSiege) { ctx.fillStyle = '#ffd84a'; ctx.fillRect(p[0] - 2, p[1] - 2, 4, 4); }
          ctx.fillStyle = n.isVillager ? (f.id === 'ironhold' ? '#b8c8ff' : '#ffc8c0') : f.css;
          const r = n.isVillager ? 1 : (small ? 1.5 : 2);
          ctx.fillRect(p[0] - r, p[1] - r, r * 2, r * 2);
        });
        // Campaign arrows
        if (f.campaign && !small) {
          const camp = f.campaign;
          let cx = 0, cz = 0, n = 0;
          camp.squads.forEach(function (sq) { const c = sq.centroid(); if (c) { cx += c.x; cz += c.z; n++; } });
          if (n) {
            const a = toPx(cx / n, cz / n), b = toPx(camp.target.center.x, camp.target.center.z);
            ctx.strokeStyle = f.css;
            ctx.lineWidth = 3;
            ctx.setLineDash([8, 5]);
            ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
            ctx.setLineDash([]);
            const ang = Math.atan2(b[1] - a[1], b[0] - a[0]);
            ctx.fillStyle = f.css;
            ctx.beginPath();
            ctx.moveTo(b[0], b[1]);
            ctx.lineTo(b[0] - Math.cos(ang - 0.4) * 12, b[1] - Math.sin(ang - 0.4) * 12);
            ctx.lineTo(b[0] - Math.cos(ang + 0.4) * 12, b[1] - Math.sin(ang + 0.4) * 12);
            ctx.fill();
          }
        }
      });
      // Player arrow
      const p = g.player;
      const pp = toPx(p.pos.x, p.pos.z);
      ctx.save();
      ctx.translate(pp[0], pp[1]);
      ctx.rotate(-p.yaw);
      ctx.fillStyle = '#ffd84a';
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 1;
      const s = small ? 5 : 7;
      ctx.beginPath();
      ctx.moveTo(0, -s); ctx.lineTo(s * 0.7, s); ctx.lineTo(0, s * 0.5); ctx.lineTo(-s * 0.7, s);
      ctx.closePath();
      ctx.fill(); ctx.stroke();
      ctx.restore();
    }

    drawMinimap(canvas) {
      const g = this.game;
      const ctx = canvas.getContext('2d');
      const w = canvas.width, h = canvas.height;
      if (!this.miniImg || this.miniImg.width !== w) this.miniImg = ctx.createImageData(w, h);
      const p = g.player.pos;
      const x0 = Math.floor(p.x) - w / 2, z0 = Math.floor(p.z) - h / 2;
      this.paintTerrain(this.miniImg, x0, z0, 1);
      ctx.putImageData(this.miniImg, 0, 0);
      this.paintOverlay(ctx, x0, z0, 1, { small: true });
      ctx.fillStyle = '#fff';
      ctx.font = '14px VT323, monospace';
      ctx.textAlign = 'center';
      ctx.fillText('N', w / 2, 11);
    }

    /** Large map of the whole war zone (kingdom panel). */
    drawWorldMap(canvas) {
      const g = this.game;
      const ctx = canvas.getContext('2d');
      const w = canvas.width, h = canvas.height;
      const Z = VK.Config.WAR_ZONE;
      const spanX = Z.maxX - Z.minX + 60, spanZ = Z.maxZ - Z.minZ + 60;
      const scale = Math.max(spanX / w, spanZ / h);
      const cx = (Z.minX + Z.maxX) / 2, cz = (Z.minZ + Z.maxZ) / 2;
      const x0 = cx - w * scale / 2, z0 = cz - h * scale / 2;
      if (!this.bigImg || this.bigImg.width !== w || this.bigImg.height !== h) this.bigImg = ctx.createImageData(w, h);
      this.paintTerrain(this.bigImg, x0, z0, scale);
      ctx.putImageData(this.bigImg, 0, 0);
      this.paintOverlay(ctx, x0, z0, scale, { small: false });
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(0, h - 22, w, 22);
      ctx.fillStyle = '#ddd';
      ctx.font = '16px VT323, monospace';
      ctx.textAlign = 'left';
      ctx.fillText('Unexplored areas are dark. Scale: 1 pixel = ' + scale.toFixed(1) + ' blocks. North is up.', 8, h - 6);
    }
  }

  VK.MapRenderer = MapRenderer;
})(window.VK);
