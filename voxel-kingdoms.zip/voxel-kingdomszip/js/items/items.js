/**
 * @file items.js
 * Item registry. Every placeable block automatically gets an item; tools,
 * weapons, food and crafting materials are declared here.
 *
 * Item definition fields:
 *   id, name, stack          identity and max stack size
 *   block                    block id placed when used (block items)
 *   placeOn                  list of block ids the placed block must sit on
 *   tool {type, tier, speed} mining tool
 *   weapon {damage, cooldown, reach}
 *   food {hunger, saturation}
 *   durability               uses before the tool breaks
 *   fuel                     smelting points (1 point smelts one item)
 *   ranged                   'bow' for bows
 *   shield                   true for shields
 *   value                    base trade value in coins
 */
(function (VK) {
  'use strict';

  const B = VK.Blocks;
  const Items = { defs: {}, list: [] };

  function reg(id, props) {
    const d = Object.assign({
      id: id,
      name: props && props.name ? props.name : id.split('_').map(VK.Util.capitalize).join(' '),
      stack: 64,
      block: null,
      placeOn: null,
      tool: null,
      weapon: null,
      food: null,
      durability: 0,
      fuel: 0,
      ranged: null,
      shield: false,
      value: 1
    }, props || {});
    Items.defs[id] = d;
    Items.list.push(d);
    return d;
  }

  // ---------------------------------------------------------- Block items
  B.defs.forEach(function (bd) {
    if (!bd || !bd.item || bd.item !== bd.name) return;
    const d = reg(bd.name, { name: bd.displayName, block: bd.id });
    if (bd.material === 'wood') d.fuel = 1.5;
  });
  // Plants placed on soil only.
  Items.defs.sapling.placeOn = [B.GRASS, B.DIRT];
  Items.defs.flower_red.placeOn = [B.GRASS, B.DIRT];
  Items.defs.flower_yellow.placeOn = [B.GRASS, B.DIRT];
  Items.defs.sapling.fuel = 0.5;

  // ------------------------------------------------------------ Materials
  reg('stick', { fuel: 0.5 });
  reg('coal', { fuel: 8, value: 1 });
  reg('iron_ingot', { value: 4 });
  reg('gold_ingot', { value: 8 });
  reg('diamond', { value: 20 });
  reg('flint');
  reg('string');
  reg('plant_fiber', { name: 'Plant Fiber' });
  reg('wheat');
  reg('wheat_seeds', { name: 'Wheat Seeds', block: B.WHEAT_0, placeOn: [B.FARMLAND] });
  reg('coin', { name: 'Gold Coin', stack: 99, value: 1 });
  reg('arrow');

  // ----------------------------------------------------------------- Food
  reg('apple', { food: { hunger: 4, saturation: 2.4 } });
  reg('bread', { food: { hunger: 5, saturation: 6 } });
  reg('berries', { name: 'Sweet Berries', food: { hunger: 2, saturation: 1.2 }, block: B.BERRY_BUSH_EMPTY, placeOn: [B.GRASS, B.DIRT], placeWithSneakOnly: true });
  reg('cooked_meat', { name: 'Roast Mutton', food: { hunger: 8, saturation: 12 } });
  reg('cheese', { name: 'Wheel of Cheese', food: { hunger: 6, saturation: 7 } });

  // ---------------------------------------------------------------- Tools
  const TIERS = [
    { key: 'wooden', label: 'Wooden', tier: 1, speed: 2, dur: 60, bonus: 0 },
    { key: 'stone', label: 'Stone', tier: 2, speed: 4, dur: 132, bonus: 1 },
    { key: 'iron', label: 'Iron', tier: 3, speed: 6, dur: 251, bonus: 2 },
    { key: 'diamond', label: 'Diamond', tier: 4, speed: 8, dur: 1562, bonus: 3 }
  ];
  TIERS.forEach(function (t) {
    reg(t.key + '_pickaxe', { name: t.label + ' Pickaxe', stack: 1, durability: t.dur, tool: { type: 'pickaxe', tier: t.tier, speed: t.speed }, weapon: { damage: 2 + t.bonus, cooldown: 0.85 }, value: 2 + t.tier * 3 });
    reg(t.key + '_axe', { name: t.label + ' Axe', stack: 1, durability: t.dur, tool: { type: 'axe', tier: t.tier, speed: t.speed }, weapon: { damage: 3 + t.bonus, cooldown: 1.0 }, value: 2 + t.tier * 3 });
    reg(t.key + '_shovel', { name: t.label + ' Shovel', stack: 1, durability: t.dur, tool: { type: 'shovel', tier: t.tier, speed: t.speed }, weapon: { damage: 1.5 + t.bonus, cooldown: 0.9 }, value: 1 + t.tier * 2 });
    reg(t.key + '_hoe', { name: t.label + ' Hoe', stack: 1, durability: t.dur, tool: { type: 'hoe', tier: t.tier, speed: t.speed }, weapon: { damage: 1, cooldown: 0.5 }, value: 1 + t.tier * 2 });
    reg(t.key + '_sword', { name: t.label + ' Sword', stack: 1, durability: t.dur, weapon: { damage: 4 + t.bonus, cooldown: 0.6 }, value: 3 + t.tier * 3 });
  });
  Items.defs.wooden_pickaxe.fuel = Items.defs.wooden_axe.fuel = Items.defs.wooden_sword.fuel = 1;

  // --------------------------------------------------------------- Weapons
  reg('bow', { stack: 1, durability: 384, ranged: 'bow', value: 6 });
  reg('shield', { stack: 1, durability: 336, shield: true, value: 8 });
  reg('spear', { stack: 1, durability: 250, weapon: { damage: 6, cooldown: 0.95, reach: 4.4 }, value: 7 });

  /** Returns an item definition (or null). */
  Items.get = function (id) { return id ? (Items.defs[id] || null) : null; };
  Items.maxStack = function (id) { const d = Items.defs[id]; return d ? d.stack : 64; };
  Items.name = function (id) { const d = Items.defs[id]; return d ? d.name : id; };

  /** Creates a new item stack object. Tools start at full durability. */
  Items.stack = function (id, count) {
    const d = Items.defs[id];
    const s = { id: id, count: count || 1 };
    if (d && d.durability) s.dur = d.durability;
    return s;
  };

  VK.Items = Items;
})(window.VK);
