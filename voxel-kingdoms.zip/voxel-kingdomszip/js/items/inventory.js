/**
 * @file inventory.js
 * Slot based item container used by the player (36 slots, the first 9 form
 * the hotbar) and by chests (27 slots).
 */
(function (VK) {
  'use strict';

  class Inventory {
    constructor(size) {
      this.size = size;
      this.slots = new Array(size).fill(null);
      this.version = 0; // bumped on every change so the UI knows when to redraw
    }

    changed() { this.version++; }

    get(i) { return this.slots[i]; }

    set(i, stack) {
      this.slots[i] = stack && stack.count > 0 ? stack : null;
      this.changed();
    }

    /** Total number of a given item id. */
    count(id) {
      let n = 0;
      for (let i = 0; i < this.size; i++) {
        const s = this.slots[i];
        if (s && s.id === id) n += s.count;
      }
      return n;
    }

    has(id, n) { return this.count(id) >= (n || 1); }

    /**
     * Adds items, first merging into existing stacks, then empty slots.
     * Hotbar slots are filled before the main inventory, like Minecraft.
     * @returns {number} number of items that did not fit
     */
    add(id, count, dur) {
      const max = VK.Items.maxStack(id);
      let left = count;
      if (max > 1) {
        for (let i = 0; i < this.size && left > 0; i++) {
          const s = this.slots[i];
          if (s && s.id === id && s.count < max) {
            const take = Math.min(max - s.count, left);
            s.count += take;
            left -= take;
          }
        }
      }
      for (let i = 0; i < this.size && left > 0; i++) {
        if (!this.slots[i]) {
          const take = Math.min(max, left);
          const st = VK.Items.stack(id, take);
          if (dur !== undefined && dur !== null) st.dur = dur;
          this.slots[i] = st;
          left -= take;
        }
      }
      this.changed();
      return left;
    }

    /** Adds a complete stack object (keeps durability). Returns leftover count. */
    addStack(stack) { return this.add(stack.id, stack.count, stack.dur); }

    /** Removes up to `count` items of an id; returns true if all were removed. */
    remove(id, count) {
      let left = count;
      for (let i = this.size - 1; i >= 0 && left > 0; i--) {
        const s = this.slots[i];
        if (s && s.id === id) {
          const take = Math.min(s.count, left);
          s.count -= take;
          left -= take;
          if (s.count <= 0) this.slots[i] = null;
        }
      }
      this.changed();
      return left === 0;
    }

    /** Removes `n` items from a specific slot. */
    takeFrom(i, n) {
      const s = this.slots[i];
      if (!s) return null;
      const take = Math.min(n, s.count);
      s.count -= take;
      if (s.count <= 0) this.slots[i] = null;
      this.changed();
      const out = VK.Items.stack(s.id, take);
      if (s.dur !== undefined) out.dur = s.dur;
      return out;
    }

    /** Whether `count` more items of `id` would fit. */
    canFit(id, count) {
      const max = VK.Items.maxStack(id);
      let room = 0;
      for (let i = 0; i < this.size; i++) {
        const s = this.slots[i];
        if (!s) room += max;
        else if (s.id === id) room += max - s.count;
        if (room >= count) return true;
      }
      return room >= count;
    }

    firstIndexOf(id) {
      for (let i = 0; i < this.size; i++) if (this.slots[i] && this.slots[i].id === id) return i;
      return -1;
    }

    clear() { this.slots.fill(null); this.changed(); }

    serialize() {
      return this.slots.map(function (s) { return s ? [s.id, s.count, s.dur === undefined ? -1 : s.dur] : 0; });
    }

    deserialize(data) {
      this.slots.fill(null);
      if (!data) return;
      for (let i = 0; i < Math.min(this.size, data.length); i++) {
        const e = data[i];
        if (e && VK.Items.get(e[0])) {
          const s = { id: e[0], count: e[1] };
          if (e[2] >= 0) s.dur = e[2];
          this.slots[i] = s;
        }
      }
      this.changed();
    }
  }

  VK.Inventory = Inventory;
})(window.VK);
