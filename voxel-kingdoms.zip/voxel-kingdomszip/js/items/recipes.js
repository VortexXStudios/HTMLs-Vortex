/**
 * @file recipes.js
 * Crafting and smelting recipes with shaped/shapeless grid matching.
 *
 * Shaped recipes use a pattern (array of strings) and a key map; the pattern
 * may be placed anywhere in the grid and may be mirrored horizontally.
 * Ingredient names starting with '#' are tags matching several items.
 * Recipes with `station: 'furnace'` are smelting recipes (recipe book only).
 */
(function (VK) {
  'use strict';

  const TAGS = {
    '#planks': ['planks', 'spruce_planks'],
    '#log': ['oak_log', 'birch_log', 'spruce_log']
  };

  const R = [];
  function shaped(out, count, pattern, key, category) {
    R.push({ out: out, count: count, pattern: pattern, key: key, category: category || 'misc', station: pattern.length > 2 || pattern[0].length > 2 ? 'table' : null });
  }
  function shapeless(out, count, list, category) {
    R.push({ out: out, count: count, shapeless: list, category: category || 'misc', station: list.length > 4 ? 'table' : null });
  }
  function smelt(out, count, input, category) {
    R.push({ out: out, count: count, smelt: input, category: category || 'smelting', station: 'furnace' });
  }

  // --------------------------------------------------------------- Basics
  shapeless('planks', 4, ['oak_log'], 'basic');
  shapeless('planks', 4, ['birch_log'], 'basic');
  shapeless('spruce_planks', 4, ['spruce_log'], 'basic');
  shaped('stick', 4, ['P', 'P'], { P: '#planks' }, 'basic');
  shaped('crafting_table', 1, ['PP', 'PP'], { P: '#planks' }, 'basic');
  shaped('torch', 4, ['C', 'S'], { C: 'coal', S: 'stick' }, 'basic');
  shaped('furnace', 1, ['CCC', 'C C', 'CCC'], { C: 'cobblestone' }, 'basic');
  shaped('chest', 1, ['PPP', 'P P', 'PPP'], { P: '#planks' }, 'basic');
  shapeless('string', 1, ['plant_fiber', 'plant_fiber', 'plant_fiber'], 'basic');

  // ---------------------------------------------------------------- Tools
  [['wooden', '#planks'], ['stone', 'cobblestone'], ['iron', 'iron_ingot'], ['diamond', 'diamond']].forEach(function (m) {
    const key = { M: m[1], S: 'stick' };
    shaped(m[0] + '_pickaxe', 1, ['MMM', ' S ', ' S '], key, 'tools');
    shaped(m[0] + '_axe', 1, ['MM', 'MS', ' S'], key, 'tools');
    shaped(m[0] + '_shovel', 1, ['M', 'S', 'S'], key, 'tools');
    shaped(m[0] + '_hoe', 1, ['MM', ' S', ' S'], key, 'tools');
    shaped(m[0] + '_sword', 1, ['M', 'M', 'S'], key, 'combat');
  });

  // --------------------------------------------------------------- Combat
  shaped('bow', 1, [' TS', 'T S', ' TS'], { T: 'stick', S: 'string' }, 'combat');
  shaped('arrow', 4, ['F', 'S'], { F: 'flint', S: 'stick' }, 'combat');
  shaped('shield', 1, ['PIP', 'PPP', ' P '], { P: '#planks', I: 'iron_ingot' }, 'combat');
  shaped('spear', 1, ['  I', ' S ', 'S  '], { I: 'iron_ingot', S: 'stick' }, 'combat');

  // ----------------------------------------------------------------- Food
  shaped('bread', 1, ['WWW'], { W: 'wheat' }, 'food');
  shaped('hay', 1, ['WWW', 'WWW', 'WWW'], { W: 'wheat' }, 'food');
  shapeless('wheat', 9, ['hay'], 'food');

  // ------------------------------------------------------ Building blocks
  shaped('stone_bricks', 4, ['SS', 'SS'], { S: 'stone' }, 'building');
  shaped('bricks', 4, ['CD', 'DC'], { C: 'cobblestone', D: 'dirt' }, 'building');
  shaped('sandstone', 1, ['SS', 'SS'], { S: 'sand' }, 'building');
  shaped('slate', 4, ['GG', 'GG'], { G: 'gravel' }, 'building');
  shaped('roof_tiles', 4, ['BB', 'BB'], { B: 'bricks' }, 'building');
  shaped('thatch', 4, ['WW', 'WW'], { W: 'wheat' }, 'building');
  shapeless('mossy_cobblestone', 1, ['cobblestone', 'plant_fiber'], 'building');
  shaped('white_wool', 1, ['SS', 'SS'], { S: 'string' }, 'building');
  shapeless('red_wool', 1, ['white_wool', 'flower_red'], 'building');
  shapeless('blue_wool', 1, ['white_wool', 'berries'], 'building');
  shaped('iron_block', 1, ['III', 'III', 'III'], { I: 'iron_ingot' }, 'building');
  shapeless('iron_ingot', 9, ['iron_block'], 'building');
  shaped('gold_block', 1, ['GGG', 'GGG', 'GGG'], { G: 'gold_ingot' }, 'building');
  shapeless('gold_ingot', 9, ['gold_block'], 'building');

  // ------------------------------------------------------------- Smelting
  smelt('iron_ingot', 1, 'iron_ore');
  smelt('gold_ingot', 1, 'gold_ore');
  smelt('glass', 1, 'sand');
  smelt('stone', 1, 'cobblestone');
  smelt('coal', 1, '#log');

  // ------------------------------------------------------------- Matching

  function matches(itemId, ingredient) {
    if (!itemId || !ingredient) return !itemId && !ingredient;
    if (ingredient.charAt(0) === '#') return TAGS[ingredient].indexOf(itemId) >= 0;
    return itemId === ingredient;
  }

  /**
   * Finds the recipe matching a crafting grid.
   * @param {Array<string|null>} grid item ids in row-major order
   * @param {number} size 2 or 3
   */
  function matchGrid(grid, size) {
    let minR = size, maxR = -1, minC = size, maxC = -1;
    const items = [];
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        const id = grid[r * size + c];
        if (id) {
          items.push(id);
          if (r < minR) minR = r; if (r > maxR) maxR = r;
          if (c < minC) minC = c; if (c > maxC) maxC = c;
        }
      }
    }
    if (!items.length) return null;
    const h = maxR - minR + 1, w = maxC - minC + 1;

    for (let i = 0; i < R.length; i++) {
      const rec = R[i];
      if (rec.smelt) continue;
      if (rec.shapeless) {
        if (rec.shapeless.length !== items.length) continue;
        const pool = items.slice();
        let ok = true;
        for (let k = 0; k < rec.shapeless.length && ok; k++) {
          const idx = pool.findIndex(function (it) { return matches(it, rec.shapeless[k]); });
          if (idx < 0) ok = false; else pool.splice(idx, 1);
        }
        if (ok) return rec;
        continue;
      }
      const ph = rec.pattern.length, pw = rec.pattern[0].length;
      if (ph !== h || pw !== w) continue;
      for (let mirror = 0; mirror < 2; mirror++) {
        let ok = true;
        for (let r = 0; r < h && ok; r++) {
          for (let c = 0; c < w && ok; c++) {
            const pc = mirror ? rec.pattern[r].charAt(w - 1 - c) : rec.pattern[r].charAt(c);
            const ingredient = pc === ' ' ? null : rec.key[pc];
            if (!matches(grid[(minR + r) * size + (minC + c)], ingredient)) ok = false;
          }
        }
        if (ok) return rec;
      }
    }
    return null;
  }

  /** Flattens a recipe into required ingredient counts: [{ing, count}]. */
  function requirements(rec) {
    const map = {};
    if (rec.smelt) map[rec.smelt] = 1;
    else if (rec.shapeless) rec.shapeless.forEach(function (i) { map[i] = (map[i] || 0) + 1; });
    else rec.pattern.forEach(function (row) {
      for (let k = 0; k < row.length; k++) {
        const ch = row.charAt(k);
        if (ch !== ' ') { const ing = rec.key[ch]; map[ing] = (map[ing] || 0) + 1; }
      }
    });
    return Object.keys(map).map(function (k) { return { ing: k, count: map[k] }; });
  }

  /** Number of inventory items matching an ingredient (tags included). */
  function countIngredient(inv, ing) {
    if (ing.charAt(0) === '#') {
      return TAGS[ing].reduce(function (s, id) { return s + inv.count(id); }, 0);
    }
    return inv.count(ing);
  }

  /** True if the inventory holds everything needed for one craft. */
  function canCraft(inv, rec) {
    return requirements(rec).every(function (r) { return countIngredient(inv, r.ing) >= r.count; });
  }

  /** Removes one craft's worth of ingredients from the inventory. */
  function consume(inv, rec) {
    requirements(rec).forEach(function (r) {
      let left = r.count;
      const ids = r.ing.charAt(0) === '#' ? TAGS[r.ing] : [r.ing];
      for (let i = 0; i < ids.length && left > 0; i++) {
        const have = inv.count(ids[i]);
        const take = Math.min(have, left);
        if (take > 0) { inv.remove(ids[i], take); left -= take; }
      }
    });
  }

  /** Display id for an ingredient (first member of a tag). */
  function ingredientIcon(ing) { return ing.charAt(0) === '#' ? TAGS[ing][0] : ing; }
  function ingredientName(ing) {
    if (ing === '#planks') return 'Any Planks';
    if (ing === '#log') return 'Any Log';
    return VK.Items.name(ing);
  }

  VK.Recipes = {
    list: R,
    TAGS: TAGS,
    matchGrid: matchGrid,
    requirements: requirements,
    canCraft: canCraft,
    consume: consume,
    countIngredient: countIngredient,
    ingredientIcon: ingredientIcon,
    ingredientName: ingredientName,
    matches: matches
  };
})(window.VK);
