/**
 * @file banners.js
 * Waving cloth banners on poles that mark faction buildings. Each kingdom
 * has a procedurally painted coat of arms:
 *   Ironhold - silver keep tower on royal blue with a silver border
 *   Redmoor  - golden crown on crimson with a golden border
 * Captured buildings switch banner textures to the new owner.
 */
(function (VK) {
  'use strict';

  const W = 32, H = 48;

  function paintBanner(factionId) {
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    const ctx = c.getContext('2d');
    const fc = VK.Models.FACTION_COLORS[factionId] || VK.Models.FACTION_COLORS.neutral;
    const rgb = function (a) { return 'rgb(' + a[0] + ',' + a[1] + ',' + a[2] + ')'; };
    ctx.fillStyle = rgb(fc.main);
    ctx.fillRect(0, 0, W, H);
    // Subtle cloth weave.
    for (let y = 0; y < H; y += 2) {
      ctx.fillStyle = 'rgba(0,0,0,0.06)';
      ctx.fillRect(0, y, W, 1);
    }
    ctx.fillStyle = rgb(fc.trim);
    ctx.fillRect(0, 0, W, 2); ctx.fillRect(0, 0, 2, H); ctx.fillRect(W - 2, 0, 2, H);
    if (factionId === 'ironhold') {
      // Keep tower emblem.
      ctx.fillStyle = rgb(fc.trim);
      ctx.fillRect(11, 14, 10, 18);
      ctx.fillRect(9, 10, 3, 5); ctx.fillRect(14, 10, 4, 5); ctx.fillRect(20, 10, 3, 5);
      ctx.fillRect(9, 13, 14, 2);
      ctx.fillStyle = rgb(fc.dark);
      ctx.fillRect(14, 25, 4, 7);
      ctx.fillRect(15, 17, 2, 3);
      // Hammers below.
      ctx.fillStyle = rgb(fc.trim);
      ctx.fillRect(8, 35, 16, 2);
      ctx.fillRect(15, 33, 2, 6);
    } else if (factionId === 'redmoor') {
      // Crown emblem.
      ctx.fillStyle = rgb(fc.trim);
      ctx.fillRect(8, 22, 16, 6);
      ctx.fillRect(8, 14, 3, 8); ctx.fillRect(14.5, 11, 3, 11); ctx.fillRect(21, 14, 3, 8);
      ctx.fillRect(7, 28, 18, 2);
      ctx.fillStyle = 'rgb(120,20,30)';
      ctx.fillRect(10, 24, 2, 2); ctx.fillRect(15, 24, 2, 2); ctx.fillRect(20, 24, 2, 2);
      // Rose below.
      ctx.fillStyle = rgb(fc.trim);
      ctx.fillRect(14, 34, 4, 4); ctx.fillRect(12, 36, 8, 1);
    }
    // Swallow-tail cut at the bottom.
    ctx.clearRect(12, H - 6, 8, 6);
    ctx.clearRect(14, H - 9, 4, 3);
    const tex = new THREE.CanvasTexture(c);
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestFilter;
    tex.generateMipmaps = false;
    return { canvas: c, texture: tex };
  }

  class BannerManager {
    constructor(game) {
      this.game = game;
      this.group = new THREE.Group();
      game.scene.add(this.group);
      this.list = [];
      this.textures = {
        ironhold: paintBanner('ironhold'),
        redmoor: paintBanner('redmoor'),
        neutral: paintBanner('neutral')
      };
      this.materials = {};
      Object.keys(this.textures).forEach((k) => {
        this.materials[k] = new THREE.MeshLambertMaterial({ map: this.textures[k].texture, side: THREE.DoubleSide, alphaTest: 0.5 });
      });
      this.poleGeo = VK.Models.buildBoxes([VK.Models.box(-0.06, 0, -0.06, 0.06, 3.2, 0.06, [96, 70, 40]), VK.Models.box(-0.09, 3.2, -0.09, 0.09, 3.36, 0.09, [220, 190, 80])]);
      this.time = 0;
    }

    /** Canvas of a faction's coat of arms (used by the UI). */
    emblemCanvas(factionId) { return (this.textures[factionId] || this.textures.neutral).canvas; }

    /**
     * Adds a flag pole with a waving banner.
     * @param {number} x world x (centre of the block the pole stands in)
     * @param {number} y world y of the pole base
     * @param {number} z
     * @param {string} factionId
     * @param {number} [scale]
     */
    add(x, y, z, factionId, scale) {
      const s = scale || 1;
      const root = new THREE.Group();
      root.position.set(x, y, z);
      root.scale.setScalar(s);
      const pole = new THREE.Mesh(this.poleGeo, VK.Models.material());
      root.add(pole);
      const geo = new THREE.PlaneGeometry(1.6, 1.1, 8, 3);
      geo.translate(0.8 + 0.06, 2.55, 0);
      const cloth = new THREE.Mesh(geo, this.materials[factionId] || this.materials.neutral);
      root.add(cloth);
      this.group.add(root);
      const base = Float32Array.from(geo.attributes.position.array);
      const banner = { root: root, cloth: cloth, base: base, faction: factionId, phase: Math.random() * 10, x: x, y: y, z: z };
      this.list.push(banner);
      return banner;
    }

    setFaction(banner, factionId) {
      if (!banner || banner.faction === factionId) return;
      banner.faction = factionId;
      banner.cloth.material = this.materials[factionId] || this.materials.neutral;
    }

    remove(banner) {
      if (!banner) return;
      const i = this.list.indexOf(banner);
      if (i >= 0) this.list.splice(i, 1);
      this.group.remove(banner.root);
      banner.cloth.geometry.dispose();
    }

    clear() {
      this.list.slice().forEach((b) => this.remove(b));
    }

    /** Animates nearby banners and hides distant ones. */
    update(dt, camPos) {
      this.time += dt;
      const maxD2 = Math.pow(this.game.world.renderDistance * 16, 2);
      for (let i = 0; i < this.list.length; i++) {
        const b = this.list[i];
        const dx = b.x - camPos.x, dz = b.z - camPos.z;
        const d2 = dx * dx + dz * dz;
        b.root.visible = d2 < maxD2;
        if (!b.root.visible || d2 > 70 * 70) continue;
        const pos = b.cloth.geometry.attributes.position;
        const arr = pos.array;
        for (let v = 0; v < arr.length; v += 3) {
          const along = b.base[v] - 0.06;
          arr[v + 2] = Math.sin(this.time * 3.2 + along * 3 + b.phase) * 0.14 * along;
          arr[v + 1] = b.base[v + 1] - along * 0.06 + Math.sin(this.time * 2.1 + along * 2 + b.phase) * 0.03 * along;
        }
        pos.needsUpdate = true;
      }
    }
  }

  VK.BannerManager = BannerManager;
})(window.VK);
