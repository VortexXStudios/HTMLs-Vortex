/**
 * @file particles.js
 * Pooled square point particles used for block breaking, combat hits,
 * boulder impacts, dust, smoke and sparkles. One draw call for all.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;

  const VERT = [
    'attribute float aSize;',
    'attribute vec3 aColor;',
    'uniform float uScale;',
    'varying vec3 vColor;',
    'varying float vFogDepth;',
    'void main() {',
    '  vColor = aColor;',
    '  vec4 mv = modelViewMatrix * vec4(position, 1.0);',
    '  vFogDepth = -mv.z;',
    '  gl_PointSize = max(1.0, aSize * uScale / max(0.1, -mv.z));',
    '  gl_Position = projectionMatrix * mv;',
    '}'
  ].join('\n');
  const FRAG = [
    'uniform float uLight;',
    'uniform vec3 uFogColor;',
    'uniform float uFogNear;',
    'uniform float uFogFar;',
    'varying vec3 vColor;',
    'varying float vFogDepth;',
    'void main() {',
    '  vec3 c = vColor * uLight;',
    '  float f = smoothstep(uFogNear, uFogFar, vFogDepth);',
    '  gl_FragColor = vec4(mix(c, uFogColor, f), 1.0);',
    '}'
  ].join('\n');

  class Particles {
    constructor(game, max) {
      this.game = game;
      this.max = max || 5000;
      this.count = 0;
      const m = this.max;
      this.pos = new Float32Array(m * 3);
      this.col = new Float32Array(m * 3);
      this.size = new Float32Array(m);
      this.vel = new Float32Array(m * 3);
      this.life = new Float32Array(m);
      this.grav = new Float32Array(m);
      this.drag = new Float32Array(m);

      this.geo = new THREE.BufferGeometry();
      this.posAttr = new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage);
      this.colAttr = new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage);
      this.sizeAttr = new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage);
      this.geo.setAttribute('position', this.posAttr);
      this.geo.setAttribute('aColor', this.colAttr);
      this.geo.setAttribute('aSize', this.sizeAttr);
      this.geo.setDrawRange(0, 0);
      const wu = game.world.uniforms;
      this.mat = new THREE.ShaderMaterial({
        uniforms: {
          uScale: { value: 400 },
          uLight: { value: 1 },
          uFogColor: wu.uFogColor,
          uFogNear: wu.uFogNear,
          uFogFar: wu.uFogFar
        },
        vertexShader: VERT,
        fragmentShader: FRAG
      });
      this.points = new THREE.Points(this.geo, this.mat);
      this.points.frustumCulled = false;
      game.scene.add(this.points);
    }

    /** Spawns a single particle. Colours are 0..1. */
    spawn(x, y, z, vx, vy, vz, r, g, b, size, life, gravity, drag) {
      if (this.count >= this.max) return;
      const i = this.count++;
      this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
      this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
      this.col[i * 3] = r; this.col[i * 3 + 1] = g; this.col[i * 3 + 2] = b;
      this.size[i] = size;
      this.life[i] = life;
      this.grav[i] = gravity === undefined ? 18 : gravity;
      this.drag[i] = drag === undefined ? 0.6 : drag;
    }

    /** Debris bursting out of a block. */
    blockBurst(x, y, z, blockId, n) {
      const def = VK.Blocks.defs[blockId];
      const c = def && def.sideColor ? def.sideColor : [128, 128, 128];
      const count = n || 14;
      for (let i = 0; i < count; i++) {
        const f = U.rand(0.7, 1.15) / 255;
        this.spawn(x + Math.random(), y + Math.random(), z + Math.random(),
          U.rand(-2.5, 2.5), U.rand(0, 4.5), U.rand(-2.5, 2.5),
          c[0] * f, c[1] * f, c[2] * f, U.rand(0.08, 0.16), U.rand(0.4, 1.0), 20, 0.4);
      }
    }

    /** Blood-red/metal sparks on combat hits. */
    hit(x, y, z, blocked) {
      for (let i = 0; i < 10; i++) {
        if (blocked) this.spawn(x, y, z, U.rand(-3, 3), U.rand(0, 4), U.rand(-3, 3), 1, U.rand(0.8, 1), 0.5, 0.07, U.rand(0.2, 0.4), 12, 1.5);
        else this.spawn(x, y, z, U.rand(-2, 2), U.rand(0, 3.5), U.rand(-2, 2), U.rand(0.55, 0.85), 0.05, 0.05, U.rand(0.07, 0.12), U.rand(0.3, 0.7), 16, 0.8);
      }
    }

    /** Dust cloud and debris of a boulder impact. */
    explosion(x, y, z, radius) {
      for (let i = 0; i < 60; i++) {
        const g = U.rand(0.35, 0.6);
        this.spawn(x + U.rand(-radius, radius) * 0.5, y + U.rand(-0.5, 1), z + U.rand(-radius, radius) * 0.5,
          U.rand(-5, 5), U.rand(1, 8), U.rand(-5, 5), g, g * 0.95, g * 0.9, U.rand(0.2, 0.5), U.rand(0.6, 1.6), 6, 1.2);
      }
      for (let i = 0; i < 20; i++) {
        this.spawn(x, y + 0.5, z, U.rand(-3, 3), U.rand(2, 5), U.rand(-3, 3), 0.25, 0.23, 0.2, U.rand(0.5, 0.9), U.rand(1.5, 2.5), -1, 1.5);
      }
    }

    smoke(x, y, z, n) {
      for (let i = 0; i < (n || 6); i++) {
        const g = U.rand(0.3, 0.5);
        this.spawn(x + U.rand(-0.3, 0.3), y, z + U.rand(-0.3, 0.3), U.rand(-0.3, 0.3), U.rand(0.8, 1.6), U.rand(-0.3, 0.3), g, g, g, U.rand(0.2, 0.35), U.rand(1, 2), -0.5, 0.5);
      }
    }

    /** Small coloured sparkles (construction complete, trades, level ups). */
    sparkle(x, y, z, r, g, b, n) {
      for (let i = 0; i < (n || 12); i++) {
        this.spawn(x + U.rand(-0.6, 0.6), y + U.rand(0, 1.5), z + U.rand(-0.6, 0.6), U.rand(-1, 1), U.rand(1, 3), U.rand(-1, 1), r, g, b, U.rand(0.06, 0.12), U.rand(0.6, 1.2), 2, 0.5);
      }
    }

    update(dt, camera, renderer) {
      const world = this.game.world;
      let i = 0;
      while (i < this.count) {
        this.life[i] -= dt;
        if (this.life[i] <= 0) {
          // Swap-remove with the last particle.
          const last = --this.count;
          if (i !== last) {
            for (let k = 0; k < 3; k++) {
              this.pos[i * 3 + k] = this.pos[last * 3 + k];
              this.vel[i * 3 + k] = this.vel[last * 3 + k];
              this.col[i * 3 + k] = this.col[last * 3 + k];
            }
            this.size[i] = this.size[last];
            this.life[i] = this.life[last];
            this.grav[i] = this.grav[last];
            this.drag[i] = this.drag[last];
          }
          continue;
        }
        const d = Math.max(0, 1 - this.drag[i] * dt);
        this.vel[i * 3] *= d;
        this.vel[i * 3 + 2] *= d;
        this.vel[i * 3 + 1] = this.vel[i * 3 + 1] * d - this.grav[i] * dt;
        const nx = this.pos[i * 3] + this.vel[i * 3] * dt;
        const ny = this.pos[i * 3 + 1] + this.vel[i * 3 + 1] * dt;
        const nz = this.pos[i * 3 + 2] + this.vel[i * 3 + 2] * dt;
        const id = world.peekBlock(Math.floor(nx), Math.floor(ny), Math.floor(nz));
        if (id > 0 && VK.Blocks.SOLID[id]) {
          this.vel[i * 3] *= 0.3; this.vel[i * 3 + 2] *= 0.3; this.vel[i * 3 + 1] = 0;
        } else {
          this.pos[i * 3] = nx; this.pos[i * 3 + 1] = ny; this.pos[i * 3 + 2] = nz;
        }
        i++;
      }
      this.geo.setDrawRange(0, this.count);
      this.posAttr.needsUpdate = true;
      this.colAttr.needsUpdate = true;
      this.sizeAttr.needsUpdate = true;
      const h = renderer.domElement.height;
      this.mat.uniforms.uScale.value = h / (2 * Math.tan(camera.fov * Math.PI / 360));
      this.mat.uniforms.uLight.value = Math.max(0.35, this.game.sky ? this.game.sky.daylight : 1);
    }
  }

  VK.Particles = Particles;
})(window.VK);
