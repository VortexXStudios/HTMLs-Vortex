/**
 * @file sky.js
 * Day/night cycle: gradient sky dome, square sun and moon, stars, drifting
 * blocky clouds, fog colour and the scene lights used by entity models.
 *
 * Time convention: t in [0,1), 0 = sunrise, 0.25 = noon, 0.5 = sunset,
 * 0.75 = midnight.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;

  const DOME_VERT = [
    'varying vec3 vDir;',
    'void main() {',
    '  vDir = normalize(position);',
    '  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);',
    '}'
  ].join('\n');
  const DOME_FRAG = [
    'uniform vec3 uTop;',
    'uniform vec3 uHorizon;',
    'uniform vec3 uBottom;',
    'uniform vec3 uSunDir;',
    'uniform vec3 uGlow;',
    'varying vec3 vDir;',
    'void main() {',
    '  vec3 d = normalize(vDir);',
    '  vec3 col = d.y > 0.0 ? mix(uHorizon, uTop, pow(d.y, 0.55)) : mix(uHorizon, uBottom, min(1.0, -d.y * 4.0));',
    '  float s = max(0.0, dot(d, uSunDir));',
    '  col += uGlow * pow(s, 6.0) * 0.55;',
    '  gl_FragColor = vec4(col, 1.0);',
    '}'
  ].join('\n');

  function squareTexture(size, painter) {
    const c = document.createElement('canvas');
    c.width = c.height = size;
    painter(c.getContext('2d'), size);
    const t = new THREE.CanvasTexture(c);
    t.magFilter = THREE.NearestFilter;
    t.minFilter = THREE.NearestFilter;
    t.generateMipmaps = false;
    return t;
  }

  class Sky {
    constructor(game) {
      this.game = game;
      const scene = game.scene;

      this.uniforms = {
        uTop: { value: new THREE.Color() },
        uHorizon: { value: new THREE.Color() },
        uBottom: { value: new THREE.Color() },
        uSunDir: { value: new THREE.Vector3(1, 0, 0) },
        uGlow: { value: new THREE.Color() }
      };
      this.dome = new THREE.Mesh(
        new THREE.SphereGeometry(1, 24, 14),
        new THREE.ShaderMaterial({
          uniforms: this.uniforms, vertexShader: DOME_VERT, fragmentShader: DOME_FRAG,
          side: THREE.BackSide, depthWrite: false, depthTest: false, fog: false
        })
      );
      this.dome.renderOrder = -10;
      this.dome.frustumCulled = false;
      scene.add(this.dome);

      // Stars: random points on a sphere.
      const starGeo = new THREE.BufferGeometry();
      const n = 1400;
      const pos = new Float32Array(n * 3);
      const rng = U.mulberry32(1234);
      for (let i = 0; i < n; i++) {
        const u = rng() * 2 - 1, th = rng() * Math.PI * 2;
        const r = Math.sqrt(1 - u * u);
        pos[i * 3] = r * Math.cos(th); pos[i * 3 + 1] = u; pos[i * 3 + 2] = r * Math.sin(th);
      }
      starGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      this.starMat = new THREE.PointsMaterial({ color: 0xffffff, size: 2, sizeAttenuation: false, transparent: true, opacity: 0, depthWrite: false, fog: false });
      this.stars = new THREE.Points(starGeo, this.starMat);
      this.stars.renderOrder = -9;
      this.stars.frustumCulled = false;
      scene.add(this.stars);

      const sunTex = squareTexture(32, function (ctx, s) {
        ctx.fillStyle = 'rgba(255,240,170,0.35)'; ctx.fillRect(0, 0, s, s);
        ctx.fillStyle = '#fff6c8'; ctx.fillRect(6, 6, s - 12, s - 12);
        ctx.fillStyle = '#ffffff'; ctx.fillRect(10, 10, s - 20, s - 20);
      });
      const moonTex = squareTexture(32, function (ctx, s) {
        ctx.fillStyle = '#dfe3ea'; ctx.fillRect(6, 6, s - 12, s - 12);
        ctx.fillStyle = '#b9bfca';
        ctx.fillRect(10, 10, 5, 5); ctx.fillRect(18, 14, 6, 4); ctx.fillRect(12, 20, 4, 4);
      });
      const mk = function (tex, size) {
        const m = new THREE.Mesh(new THREE.PlaneGeometry(size, size),
          new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, fog: false }));
        m.renderOrder = -8;
        m.frustumCulled = false;
        scene.add(m);
        return m;
      };
      this.sun = mk(sunTex, 1);
      this.moon = mk(moonTex, 1);

      // Clouds: a large textured plane with a blocky cloud pattern.
      const noise = new VK.Noise.Simplex(4242);
      const cloudTex = squareTexture(64, function (ctx, s) {
        const img = ctx.createImageData(s, s);
        for (let y = 0; y < s; y++) {
          for (let x = 0; x < s; x++) {
            // Tileable noise by sampling on a torus.
            const a = x / s * Math.PI * 2, b = y / s * Math.PI * 2;
            const v = noise.noise3D(Math.cos(a) * 1.6, Math.sin(a) * 1.6 + Math.cos(b) * 1.6, Math.sin(b) * 1.6);
            const on = v > 0.25;
            const i = (y * s + x) * 4;
            img.data[i] = img.data[i + 1] = img.data[i + 2] = 255;
            img.data[i + 3] = on ? 220 : 0;
          }
        }
        ctx.putImageData(img, 0, 0);
      });
      cloudTex.wrapS = cloudTex.wrapT = THREE.RepeatWrapping;
      this.cloudRepeat = 3;
      cloudTex.repeat.set(this.cloudRepeat, this.cloudRepeat);
      this.cloudTex = cloudTex;
      this.cloudSize = 1536;
      this.cloudMat = new THREE.MeshBasicMaterial({ map: cloudTex, transparent: true, depthWrite: false, side: THREE.DoubleSide, fog: false, opacity: 0.8 });
      this.clouds = new THREE.Mesh(new THREE.PlaneGeometry(this.cloudSize, this.cloudSize), this.cloudMat);
      this.clouds.rotation.x = -Math.PI / 2;
      this.clouds.renderOrder = 1;
      this.clouds.frustumCulled = false;
      scene.add(this.clouds);
      this.cloudDrift = 0;

      // Lights for entity models (terrain uses its own shader lighting).
      this.hemi = new THREE.HemisphereLight(0xbfd8ff, 0x6b5a40, 0.6);
      scene.add(this.hemi);
      this.dir = new THREE.DirectionalLight(0xffffff, 0.7);
      scene.add(this.dir);
      scene.add(this.dir.target);

      this.daylight = 1;
      this.dayFactor = 1;
      this.fogColor = new THREE.Color();
      this.tmpA = new THREE.Color();
      this.tmpB = new THREE.Color();
      this.C = {
        dayTop: new THREE.Color(0.30, 0.54, 0.98),
        dayHorizon: new THREE.Color(0.68, 0.82, 1.0),
        nightTop: new THREE.Color(0.008, 0.01, 0.035),
        nightHorizon: new THREE.Color(0.03, 0.04, 0.09),
        sunsetHorizon: new THREE.Color(0.98, 0.5, 0.26),
        bottomDay: new THREE.Color(0.42, 0.5, 0.62),
        bottomNight: new THREE.Color(0.01, 0.01, 0.02)
      };
    }

    /**
     * @param {number} dt seconds
     * @param {number} t time of day in [0,1)
     * @param {THREE.Camera} camera
     * @param {boolean} underwater
     */
    update(dt, t, camera, underwater) {
      const ang = t * Math.PI * 2;
      const sy = Math.sin(ang);
      const sunDir = new THREE.Vector3(Math.cos(ang), sy, 0.28).normalize();
      const dayF = U.smoothstep(-0.14, 0.22, sy);
      const sunsetF = U.smoothstep(0.38, 0.0, Math.abs(sy));
      this.dayFactor = dayF;
      this.daylight = U.lerp(0.16, 1.0, dayF);

      const C = this.C;
      const top = this.tmpA.copy(C.nightTop).lerp(C.dayTop, dayF);
      const hor = this.tmpB.copy(C.nightHorizon).lerp(C.dayHorizon, dayF);
      hor.lerp(C.sunsetHorizon, sunsetF * 0.75);
      this.uniforms.uTop.value.copy(top);
      this.uniforms.uHorizon.value.copy(hor);
      this.uniforms.uBottom.value.copy(C.bottomNight).lerp(C.bottomDay, dayF);
      this.uniforms.uSunDir.value.copy(sunDir);
      this.uniforms.uGlow.value.setRGB(1.0, 0.7, 0.4).multiplyScalar(0.2 + sunsetF * 0.8);
      this.fogColor.copy(hor);

      // Chunk shader uniforms.
      const wu = this.game.world ? this.game.world.uniforms : null;
      if (wu) {
        wu.uDaylight.value = this.daylight;
        const tint = wu.uSkyTint.value;
        tint.setRGB(0.62, 0.68, 1.0).lerp(new THREE.Color(1, 1, 1), dayF);
        tint.lerp(new THREE.Color(1.0, 0.82, 0.66), sunsetF * 0.5);
        const far = this.game.world.renderDistance * 16 - 6;
        if (underwater) {
          wu.uFogColor.value.setRGB(0.08, 0.2, 0.45).multiplyScalar(0.3 + 0.7 * this.daylight);
          wu.uFogNear.value = 2;
          wu.uFogFar.value = 26;
        } else {
          wu.uFogColor.value.copy(hor);
          wu.uFogNear.value = far * 0.55;
          wu.uFogFar.value = far;
        }
      }

      // Sky objects follow the camera.
      const cp = camera.position;
      const R = camera.far * 0.85;
      this.dome.position.copy(cp);
      this.dome.scale.setScalar(camera.far * 0.95);
      this.stars.position.copy(cp);
      this.stars.scale.setScalar(R);
      this.stars.rotation.z = ang;
      this.starMat.opacity = U.clamp(1 - dayF * 1.4, 0, 1);

      const sunDist = camera.far * 0.7;
      this.sun.position.copy(cp).addScaledVector(sunDir, sunDist);
      this.sun.scale.setScalar(sunDist * 0.16);
      this.sun.lookAt(cp);
      this.moon.position.copy(cp).addScaledVector(sunDir, -sunDist);
      this.moon.scale.setScalar(sunDist * 0.11);
      this.moon.lookAt(cp);

      this.cloudDrift += dt * 1.2;
      this.clouds.position.set(cp.x, 124, cp.z);
      const rep = this.cloudRepeat / this.cloudSize;
      this.cloudTex.offset.set((cp.x + this.cloudDrift) * rep, -cp.z * rep);
      this.cloudMat.color.setRGB(1, 1, 1).multiplyScalar(0.18 + 0.82 * dayF);
      this.cloudMat.color.lerp(new THREE.Color(1, 0.75, 0.6), sunsetF * 0.4);

      // Entity lights.
      this.hemi.intensity = 0.22 + 0.5 * dayF;
      this.hemi.color.setRGB(0.55, 0.62, 0.85).lerp(new THREE.Color(0.75, 0.85, 1.0), dayF);
      const lightDir = sy > -0.05 ? sunDir : sunDir.clone().negate();
      this.dir.position.copy(cp).addScaledVector(lightDir, 50);
      this.dir.target.position.copy(cp);
      this.dir.intensity = 0.12 + 0.62 * dayF;
      this.dir.color.setRGB(1, 1, 1).lerp(new THREE.Color(1, 0.75, 0.55), sunsetF * 0.6);

      if (this.game.renderer) this.game.renderer.setClearColor(hor);
    }
  }

  VK.Sky = Sky;
})(window.VK);
