/**
 * @file models.js
 * Blocky, vertex-coloured entity models and their animation:
 *   - HumanoidModel: villagers, soldiers, archers, captains and the player
 *     (walk cycle, melee swings, spear thrusts, bow/crossbow aiming,
 *     carrying, hurt flash, death fall, health bar, two LOD levels)
 *   - TrebuchetModel: siege engine with an animated throwing arm
 *   - PileModel: resource stockpiles that grow with their content
 *   - projectile geometries (arrow, crossbow bolt, boulder)
 *
 * Geometry is built from axis-aligned boxes and cached by appearance so
 * hundreds of NPCs share a handful of buffers and two materials.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;

  // ---------------------------------------------------------- Palettes

  const SKIN = [[236, 196, 160], [214, 168, 128], [178, 126, 92], [124, 86, 58]];
  const HAIR = [[62, 42, 26], [112, 76, 42], [32, 26, 22], [172, 132, 72], [150, 146, 140], [140, 60, 30]];
  const STEEL = [170, 174, 182];
  const STEEL_DARK = [108, 112, 120];
  const LEATHER = [122, 84, 50];
  const LEATHER_DARK = [78, 54, 32];
  const WOOD = [124, 88, 52];
  const STRAW = [214, 184, 90];
  const CLOTH = [[118, 92, 64], [92, 110, 70], [128, 116, 96], [96, 84, 110], [140, 120, 90]];

  const FACTION_COLORS = {
    ironhold: { main: [52, 82, 184], dark: [30, 46, 112], trim: [200, 204, 216], light: [124, 154, 232] },
    redmoor: { main: [178, 42, 42], dark: [102, 24, 24], trim: [228, 186, 66], light: [232, 112, 102] },
    neutral: { main: [120, 120, 120], dark: [80, 80, 80], trim: [200, 200, 200], light: [170, 170, 170] }
  };

  function box(x0, y0, z0, x1, y1, z1, color) { return { min: [x0, y0, z0], max: [x1, y1, z1], color: color }; }
  function shade(c, f) { return [c[0] * f, c[1] * f, c[2] * f]; }

  /** Builds a non-indexed BufferGeometry with normals and vertex colours. */
  function buildBoxes(boxes) {
    const n = boxes.length * 36;
    const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3), col = new Float32Array(n * 3);
    let o = 0;
    const order = [0, 1, 2, 0, 2, 3];
    for (let i = 0; i < boxes.length; i++) {
      const b = boxes[i];
      const x0 = b.min[0], y0 = b.min[1], z0 = b.min[2], x1 = b.max[0], y1 = b.max[1], z1 = b.max[2];
      const r = b.color[0] / 255, g = b.color[1] / 255, bl = b.color[2] / 255;
      const faces = [
        [[x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], 1, 0, 0],
        [[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], -1, 0, 0],
        [[x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], 0, 1, 0],
        [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], 0, -1, 0],
        [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], 0, 0, 1],
        [[x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], 0, 0, -1]
      ];
      for (let f = 0; f < 6; f++) {
        const face = faces[f];
        for (let k = 0; k < 6; k++) {
          const v = face[order[k]];
          pos[o * 3] = v[0]; pos[o * 3 + 1] = v[1]; pos[o * 3 + 2] = v[2];
          nor[o * 3] = face[4]; nor[o * 3 + 1] = face[5]; nor[o * 3 + 2] = face[6];
          col[o * 3] = r; col[o * 3 + 1] = g; col[o * 3 + 2] = bl;
          o++;
        }
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    geo.computeBoundingSphere();
    return geo;
  }

  const cache = new Map();
  function cached(key, fn) {
    let g = cache.get(key);
    if (!g) { g = fn(); cache.set(key, g); }
    return g;
  }

  let MAT = null, MAT_HURT = null;
  function materials() {
    if (!MAT) {
      MAT = new THREE.MeshLambertMaterial({ vertexColors: true });
      MAT_HURT = new THREE.MeshLambertMaterial({ vertexColors: true, emissive: 0xaa1010 });
    }
    return MAT;
  }

  // ------------------------------------------------------- Appearance

  /**
   * Chooses clothing, headgear and equipment for an NPC.
   * @param {string} type unit type (villager, swordsman, spearman, archer, crossbowman, captain)
   * @param {string} job villager job
   * @param {string} factionId
   * @param {function} rnd random source
   */
  function appearanceFor(type, job, factionId, rnd) {
    const fc = FACTION_COLORS[factionId] || FACTION_COLORS.neutral;
    const pick = function (arr) { return arr[Math.floor(rnd() * arr.length)]; };
    const a = {
      faction: factionId,
      skin: pick(SKIN), hair: pick(HAIR), beard: rnd() < 0.3,
      shirt: pick(CLOTH), pants: shade(pick(CLOTH), 0.7), boots: LEATHER_DARK,
      headgear: 'hair', rightHand: null, leftHand: null,
      tabard: null, trim: fc.trim, cape: null, quiver: false, sash: null, apron: null,
      sleeve: null, glove: null, pauldron: false, plume: null, hoodColor: null, capColor: null
    };
    if (type === 'villager') {
      a.sash = fc.main;
      switch (job) {
        case 'woodcutter': a.headgear = 'hood'; a.hoodColor = [70, 96, 52]; a.rightHand = 'axe'; a.shirt = [96, 120, 70]; break;
        case 'miner': a.headgear = 'minerhelm'; a.rightHand = 'pickaxe'; a.shirt = [110, 100, 92]; break;
        case 'farmer': a.headgear = 'strawhat'; a.rightHand = 'hoe'; a.apron = [150, 130, 90]; break;
        case 'builder': a.headgear = 'cap'; a.capColor = [210, 170, 60]; a.rightHand = 'hammer'; a.apron = LEATHER; break;
        case 'hauler': a.headgear = 'hair'; a.shirt = [140, 120, 90]; break;
        default: a.headgear = rnd() < 0.5 ? 'hair' : 'cap'; a.capColor = fc.main;
      }
      return a;
    }
    // Military units wear the faction tabard.
    a.tabard = fc.main;
    a.shirt = [130, 132, 138];       // chainmail
    a.sleeve = [130, 132, 138];
    a.pants = fc.dark;
    a.boots = [60, 56, 54];
    a.glove = LEATHER;
    a.beard = rnd() < 0.4;
    switch (type) {
      case 'swordsman': a.headgear = 'nasal'; a.rightHand = 'sword'; a.leftHand = 'shield'; a.pauldron = true; break;
      case 'spearman': a.headgear = 'kettle'; a.rightHand = 'spear'; a.leftHand = 'shield'; break;
      case 'archer':
        a.headgear = 'hood'; a.hoodColor = fc.dark; a.leftHand = 'bow'; a.quiver = true;
        a.shirt = [118, 94, 64]; a.sleeve = [118, 94, 64]; break;
      case 'crossbowman': a.headgear = 'kettle'; a.rightHand = 'crossbow'; a.quiver = true; break;
      case 'captain':
        a.headgear = 'greathelm'; a.plume = fc.light; a.rightHand = 'sword'; a.leftHand = 'shield';
        a.cape = fc.main; a.pauldron = true; a.shirt = STEEL; a.sleeve = STEEL; break;
      default: a.headgear = 'nasal'; a.rightHand = 'sword';
    }
    return a;
  }

  /** Appearance of the player's third person model. */
  function playerAppearance() {
    return {
      faction: 'neutral', skin: [220, 172, 130], hair: [70, 46, 26], beard: false,
      shirt: [60, 150, 170], pants: [52, 58, 130], boots: [70, 60, 60], headgear: 'hair',
      rightHand: null, leftHand: null, tabard: null, trim: [200, 200, 200], cape: null, quiver: false,
      sash: null, apron: null, sleeve: null, glove: null, pauldron: false, plume: null
    };
  }

  // ------------------------------------------------------ Part builders

  function headBoxes(a) {
    const b = [];
    b.push(box(-0.22, 0, -0.22, 0.22, 0.44, 0.22, a.skin));
    b.push(box(-0.15, 0.2, 0.221, -0.05, 0.26, 0.232, [245, 245, 245]));
    b.push(box(-0.11, 0.2, 0.232, -0.05, 0.26, 0.238, [40, 50, 90]));
    b.push(box(0.05, 0.2, 0.221, 0.15, 0.26, 0.232, [245, 245, 245]));
    b.push(box(0.05, 0.2, 0.232, 0.11, 0.26, 0.238, [40, 50, 90]));
    b.push(box(-0.07, 0.07, 0.221, 0.07, 0.1, 0.232, shade(a.skin, 0.7)));
    if (a.beard) {
      b.push(box(-0.225, 0, 0.18, 0.225, 0.12, 0.24, a.hair));
      b.push(box(-0.225, 0.1, 0.18, -0.16, 0.24, 0.235, a.hair));
      b.push(box(0.16, 0.1, 0.18, 0.225, 0.24, 0.235, a.hair));
    }
    switch (a.headgear) {
      case 'hood': {
        const h = a.hoodColor || [90, 80, 60];
        b.push(box(-0.25, 0.4, -0.25, 0.25, 0.5, 0.25, h));
        b.push(box(-0.25, 0.0, -0.25, 0.25, 0.4, -0.19, h));
        b.push(box(-0.25, 0.0, -0.19, -0.2, 0.4, 0.24, h));
        b.push(box(0.2, 0.0, -0.19, 0.25, 0.4, 0.24, h));
        b.push(box(-0.25, 0.34, 0.2, 0.25, 0.4, 0.25, shade(h, 0.85)));
        b.push(box(-0.08, 0.2, -0.33, 0.08, 0.44, -0.24, shade(h, 0.9)));
        break;
      }
      case 'nasal':
        b.push(box(-0.24, 0.3, -0.24, 0.24, 0.5, 0.24, STEEL));
        b.push(box(-0.245, 0.28, -0.245, 0.245, 0.32, 0.245, STEEL_DARK));
        b.push(box(-0.025, 0.12, 0.235, 0.025, 0.31, 0.26, STEEL_DARK));
        break;
      case 'greathelm':
        b.push(box(-0.25, 0.02, -0.25, 0.25, 0.5, 0.25, STEEL));
        b.push(box(-0.19, 0.22, 0.25, 0.19, 0.26, 0.262, [20, 20, 24]));
        b.push(box(-0.255, 0.3, -0.255, 0.255, 0.33, 0.255, a.trim));
        b.push(box(-0.02, 0.05, 0.25, 0.02, 0.22, 0.262, a.trim));
        break;
      case 'kettle':
        b.push(box(-0.33, 0.33, -0.33, 0.33, 0.37, 0.33, STEEL_DARK));
        b.push(box(-0.23, 0.36, -0.23, 0.23, 0.52, 0.23, STEEL));
        break;
      case 'strawhat':
        b.push(box(-0.35, 0.36, -0.35, 0.35, 0.4, 0.35, STRAW));
        b.push(box(-0.2, 0.4, -0.2, 0.2, 0.53, 0.2, STRAW));
        b.push(box(-0.205, 0.4, -0.205, 0.205, 0.44, 0.205, a.sash || [150, 60, 40]));
        break;
      case 'cap':
        b.push(box(-0.235, 0.34, -0.235, 0.235, 0.48, 0.235, a.capColor || [120, 90, 60]));
        b.push(box(-0.2, 0.34, 0.23, 0.2, 0.38, 0.36, shade(a.capColor || [120, 90, 60], 0.8)));
        b.push(box(-0.23, 0.12, -0.235, 0.23, 0.36, -0.2, a.hair));
        break;
      case 'minerhelm':
        b.push(box(-0.24, 0.32, -0.24, 0.24, 0.5, 0.24, [92, 70, 44]));
        b.push(box(-0.05, 0.36, 0.24, 0.05, 0.44, 0.29, [255, 220, 90]));
        break;
      default:
        b.push(box(-0.23, 0.36, -0.23, 0.23, 0.47, 0.23, a.hair));
        b.push(box(-0.23, 0.12, -0.235, 0.23, 0.46, -0.2, a.hair));
        b.push(box(-0.235, 0.26, -0.2, -0.2, 0.46, 0.08, a.hair));
        b.push(box(0.2, 0.26, -0.2, 0.235, 0.46, 0.08, a.hair));
    }
    if (a.plume) b.push(box(-0.04, 0.5, -0.16, 0.04, 0.68, 0.1, a.plume));
    return b;
  }

  function bodyBoxes(a) {
    const b = [];
    b.push(box(-0.26, 0, -0.14, 0.26, 0.7, 0.14, a.shirt));
    b.push(box(-0.265, 0.06, -0.145, 0.265, 0.13, 0.145, LEATHER_DARK));
    b.push(box(-0.04, 0.06, 0.145, 0.04, 0.13, 0.152, [200, 180, 90]));
    if (a.tabard) {
      b.push(box(-0.19, 0.0, 0.141, 0.19, 0.64, 0.16, a.tabard));
      b.push(box(-0.19, 0.0, -0.16, 0.19, 0.64, -0.141, a.tabard));
      b.push(box(-0.06, 0.28, 0.16, 0.06, 0.5, 0.172, a.trim));
      b.push(box(-0.12, 0.36, 0.16, 0.12, 0.42, 0.172, a.trim));
      b.push(box(-0.19, 0.0, 0.141, 0.19, 0.04, 0.165, a.trim));
    }
    if (a.apron) b.push(box(-0.2, 0.0, 0.141, 0.2, 0.46, 0.156, a.apron));
    if (a.sash) {
      b.push(box(-0.265, 0.5, 0.141, 0.265, 0.56, 0.152, a.sash));
      b.push(box(-0.265, 0.5, -0.152, 0.265, 0.56, -0.141, a.sash));
    }
    if (a.cape) {
      b.push(box(-0.25, 0.0, -0.215, 0.25, 0.7, -0.15, a.cape));
      b.push(box(-0.28, 0.6, -0.17, 0.28, 0.72, 0.15, shade(a.cape, 0.8)));
    }
    if (a.quiver) {
      b.push(box(0.04, 0.16, -0.26, 0.18, 0.66, -0.15, LEATHER));
      b.push(box(0.06, 0.66, -0.24, 0.16, 0.78, -0.17, [236, 236, 236]));
    }
    return b;
  }

  function armBoxes(a) {
    const b = [];
    b.push(box(-0.1, -0.4, -0.1, 0.1, 0.02, 0.1, a.sleeve || a.shirt));
    b.push(box(-0.1, -0.68, -0.1, 0.1, -0.4, 0.1, a.glove || a.skin));
    if (a.pauldron) b.push(box(-0.125, -0.12, -0.125, 0.125, 0.06, 0.125, STEEL));
    return b;
  }

  function legBoxes(a) {
    return [
      box(-0.12, -0.6, -0.12, 0.12, 0, 0.12, a.pants),
      box(-0.125, -0.72, -0.13, 0.125, -0.56, 0.145, a.boots)
    ];
  }

  function itemBoxes(name, factionId) {
    const fc = FACTION_COLORS[factionId] || FACTION_COLORS.neutral;
    switch (name) {
      case 'sword': return [
        box(-0.03, -0.03, -0.12, 0.03, 0.03, 0.08, LEATHER_DARK),
        box(-0.14, -0.035, 0.08, 0.14, 0.035, 0.12, STEEL_DARK),
        box(-0.04, -0.015, 0.12, 0.04, 0.015, 0.86, [214, 218, 226])
      ];
      case 'spear': return [
        box(-0.03, -0.03, -0.9, 0.03, 0.03, 1.3, WOOD),
        box(-0.055, -0.02, 1.3, 0.055, 0.02, 1.58, STEEL),
        box(-0.04, -0.04, 1.2, 0.04, 0.04, 1.3, fc.main)
      ];
      case 'axe': return [
        box(-0.03, -0.03, -0.1, 0.03, 0.03, 0.62, WOOD),
        box(-0.025, 0.0, 0.42, 0.025, 0.22, 0.62, STEEL)
      ];
      case 'pickaxe': return [
        box(-0.03, -0.03, -0.1, 0.03, 0.03, 0.62, WOOD),
        box(-0.025, -0.2, 0.52, 0.025, 0.2, 0.6, STEEL)
      ];
      case 'hoe': return [
        box(-0.03, -0.03, -0.1, 0.03, 0.03, 0.7, WOOD),
        box(-0.02, 0.0, 0.6, 0.02, 0.16, 0.68, STEEL_DARK)
      ];
      case 'hammer': return [
        box(-0.03, -0.03, -0.1, 0.03, 0.03, 0.45, WOOD),
        box(-0.07, -0.09, 0.38, 0.07, 0.09, 0.54, [80, 80, 86])
      ];
      case 'crossbow': return [
        box(-0.04, -0.05, -0.12, 0.04, 0.04, 0.55, WOOD),
        box(-0.32, -0.02, 0.44, 0.32, 0.03, 0.5, [70, 60, 50]),
        box(-0.3, -0.005, 0.28, 0.3, 0.005, 0.3, [230, 230, 230])
      ];
      case 'bow': return [
        box(-0.03, -0.12, -0.16, 0.03, -0.06, 0.16, WOOD),
        box(-0.03, -0.07, 0.16, 0.03, -0.01, 0.4, WOOD),
        box(-0.03, -0.02, 0.4, 0.03, 0.03, 0.56, WOOD),
        box(-0.03, -0.07, -0.4, 0.03, -0.01, -0.16, WOOD),
        box(-0.03, -0.02, -0.56, 0.03, 0.03, -0.4, WOOD),
        box(-0.006, 0.03, -0.55, 0.006, 0.04, 0.55, [236, 236, 236])
      ];
      case 'shield': return [
        box(-0.3, -0.64, 0.12, 0.3, 0.02, 0.18, fc.dark),
        box(-0.26, -0.6, 0.18, 0.26, -0.02, 0.2, fc.main),
        box(-0.04, -0.56, 0.2, 0.04, -0.06, 0.212, fc.trim),
        box(-0.22, -0.34, 0.2, 0.22, -0.26, 0.212, fc.trim)
      ];
      default: return [];
    }
  }

  function carryBoxes(type) {
    switch (type) {
      case 'wood': return [
        box(-0.26, 0.0, -0.12, 0.26, 0.12, 0.0, [122, 92, 54]),
        box(-0.26, 0.0, 0.02, 0.26, 0.12, 0.14, [110, 82, 48]),
        box(-0.26, 0.12, -0.06, 0.26, 0.24, 0.08, [128, 98, 58])
      ];
      case 'stone': return [box(-0.18, 0.0, -0.14, 0.18, 0.3, 0.16, [128, 128, 128]), box(-0.1, 0.3, -0.06, 0.12, 0.42, 0.1, [110, 110, 110])];
      case 'food': return [box(-0.2, 0.0, -0.14, 0.2, 0.3, 0.16, [212, 180, 64]), box(-0.2, 0.12, -0.15, 0.2, 0.16, 0.17, [150, 70, 40])];
      case 'iron': return [box(-0.2, 0.0, -0.1, 0.2, 0.08, 0.1, [96, 96, 104]), box(-0.18, 0.08, -0.08, 0.18, 0.16, 0.08, [120, 120, 128])];
      case 'gold': return [box(-0.14, 0.0, -0.1, 0.14, 0.14, 0.1, [236, 196, 70])];
      default: return [box(-0.2, 0.0, -0.15, 0.2, 0.32, 0.17, [150, 104, 50]), box(-0.205, 0.26, -0.155, 0.205, 0.3, 0.175, [90, 62, 30])];
    }
  }

  /**
   * Cache keys per body part. Keying parts separately keeps the number of
   * distinct geometries small even though every NPC looks a bit different.
   */
  function partKeys(a) {
    return {
      head: 'h' + JSON.stringify([a.skin, a.hair, a.beard, a.headgear, a.hoodColor, a.capColor, a.plume, a.trim, a.sash]),
      body: 'b' + JSON.stringify([a.shirt, a.tabard, a.trim, a.apron, a.sash, a.cape, a.quiver]),
      arm: 'a' + JSON.stringify([a.sleeve || a.shirt, a.glove || a.skin, a.pauldron]),
      leg: 'l' + JSON.stringify([a.pants, a.boots]),
      low: 'o' + JSON.stringify([a.pants, a.tabard || a.shirt, a.sleeve || a.shirt, a.headgear, a.hoodColor, a.hair, a.skin])
    };
  }

  // ----------------------------------------------------- HumanoidModel

  class HumanoidModel {
    constructor(app) {
      materials();
      this.app = app;
      const keys = partKeys(app);
      this.root = new THREE.Group();
      this.full = new THREE.Group();
      this.root.add(this.full);
      this.meshes = [];
      const mk = (geo, parent, x, y, z) => {
        const m = new THREE.Mesh(geo, MAT);
        m.position.set(x, y, z);
        parent.add(m);
        this.meshes.push(m);
        return m;
      };
      this.body = mk(cached(keys.body, function () { return buildBoxes(bodyBoxes(app)); }), this.full, 0, 0.72, 0);
      this.head = mk(cached(keys.head, function () { return buildBoxes(headBoxes(app)); }), this.full, 0, 1.42, 0);
      const armGeo = cached(keys.arm, function () { return buildBoxes(armBoxes(app)); });
      this.armR = mk(armGeo, this.full, -0.36, 1.38, 0);
      this.armL = mk(armGeo, this.full, 0.36, 1.38, 0);
      const legGeo = cached(keys.leg, function () { return buildBoxes(legBoxes(app)); });
      this.legR = mk(legGeo, this.full, -0.13, 0.72, 0);
      this.legL = mk(legGeo, this.full, 0.13, 0.72, 0);
      this.rightItem = null;
      this.leftItem = null;
      this.setRightItem(app.rightHand);
      if (app.leftHand) {
        this.leftItem = mk(cached('i' + app.leftHand + app.faction, function () { return buildBoxes(itemBoxes(app.leftHand, app.faction)); }), this.armL, 0, app.leftHand === 'shield' ? 0 : -0.6, app.leftHand === 'shield' ? 0 : 0.02);
      }
      this.carryMesh = null;
      this.carryType = null;

      // Low detail version: one mesh.
      this.low = new THREE.Mesh(cached(keys.low, function () {
        const bb = [];
        bb.push(box(-0.26, 0, -0.12, 0.26, 0.72, 0.12, app.pants));
        bb.push(box(-0.3, 0.72, -0.14, 0.3, 1.42, 0.14, app.tabard || app.shirt));
        bb.push(box(-0.46, 0.72, -0.1, -0.26, 1.4, 0.1, app.sleeve || app.shirt));
        bb.push(box(0.26, 0.72, -0.1, 0.46, 1.4, 0.1, app.sleeve || app.shirt));
        const hg = app.headgear;
        const headCol = (hg === 'nasal' || hg === 'greathelm' || hg === 'kettle') ? STEEL : (hg === 'hood' ? (app.hoodColor || app.hair) : app.skin);
        bb.push(box(-0.22, 1.42, -0.22, 0.22, 1.86, 0.22, headCol));
        return buildBoxes(bb);
      }), MAT);
      this.low.visible = false;
      this.root.add(this.low);

      this.lod = 0;
      this.walkPhase = Math.random() * 6;
      this.action = null;
      this.actionT = 0;
      this.actionDur = 0.3;
      this.hurtT = 0;
      this.dead = false;
      this.deathT = 0;
      this.hpSprite = null;
      this.hpFrac = 1;
    }

    setRightItem(name) {
      if (this.rightItemName === name) return;
      this.rightItemName = name;
      if (this.rightItem) { this.armR.remove(this.rightItem); this.meshes.splice(this.meshes.indexOf(this.rightItem), 1); this.rightItem = null; }
      if (!name) return;
      const fac = this.app.faction;
      const m = new THREE.Mesh(cached('i' + name + fac, function () { return buildBoxes(itemBoxes(name, fac)); }), MAT);
      m.position.set(0, -0.6, 0.02);
      this.armR.add(m);
      this.meshes.push(m);
      this.rightItem = m;
    }

    setCarry(type) {
      if (this.carryType === type) return;
      this.carryType = type;
      if (this.carryMesh) { this.body.remove(this.carryMesh); this.carryMesh = null; }
      if (!type) return;
      this.carryMesh = new THREE.Mesh(cached('c' + type, function () { return buildBoxes(carryBoxes(type)); }), MAT);
      this.carryMesh.position.set(0, 0.28, 0.36);
      this.body.add(this.carryMesh);
    }

    /** 0 = full detail, 1 = low detail, 2 = hidden. */
    setLOD(level) {
      if (level === this.lod) return;
      this.lod = level;
      this.root.visible = level < 2;
      this.full.visible = level === 0;
      this.low.visible = level === 1;
    }

    playAction(name, dur) {
      this.action = name;
      this.actionT = 0;
      this.actionDur = dur || 0.35;
    }

    flashHurt() {
      this.hurtT = 0.22;
      for (let i = 0; i < this.meshes.length; i++) this.meshes[i].material = MAT_HURT;
      if (this.carryMesh) this.carryMesh.material = MAT_HURT;
      this.low.material = MAT_HURT;
    }

    setDead() { this.dead = true; this.deathT = 0; this.setHealth(0, false); }

    /** Shows a small health bar above the head. */
    setHealth(frac, visible) {
      if (!visible) { if (this.hpSprite) this.hpSprite.visible = false; return; }
      if (!this.hpSprite) {
        const c = document.createElement('canvas');
        c.width = 32; c.height = 4;
        const tex = new THREE.CanvasTexture(c);
        tex.magFilter = THREE.NearestFilter; tex.minFilter = THREE.NearestFilter; tex.generateMipmaps = false;
        this.hpCanvas = c;
        this.hpSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: true, fog: false }));
        this.hpSprite.scale.set(0.9, 0.11, 1);
        this.hpSprite.position.y = 2.3;
        this.root.add(this.hpSprite);
        this.hpFrac = -1;
      }
      this.hpSprite.visible = true;
      if (Math.abs(frac - this.hpFrac) > 0.01) {
        this.hpFrac = frac;
        const ctx = this.hpCanvas.getContext('2d');
        ctx.fillStyle = '#111'; ctx.fillRect(0, 0, 32, 4);
        ctx.fillStyle = frac > 0.5 ? '#4ee04e' : (frac > 0.25 ? '#e0c84e' : '#e04e4e');
        ctx.fillRect(1, 1, Math.max(0, Math.round(30 * frac)), 2);
        this.hpSprite.material.map.needsUpdate = true;
      }
    }

    /**
     * @param {number} dt
     * @param {object} s {speed, aiming, carrying, combat, headYaw, headPitch}
     */
    update(dt, s) {
      if (this.hurtT > 0) {
        this.hurtT -= dt;
        if (this.hurtT <= 0) {
          for (let i = 0; i < this.meshes.length; i++) this.meshes[i].material = MAT;
          if (this.carryMesh) this.carryMesh.material = MAT;
          this.low.material = MAT;
        }
      }
      if (this.dead) {
        this.deathT += dt;
        const t = Math.min(1, this.deathT / 0.45);
        this.full.rotation.z = -t * Math.PI / 2;
        this.low.rotation.z = -t * Math.PI / 2;
        this.full.position.x = -t * 0.3;
        if (this.deathT > 2.2) this.root.position.y -= dt * 0.5;
        return;
      }
      if (this.lod !== 0) return;
      this.setCarry(s.carrying || null);

      const sp = s.speed || 0;
      this.walkPhase += dt * sp * 3.3;
      const amp = Math.min(1, sp / 3) * 0.75;
      const swing = Math.sin(this.walkPhase) * amp;
      this.legL.rotation.x = swing;
      this.legR.rotation.x = -swing;
      const idle = Math.sin(this.walkPhase * 0.3 + performance.now() * 0.0015) * 0.04;
      let rX = swing * 0.8 + idle, lX = -swing * 0.8 - idle, rZ = -0.06, lZ = 0.06;
      const app = this.app;
      if (s.carrying) { rX = -1.0; lX = -1.0; rZ = 0.18; lZ = -0.18; }
      if (s.combat) {
        if (app.leftHand === 'shield') { lX = -0.85; lZ = -0.35; }
        if (app.rightHand === 'spear') { rX = -0.55; }
        if (app.rightHand === 'sword') { rX = -0.45; }
      }
      if (s.aiming) {
        if (app.leftHand === 'bow') { lX = -1.55; lZ = -0.05; rX = -1.5; rZ = 0.45; }
        else if (app.rightHand === 'crossbow') { rX = -1.5; lX = -1.35; lZ = -0.45; }
      }
      if (this.action) {
        this.actionT += dt;
        const t = Math.min(1, this.actionT / this.actionDur);
        switch (this.action) {
          case 'swing':
            rX = t < 0.35 ? U.lerp(rX, -2.7, t / 0.35) : U.lerp(-2.7, -0.2, (t - 0.35) / 0.65);
            break;
          case 'chop':
            rX = t < 0.4 ? U.lerp(-0.4, -2.4, t / 0.4) : U.lerp(-2.4, -0.6, (t - 0.4) / 0.6);
            lX = rX * 0.8;
            break;
          case 'build':
            rX = t < 0.5 ? U.lerp(-0.8, -2.0, t / 0.5) : U.lerp(-2.0, -0.8, (t - 0.5) / 0.5);
            break;
          case 'thrust':
            rX = t < 0.3 ? U.lerp(-0.6, -1.0, t / 0.3) : (t < 0.55 ? -1.6 : U.lerp(-1.6, -0.6, (t - 0.55) / 0.45));
            this.armR.position.z = t < 0.55 ? t * 0.5 : (1 - t) * 0.6;
            break;
          case 'shoot':
            if (app.leftHand === 'bow') { lX = -1.55; rX = U.lerp(-1.5, -1.1, t); rZ = U.lerp(0.45, 0.9, t); }
            else { rX = -1.5 + Math.sin(t * Math.PI) * 0.3; lX = -1.35; }
            break;
          case 'wave':
            lX = -2.8 + Math.sin(t * Math.PI * 4) * 0.3; lZ = -0.3;
            break;
          case 'harvest':
            rX = -1.2 + Math.sin(t * Math.PI * 2) * 0.5; lX = -0.9;
            this.body.rotation.x = Math.sin(t * Math.PI) * 0.25;
            break;
        }
        if (this.actionT >= this.actionDur) {
          this.action = null;
          this.armR.position.z = 0;
          this.body.rotation.x = 0;
        }
      }
      this.armR.rotation.x = rX; this.armR.rotation.z = rZ;
      this.armL.rotation.x = lX; this.armL.rotation.z = lZ;
      this.head.rotation.y = U.clamp(s.headYaw || 0, -0.9, 0.9);
      this.head.rotation.x = U.clamp(s.headPitch || 0, -0.6, 0.6);
    }

    dispose() {
      if (this.hpSprite) { this.hpSprite.material.map.dispose(); this.hpSprite.material.dispose(); }
    }
  }

  // ----------------------------------------------------- TrebuchetModel

  class TrebuchetModel {
    constructor(factionId) {
      materials();
      const fc = FACTION_COLORS[factionId] || FACTION_COLORS.neutral;
      this.root = new THREE.Group();
      this.full = new THREE.Group();
      this.root.add(this.full);
      const frame = cached('treb_frame_' + factionId, function () {
        const b = [];
        const W = [118, 86, 50], D = [86, 62, 36], I = [70, 70, 76];
        b.push(box(-0.95, 0.35, -1.7, -0.7, 0.6, 1.7, W));
        b.push(box(0.7, 0.35, -1.7, 0.95, 0.6, 1.7, W));
        b.push(box(-0.95, 0.35, -1.5, 0.95, 0.55, -1.25, D));
        b.push(box(-0.95, 0.35, 1.25, 0.95, 0.55, 1.5, D));
        b.push(box(-0.95, 0.35, -0.12, 0.95, 0.55, 0.12, D));
        [[-1.05, -1.3], [-1.05, 1.3], [0.85, -1.3], [0.85, 1.3]].forEach(function (w) {
          b.push(box(w[0], 0, w[1] - 0.35, w[0] + 0.2, 0.7, w[1] + 0.35, [70, 52, 32]));
          b.push(box(w[0] - 0.01, 0.28, w[1] - 0.08, w[0] + 0.21, 0.42, w[1] + 0.08, I));
        });
        b.push(box(-0.92, 0.55, -0.14, -0.72, 2.8, 0.14, W));
        b.push(box(0.72, 0.55, -0.14, 0.92, 2.8, 0.14, W));
        b.push(box(-0.92, 0.55, -0.9, -0.72, 0.75, 0.9, D));
        b.push(box(0.72, 0.55, -0.9, 0.92, 0.75, 0.9, D));
        b.push(box(-0.9, 1.2, -0.6, -0.74, 1.35, 0.6, D));
        b.push(box(0.74, 1.2, -0.6, 0.9, 1.35, 0.6, D));
        b.push(box(-1.0, 2.6, -0.08, 1.0, 2.76, 0.08, I));
        b.push(box(0.72, 2.8, -0.06, 0.78, 3.9, 0.0, [60, 44, 26]));
        b.push(box(0.78, 3.4, -0.04, 1.5, 3.85, -0.02, fc.main));
        b.push(box(0.78, 3.4, -0.045, 1.5, 3.45, -0.015, fc.trim));
        return buildBoxes(b);
      });
      this.frame = new THREE.Mesh(frame, MAT);
      this.full.add(this.frame);
      this.armPivot = new THREE.Group();
      this.armPivot.position.set(0, 2.68, 0);
      this.full.add(this.armPivot);
      const arm = cached('treb_arm', function () {
        return buildBoxes([
          box(-0.09, -0.09, -3.2, 0.09, 0.09, 1.0, [128, 94, 56]),
          box(-0.3, -0.75, 0.75, 0.3, -0.05, 1.3, [92, 92, 96]),
          box(-0.06, -0.06, -3.4, 0.06, 0.06, -3.2, [70, 70, 76]),
          box(-0.12, -0.45, -3.35, 0.12, -0.2, -3.1, [120, 120, 120])
        ]);
      });
      this.arm = new THREE.Mesh(arm, MAT);
      this.armPivot.add(this.arm);
      this.meshes = [this.frame, this.arm];
      this.cocked = -0.9;
      this.armPivot.rotation.x = this.cocked;
      this.fireT = -1;
      this.hurtT = 0;
      this.dead = false;
      this.deathT = 0;
      this.lod = 0;
      this.hpSprite = null;
      this.wheelPhase = 0;
    }

    setLOD(level) {
      if (level === this.lod) return;
      this.lod = level;
      this.root.visible = level < 2;
    }
    playAction(name) { if (name === 'shoot') this.fireT = 0; }
    flashHurt() {
      this.hurtT = 0.22;
      this.meshes.forEach(function (m) { m.material = MAT_HURT; });
    }
    setDead() { this.dead = true; this.deathT = 0; }
    setHealth(frac, visible) { HumanoidModel.prototype.setHealth.call(this, frac, visible); if (this.hpSprite) this.hpSprite.position.y = 4.2; }

    update(dt) {
      if (this.hurtT > 0) {
        this.hurtT -= dt;
        if (this.hurtT <= 0) this.meshes.forEach(function (m) { m.material = MAT; });
      }
      if (this.dead) {
        this.deathT += dt;
        const t = Math.min(1, this.deathT / 0.8);
        this.full.rotation.z = t * 0.5;
        this.armPivot.rotation.x = U.lerp(this.armPivot.rotation.x, 1.2, t);
        if (this.deathT > 2.5) this.root.position.y -= dt * 0.4;
        return;
      }
      if (this.fireT >= 0) {
        this.fireT += dt;
        if (this.fireT < 0.35) this.armPivot.rotation.x = U.lerp(this.cocked, 2.1, this.fireT / 0.35);
        else if (this.fireT < 4.5) this.armPivot.rotation.x = U.lerp(2.1, this.cocked, (this.fireT - 0.35) / 4.15);
        else { this.armPivot.rotation.x = this.cocked; this.fireT = -1; }
      }
    }
    dispose() { if (this.hpSprite) { this.hpSprite.material.map.dispose(); this.hpSprite.material.dispose(); } }
  }

  // --------------------------------------------------------- PileModel

  const PILE_COLORS = {
    wood: [[120, 90, 52], [104, 78, 44], [136, 104, 62]],
    stone: [[130, 130, 130], [112, 112, 112], [146, 146, 146]],
    food: [[214, 182, 66], [200, 168, 58], [150, 70, 40]],
    iron: [[96, 96, 104], [120, 120, 128], [84, 84, 90]],
    gold: [[236, 196, 70], [214, 176, 60], [250, 214, 90]]
  };

  /** Visual stockpile: little crates/logs/stones that grow with the amount. */
  class PileModel {
    constructor(type) {
      materials();
      this.type = type;
      this.root = new THREE.Group();
      this.mesh = null;
      this.shown = -1;
    }
    setAmount(n) {
      const units = Math.min(12, Math.ceil(n / 5));
      if (units === this.shown) return;
      this.shown = units;
      if (this.mesh) { this.root.remove(this.mesh); this.mesh = null; }
      if (units <= 0) return;
      const type = this.type;
      const geo = cached('pile_' + type + '_' + units, function () {
        const b = [];
        const cols = PILE_COLORS[type] || PILE_COLORS.wood;
        for (let i = 0; i < units; i++) {
          const layer = Math.floor(i / 6), k = i % 6;
          const x = (k % 3) * 0.34 - 0.34, z = Math.floor(k / 3) * 0.36 - 0.18;
          const y = layer * 0.3;
          const c = cols[i % cols.length];
          if (type === 'wood') b.push(box(x - 0.15, y, -0.5, x + 0.15, y + 0.28, 0.5, c));
          else b.push(box(x - 0.15, y, z - 0.16, x + 0.15, y + 0.28, z + 0.16, c));
        }
        return buildBoxes(b);
      });
      this.mesh = new THREE.Mesh(geo, MAT);
      this.root.add(this.mesh);
    }
  }

  // ------------------------------------------------------- Projectiles

  function projectileGeometry(type) {
    return cached('proj_' + type, function () {
      if (type === 'boulder') {
        return buildBoxes([
          box(-0.36, -0.36, -0.36, 0.36, 0.36, 0.36, [120, 118, 112]),
          box(-0.28, 0.3, -0.2, 0.2, 0.42, 0.25, [100, 98, 94]),
          box(-0.42, -0.2, -0.1, -0.3, 0.2, 0.28, [136, 134, 128])
        ]);
      }
      if (type === 'bolt') {
        return buildBoxes([
          box(-0.03, -0.03, -0.25, 0.03, 0.03, 0.25, [90, 70, 44]),
          box(-0.045, -0.045, 0.25, 0.045, 0.045, 0.34, STEEL_DARK),
          box(-0.07, -0.005, -0.28, 0.07, 0.005, -0.16, [180, 40, 40])
        ]);
      }
      return buildBoxes([
        box(-0.02, -0.02, -0.38, 0.02, 0.02, 0.3, [150, 120, 80]),
        box(-0.035, -0.035, 0.3, 0.035, 0.035, 0.4, STEEL),
        box(-0.07, -0.004, -0.42, 0.07, 0.004, -0.26, [240, 240, 240]),
        box(-0.004, -0.07, -0.42, 0.004, 0.07, -0.26, [240, 240, 240])
      ]);
    });
  }

  VK.Models = {
    FACTION_COLORS: FACTION_COLORS,
    buildBoxes: buildBoxes,
    box: box,
    appearanceFor: appearanceFor,
    playerAppearance: playerAppearance,
    HumanoidModel: HumanoidModel,
    TrebuchetModel: TrebuchetModel,
    PileModel: PileModel,
    projectileGeometry: projectileGeometry,
    material: function () { return materials(); }
  };
})(window.VK);
