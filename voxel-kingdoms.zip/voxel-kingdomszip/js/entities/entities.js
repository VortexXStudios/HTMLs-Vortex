/**
 * @file entities.js
 * Owns every NPC, projectile and dropped item. Maintains a uniform spatial
 * hash (16x16 block cells) rebuilt each frame for fast radius queries used
 * by perception, crowd separation, projectile hits and player targeting.
 */
(function (VK) {
  'use strict';

  const CELL = 16;

  function cellKey(cx, cz) { return (cx + 8192) * 16384 + (cz + 8192); }

  class EntityManager {
    constructor(game) {
      this.game = game;
      this.npcs = [];
      this.byId = new Map();
      this.grid = new Map();
      this.group = new THREE.Group();
      game.scene.add(this.group);
      this.projectiles = new VK.ProjectileSystem(game);
      this.drops = new VK.DropSystem(game);
      this.sep = { x: 0, z: 0 };
      this.sepList = [];
      this.q = [];
    }

    add(npc) {
      this.npcs.push(npc);
      this.byId.set(npc.id, npc);
      this.group.add(npc.model.root);
    }

    remove(npc) {
      const i = this.npcs.indexOf(npc);
      if (i >= 0) this.npcs.splice(i, 1);
      this.byId.delete(npc.id);
      this.group.remove(npc.model.root);
      if (npc.model.dispose) npc.model.dispose();
    }

    rebuildGrid() {
      this.grid.clear();
      for (let i = 0; i < this.npcs.length; i++) {
        const n = this.npcs[i];
        if (n.dead || n.asleep) continue;
        const k = cellKey(Math.floor(n.pos.x / CELL), Math.floor(n.pos.z / CELL));
        let arr = this.grid.get(k);
        if (!arr) { arr = []; this.grid.set(k, arr); }
        arr.push(n);
      }
    }

    /**
     * Living, awake NPCs within a horizontal radius.
     * The returned array is reused; copy it if you need to keep it.
     */
    queryRadius(x, z, r, out) {
      out = out || this.q;
      out.length = 0;
      const x0 = Math.floor((x - r) / CELL), x1 = Math.floor((x + r) / CELL);
      const z0 = Math.floor((z - r) / CELL), z1 = Math.floor((z + r) / CELL);
      const r2 = r * r;
      for (let cz = z0; cz <= z1; cz++) {
        for (let cx = x0; cx <= x1; cx++) {
          const arr = this.grid.get(cellKey(cx, cz));
          if (!arr) continue;
          for (let i = 0; i < arr.length; i++) {
            const n = arr[i];
            const dx = n.pos.x - x, dz = n.pos.z - z;
            if (dx * dx + dz * dz <= r2) out.push(n);
          }
        }
      }
      return out;
    }

    /** Gentle push away from overlapping neighbours (crowd separation). */
    separation(npc) {
      const s = this.sep;
      s.x = 0; s.z = 0;
      const rad = npc.hw + 0.45;
      const list = this.queryRadius(npc.pos.x, npc.pos.z, rad + 1.2, this.sepList);
      for (let i = 0; i < list.length; i++) {
        const o = list[i];
        if (o === npc) continue;
        const dx = npc.pos.x - o.pos.x, dz = npc.pos.z - o.pos.z;
        const min = npc.hw + o.hw + 0.25;
        const d2 = dx * dx + dz * dz;
        if (d2 >= min * min || Math.abs(npc.pos.y - o.pos.y) > 1.5) continue;
        const d = Math.sqrt(d2) || 0.01;
        const push = (min - d) / min;
        s.x += (dx / d) * push * 3;
        s.z += (dz / d) * push * 3;
      }
      return s;
    }

    /** True if an NPC or the player clearly overlaps the block cell. */
    cellOccupied(x, y, z) {
      const list = this.queryRadius(x + 0.5, z + 0.5, 2.5, []);
      for (let i = 0; i < list.length; i++) if (VK.Physics.cellIntersects(list[i], x, y, z, 0.1)) return true;
      const p = this.game.player;
      return !!(p && !p.dead && !p.spectator && VK.Physics.cellIntersects(p, x, y, z, 0.05));
    }

    /** Finds an entity hit by a projectile at `pos` (friendly fire excluded). */
    projectileHitTest(pos, radius, owner, factionId) {
      const list = this.queryRadius(pos.x, pos.z, 3, []);
      for (let i = 0; i < list.length; i++) {
        const n = list[i];
        if (n === owner) continue;
        if (factionId && n.faction.id === factionId) continue;
        if (pos.x > n.pos.x - n.hw - radius && pos.x < n.pos.x + n.hw + radius &&
          pos.z > n.pos.z - n.hw - radius && pos.z < n.pos.z + n.hw + radius &&
          pos.y > n.pos.y - radius && pos.y < n.pos.y + n.h + radius) return n;
      }
      const p = this.game.player;
      if (p && !p.dead && !p.spectator && owner !== p && !(factionId && p.faction === factionId)) {
        if (pos.x > p.pos.x - p.hw - radius && pos.x < p.pos.x + p.hw + radius &&
          pos.z > p.pos.z - p.hw - radius && pos.z < p.pos.z + p.hw + radius &&
          pos.y > p.pos.y - radius && pos.y < p.pos.y + p.h + radius) return p;
      }
      return null;
    }

    /** Explosion damage with linear falloff. */
    areaDamage(pos, r, dmg, owner, factionId) {
      const list = this.queryRadius(pos.x, pos.z, r, []);
      for (let i = 0; i < list.length; i++) {
        const n = list[i];
        if (factionId && n.faction.id === factionId) continue;
        const d = Math.sqrt(Math.pow(n.pos.x - pos.x, 2) + Math.pow(n.pos.y + 0.9 - pos.y, 2) + Math.pow(n.pos.z - pos.z, 2));
        if (d < r) VK.Combat.applyDamage(n, dmg * (1 - d / r), owner, 'blast');
      }
      const p = this.game.player;
      if (p && !p.dead && !p.spectator && !(factionId && p.faction === factionId)) {
        const d = Math.sqrt(Math.pow(p.pos.x - pos.x, 2) + Math.pow(p.pos.y + 0.9 - pos.y, 2) + Math.pow(p.pos.z - pos.z, 2));
        if (d < r) VK.Combat.applyDamage(p, dmg * 0.6 * (1 - d / r), owner, 'blast');
      }
    }

    /** Ray vs NPC boxes (slab test). Returns {entity, t} of the closest hit. */
    raycastEntities(o, dir, maxDist) {
      const list = this.queryRadius(o.x, o.z, maxDist + 2, []);
      let best = null, bestT = maxDist;
      for (let i = 0; i < list.length; i++) {
        const n = list[i];
        const pad = 0.1;
        const min = [n.pos.x - n.hw - pad, n.pos.y, n.pos.z - n.hw - pad];
        const max = [n.pos.x + n.hw + pad, n.pos.y + n.h + pad, n.pos.z + n.hw + pad];
        const org = [o.x, o.y, o.z], dv = [dir.x, dir.y, dir.z];
        let t0 = 0, t1 = bestT, ok = true;
        for (let a = 0; a < 3 && ok; a++) {
          if (Math.abs(dv[a]) < 1e-8) { if (org[a] < min[a] || org[a] > max[a]) ok = false; continue; }
          let ta = (min[a] - org[a]) / dv[a], tb = (max[a] - org[a]) / dv[a];
          if (ta > tb) { const tmp = ta; ta = tb; tb = tmp; }
          t0 = Math.max(t0, ta); t1 = Math.min(t1, tb);
          if (t0 > t1) ok = false;
        }
        if (ok && t0 < bestT) { bestT = t0; best = n; }
      }
      return best ? { entity: best, t: bestT } : null;
    }

    /** Warns nearby soldiers of the same faction about an enemy. */
    alertAllies(npc, enemy, radius) {
      if (!enemy) return;
      const list = this.queryRadius(npc.pos.x, npc.pos.z, radius, []);
      for (let i = 0; i < list.length; i++) {
        const n = list[i];
        if (n === npc || n.faction !== npc.faction || !n.isSoldier || n.isSiege) continue;
        if (!VK.Diplomacy.isHostile(n, enemy)) continue;
        n.alertT = 10;
        if (!n.target) { n.lastAttacker = enemy; n.lastAttackedAt = this.game.elapsed; }
        if (n.squad) n.squad.reportEnemies([enemy]);
      }
    }

    update(dt) {
      this.rebuildGrid();
      for (let i = this.npcs.length - 1; i >= 0; i--) {
        const n = this.npcs[i];
        if (!n.update(dt)) this.remove(n);
      }
      this.projectiles.update(dt);
      this.drops.update(dt);
    }

    clear() {
      this.npcs.slice().forEach((n) => this.remove(n));
      this.projectiles.clear();
      this.drops.clear();
      this.grid.clear();
    }
  }

  VK.EntityManager = EntityManager;
})(window.VK);
