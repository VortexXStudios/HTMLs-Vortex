/**
 * @file projectiles.js
 * Arrows, crossbow bolts and trebuchet boulders with ballistic flight,
 * block collision (arrows stick, boulders explode) and entity hits.
 * Also provides the ballistic aiming solution used by archers, towers
 * and siege engines.
 */
(function (VK) {
  'use strict';

  const B = VK.Blocks;

  const TYPES = {
    arrow: { gravity: 20, drag: 0.08, life: 12, radius: 0.15 },
    bolt: { gravity: 14, drag: 0.05, life: 12, radius: 0.15 },
    boulder: { gravity: 16, drag: 0.0, life: 20, radius: 0.5 }
  };

  class ProjectileSystem {
    constructor(game) {
      this.game = game;
      this.list = [];
      this.group = new THREE.Group();
      game.scene.add(this.group);
      this.tmp = new THREE.Vector3();
    }

    /**
     * Launches a projectile.
     * @param {string} type arrow | bolt | boulder
     * @param {object} opts {owner, factionId, damage, blast, power}
     */
    spawn(type, x, y, z, vx, vy, vz, opts) {
      const def = TYPES[type];
      const mesh = new THREE.Mesh(VK.Models.projectileGeometry(type), VK.Models.material());
      mesh.position.set(x, y, z);
      this.group.add(mesh);
      const p = {
        type: type, def: def, mesh: mesh,
        pos: new THREE.Vector3(x, y, z), vel: new THREE.Vector3(vx, vy, vz),
        owner: opts.owner || null, factionId: opts.factionId || null,
        damage: opts.damage || 4, blast: opts.blast || 0, power: opts.power || 0,
        life: def.life, stuck: false, stuckT: 0
      };
      this.list.push(p);
      return p;
    }

    remove(i) {
      const p = this.list[i];
      this.group.remove(p.mesh);
      this.list.splice(i, 1);
    }

    update(dt) {
      const world = this.game.world;
      const ents = this.game.entities;
      for (let i = this.list.length - 1; i >= 0; i--) {
        const p = this.list[i];
        p.life -= dt;
        if (p.stuck) {
          p.stuckT -= dt;
          if (p.stuckT <= 0 || p.life <= 0) this.remove(i);
          continue;
        }
        if (p.life <= 0 || p.pos.y < 0) { this.remove(i); continue; }
        p.vel.y -= p.def.gravity * dt;
        if (p.def.drag) p.vel.multiplyScalar(Math.max(0, 1 - p.def.drag * dt));
        const speed = p.vel.length();
        const steps = Math.max(1, Math.ceil(speed * dt / 0.4));
        const sdt = dt / steps;
        let done = false;
        for (let s = 0; s < steps && !done; s++) {
          p.pos.addScaledVector(p.vel, sdt);
          // Entity hits
          const target = ents.projectileHitTest(p.pos, p.def.radius, p.owner, p.factionId);
          if (target) {
            if (p.type === 'boulder') this.detonate(p);
            else VK.Combat.projectileHit(p, target);
            this.remove(i);
            done = true;
            break;
          }
          // Block hits
          const bx = Math.floor(p.pos.x), by = Math.floor(p.pos.y), bz = Math.floor(p.pos.z);
          const id = world.peekBlock(bx, by, bz);
          if (id > 0 && B.SOLID[id]) {
            if (p.type === 'boulder') {
              p.pos.addScaledVector(p.vel, -sdt * 0.5);
              this.detonate(p);
              this.remove(i);
            } else {
              p.pos.addScaledVector(p.vel, -sdt * 0.6);
              p.stuck = true;
              p.stuckT = 8;
              if (this.game.audio) this.game.audio.play('arrow', p.pos);
              if (this.game.particles) this.game.particles.blockBurst(bx, by, bz, id, 3);
              // Arrows slowly chip wooden gates and walls during sieges.
              if (p.factionId) world.damageBlock(bx, by, bz, 1, 'siege');
              p.mesh.position.copy(p.pos);
            }
            done = true;
            break;
          }
        }
        if (done || p.stuck) continue;
        p.mesh.position.copy(p.pos);
        if (p.type === 'boulder') {
          p.mesh.rotation.x += dt * 4;
          p.mesh.rotation.z += dt * 3;
        } else {
          this.tmp.copy(p.pos).add(p.vel);
          p.mesh.lookAt(this.tmp);
        }
      }
    }

    /** Boulder impact: blocks and nearby entities take area damage. */
    detonate(p) {
      const g = this.game;
      g.world.explode(p.pos.x, p.pos.y, p.pos.z, p.blast || 2.2, p.power || 60, 'siege');
      g.entities.areaDamage(p.pos, (p.blast || 2.2) + 1.5, p.damage, p.owner, p.factionId);
    }

    clear() {
      for (let i = this.list.length - 1; i >= 0; i--) this.remove(i);
    }
  }

  /**
   * Launch velocity for hitting a target with a projectile of a given speed.
   * @param {boolean} high use the high arc (trebuchets)
   * @returns {THREE.Vector3|null} null if out of range
   */
  ProjectileSystem.aim = function (from, to, speed, gravity, high) {
    const dx = to.x - from.x, dz = to.z - from.z, dy = to.y - from.y;
    const d = Math.sqrt(dx * dx + dz * dz);
    if (d < 0.01) return new THREE.Vector3(0, speed, 0);
    const v2 = speed * speed;
    const disc = v2 * v2 - gravity * (gravity * d * d + 2 * dy * v2);
    if (disc < 0) return null;
    const root = Math.sqrt(disc);
    const angle = Math.atan((v2 + (high ? root : -root)) / (gravity * d));
    const h = Math.cos(angle) * speed;
    return new THREE.Vector3(dx / d * h, Math.sin(angle) * speed, dz / d * h);
  };

  /** Range of a projectile on flat ground. */
  ProjectileSystem.maxRange = function (speed, gravity) { return speed * speed / gravity; };

  ProjectileSystem.TYPES = TYPES;
  VK.ProjectileSystem = ProjectileSystem;
})(window.VK);
