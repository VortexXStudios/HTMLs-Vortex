/**
 * @file drops.js
 * Dropped item entities: small spinning cubes for blocks and billboard
 * sprites for items. They fall with physics, merge with identical nearby
 * drops, get collected by the player and despawn after five minutes.
 */
(function (VK) {
  'use strict';

  const B = VK.Blocks;
  const U = VK.Util;
  const DESPAWN = 300;

  class DropSystem {
    constructor(game) {
      this.game = game;
      this.list = [];
      this.group = new THREE.Group();
      game.scene.add(this.group);
      this.cubeGeos = new Map();
      this.spriteMats = new Map();
      this.cubeMat = new THREE.MeshLambertMaterial({ map: VK.Textures.texture, alphaTest: 0.5 });
      this.mergeTimer = 0;
    }

    cubeGeometry(blockId) {
      let g = this.cubeGeos.get(blockId);
      if (g) return g;
      g = new THREE.BoxGeometry(0.26, 0.26, 0.26);
      const uv = g.attributes.uv;
      const UVT = VK.Textures.uv;
      for (let f = 0; f < 6; f++) {
        const tile = B.faceTile[blockId * 6 + f];
        const u0 = UVT[tile * 4], v0 = UVT[tile * 4 + 1], u1 = UVT[tile * 4 + 2], v1 = UVT[tile * 4 + 3];
        for (let k = 0; k < 4; k++) {
          const i = f * 4 + k;
          uv.setXY(i, u0 + uv.getX(i) * (u1 - u0), v0 + uv.getY(i) * (v1 - v0));
        }
      }
      uv.needsUpdate = true;
      this.cubeGeos.set(blockId, g);
      return g;
    }

    spriteMaterial(itemId) {
      let m = this.spriteMats.get(itemId);
      if (m) return m;
      const tex = new THREE.CanvasTexture(VK.Icons.canvas(itemId));
      tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestFilter;
      tex.generateMipmaps = false;
      m = new THREE.SpriteMaterial({ map: tex, alphaTest: 0.5 });
      this.spriteMats.set(itemId, m);
      return m;
    }

    makeMesh(stack) {
      const def = VK.Items.get(stack.id);
      if (def && def.block !== null && def.block !== undefined && !B.CROSS[def.block] && B.faceTile[def.block * 6 + 2] !== undefined && B.defs[def.block].tex) {
        return new THREE.Mesh(this.cubeGeometry(def.block), this.cubeMat);
      }
      const s = new THREE.Sprite(this.spriteMaterial(stack.id));
      s.scale.set(0.38, 0.38, 0.38);
      return s;
    }

    /** Spawns a drop with a small random toss (or an explicit velocity). */
    spawn(stack, x, y, z, vx, vy, vz) {
      if (!stack || stack.count <= 0) return null;
      const mesh = this.makeMesh(stack);
      this.group.add(mesh);
      const d = {
        stack: { id: stack.id, count: stack.count, dur: stack.dur },
        pos: new THREE.Vector3(x, y, z),
        vel: new THREE.Vector3(vx !== undefined ? vx : U.rand(-1.5, 1.5), vy !== undefined ? vy : U.rand(2, 4), vz !== undefined ? vz : U.rand(-1.5, 1.5)),
        hw: 0.13, h: 0.26, onGround: false, factionId: null,
        age: 0, pickupDelay: 0.6, mesh: mesh, phase: Math.random() * 6
      };
      mesh.position.copy(d.pos);
      this.list.push(d);
      return d;
    }

    remove(i) {
      this.group.remove(this.list[i].mesh);
      this.list.splice(i, 1);
    }

    update(dt) {
      const g = this.game;
      const player = g.player;
      this.mergeTimer += dt;
      const doMerge = this.mergeTimer > 1;
      if (doMerge) this.mergeTimer = 0;
      for (let i = this.list.length - 1; i >= 0; i--) {
        const d = this.list[i];
        d.age += dt;
        if (d.age > DESPAWN) { this.remove(i); continue; }
        // Physics
        const dxp = d.pos.x - g.camera.position.x, dzp = d.pos.z - g.camera.position.z;
        const far = dxp * dxp + dzp * dzp > 80 * 80;
        if (!far) {
          d.vel.y -= 22 * dt;
          if (d.onGround) { d.vel.x *= Math.max(0, 1 - 8 * dt); d.vel.z *= Math.max(0, 1 - 8 * dt); }
          if (d.inWater) { d.vel.y = Math.min(d.vel.y + 30 * dt, 1.2); d.vel.multiplyScalar(0.96); }
          VK.Physics.move(g.world, d, dt);
        }
        d.mesh.visible = !far;
        d.mesh.position.set(d.pos.x, d.pos.y + 0.15 + Math.sin(d.age * 2.5 + d.phase) * 0.06, d.pos.z);
        d.mesh.rotation.y = d.age * 1.6 + d.phase;

        // Pickup by the player.
        if (player && !player.dead && d.age > d.pickupDelay) {
          const px = player.pos.x - d.pos.x, py = player.pos.y + 0.6 - d.pos.y, pz = player.pos.z - d.pos.z;
          if (px * px + py * py + pz * pz < 2.6) {
            const left = player.inventory.add(d.stack.id, d.stack.count, d.stack.dur);
            if (left < d.stack.count) {
              if (g.audio) g.audio.play('pickup');
              if (g.ui) g.ui.hud.flashItem(d.stack.id);
            }
            if (left <= 0) { this.remove(i); continue; }
            d.stack.count = left;
          }
        }

        // Merge identical stacks lying close together.
        if (doMerge && !d.stack.dur) {
          for (let j = i - 1; j >= 0; j--) {
            const o = this.list[j];
            if (o.stack.id !== d.stack.id || o.stack.dur) continue;
            if (o.pos.distanceToSquared(d.pos) > 1.2) continue;
            const max = VK.Items.maxStack(d.stack.id);
            if (o.stack.count + d.stack.count > max) continue;
            o.stack.count += d.stack.count;
            this.remove(i);
            break;
          }
        }
      }
    }

    clear() {
      for (let i = this.list.length - 1; i >= 0; i--) this.remove(i);
    }
  }

  VK.DropSystem = DropSystem;
})(window.VK);
