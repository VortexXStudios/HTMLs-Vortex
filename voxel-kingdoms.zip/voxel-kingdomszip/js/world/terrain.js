/**
 * @file terrain.js
 * Deterministic procedural terrain: continents, plains, hills, forests,
 * ridged mountains with snow caps, meandering rivers, oceans, beaches,
 * spaghetti caves, ore veins, trees and ground plants.
 *
 * "Sites" (the two capital cities) are levelled so castles can be built on
 * them; everything else is a pure function of the seed and coordinates, so
 * chunks can be regenerated at any time and only player/NPC modifications
 * need to be stored.
 */
(function (VK) {
  'use strict';

  const CS = VK.Config.CHUNK_SIZE;
  const H = VK.Config.WORLD_HEIGHT;
  const SEA = VK.Config.SEA_LEVEL;
  const B = VK.Blocks;
  const U = VK.Util;
  const N = VK.Noise;

  const BIOME = { OCEAN: 0, BEACH: 1, PLAINS: 2, FOREST: 3, HILLS: 4, MOUNTAINS: 5, TAIGA: 6, RIVER: 7 };
  const BIOME_NAMES = ['Ocean', 'Beach', 'Plains', 'Forest', 'Hills', 'Mountains', 'Taiga', 'River'];
  const TREE_DENSITY = [0, 0, 0.004, 0.055, 0.013, 0.012, 0.036, 0];

  // Cave noise lattice (sampled every 4 blocks and trilinearly interpolated)
  const CG = 4;
  const CGX = CS / CG + 1;      // 5
  const CGY = H / CG + 1;       // 33

  class TerrainGenerator {
    constructor(seed) {
      this.seed = seed >>> 0;
      const s = this.seed;
      this.nCont = new N.Simplex(s ^ 0x1a2b3c);
      this.nWarp = new N.Simplex(s ^ 0x2b3c4d);
      this.nHill = new N.Simplex(s ^ 0x3c4d5e);
      this.nHillMask = new N.Simplex(s ^ 0x4d5e6f);
      this.nDetail = new N.Simplex(s ^ 0x5e6f70);
      this.nMount = new N.Simplex(s ^ 0x6f7081);
      this.nRidge = new N.Simplex(s ^ 0x708192);
      this.nRiver = new N.Simplex(s ^ 0x8192a3);
      this.nTemp = new N.Simplex(s ^ 0x92a3b4);
      this.nMoist = new N.Simplex(s ^ 0xa3b4c5);
      this.nForest = new N.Simplex(s ^ 0xb4c5d6);
      this.nCave1 = new N.Simplex(s ^ 0xc5d6e7);
      this.nCave2 = new N.Simplex(s ^ 0xd6e7f8);
      this.sites = [];
      // Reusable output of sample()
      this.col = { h: 0, biome: 0, temp: 0, moist: 0, riverT: 1, siteW: 0, mountain: 0 };
      // Scratch buffers for a chunk
      this.hBuf = new Int16Array(CS * CS);
      this.bBuf = new Uint8Array(CS * CS);
      this.tBuf = new Float32Array(CS * CS);
      this.sBuf = new Float32Array(CS * CS);
      this.cave1 = new Float32Array(CGX * CGY * CGX);
      this.cave2 = new Float32Array(CGX * CGY * CGX);
    }

    /** Registers a levelled building site (capital). Must happen before generation. */
    addSite(x, z, radius, height) {
      this.sites.push({ x: x, z: z, r: radius, h: height });
    }

    /**
     * Samples the terrain column at world (x, z). Returns a shared object;
     * copy the values you need before calling sample() again.
     */
    sample(x, z) {
      const fbm = N.fbm2;
      const wx = x + this.nWarp.noise2D(x * 0.004, z * 0.004) * 36;
      const wz = z + this.nWarp.noise2D(x * 0.004 + 71.3, z * 0.004 - 33.1) * 36;

      const cont = fbm(this.nCont, wx * 0.0021, wz * 0.0021, 3);
      const hillMask = U.smoothstep(-0.15, 0.45, fbm(this.nHillMask, x * 0.0045, z * 0.0045, 2));
      const hills = fbm(this.nHill, wx * 0.013, wz * 0.013, 3);
      const detail = this.nDetail.noise2D(x * 0.06, z * 0.06);
      const mountain = U.smoothstep(0.18, 0.6, fbm(this.nMount, wx * 0.0032, wz * 0.0032, 2));

      let h = SEA + 5 + cont * 11 + detail * 1.2 + hills * (2.5 + hillMask * 11);
      if (mountain > 0) {
        const ridge = N.ridged2(this.nRidge, wx * 0.0075, wz * 0.0075, 4);
        h += mountain * (ridge * 58 + 6);
      }

      // Rivers follow the zero-crossings of a low frequency noise field.
      const rv = Math.abs(fbm(this.nRiver, wx * 0.0022, wz * 0.0022, 2));
      let riverT = U.smoothstep(0.012, 0.075, rv);

      // Levelled sites for the capital cities.
      let siteW = 0, siteH = 0;
      for (let i = 0; i < this.sites.length; i++) {
        const s = this.sites[i];
        const d = U.dist2(x, z, s.x, s.z);
        const w = 1 - U.smoothstep(s.r * 0.75, s.r + 30, d);
        if (w > siteW) { siteW = w; siteH = s.h; }
      }
      if (siteW > 0) {
        h = U.lerp(h, siteH, siteW);
        riverT = U.lerp(riverT, 1, siteW);
      }

      if (riverT < 1) {
        const bed = SEA - 2 - (1 - riverT) * 3;
        if (h > bed) h = U.lerp(bed, h, riverT);
      }

      const temp = this.nTemp.noise2D(x * 0.0014, z * 0.0014) - Math.max(0, h - SEA - 20) * 0.02;
      const moist = fbm(this.nMoist, x * 0.0028 + 10, z * 0.0028 - 10, 2);

      let biome;
      if (h < SEA - 1) biome = (riverT < 0.9 && cont > -0.35) ? BIOME.RIVER : BIOME.OCEAN;
      else if (h <= SEA + 1 && (riverT < 0.95 || cont < -0.2)) biome = BIOME.BEACH;
      else if (h > SEA + 34 || mountain > 0.5) biome = BIOME.MOUNTAINS;
      else if (moist > 0.1) biome = temp < -0.3 ? BIOME.TAIGA : BIOME.FOREST;
      else if (hillMask > 0.55 && hills > 0) biome = BIOME.HILLS;
      else biome = temp < -0.45 ? BIOME.TAIGA : BIOME.PLAINS;

      const c = this.col;
      c.h = Math.max(4, Math.min(H - 12, Math.floor(h)));
      c.biome = biome;
      c.temp = temp;
      c.moist = moist;
      c.riverT = riverT;
      c.siteW = siteW;
      c.mountain = mountain;
      return c;
    }

    /** Stone with ore veins (clustered in 2x2x2 cells). */
    stoneAt(x, y, z) {
      const c = U.hash3(x >> 1, y >> 1, z >> 1, this.seed ^ 0x5f3a);
      let ore = 0;
      if (c < 0.014 && y < 100) ore = B.COAL_ORE;
      else if (c < 0.023 && y < 64) ore = B.IRON_ORE;
      else if (c < 0.0265 && y < 34) ore = B.GOLD_ORE;
      else if (c < 0.028 && y < 18) ore = B.DIAMOND_ORE;
      if (ore && U.hash3(x, y, z, this.seed ^ 0x77) < 0.55) return ore;
      return B.STONE;
    }

    /** Samples the two cave noise fields on a coarse lattice for a chunk. */
    buildCaveGrid(bx, bz) {
      for (let gz = 0; gz < CGX; gz++) {
        for (let gx = 0; gx < CGX; gx++) {
          const wx = bx + gx * CG, wz = bz + gz * CG;
          for (let gy = 0; gy < CGY; gy++) {
            const y = gy * CG;
            const i = gx + gz * CGX + gy * CGX * CGX;
            this.cave1[i] = this.nCave1.noise3D(wx / 30, y / 17, wz / 30);
            this.cave2[i] = this.nCave2.noise3D(wx / 30 + 50, y / 17, wz / 30 - 50);
          }
        }
      }
    }

    /** Trilinear interpolation of a cave lattice at local block coordinates. */
    caveValue(arr, x, y, z) {
      const fx = x / CG, fy = y / CG, fz = z / CG;
      const x0 = Math.floor(fx), y0 = Math.floor(fy), z0 = Math.floor(fz);
      const tx = fx - x0, ty = fy - y0, tz = fz - z0;
      const x1 = Math.min(x0 + 1, CGX - 1), y1 = Math.min(y0 + 1, CGY - 1), z1 = Math.min(z0 + 1, CGX - 1);
      const S = CGX, SS = CGX * CGX;
      const c000 = arr[x0 + z0 * S + y0 * SS], c100 = arr[x1 + z0 * S + y0 * SS];
      const c010 = arr[x0 + z0 * S + y1 * SS], c110 = arr[x1 + z0 * S + y1 * SS];
      const c001 = arr[x0 + z1 * S + y0 * SS], c101 = arr[x1 + z1 * S + y0 * SS];
      const c011 = arr[x0 + z1 * S + y1 * SS], c111 = arr[x1 + z1 * S + y1 * SS];
      const a = c000 + (c100 - c000) * tx, b = c010 + (c110 - c010) * tx;
      const c = c001 + (c101 - c001) * tx, d = c011 + (c111 - c011) * tx;
      const e = a + (b - a) * ty, f = c + (d - c) * ty;
      return e + (f - e) * tz;
    }

    isCave(x, y, z) {
      return Math.abs(this.caveValue(this.cave1, x, y, z)) < 0.085 &&
        Math.abs(this.caveValue(this.cave2, x, y, z)) < 0.085;
    }

    /** Fills a chunk's voxel array. Modifications are applied by the World afterwards. */
    generate(chunk) {
      const bx = chunk.cx * CS, bz = chunk.cz * CS;
      const blocks = chunk.blocks;
      blocks.fill(0);
      const hB = this.hBuf, bB = this.bBuf, tB = this.tBuf, sB = this.sBuf;

      for (let z = 0; z < CS; z++) {
        for (let x = 0; x < CS; x++) {
          const c = this.sample(bx + x, bz + z);
          const i = x + z * CS;
          hB[i] = c.h; bB[i] = c.biome; tB[i] = c.temp; sB[i] = c.siteW;
        }
      }
      this.buildCaveGrid(bx, bz);

      const topIds = new Uint8Array(CS * CS);
      for (let z = 0; z < CS; z++) {
        for (let x = 0; x < CS; x++) {
          const i = x + z * CS;
          const h = hB[i], biome = bB[i], temp = tB[i], siteW = sB[i];
          const wx = bx + x, wz = bz + z;
          const hx1 = x < CS - 1 ? hB[i + 1] : h, hx0 = x > 0 ? hB[i - 1] : h;
          const hz1 = z < CS - 1 ? hB[i + CS] : h, hz0 = z > 0 ? hB[i - CS] : h;
          const slope = Math.max(Math.abs(hx1 - hx0), Math.abs(hz1 - hz0));
          const fillerDepth = 3 + (U.hash2(wx, wz, this.seed) < 0.5 ? 1 : 0);

          let top = B.GRASS, filler = B.DIRT;
          switch (biome) {
            case BIOME.OCEAN:
            case BIOME.RIVER:
              top = (h < SEA - 6 || U.hash2(wx, wz, this.seed ^ 0x31) < 0.25) ? B.GRAVEL : B.SAND;
              filler = B.SAND;
              break;
            case BIOME.BEACH:
              top = B.SAND; filler = B.SAND;
              break;
            case BIOME.MOUNTAINS:
              if (h > SEA + 46) { top = B.SNOW; filler = B.STONE; }
              else if (slope >= 3 || h > SEA + 38) { top = B.STONE; filler = B.STONE; }
              break;
            case BIOME.TAIGA:
              if (temp < -0.55 && h > SEA + 12) top = B.SNOW;
              break;
            default:
              if (slope >= 5) { top = B.STONE; filler = B.STONE; }
          }
          if (h < SEA && top === B.GRASS) { top = B.SAND; filler = B.SAND; }
          topIds[i] = top;

          const noCaves = h <= SEA + 2 || siteW > 0.25;
          const maxY = Math.max(h, SEA);
          for (let y = 0; y <= maxY; y++) {
            let id;
            if (y === 0) id = B.BEDROCK;
            else if (y <= 3 && U.hash3(wx, y, wz, this.seed ^ 0xbed) < 1 - y * 0.3) id = B.BEDROCK;
            else if (y < h - fillerDepth) id = this.stoneAt(wx, y, wz);
            else if (y < h) id = filler;
            else if (y === h) id = top;
            else id = y <= SEA ? B.WATER : 0;

            if (id !== 0 && id !== B.WATER && id !== B.BEDROCK && !noCaves && y > 4 && y < h - 2 && this.isCave(x, y, z)) {
              id = 0;
            }
            blocks[x | (z << 4) | (y << 8)] = id;
          }
        }
      }

      this.decoratePlants(chunk, bx, bz, topIds);
      this.decorateTrees(chunk, bx, bz, topIds);
      chunk.generated = true;
    }

    /** Tall grass, flowers and berry bushes on grass blocks. */
    decoratePlants(chunk, bx, bz, topIds) {
      const blocks = chunk.blocks;
      for (let z = 0; z < CS; z++) {
        for (let x = 0; x < CS; x++) {
          const i = x + z * CS;
          if (topIds[i] !== B.GRASS) continue;
          const h = this.hBuf[i];
          if (h + 1 >= H) continue;
          const idx = x | (z << 4) | ((h + 1) << 8);
          if (blocks[idx] !== 0 || blocks[x | (z << 4) | (h << 8)] !== B.GRASS) continue;
          const biome = this.bBuf[i];
          const r = U.hash2(bx + x, bz + z, this.seed ^ 0xabc);
          let grass = 0.1, flower = 0.012, berry = 0;
          if (biome === BIOME.PLAINS) { grass = 0.16; flower = 0.022; }
          else if (biome === BIOME.FOREST) { grass = 0.08; flower = 0.012; berry = 0.007; }
          else if (biome === BIOME.TAIGA) { grass = 0.05; flower = 0.003; berry = 0.005; }
          else if (biome === BIOME.MOUNTAINS) { grass = 0.04; flower = 0.004; }
          if (this.sBuf[i] > 0.8) { flower *= 0.3; berry = 0; }
          if (r < flower) blocks[idx] = U.hash2(bx + x, bz + z, this.seed ^ 0xf10) < 0.5 ? B.FLOWER_RED : B.FLOWER_YELLOW;
          else if (r < flower + berry) blocks[idx] = B.BERRY_BUSH;
          else if (r < flower + berry + grass) blocks[idx] = B.TALL_GRASS;
        }
      }
    }

    /** Places trees whose canopy may overlap this chunk (3-block margin). */
    decorateTrees(chunk, bx, bz, topIds) {
      const blocks = chunk.blocks;
      const self = this;
      const setter = function (x, y, z, id, leaf) {
        const lx = x - bx, lz = z - bz;
        if (lx < 0 || lx >= CS || lz < 0 || lz >= CS || y < 1 || y >= H) return;
        const i = lx | (lz << 4) | (y << 8);
        const cur = blocks[i];
        if (leaf) { if (cur === 0 || B.CROSS[cur]) blocks[i] = id; }
        else if (cur === 0 || B.CROSS[cur] || !B.OPAQUE[cur]) blocks[i] = id;
      };
      for (let lz = -3; lz < CS + 3; lz++) {
        for (let lx = -3; lx < CS + 3; lx++) {
          const wx = bx + lx, wz = bz + lz;
          const tr = U.hash2(wx, wz, this.seed ^ 0x7ee5);
          if (tr > 0.09) continue;
          const inside = lx >= 0 && lx < CS && lz >= 0 && lz < CS;
          let h, biome, top;
          if (inside) {
            const i = lx + lz * CS;
            h = this.hBuf[i]; biome = this.bBuf[i]; top = topIds[i];
          } else {
            const c = this.sample(wx, wz);
            h = c.h; biome = c.biome;
            top = (biome === BIOME.OCEAN || biome === BIOME.RIVER || biome === BIOME.BEACH ||
              (biome === BIOME.MOUNTAINS && h > SEA + 38)) ? B.STONE : B.GRASS;
          }
          if (top !== B.GRASS || h <= SEA) continue;
          let density = TREE_DENSITY[biome];
          if (biome === BIOME.MOUNTAINS && h > SEA + 36) density = 0;
          if (this.nForest.noise2D(wx * 0.011, wz * 0.011) > 0.45 && density > 0) density += 0.02;
          for (let s = 0; s < this.sites.length; s++) {
            const site = this.sites[s];
            const d = U.dist2(wx, wz, site.x, site.z);
            if (d < site.r * 0.85) density = 0;
            else if (d < site.r + 55 && density > 0) density = Math.max(density, 0.035);
            else if (d < site.r + 55) density = 0.03;
          }
          if (tr >= density) continue;
          let type = 'oak';
          const tsel = U.hash2(wx, wz, this.seed ^ 0x51c);
          if (biome === BIOME.TAIGA || biome === BIOME.MOUNTAINS) type = 'spruce';
          else if (biome === BIOME.FOREST) type = tsel < 0.3 ? 'birch' : 'oak';
          else if (biome === BIOME.HILLS) type = tsel < 0.25 ? 'spruce' : 'oak';
          const rng = U.mulberry32((U.hash2(wx, wz, this.seed ^ 0x3ee) * 4294967296) >>> 0);
          self.placeTree(type, wx, h + 1, wz, rng, setter);
        }
      }
    }

    /**
     * Builds a tree using the provided setter(x, y, z, id, isLeaf).
     * Shared by world generation and sapling growth.
     */
    placeTree(type, x, y, z, rnd, set) {
      if (type === 'spruce') {
        const hgt = 6 + Math.floor(rnd() * 4);
        for (let k = 0; k < hgt; k++) set(x, y + k, z, B.SPRUCE_LOG, false);
        const topY = y + hgt;
        set(x, topY, z, B.SPRUCE_LEAVES, true);
        set(x, topY + 1, z, B.SPRUCE_LEAVES, true);
        let r = 0;
        for (let ly = topY - 1; ly >= y + 2; ly--) {
          r = ((topY - ly) % 2 === 1) ? Math.min(3, 1 + Math.floor((topY - ly) / 3)) : Math.max(1, r - 1);
          for (let dz = -r; dz <= r; dz++) {
            for (let dx = -r; dx <= r; dx++) {
              if (dx === 0 && dz === 0) continue;
              if (Math.abs(dx) + Math.abs(dz) > r + 1) continue;
              set(x + dx, ly, z + dz, B.SPRUCE_LEAVES, true);
            }
          }
        }
        return;
      }
      const birch = type === 'birch';
      const log = birch ? B.BIRCH_LOG : B.OAK_LOG;
      const leaf = birch ? B.BIRCH_LEAVES : B.OAK_LEAVES;
      const hgt = (birch ? 5 : 4) + Math.floor(rnd() * 3);
      for (let k = 0; k < hgt; k++) set(x, y + k, z, log, false);
      for (let ly = y + hgt - 3; ly <= y + hgt; ly++) {
        const r = ly >= y + hgt - 1 ? 1 : 2;
        for (let dz = -r; dz <= r; dz++) {
          for (let dx = -r; dx <= r; dx++) {
            if (Math.abs(dx) === r && Math.abs(dz) === r && (ly >= y + hgt - 1 || rnd() < 0.5)) continue;
            if (dx === 0 && dz === 0 && ly < y + hgt) continue;
            set(x + dx, ly, z + dz, leaf, true);
          }
        }
      }
    }

    /**
     * Searches around (x, z) for the best capital site: dry, flat-ish,
     * not mountainous. Must be called before sites are registered.
     */
    findSiteNear(x, z, radius) {
      let best = null, bestScore = Infinity;
      for (let dz = -radius; dz <= radius; dz += 8) {
        for (let dx = -radius; dx <= radius; dx += 8) {
          const cx = x + dx, cz = z + dz;
          const c = this.sample(cx, cz);
          if (c.h <= SEA + 2 || c.mountain > 0.25 || c.riverT < 0.98) continue;
          const center = c.h;
          let score = Math.abs(center - (SEA + 8)) * 0.6 + Math.sqrt(dx * dx + dz * dz) * 0.05;
          let wet = 0;
          for (let a = 0; a < 12; a++) {
            const ang = a / 12 * Math.PI * 2;
            for (const rr of [16, 32]) {
              const s = this.sample(cx + Math.cos(ang) * rr, cz + Math.sin(ang) * rr);
              score += Math.abs(s.h - center) * 0.25;
              if (s.h <= SEA || s.riverT < 0.9) wet++;
            }
          }
          score += wet * 6;
          if (score < bestScore) { bestScore = score; best = { x: cx, z: cz, h: Math.max(center, SEA + 4) }; }
        }
      }
      if (!best) {
        const c = this.sample(x, z);
        best = { x: x, z: z, h: Math.max(c.h, SEA + 5) };
      }
      return best;
    }
  }

  TerrainGenerator.BIOME = BIOME;
  TerrainGenerator.BIOME_NAMES = BIOME_NAMES;
  VK.TerrainGenerator = TerrainGenerator;
})(window.VK);
