/**
 * @file blocks.js
 * Block registry: numeric ids, physical/visual flags, textures per face,
 * harvesting rules, item drops, economy material and siege hit points.
 *
 * Hot paths (meshing, physics, pathfinding) read the flat typed arrays
 * (SOLID, OPAQUE, ...) instead of the definition objects.
 */
(function (VK) {
  'use strict';

  const ID = {
    AIR: 0, GRASS: 1, DIRT: 2, STONE: 3, COBBLESTONE: 4, SAND: 5, GRAVEL: 6, WATER: 7, BEDROCK: 8,
    OAK_LOG: 9, OAK_LEAVES: 10, BIRCH_LOG: 11, BIRCH_LEAVES: 12, SPRUCE_LOG: 13, SPRUCE_LEAVES: 14,
    PLANKS: 15, SPRUCE_PLANKS: 16, COAL_ORE: 17, IRON_ORE: 18, GOLD_ORE: 19, DIAMOND_ORE: 20,
    SNOW: 21, GLASS: 22, STONE_BRICKS: 23, BRICKS: 24, CRAFTING_TABLE: 25, FURNACE: 26,
    TALL_GRASS: 27, FLOWER_RED: 28, FLOWER_YELLOW: 29, WHEAT_0: 30, WHEAT_1: 31, WHEAT_2: 32, WHEAT_3: 33,
    FARMLAND: 34, BLUE_WOOL: 35, RED_WOOL: 36, WHITE_WOOL: 37, HAY: 38, TORCH: 39, CHEST: 40,
    BERRY_BUSH: 41, BERRY_BUSH_EMPTY: 42, MOSSY_COBBLE: 43, GATE_BLUE: 44, GATE_RED: 45, SLATE: 46,
    ROOF_TILES: 47, SAPLING: 48, IRON_BLOCK: 49, GOLD_BLOCK: 50, THATCH: 51, SANDSTONE: 52,
    CRACKED_BRICKS: 53
  };

  // Face order used everywhere: +x, -x, +y, -y, +z, -z
  const FACE_PX = 0, FACE_NX = 1, FACE_PY = 2, FACE_NY = 3, FACE_PZ = 4, FACE_NZ = 5;

  const Blocks = Object.assign({}, ID);
  Blocks.ID = ID;
  Blocks.defs = [];
  Blocks.SOLID = new Uint8Array(256);
  Blocks.OPAQUE = new Uint8Array(256);
  Blocks.LIQUID = new Uint8Array(256);
  Blocks.CROSS = new Uint8Array(256);
  Blocks.SELFCULL = new Uint8Array(256);
  Blocks.LIGHT = new Uint8Array(256);
  Blocks.REPLACEABLE = new Uint8Array(256);
  Blocks.GROWABLE = new Uint8Array(256);
  Blocks.GROUND = new Uint8Array(256);       // natural ground an NPC may stand on
  Blocks.faceTile = new Int16Array(256 * 6);
  Blocks.FACES = { PX: FACE_PX, NX: FACE_NX, PY: FACE_PY, NY: FACE_NY, PZ: FACE_PZ, NZ: FACE_NZ };

  function titleCase(name) {
    return name.split('_').map(function (w) { return w.charAt(0).toUpperCase() + w.slice(1); }).join(' ');
  }

  /**
   * Registers a block definition.
   * Properties:
   *   solid/opaque/liquid/cross/selfCull  render + collision flags
   *   hardness     seconds-ish base break time (-1 = unbreakable)
   *   tool         'pickaxe' | 'axe' | 'shovel' | null (preferred tool)
   *   needsTool    true if it drops nothing without the right tool
   *   tier         minimum tool tier to harvest
   *   material     faction economy resource consumed when NPCs place it
   *   siegeHp      damage points needed to break it in combat
   *   drops        array of {id, min, max, chance} (defaults to its own item)
   */
  function reg(id, name, p) {
    const d = Object.assign({
      id: id,
      name: name,
      displayName: titleCase(name),
      solid: true,
      opaque: true,
      liquid: false,
      cross: false,
      selfCull: false,
      hardness: 1,
      tool: null,
      needsTool: false,
      tier: 0,
      material: null,
      siegeHp: 20,
      light: 0,
      replaceable: false,
      growable: false,
      ground: false,
      tex: name,
      item: name,
      drops: null
    }, p || {});
    if (d.drops === null && d.item) d.drops = [{ id: d.item, min: 1, max: 1 }];
    Blocks.defs[id] = d;
  }

  reg(ID.AIR, 'air', { solid: false, opaque: false, hardness: 0, tex: null, item: null, drops: [] });
  reg(ID.GRASS, 'grass', { tex: { top: 'grass_top', side: 'grass_side', bottom: 'dirt' }, hardness: 0.6, tool: 'shovel', item: null, drops: [{ id: 'dirt' }], siegeHp: 12, ground: true, displayName: 'Grass Block' });
  reg(ID.DIRT, 'dirt', { hardness: 0.5, tool: 'shovel', siegeHp: 10, ground: true });
  reg(ID.STONE, 'stone', { hardness: 1.5, tool: 'pickaxe', needsTool: true, tier: 1, material: 'stone', drops: [{ id: 'cobblestone' }], siegeHp: 45, ground: true });
  reg(ID.COBBLESTONE, 'cobblestone', { hardness: 2, tool: 'pickaxe', needsTool: true, tier: 1, material: 'stone', siegeHp: 40 });
  reg(ID.SAND, 'sand', { hardness: 0.5, tool: 'shovel', siegeHp: 8, ground: true });
  reg(ID.GRAVEL, 'gravel', { hardness: 0.6, tool: 'shovel', drops: [{ id: 'flint', chance: 0.3, alt: 'gravel' }], siegeHp: 8, ground: true });
  reg(ID.WATER, 'water', { solid: false, opaque: false, liquid: true, selfCull: true, hardness: -1, item: null, drops: [] });
  reg(ID.BEDROCK, 'bedrock', { hardness: -1, item: null, drops: [], siegeHp: 1e9, ground: true });

  const LOG = { hardness: 2, tool: 'axe', material: 'wood', siegeHp: 30 };
  const LEAVES = { opaque: false, selfCull: true, hardness: 0.2, siegeHp: 3 };
  reg(ID.OAK_LOG, 'oak_log', Object.assign({ tex: { top: 'oak_log_top', bottom: 'oak_log_top', side: 'oak_log' } }, LOG));
  reg(ID.OAK_LEAVES, 'oak_leaves', Object.assign({ item: null, drops: [{ id: 'sapling', chance: 0.06 }, { id: 'apple', chance: 0.05 }] }, LEAVES));
  reg(ID.BIRCH_LOG, 'birch_log', Object.assign({ tex: { top: 'birch_log_top', bottom: 'birch_log_top', side: 'birch_log' } }, LOG));
  reg(ID.BIRCH_LEAVES, 'birch_leaves', Object.assign({ item: null, drops: [{ id: 'sapling', chance: 0.06 }] }, LEAVES));
  reg(ID.SPRUCE_LOG, 'spruce_log', Object.assign({ tex: { top: 'spruce_log_top', bottom: 'spruce_log_top', side: 'spruce_log' } }, LOG));
  reg(ID.SPRUCE_LEAVES, 'spruce_leaves', Object.assign({ item: null, drops: [{ id: 'sapling', chance: 0.06 }] }, LEAVES));

  reg(ID.PLANKS, 'planks', { hardness: 2, tool: 'axe', material: 'wood', siegeHp: 22, displayName: 'Oak Planks' });
  reg(ID.SPRUCE_PLANKS, 'spruce_planks', { hardness: 2, tool: 'axe', material: 'wood', siegeHp: 22 });

  reg(ID.COAL_ORE, 'coal_ore', { hardness: 3, tool: 'pickaxe', needsTool: true, tier: 1, material: 'stone', drops: [{ id: 'coal', min: 1, max: 2 }], siegeHp: 45, ground: true });
  reg(ID.IRON_ORE, 'iron_ore', { hardness: 3, tool: 'pickaxe', needsTool: true, tier: 2, material: 'iron', siegeHp: 45, ground: true });
  reg(ID.GOLD_ORE, 'gold_ore', { hardness: 3, tool: 'pickaxe', needsTool: true, tier: 3, material: 'gold', siegeHp: 45, ground: true });
  reg(ID.DIAMOND_ORE, 'diamond_ore', { hardness: 3, tool: 'pickaxe', needsTool: true, tier: 3, material: 'gold', drops: [{ id: 'diamond' }], siegeHp: 50, ground: true });

  reg(ID.SNOW, 'snow', { hardness: 0.3, tool: 'shovel', siegeHp: 6, ground: true, displayName: 'Snow Block' });
  reg(ID.GLASS, 'glass', { opaque: false, selfCull: true, hardness: 0.3, material: 'stone', drops: [], siegeHp: 4 });
  reg(ID.STONE_BRICKS, 'stone_bricks', { hardness: 1.5, tool: 'pickaxe', needsTool: true, tier: 1, material: 'stone', siegeHp: 55 });
  reg(ID.BRICKS, 'bricks', { hardness: 2, tool: 'pickaxe', needsTool: true, tier: 1, material: 'stone', siegeHp: 52 });
  reg(ID.CRAFTING_TABLE, 'crafting_table', { tex: { top: 'crafting_table_top', bottom: 'planks', side: 'crafting_table_side' }, hardness: 2.5, tool: 'axe', material: 'wood', siegeHp: 20 });
  reg(ID.FURNACE, 'furnace', { tex: { top: 'furnace_top', bottom: 'furnace_top', side: 'furnace_side', front: 'furnace_front' }, hardness: 3.5, tool: 'pickaxe', needsTool: true, tier: 1, material: 'stone', siegeHp: 40 });

  const PLANT = { solid: false, opaque: false, cross: true, hardness: 0, siegeHp: 1 };
  reg(ID.TALL_GRASS, 'tall_grass', Object.assign({ replaceable: true, item: null, drops: [{ id: 'wheat_seeds', chance: 0.14 }, { id: 'plant_fiber', chance: 0.5 }] }, PLANT));
  reg(ID.FLOWER_RED, 'flower_red', Object.assign({ displayName: 'Poppy' }, PLANT));
  reg(ID.FLOWER_YELLOW, 'flower_yellow', Object.assign({ displayName: 'Dandelion' }, PLANT));
  reg(ID.WHEAT_0, 'wheat_0', Object.assign({ growable: true, item: null, drops: [{ id: 'wheat_seeds' }], displayName: 'Wheat Crop' }, PLANT));
  reg(ID.WHEAT_1, 'wheat_1', Object.assign({ growable: true, item: null, drops: [{ id: 'wheat_seeds' }], displayName: 'Wheat Crop' }, PLANT));
  reg(ID.WHEAT_2, 'wheat_2', Object.assign({ growable: true, item: null, drops: [{ id: 'wheat_seeds' }], displayName: 'Wheat Crop' }, PLANT));
  reg(ID.WHEAT_3, 'wheat_3', Object.assign({ item: null, drops: [{ id: 'wheat' }, { id: 'wheat_seeds', min: 1, max: 2 }], displayName: 'Ripe Wheat' }, PLANT));
  reg(ID.FARMLAND, 'farmland', { tex: { top: 'farmland', bottom: 'dirt', side: 'dirt' }, hardness: 0.6, tool: 'shovel', item: null, drops: [{ id: 'dirt' }], siegeHp: 8, ground: true });

  reg(ID.BLUE_WOOL, 'blue_wool', { hardness: 0.8, material: 'food', siegeHp: 10 });
  reg(ID.RED_WOOL, 'red_wool', { hardness: 0.8, material: 'food', siegeHp: 10 });
  reg(ID.WHITE_WOOL, 'white_wool', { hardness: 0.8, material: 'food', siegeHp: 10 });
  reg(ID.HAY, 'hay', { tex: { top: 'hay_top', bottom: 'hay_top', side: 'hay_side' }, hardness: 0.5, material: 'food', siegeHp: 10, displayName: 'Hay Bale' });
  reg(ID.TORCH, 'torch', { solid: false, opaque: false, cross: true, hardness: 0, light: 14, siegeHp: 1 });
  reg(ID.CHEST, 'chest', { tex: { top: 'chest_top', bottom: 'chest_top', side: 'chest_side', front: 'chest_front' }, hardness: 2.5, tool: 'axe', material: 'wood', siegeHp: 18 });
  reg(ID.BERRY_BUSH, 'berry_bush', Object.assign({ item: null, drops: [{ id: 'berries', min: 1, max: 3 }] }, PLANT));
  reg(ID.BERRY_BUSH_EMPTY, 'berry_bush_empty', Object.assign({ tex: 'berry_bush_empty', growable: true, item: null, drops: [], displayName: 'Berry Bush' }, PLANT));
  reg(ID.MOSSY_COBBLE, 'mossy_cobblestone', { hardness: 2, tool: 'pickaxe', needsTool: true, tier: 1, material: 'stone', siegeHp: 40 });
  reg(ID.GATE_BLUE, 'gate_blue', { hardness: 3, tool: 'axe', material: 'wood', siegeHp: 36, item: null, drops: [{ id: 'planks', min: 1, max: 2 }], displayName: 'Ironhold Gate', gateFaction: 'ironhold' });
  reg(ID.GATE_RED, 'gate_red', { hardness: 3, tool: 'axe', material: 'wood', siegeHp: 36, item: null, drops: [{ id: 'planks', min: 1, max: 2 }], displayName: 'Redmoor Gate', gateFaction: 'redmoor' });
  reg(ID.SLATE, 'slate', { hardness: 1.5, tool: 'pickaxe', needsTool: true, tier: 1, material: 'stone', siegeHp: 30, displayName: 'Slate Shingles' });
  reg(ID.ROOF_TILES, 'roof_tiles', { hardness: 1.5, tool: 'pickaxe', needsTool: true, tier: 1, material: 'stone', siegeHp: 30, displayName: 'Clay Roof Tiles' });
  reg(ID.SAPLING, 'sapling', Object.assign({ growable: true }, PLANT));
  reg(ID.IRON_BLOCK, 'iron_block', { hardness: 5, tool: 'pickaxe', needsTool: true, tier: 2, material: 'iron', siegeHp: 90, displayName: 'Block of Iron' });
  reg(ID.GOLD_BLOCK, 'gold_block', { hardness: 3, tool: 'pickaxe', needsTool: true, tier: 3, material: 'gold', siegeHp: 70, displayName: 'Block of Gold' });
  reg(ID.THATCH, 'thatch', { hardness: 0.5, material: 'food', siegeHp: 10 });
  reg(ID.SANDSTONE, 'sandstone', { tex: { top: 'sandstone_top', bottom: 'sandstone_top', side: 'sandstone' }, hardness: 0.8, tool: 'pickaxe', needsTool: true, tier: 1, material: 'stone', siegeHp: 36 });
  reg(ID.CRACKED_BRICKS, 'cracked_stone_bricks', { tex: 'stone_brick_cracked', hardness: 1.5, tool: 'pickaxe', needsTool: true, tier: 1, material: 'stone', siegeHp: 35, item: 'stone_bricks', drops: [{ id: 'cobblestone' }] });

  Blocks.count = Blocks.defs.length;

  // Fill the flat flag arrays.
  for (let i = 0; i < Blocks.defs.length; i++) {
    const d = Blocks.defs[i];
    if (!d) continue;
    Blocks.SOLID[i] = d.solid ? 1 : 0;
    Blocks.OPAQUE[i] = d.opaque ? 1 : 0;
    Blocks.LIQUID[i] = d.liquid ? 1 : 0;
    Blocks.CROSS[i] = d.cross ? 1 : 0;
    Blocks.SELFCULL[i] = d.selfCull ? 1 : 0;
    Blocks.LIGHT[i] = d.light;
    Blocks.REPLACEABLE[i] = (d.replaceable || i === ID.AIR || i === ID.WATER) ? 1 : 0;
    Blocks.GROWABLE[i] = d.growable ? 1 : 0;
    Blocks.GROUND[i] = d.ground ? 1 : 0;
  }

  /** Resolves texture names to atlas indices. Call after VK.Textures.build(). */
  Blocks.init = function () {
    const idx = VK.Textures.index;
    for (let i = 0; i < Blocks.defs.length; i++) {
      const d = Blocks.defs[i];
      if (!d || !d.tex) continue;
      let top, bottom, side, front;
      if (typeof d.tex === 'string') { top = bottom = side = front = d.tex; }
      else {
        side = d.tex.side || d.tex.all;
        top = d.tex.top || side;
        bottom = d.tex.bottom || side;
        front = d.tex.front || side;
      }
      const f = function (n) {
        if (idx[n] === undefined) throw new Error('Missing texture tile: ' + n);
        return idx[n];
      };
      Blocks.faceTile[i * 6 + FACE_PX] = f(side);
      Blocks.faceTile[i * 6 + FACE_NX] = f(side);
      Blocks.faceTile[i * 6 + FACE_PY] = f(top);
      Blocks.faceTile[i * 6 + FACE_NY] = f(bottom);
      Blocks.faceTile[i * 6 + FACE_PZ] = f(front);
      Blocks.faceTile[i * 6 + FACE_NZ] = f(side);
      d.color = VK.Textures.avg[Blocks.faceTile[i * 6 + FACE_PY]];
      d.sideColor = VK.Textures.avg[Blocks.faceTile[i * 6 + FACE_PX]];
    }
  };

  Blocks.get = function (id) { return Blocks.defs[id] || Blocks.defs[0]; };

  /** True when a block stops movement for an entity of the given faction. */
  Blocks.blocksMovement = function (id, factionId) {
    if (!Blocks.SOLID[id]) return false;
    if (id === ID.GATE_BLUE) return factionId !== 'ironhold';
    if (id === ID.GATE_RED) return factionId !== 'redmoor';
    return true;
  };

  /** Economy resource needed to place this block (or null if free). */
  Blocks.material = function (id) { const d = Blocks.defs[id]; return d ? d.material : null; };

  /** Whether the given item (tool) can harvest the block's drops. */
  Blocks.canHarvest = function (id, itemDef) {
    const d = Blocks.get(id);
    if (!d.needsTool) return true;
    const tool = itemDef && itemDef.tool;
    return !!(tool && tool.type === d.tool && tool.tier >= d.tier);
  };

  /** Seconds needed to break a block with the given held item (Minecraft-like formula). */
  Blocks.breakTime = function (id, itemDef) {
    const d = Blocks.get(id);
    if (d.hardness < 0) return Infinity;
    if (d.hardness === 0) return 0.05;
    let speed = 1;
    const tool = itemDef && itemDef.tool;
    if (tool && tool.type === d.tool) speed = tool.speed;
    const harvest = Blocks.canHarvest(id, itemDef);
    return d.hardness * (harvest ? 1.5 : 5) / speed;
  };

  /** Rolls the drops of a broken block. Returns [[itemId, count], ...]. */
  Blocks.rollDrops = function (id, itemDef, rng) {
    const d = Blocks.get(id);
    const out = [];
    if (!Blocks.canHarvest(id, itemDef)) return out;
    const r = rng || Math.random;
    (d.drops || []).forEach(function (drop) {
      if (drop.chance !== undefined && r() >= drop.chance) {
        if (drop.alt) out.push([drop.alt, 1]);
        return;
      }
      const min = drop.min || 1, max = drop.max || min;
      const n = min + Math.floor(r() * (max - min + 1));
      if (n > 0) out.push([drop.id, n]);
    });
    return out;
  };

  VK.Blocks = Blocks;
})(window.VK);
