/**
 * @file world.js
 * Infinite voxel world: chunk streaming (generation + meshing with per-frame
 * time budgets), LOD selection, unloading/eviction, block get/set with change
 * tracking, persistence of modifications, ray casting, line of sight, crop
 * and tree growth, and block damage used by sieges.
 *
 * Chunks are regenerated from the seed on demand; only modifications are
 * stored (`mods`), so evicting chunk data from memory is always safe.
 */
(function (VK) {
  'use strict';

  const CS = VK.Config.CHUNK_SIZE;
  const H = VK.Config.WORLD_HEIGHT;
  const B = VK.Blocks;
  const U = VK.Util;

  // ------------------------------------------------------------ Shaders

  const CHUNK_VERT = [
    'attribute vec2 aLight;',
    'varying vec2 vUv;',
    'varying vec2 vLight;',
    'varying float vFogDepth;',
    'varying vec3 vWorld;',
    'void main() {',
    '  vUv = uv;',
    '  vLight = aLight;',
    '  vec4 wp = modelMatrix * vec4(position, 1.0);',
    '  vWorld = wp.xyz;',
    '  vec4 mv = viewMatrix * wp;',
    '  vFogDepth = length(mv.xyz);',
    '  gl_Position = projectionMatrix * mv;',
    '}'
  ].join('\n');

  const CHUNK_FRAG = [
    'uniform sampler2D map;',
    'uniform float uDaylight;',
    'uniform vec3 uSkyTint;',
    'uniform vec3 uFogColor;',
    'uniform float uFogNear;',
    'uniform float uFogFar;',
    'uniform float uTime;',
    'uniform float uWater;',
    'uniform float uAlpha;',
    'varying vec2 vUv;',
    'varying vec2 vLight;',
    'varying float vFogDepth;',
    'varying vec3 vWorld;',
    'void main() {',
    '  vec4 tex = texture2D(map, vUv);',
    '  if (uWater < 0.5 && tex.a < 0.5) discard;',
    '  float sky = vLight.x * uDaylight;',
    '  vec3 light = max(uSkyTint * sky, vec3(1.0, 0.8, 0.55) * vLight.y);',
    '  light = max(light, vec3(0.035));',
    '  vec3 col = tex.rgb * light;',
    '  float alpha = 1.0;',
    '  if (uWater > 0.5) {',
    '    col *= 0.9 + 0.1 * sin(uTime * 1.6 + vWorld.x * 0.8 + vWorld.z * 0.6);',
    '    alpha = uAlpha;',
    '  }',
    '  float f = smoothstep(uFogNear, uFogFar, vFogDepth);',
    '  gl_FragColor = vec4(mix(col, uFogColor, f), alpha);',
    '}'
  ].join('\n');

  class World {
    /**
     * @param {Game} game
     * @param {number} seed
     */
    constructor(game, seed) {
      this.game = game;
      this.seed = seed >>> 0;
      this.terrain = new VK.TerrainGenerator(this.seed);
      this.chunks = new Map();
      this.mods = new Map();        // chunkKey -> Map(blockIndex -> id)
      this.growables = new Set();   // posKeys of crops, saplings, bushes
      this.blockDamage = new Map(); // posKey -> accumulated siege damage
      this.chests = new Map();      // posKey -> Inventory (player chests)
      this.pinned = new Set();      // chunk keys that must stay in memory
      this.onBlockChanged = null;   // callback(x, y, z, oldId, newId, cause)

      this.group = new THREE.Group();
      this.group.name = 'world';
      game.scene.add(this.group);

      // Uniforms shared by the opaque and water materials.
      this.uniforms = {
        map: { value: VK.Textures.texture },
        uDaylight: { value: 1 },
        uSkyTint: { value: new THREE.Color(1, 1, 1) },
        uFogColor: { value: new THREE.Color(0.7, 0.8, 1) },
        uFogNear: { value: 60 },
        uFogFar: { value: 110 },
        uTime: { value: 0 }
      };
      const u = this.uniforms;
      this.matOpaque = new THREE.ShaderMaterial({
        uniforms: {
          map: u.map, uDaylight: u.uDaylight, uSkyTint: u.uSkyTint, uFogColor: u.uFogColor,
          uFogNear: u.uFogNear, uFogFar: u.uFogFar, uTime: u.uTime,
          uWater: { value: 0 }, uAlpha: { value: 1 }
        },
        vertexShader: CHUNK_VERT,
        fragmentShader: CHUNK_FRAG
      });
      this.matWater = new THREE.ShaderMaterial({
        uniforms: {
          map: u.map, uDaylight: u.uDaylight, uSkyTint: u.uSkyTint, uFogColor: u.uFogColor,
          uFogNear: u.uFogNear, uFogFar: u.uFogFar, uTime: u.uTime,
          uWater: { value: 1 }, uAlpha: { value: 0.72 }
        },
        vertexShader: CHUNK_VERT,
        fragmentShader: CHUNK_FRAG,
        transparent: true,
        depthWrite: false,
        side: THREE.DoubleSide
      });

      this.renderDistance = VK.Config.RENDER_DISTANCE;
      this.center = { cx: 0, cz: 0, valid: false };
      this.genQueue = [];
      this.meshQueue = [];
      this.urgent = new Set();
      this.scanTimer = 0;
      this.growTimer = 0;
      this.needsScan = true;
      this._last = null;
      this.stats = { generated: 0, meshed: 0, meshMs: 0 };
    }

    // ----------------------------------------------------------- Chunks

    /** Returns chunk data, generating it synchronously if necessary. */
    ensureChunk(cx, cz) {
      const key = U.chunkKey(cx, cz);
      let c = this.chunks.get(key);
      if (c) return c;
      c = new VK.Chunk(cx, cz);
      this.terrain.generate(c);
      const m = this.mods.get(key);
      if (m) {
        const bx = cx * CS, bz = cz * CS;
        const self = this;
        m.forEach(function (id, idx) {
          c.blocks[idx] = id;
          if (B.GROWABLE[id]) self.growables.add(U.posKey(bx + (idx & 15), idx >> 8, bz + ((idx >> 4) & 15)));
        });
      }
      c.computeMaps();
      this.chunks.set(key, c);
      for (let dz = -1; dz <= 1; dz++) {
        for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dz) continue;
          const n = this.chunks.get(U.chunkKey(cx + dx, cz + dz));
          if (n && n.meshLod >= 0) n.dirty = true;
        }
      }
      this.stats.generated++;
      this.needsScan = true;
      return c;
    }

    hasChunk(cx, cz) { return this.chunks.has(U.chunkKey(cx, cz)); }

    // ----------------------------------------------------------- Blocks

    /** Block id at integer world coordinates (generates the chunk if needed). */
    getBlock(x, y, z) {
      if (y < 0) return B.BEDROCK;
      if (y >= H) return 0;
      const cx = x >> 4, cz = z >> 4;
      let c = this._last;
      if (!c || c.cx !== cx || c.cz !== cz) {
        c = this.chunks.get(U.chunkKey(cx, cz)) || this.ensureChunk(cx, cz);
        this._last = c;
      }
      return c.blocks[(x & 15) | ((z & 15) << 4) | (y << 8)];
    }

    /** Block id if the chunk is loaded, otherwise -1. Never generates. */
    peekBlock(x, y, z) {
      if (y < 0) return B.BEDROCK;
      if (y >= H) return 0;
      const cx = x >> 4, cz = z >> 4;
      let c = this._last;
      if (!c || c.cx !== cx || c.cz !== cz) {
        c = this.chunks.get(U.chunkKey(cx, cz));
        if (!c) return -1;
        this._last = c;
      }
      return c.blocks[(x & 15) | ((z & 15) << 4) | (y << 8)];
    }

    getBlockF(x, y, z) { return this.getBlock(Math.floor(x), Math.floor(y), Math.floor(z)); }

    isSolid(x, y, z) { return B.SOLID[this.getBlock(x, y, z)] === 1; }

    /**
     * Changes a block, records the modification, updates lighting/growth
     * bookkeeping, marks meshes dirty and notifies listeners.
     * @param {object} [opts] { cause: string, urgent: boolean }
     */
    setBlock(x, y, z, id, opts) {
      if (y < 0 || y >= H) return false;
      const c = this.ensureChunk(x >> 4, z >> 4);
      const lx = x & 15, lz = z & 15;
      const idx = lx | (lz << 4) | (y << 8);
      const old = c.blocks[idx];
      if (old === id) return false;
      c.blocks[idx] = id;
      let m = this.mods.get(c.key);
      if (!m) { m = new Map(); this.mods.set(c.key, m); }
      m.set(idx, id);
      c.updateColumn(lx, lz);
      if (old === B.TORCH) c.torches.delete(idx);
      if (id === B.TORCH) c.torches.add(idx);
      const pk = U.posKey(x, y, z);
      if (B.GROWABLE[old]) this.growables.delete(pk);
      if (B.GROWABLE[id]) this.growables.add(pk);
      this.blockDamage.delete(pk);
      this.markDirtyAround(c, lx, lz, B.LIGHT[old] || B.LIGHT[id], opts && opts.urgent);
      if (this.onBlockChanged) this.onBlockChanged(x, y, z, old, id, opts ? opts.cause : null);
      return true;
    }

    markDirtyAround(c, lx, lz, wide, urgent) {
      const list = [c];
      const add = (dx, dz) => {
        const n = this.chunks.get(U.chunkKey(c.cx + dx, c.cz + dz));
        if (n) list.push(n);
      };
      if (wide) {
        for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (dx || dz) add(dx, dz);
      } else {
        const w = lx === 0, e = lx === CS - 1, n = lz === 0, s = lz === CS - 1;
        if (w) add(-1, 0);
        if (e) add(1, 0);
        if (n) add(0, -1);
        if (s) add(0, 1);
        if (w && n) add(-1, -1);
        if (w && s) add(-1, 1);
        if (e && n) add(1, -1);
        if (e && s) add(1, 1);
      }
      for (let i = 0; i < list.length; i++) {
        list[i].dirty = true;
        if (urgent) this.urgent.add(list[i]);
      }
    }

    // --------------------------------------------------------- Queries

    /**
     * Surface information of a column: the y an entity would stand at
     * (ignoring tree canopies), whether that is water, and the ground block.
     */
    surface(x, z) {
      const c = this.ensureChunk(x >> 4, z >> 4);
      const col = (x & 15) | ((z & 15) << 4);
      let y = c.topMap[col];
      while (y > 0) {
        const id = c.blocks[col | (y << 8)];
        if (id === B.WATER) return { y: y + 1, water: true, ground: id };
        if (B.SOLID[id] && id !== B.OAK_LEAVES && id !== B.BIRCH_LEAVES && id !== B.SPRUCE_LEAVES &&
          id !== B.OAK_LOG && id !== B.BIRCH_LOG && id !== B.SPRUCE_LOG) {
          return { y: y + 1, water: false, ground: id };
        }
        y--;
      }
      return { y: 1, water: false, ground: B.BEDROCK };
    }

    /** Feet-level y of the ground at a column. */
    groundY(x, z) { return this.surface(Math.floor(x), Math.floor(z)).y; }

    /** True if an entity of the given faction can stand with its feet at (x, y, z). */
    isStandable(x, y, z, faction) {
      const a = this.getBlock(x, y, z), b = this.getBlock(x, y + 1, z);
      if (B.blocksMovement(a, faction) || B.blocksMovement(b, faction)) return false;
      if (a === B.WATER) return true;
      const below = this.getBlock(x, y - 1, z);
      return B.SOLID[below] === 1 || below === B.WATER;
    }

    /** Nearest standable cell to (x, y, z) searching outwards. */
    findStandableNear(x, y, z, radius, faction) {
      x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
      for (let r = 0; r <= radius; r++) {
        for (let dz = -r; dz <= r; dz++) {
          for (let dx = -r; dx <= r; dx++) {
            if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
            for (let dy = 0; dy <= 4; dy++) {
              for (const s of [1, -1]) {
                const yy = y + dy * s;
                if (yy < 1 || yy >= H - 2) continue;
                if (this.isStandable(x + dx, yy, z + dz, faction)) return { x: x + dx, y: yy, z: z + dz };
              }
            }
          }
        }
      }
      return null;
    }

    /**
     * Voxel ray cast (Amanatides & Woo DDA).
     * @param {function(id,x,y,z):boolean} stop returns true to stop at a block
     * @returns {{x,y,z,id,nx,ny,nz,t}|null}
     */
    raycast(ox, oy, oz, dx, dy, dz, maxDist, stop) {
      let x = Math.floor(ox), y = Math.floor(oy), z = Math.floor(oz);
      const stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1, stepZ = dz > 0 ? 1 : -1;
      const tDX = dx !== 0 ? Math.abs(1 / dx) : Infinity;
      const tDY = dy !== 0 ? Math.abs(1 / dy) : Infinity;
      const tDZ = dz !== 0 ? Math.abs(1 / dz) : Infinity;
      let tMX = dx !== 0 ? (dx > 0 ? (x + 1 - ox) : (ox - x)) * tDX : Infinity;
      let tMY = dy !== 0 ? (dy > 0 ? (y + 1 - oy) : (oy - y)) * tDY : Infinity;
      let tMZ = dz !== 0 ? (dz > 0 ? (z + 1 - oz) : (oz - z)) * tDZ : Infinity;
      let t = 0, nx = 0, ny = 0, nz = 0;
      for (let guard = 0; guard < 512 && t <= maxDist; guard++) {
        const id = this.peekBlock(x, y, z);
        if (id > 0 && stop(id, x, y, z)) return { x: x, y: y, z: z, id: id, nx: nx, ny: ny, nz: nz, t: t };
        if (tMX < tMY && tMX < tMZ) { x += stepX; t = tMX; tMX += tDX; nx = -stepX; ny = 0; nz = 0; }
        else if (tMY < tMZ) { y += stepY; t = tMY; tMY += tDY; nx = 0; ny = -stepY; nz = 0; }
        else { z += stepZ; t = tMZ; tMZ += tDZ; nx = 0; ny = 0; nz = -stepZ; }
      }
      return null;
    }

    /** True if nothing opaque blocks the segment a -> b. */
    lineOfSight(ax, ay, az, bx, by, bz) {
      const dx = bx - ax, dy = by - ay, dz = bz - az;
      const len = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (len < 0.01) return true;
      const hit = this.raycast(ax, ay, az, dx / len, dy / len, dz / len, len - 0.3, function (id) { return B.OPAQUE[id] === 1; });
      return hit === null;
    }

    // --------------------------------------------------- Damage / growth

    /**
     * Applies siege damage to a block; breaks it when its hit points are used up.
     * @returns {boolean} true if the block broke
     */
    damageBlock(x, y, z, amount, cause) {
      const id = this.getBlock(x, y, z);
      if (id === 0 || B.LIQUID[id] || id === B.BEDROCK) return false;
      const def = B.defs[id];
      const k = U.posKey(x, y, z);
      const dmg = (this.blockDamage.get(k) || 0) + amount;
      const game = this.game;
      if (dmg >= def.siegeHp) {
        if (game.particles) game.particles.blockBurst(x, y, z, id, 18);
        if (game.audio) game.audio.play('break', { x: x + 0.5, y: y + 0.5, z: z + 0.5 });
        this.spillChest(x, y, z, id);
        // Damaged stone bricks crack before breaking completely.
        if (id === B.STONE_BRICKS && Math.random() < 0.35) this.setBlock(x, y, z, B.CRACKED_BRICKS, { cause: cause });
        else this.setBlock(x, y, z, 0, { cause: cause });
        return true;
      }
      this.blockDamage.set(k, dmg);
      if (game.particles && Math.random() < 0.6) game.particles.blockBurst(x, y, z, id, 4);
      return false;
    }

    /** Area damage (trebuchet boulders). Stronger blocks resist more. */
    explode(x, y, z, radius, power, cause) {
      const r = Math.ceil(radius);
      const cx = Math.floor(x), cy = Math.floor(y), cz = Math.floor(z);
      for (let dy = -r; dy <= r; dy++) {
        for (let dz = -r; dz <= r; dz++) {
          for (let dx = -r; dx <= r; dx++) {
            const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (d > radius) continue;
            this.damageBlock(cx + dx, cy + dy, cz + dz, power * (1 - d / (radius + 0.5)) * U.rand(0.7, 1.3), cause);
          }
        }
      }
      if (this.game.particles) this.game.particles.explosion(x, y, z, radius);
      if (this.game.audio) this.game.audio.play('boom', { x: x, y: y, z: z });
    }

    /** Drops the content of a player chest when the block is destroyed. */
    spillChest(x, y, z, id) {
      if (id !== B.CHEST) return;
      const k = U.posKey(x, y, z);
      const inv = this.chests.get(k);
      if (!inv) return;
      const ents = this.game.entities;
      inv.slots.forEach(function (s) {
        if (s && ents) ents.drops.spawn(s, x + 0.5, y + 0.5, z + 0.5);
      });
      this.chests.delete(k);
    }

    /** Grows a sapling into a tree if there is room. */
    growTree(x, y, z) {
      const below = this.getBlock(x, y - 1, z);
      if (below !== B.GRASS && below !== B.DIRT) return;
      for (let k = 1; k < 7; k++) {
        const id = this.getBlock(x, y + k, z);
        if (id !== 0 && !B.CROSS[id] && !B.SELFCULL[id]) return;
      }
      const biome = this.terrain.sample(x, z).biome;
      const BI = VK.TerrainGenerator.BIOME;
      let type = 'oak';
      if (biome === BI.TAIGA || biome === BI.MOUNTAINS) type = 'spruce';
      else if (biome === BI.FOREST && Math.random() < 0.3) type = 'birch';
      this.setBlock(x, y, z, 0, { cause: 'grow' });
      const self = this;
      this.terrain.placeTree(type, x, y, z, Math.random, function (tx, ty, tz, id, leaf) {
        const cur = self.getBlock(tx, ty, tz);
        const ok = leaf ? (cur === 0 || B.CROSS[cur]) : (cur === 0 || B.CROSS[cur] || B.SELFCULL[cur]);
        if (ok) self.setBlock(tx, ty, tz, id, { cause: 'grow' });
      });
    }

    /** Random growth ticks for crops, berry bushes and saplings. */
    tickGrowables(dt) {
      this.growTimer += dt;
      if (this.growTimer < 1) return;
      const step = this.growTimer;
      this.growTimer = 0;
      const changes = [];
      const stale = [];
      this.growables.forEach((k) => {
        const p = U.unpackPosKey(k);
        const c = this.chunks.get(U.chunkKey(p.x >> 4, p.z >> 4));
        if (!c) return;
        const id = c.blocks[(p.x & 15) | ((p.z & 15) << 4) | (p.y << 8)];
        if (id >= B.WHEAT_0 && id <= B.WHEAT_2) {
          if (Math.random() < 0.02 * step) changes.push([p, id + 1]);
        } else if (id === B.BERRY_BUSH_EMPTY) {
          if (Math.random() < 0.008 * step) changes.push([p, B.BERRY_BUSH]);
        } else if (id === B.SAPLING) {
          if (Math.random() < 0.0045 * step) changes.push([p, -1]);
        } else stale.push(k);
      });
      stale.forEach((k) => this.growables.delete(k));
      changes.forEach((ch) => {
        const p = ch[0];
        if (ch[1] < 0) this.growTree(p.x, p.y, p.z);
        else this.setBlock(p.x, p.y, p.z, ch[1], { cause: 'grow' });
      });
    }

    // --------------------------------------------------------- Streaming

    setRenderDistance(r) {
      this.renderDistance = U.clamp(Math.round(r), 3, 14);
      this.needsScan = true;
    }

    /** Rebuilds the generation and meshing queues around the current centre. */
    rescan() {
      const R = this.renderDistance;
      const L = VK.Config.LOD_DISTANCE;
      const cx = this.center.cx, cz = this.center.cz;
      const gen = [], mesh = [];
      const genR2 = (R + 1.5) * (R + 1.5);
      const meshR2 = (R + 0.5) * (R + 0.5);
      for (let dz = -R - 1; dz <= R + 1; dz++) {
        for (let dx = -R - 1; dx <= R + 1; dx++) {
          const d2 = dx * dx + dz * dz;
          if (d2 > genR2) continue;
          const c = this.chunks.get(U.chunkKey(cx + dx, cz + dz));
          if (!c) { gen.push([cx + dx, cz + dz, d2]); continue; }
          if (d2 > meshR2) continue;
          const lod = d2 > L * L ? 1 : 0;
          if ((c.dirty || c.meshLod !== lod) && this.neighboursReady(c)) mesh.push([c, lod, d2 + (c.meshLod < 0 ? 0 : 6)]);
        }
      }
      gen.sort(function (a, b) { return a[2] - b[2]; });
      mesh.sort(function (a, b) { return a[2] - b[2]; });
      this.genQueue = gen;
      this.meshQueue = mesh;

      // Drop meshes that are now out of range.
      const dropR2 = (R + 1.5) * (R + 1.5);
      this.chunks.forEach((c) => {
        if (c.meshLod < 0) return;
        const ddx = c.cx - cx, ddz = c.cz - cz;
        if (ddx * ddx + ddz * ddz > dropR2) this.disposeMesh(c);
      });
      if (this.chunks.size > VK.Config.MAX_DATA_CHUNKS) this.evict();
      this.needsScan = false;
    }

    neighboursReady(c) {
      for (let dz = -1; dz <= 1; dz++) {
        for (let dx = -1; dx <= 1; dx++) {
          if (!this.chunks.has(U.chunkKey(c.cx + dx, c.cz + dz))) return false;
        }
      }
      return true;
    }

    /** Removes far away, unpinned chunk data when over the memory budget. */
    evict() {
      const R = this.renderDistance + 2;
      const cands = [];
      this.chunks.forEach((c) => {
        if (this.pinned.has(c.key)) return;
        const dx = c.cx - this.center.cx, dz = c.cz - this.center.cz;
        const d2 = dx * dx + dz * dz;
        if (d2 <= R * R) return;
        cands.push([c, d2]);
      });
      cands.sort(function (a, b) { return b[1] - a[1]; });
      const excess = this.chunks.size - VK.Config.MAX_DATA_CHUNKS + 48;
      for (let i = 0; i < Math.min(excess, cands.length); i++) {
        const c = cands[i][0];
        this.disposeMesh(c);
        this.chunks.delete(c.key);
        if (this._last === c) this._last = null;
      }
    }

    disposeMesh(c) {
      if (c.meshOpaque) { this.group.remove(c.meshOpaque); c.meshOpaque.geometry.dispose(); c.meshOpaque = null; }
      if (c.meshWater) { this.group.remove(c.meshWater); c.meshWater.geometry.dispose(); c.meshWater = null; }
      c.meshLod = -1;
      c.dirty = true;
    }

    makeMesh(mesh, data, mat, bx, bz, order) {
      if (!data) {
        if (mesh) { this.group.remove(mesh); mesh.geometry.dispose(); }
        return null;
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(data.position, 3));
      g.setAttribute('uv', new THREE.BufferAttribute(data.uv, 2));
      g.setAttribute('aLight', new THREE.BufferAttribute(data.light, 2));
      g.setIndex(new THREE.BufferAttribute(data.index, 1));
      g.computeBoundingSphere();
      if (mesh) {
        mesh.geometry.dispose();
        mesh.geometry = g;
      } else {
        mesh = new THREE.Mesh(g, mat);
        mesh.position.set(bx, 0, bz);
        mesh.matrixAutoUpdate = false;
        mesh.updateMatrix();
        mesh.renderOrder = order;
        this.group.add(mesh);
      }
      return mesh;
    }

    meshChunk(c, lod) {
      const t0 = performance.now();
      const data = VK.Mesher.build(this, c, lod);
      const bx = c.cx * CS, bz = c.cz * CS;
      c.meshOpaque = this.makeMesh(c.meshOpaque, data.opaque, this.matOpaque, bx, bz, 0);
      c.meshWater = this.makeMesh(c.meshWater, data.water, this.matWater, bx, bz, 2);
      c.meshLod = lod;
      c.dirty = false;
      this.stats.meshed++;
      this.stats.meshMs = performance.now() - t0;
    }

    /**
     * Per-frame streaming update around a camera position.
     * @param {number} dt seconds
     */
    update(dt, px, pz) {
      const pcx = Math.floor(px / CS), pcz = Math.floor(pz / CS);
      if (!this.center.valid || pcx !== this.center.cx || pcz !== this.center.cz) {
        this.center.cx = pcx; this.center.cz = pcz; this.center.valid = true;
        this.needsScan = true;
      }
      this.scanTimer += dt;
      if (this.needsScan || this.scanTimer > 0.5) { this.scanTimer = 0; this.rescan(); }

      // Player edits are re-meshed immediately.
      if (this.urgent.size) {
        const L = VK.Config.LOD_DISTANCE;
        this.urgent.forEach((c) => {
          if (!this.chunks.has(c.key) || !this.neighboursReady(c)) return;
          const dx = c.cx - pcx, dz = c.cz - pcz;
          const d2 = dx * dx + dz * dz;
          if (d2 > (this.renderDistance + 0.5) * (this.renderDistance + 0.5)) return;
          this.meshChunk(c, d2 > L * L ? 1 : 0);
        });
        this.urgent.clear();
      }

      const start = performance.now();
      while (this.genQueue.length && performance.now() - start < VK.Config.GEN_BUDGET_MS) {
        const g = this.genQueue.shift();
        if (!this.hasChunk(g[0], g[1])) this.ensureChunk(g[0], g[1]);
      }
      const mstart = performance.now();
      while (this.meshQueue.length && performance.now() - mstart < VK.Config.MESH_BUDGET_MS) {
        const m = this.meshQueue.shift();
        const c = m[0];
        if (!this.chunks.has(c.key)) continue;
        if (!c.dirty && c.meshLod === m[1]) continue;
        if (!this.neighboursReady(c)) continue;
        this.meshChunk(c, m[1]);
      }

      this.uniforms.uTime.value += dt;
      this.tickGrowables(dt);
    }

    /** Synchronously generates and meshes everything around a point (loading screen). */
    pregenerate(px, pz, radius, onProgress) {
      const cx = Math.floor(px / CS), cz = Math.floor(pz / CS);
      const list = [];
      for (let dz = -radius; dz <= radius; dz++) {
        for (let dx = -radius; dx <= radius; dx++) {
          if (dx * dx + dz * dz <= (radius + 0.5) * (radius + 0.5)) list.push([cx + dx, cz + dz]);
        }
      }
      let i = 0;
      const self = this;
      return new Promise(function (resolve) {
        function step() {
          const t0 = performance.now();
          while (i < list.length && performance.now() - t0 < 30) {
            self.ensureChunk(list[i][0], list[i][1]);
            i++;
          }
          if (onProgress) onProgress(i / list.length);
          if (i < list.length) U.nextFrame().then(step);
          else resolve();
        }
        step();
      });
    }

    /** Immediately meshes the loaded chunks around a point (after loading). */
    meshAround(px, pz, radius) {
      const cx = Math.floor(px / CS), cz = Math.floor(pz / CS);
      this.center.cx = cx; this.center.cz = cz; this.center.valid = true;
      for (let dz = -radius; dz <= radius; dz++) {
        for (let dx = -radius; dx <= radius; dx++) {
          const c = this.chunks.get(U.chunkKey(cx + dx, cz + dz));
          if (c && this.neighboursReady(c)) this.meshChunk(c, 0);
        }
      }
      this.needsScan = true;
    }

    // ------------------------------------------------------ Persistence

    serialize() {
      const mods = {};
      this.mods.forEach(function (m, key) {
        const arr = [];
        m.forEach(function (id, idx) { arr.push(idx, id); });
        mods[key] = arr;
      });
      const chests = [];
      this.chests.forEach(function (inv, k) { chests.push([k, inv.serialize()]); });
      return { seed: this.seed, mods: mods, chests: chests };
    }

    deserialize(data) {
      this.mods = new Map();
      const mods = data.mods || {};
      Object.keys(mods).forEach((key) => {
        const arr = mods[key];
        const m = new Map();
        for (let i = 0; i < arr.length; i += 2) m.set(arr[i], arr[i + 1]);
        this.mods.set(Number(key), m);
      });
      this.chests = new Map();
      (data.chests || []).forEach((e) => {
        const inv = new VK.Inventory(27);
        inv.deserialize(e[1]);
        this.chests.set(e[0], inv);
      });
    }

    /** Frees all GPU resources. */
    dispose() {
      this.chunks.forEach((c) => this.disposeMesh(c));
      this.chunks.clear();
      this.game.scene.remove(this.group);
      this.matOpaque.dispose();
      this.matWater.dispose();
    }
  }

  VK.World = World;
})(window.VK);
