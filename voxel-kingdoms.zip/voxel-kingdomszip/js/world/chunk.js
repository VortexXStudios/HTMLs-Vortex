/**
 * @file chunk.js
 * A 16 x 128 x 16 column of voxels plus derived per-column maps.
 *
 * Block index layout: x | z << 4 | y << 8  (one byte per block).
 *   heightMap[col] highest y of a light-blocking (opaque) block, -1 if none
 *   topMap[col]    highest y of any non-air block, -1 if none
 */
(function (VK) {
  'use strict';

  const CS = VK.Config.CHUNK_SIZE;
  const H = VK.Config.WORLD_HEIGHT;

  class Chunk {
    constructor(cx, cz) {
      this.cx = cx;
      this.cz = cz;
      this.key = VK.Util.chunkKey(cx, cz);
      this.blocks = new Uint8Array(CS * CS * H);
      this.heightMap = new Int16Array(CS * CS);
      this.topMap = new Int16Array(CS * CS);
      this.maxY = 0;
      this.generated = false;
      // Rendering state
      this.meshOpaque = null;
      this.meshWater = null;
      this.meshLod = -1;       // 0 = full detail, 1 = half resolution, -1 = none
      this.dirty = true;
      // Block light sources (block indices) inside this chunk
      this.torches = new Set();
      // Mini-map colours (RGBA per column), rebuilt lazily
      this.mapColors = null;
      this.mapDirty = true;
    }

    static index(x, y, z) { return x | (z << 4) | (y << 8); }

    get(x, y, z) { return this.blocks[x | (z << 4) | (y << 8)]; }

    set(x, y, z, id) { this.blocks[x | (z << 4) | (y << 8)] = id; }

    /** Recomputes height/top maps, max height and the torch list. */
    computeMaps() {
      const OPAQUE = VK.Blocks.OPAQUE;
      const TORCH = VK.Blocks.TORCH;
      let maxY = 0;
      this.torches.clear();
      for (let z = 0; z < CS; z++) {
        for (let x = 0; x < CS; x++) {
          const col = x | (z << 4);
          let h = -1, top = -1;
          for (let y = H - 1; y >= 0; y--) {
            const id = this.blocks[col | (y << 8)];
            if (id === 0) continue;
            if (top < 0) top = y;
            if (OPAQUE[id]) { h = y; break; }
          }
          this.heightMap[col] = h;
          this.topMap[col] = top;
          if (top > maxY) maxY = top;
        }
      }
      // Torches can only come from modifications; scan cheaply above the ground.
      for (let i = 0; i < this.blocks.length; i++) if (this.blocks[i] === TORCH) this.torches.add(i);
      this.maxY = maxY;
      this.mapDirty = true;
    }

    /** Updates the column maps after a single block change. */
    updateColumn(x, z) {
      const OPAQUE = VK.Blocks.OPAQUE;
      const col = x | (z << 4);
      let h = -1, top = -1;
      for (let y = H - 1; y >= 0; y--) {
        const id = this.blocks[col | (y << 8)];
        if (id === 0) continue;
        if (top < 0) top = y;
        if (OPAQUE[id]) { h = y; break; }
      }
      this.heightMap[col] = h;
      this.topMap[col] = top;
      if (top > this.maxY) this.maxY = top;
      this.mapDirty = true;
    }

    /** Computes a top-down RGBA colour per column for the maps. */
    buildMapColors() {
      if (!this.mapColors) this.mapColors = new Uint8ClampedArray(CS * CS * 4);
      const defs = VK.Blocks.defs;
      const WATER = VK.Blocks.WATER;
      for (let z = 0; z < CS; z++) {
        for (let x = 0; x < CS; x++) {
          const col = x | (z << 4);
          const top = this.topMap[col];
          const o = col * 4;
          if (top < 0) { this.mapColors[o + 3] = 0; continue; }
          const id = this.blocks[col | (top << 8)];
          let c = defs[id] && defs[id].color ? defs[id].color : [128, 128, 128];
          let shade = 0.75 + (top - VK.Config.SEA_LEVEL) * 0.006;
          if (id === WATER) {
            // Darker water when deep.
            let depth = 0;
            for (let y = top; y > 0 && this.blocks[col | (y << 8)] === WATER; y--) depth++;
            shade = 1.05 - Math.min(0.45, depth * 0.05);
          }
          // Simple relief shading from the western neighbour.
          if (x > 0) {
            const tw = this.topMap[col - 1];
            if (tw > top) shade *= 0.86; else if (tw < top) shade *= 1.1;
          }
          this.mapColors[o] = c[0] * shade;
          this.mapColors[o + 1] = c[1] * shade;
          this.mapColors[o + 2] = c[2] * shade;
          this.mapColors[o + 3] = 255;
        }
      }
      this.mapDirty = false;
    }
  }

  VK.Chunk = Chunk;
})(window.VK);
