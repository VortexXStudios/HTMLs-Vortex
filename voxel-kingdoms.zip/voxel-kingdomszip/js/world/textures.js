/**
 * @file textures.js
 * Procedurally paints every block texture (16x16 pixel art) into a single
 * texture atlas at start-up. No image files are needed.
 *
 * API:
 *   VK.Textures.build()            paints the atlas and creates the THREE texture
 *   VK.Textures.index[name]        atlas slot of a named tile
 *   VK.Textures.uv[index*4 + k]    [u0, v0, u1, v1] of a tile (inset against bleeding)
 *   VK.Textures.avgColor(name)     average RGB of a tile (map + particles)
 *   VK.Textures.tileCanvas(name)   16x16 canvas copy (UI icons)
 */
(function (VK) {
  'use strict';

  const T = 16;           // tile size in pixels
  const COLS = 16;        // tiles per atlas row
  const SIZE = T * COLS;  // atlas size in pixels
  const U = VK.Util;

  // ------------------------------------------------------ Pixel utilities

  /** A 16x16 RGBA pixel buffer with a seeded random source. */
  class Tile {
    constructor(seed) {
      this.d = new Uint8ClampedArray(T * T * 4);
      this.r = U.mulberry32(seed);
    }
    set(x, y, c, a) {
      x = ((x % T) + T) % T;
      y = ((y % T) + T) % T;
      const i = (y * T + x) * 4;
      this.d[i] = c[0]; this.d[i + 1] = c[1]; this.d[i + 2] = c[2];
      this.d[i + 3] = a === undefined ? 255 : a;
    }
    get(x, y) {
      x = ((x % T) + T) % T;
      y = ((y % T) + T) % T;
      const i = (y * T + x) * 4;
      return [this.d[i], this.d[i + 1], this.d[i + 2], this.d[i + 3]];
    }
    alpha(x, y) { return this.d[(y * T + x) * 4 + 3]; }
  }

  function jit(t, c, amt) {
    const f = 1 + (t.r() - 0.5) * amt;
    return [c[0] * f, c[1] * f, c[2] * f];
  }
  function mul(c, f) { return [c[0] * f, c[1] * f, c[2] * f]; }
  function fill(t, c, amt) {
    for (let y = 0; y < T; y++) for (let x = 0; x < T; x++) t.set(x, y, jit(t, c, amt));
  }
  function speck(t, c, p, amt) {
    for (let y = 0; y < T; y++) for (let x = 0; x < T; x++) if (t.r() < p) t.set(x, y, jit(t, c, amt || 0.1));
  }
  function clear(t) { t.d.fill(0); }
  function rect(t, x0, y0, w, h, c, amt) {
    for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) t.set(x, y, amt ? jit(t, c, amt) : c);
  }
  function line(t, x0, y0, x1, y1, c, a) {
    const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
    const sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    let err = dx + dy;
    for (;;) {
      t.set(x0, y0, c, a);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * err;
      if (e2 >= dy) { err += dy; x0 += sx; }
      if (e2 <= dx) { err += dx; y0 += sy; }
    }
  }

  /** Tileable Voronoi cells: stones, gravel, cobble. */
  function voronoi(t, count, colorFn, edge, edgeW) {
    const pts = [];
    for (let i = 0; i < count; i++) pts.push([t.r() * T, t.r() * T, colorFn(i)]);
    for (let y = 0; y < T; y++) {
      for (let x = 0; x < T; x++) {
        let d1 = 1e9, d2 = 1e9, best = 0;
        for (let i = 0; i < pts.length; i++) {
          for (let oy = -1; oy <= 1; oy++) {
            for (let ox = -1; ox <= 1; ox++) {
              const dx = x + 0.5 - (pts[i][0] + ox * T);
              const dy = y + 0.5 - (pts[i][1] + oy * T);
              const d = Math.sqrt(dx * dx + dy * dy);
              if (d < d1) { d2 = d1; d1 = d; best = i; } else if (d < d2) d2 = d;
            }
          }
        }
        if (d2 - d1 < (edgeW || 1)) t.set(x, y, jit(t, edge, 0.1));
        else {
          const shade = 1.08 - Math.min(0.2, d1 * 0.04);
          t.set(x, y, jit(t, mul(pts[best][2], shade), 0.1));
        }
      }
    }
  }

  /** Running-bond brick pattern. */
  function bricks(t, brick, mortar, bw, bh, varAmt) {
    for (let row = 0; row < T / bh; row++) {
      const offset = (row % 2) * (bw / 2);
      for (let bx = -1; bx < T / bw + 1; bx++) {
        const c = jit(t, brick, varAmt);
        for (let y = row * bh; y < row * bh + bh; y++) {
          for (let x = bx * bw + offset; x < bx * bw + offset + bw; x++) {
            if (x < 0 || x >= T) continue;
            const lx = x - (bx * bw + offset), ly = y - row * bh;
            if (ly === bh - 1 || lx === bw - 1) t.set(x, y, jit(t, mortar, 0.08));
            else t.set(x, y, jit(t, c, 0.08));
          }
        }
      }
    }
  }

  /** Horizontal boards with staggered seams. */
  function planks(t, base, dark) {
    for (let y = 0; y < T; y++) {
      const row = Math.floor(y / 4);
      const seam = (row * 7 + 3) % T;
      const boardShade = 0.94 + ((row * 37) % 5) * 0.03;
      for (let x = 0; x < T; x++) {
        if (y % 4 === 3 || x === seam) t.set(x, y, jit(t, dark, 0.08));
        else {
          const grain = (Math.sin((x + row * 3) * 1.7) * 0.04) + boardShade;
          t.set(x, y, jit(t, mul(base, grain), 0.08));
        }
      }
    }
  }

  /** Stone background with blobs of ore colour. */
  function ore(t, color, clusters) {
    fill(t, [128, 128, 128], 0.12);
    for (let i = 0; i < clusters; i++) {
      const cx = Math.floor(t.r() * T), cy = Math.floor(t.r() * T);
      const n = 3 + Math.floor(t.r() * 3);
      for (let k = 0; k < n; k++) {
        const x = cx + Math.floor(t.r() * 3) - 1, y = cy + Math.floor(t.r() * 3) - 1;
        t.set(x, y, jit(t, color, 0.18));
        if (t.r() < 0.4) t.set(x + 1, y + 1, jit(t, mul(color, 0.7), 0.1));
      }
    }
  }

  function barkLines(t, base, dark) {
    for (let x = 0; x < T; x++) {
      const colShade = 0.85 + t.r() * 0.3;
      const isLine = (x % 4 === 1) || t.r() < 0.12;
      for (let y = 0; y < T; y++) {
        if (isLine && t.r() < 0.85) t.set(x, y, jit(t, dark, 0.12));
        else t.set(x, y, jit(t, mul(base, colShade), 0.1));
      }
    }
  }

  function logTop(t, bark, light, darkRing) {
    for (let y = 0; y < T; y++) {
      for (let x = 0; x < T; x++) {
        const d = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5));
        if (d >= 7) t.set(x, y, jit(t, bark, 0.12));
        else t.set(x, y, jit(t, Math.floor(d) % 2 === 0 ? light : darkRing, 0.06));
      }
    }
  }

  function leaves(t, base, dark, light) {
    fill(t, base, 0.3);
    speck(t, dark, 0.28, 0.2);
    speck(t, light, 0.1, 0.15);
  }

  function shingles(t, base, edge) {
    for (let y = 0; y < T; y++) {
      const row = Math.floor(y / 4);
      const off = (row % 2) * 2;
      for (let x = 0; x < T; x++) {
        const lx = (x + off) % 4;
        const ly = y % 4;
        if (ly === 3 || (lx === 0 && ly > 0)) t.set(x, y, jit(t, edge, 0.08));
        else t.set(x, y, jit(t, mul(base, 1 - ly * 0.04), 0.1));
      }
    }
  }

  function blades(t, colors, count, minH, maxH) {
    for (let i = 0; i < count; i++) {
      const x = 1 + Math.floor(t.r() * 14);
      const h = minH + Math.floor(t.r() * (maxH - minH + 1));
      const lean = t.r() < 0.5 ? -1 : 1;
      const c = colors[Math.floor(t.r() * colors.length)];
      for (let k = 0; k < h; k++) {
        const xx = x + (k > h * 0.6 ? lean : 0);
        t.set(xx, 15 - k, jit(t, c, 0.15));
      }
    }
  }

  function flower(t, petal, center) {
    clear(t);
    line(t, 8, 15, 8, 7, [60, 130, 40]);
    line(t, 7, 12, 5, 10, [70, 145, 45]);
    line(t, 9, 11, 11, 9, [70, 145, 45]);
    rect(t, 6, 3, 5, 4, petal, 0.15);
    t.set(6, 3, [0, 0, 0], 0); t.set(10, 3, [0, 0, 0], 0);
    t.set(6, 6, [0, 0, 0], 0); t.set(10, 6, [0, 0, 0], 0);
    rect(t, 8, 4, 1, 2, center);
  }

  function wheat(t, stage) {
    clear(t);
    const heights = [4, 8, 11, 14];
    const colors = [[[70, 160, 50], [90, 175, 60]], [[80, 165, 50], [100, 170, 60]],
      [[150, 170, 60], [120, 160, 55]], [[215, 185, 70], [195, 160, 55]]];
    for (let x = 1; x < 16; x += 2) {
      const h = heights[stage] - Math.floor(t.r() * 3);
      const c = colors[stage][Math.floor(t.r() * 2)];
      for (let k = 0; k < h; k++) t.set(x, 15 - k, jit(t, c, 0.12));
      if (stage === 3) {
        t.set(x, 15 - h, jit(t, [170, 130, 40], 0.1));
        t.set(x - 1, 16 - h, jit(t, [190, 150, 50], 0.1));
        t.set(x + 1, 17 - h, jit(t, [190, 150, 50], 0.1));
      }
    }
  }

  function gate(t, stripe) {
    for (let x = 0; x < T; x++) {
      const board = Math.floor(x / 4);
      const base = [96 + board * 4, 70, 44];
      for (let y = 0; y < T; y++) {
        if (x % 4 === 3) t.set(x, y, jit(t, [60, 42, 26], 0.1));
        else t.set(x, y, jit(t, base, 0.1));
      }
    }
    rect(t, 0, 6, 16, 4, stripe, 0.08);
    for (const by of [2, 12]) {
      rect(t, 0, by, 16, 2, [72, 72, 78], 0.06);
      for (let x = 1; x < 16; x += 5) t.set(x, by, [150, 150, 160]);
    }
  }

  function crack(t, stage) {
    clear(t);
    const segments = 2 + stage * 2;
    for (let s = 0; s < segments; s++) {
      let x = 8, y = 8;
      if (s > 3) { x = Math.floor(t.r() * T); y = Math.floor(t.r() * T); }
      const len = 3 + Math.floor(t.r() * (3 + stage));
      for (let k = 0; k < len; k++) {
        t.set(x, y, [0, 0, 0], 200);
        x += Math.floor(t.r() * 3) - 1;
        y += Math.floor(t.r() * 3) - 1;
      }
    }
  }

  // ------------------------------------------------------ Tile catalogue

  const GREEN = [96, 160, 56];
  const DIRT = [134, 96, 67];

  const PAINTERS = [
    ['grass_top', function (t) { fill(t, GREEN, 0.28); speck(t, [70, 125, 40], 0.18, 0.2); speck(t, [125, 188, 72], 0.1, 0.15); }],
    ['dirt', function (t) { fill(t, DIRT, 0.2); speck(t, [104, 74, 50], 0.2, 0.15); speck(t, [160, 120, 86], 0.08, 0.1); }],
    ['grass_side', function (t) {
      fill(t, DIRT, 0.2); speck(t, [104, 74, 50], 0.2, 0.15);
      for (let x = 0; x < T; x++) {
        const h = 2 + (t.r() < 0.6 ? 1 : 0) + (t.r() < 0.25 ? 1 : 0);
        for (let y = 0; y < h; y++) t.set(x, y, jit(t, GREEN, 0.25));
      }
    }],
    ['stone', function (t) {
      fill(t, [128, 128, 128], 0.12);
      for (let i = 0; i < 10; i++) {
        const x = Math.floor(t.r() * T), y = Math.floor(t.r() * T), len = 2 + Math.floor(t.r() * 3);
        for (let k = 0; k < len; k++) t.set(x + k, y, jit(t, [106, 106, 106], 0.06));
      }
    }],
    ['cobblestone', function (t) {
      voronoi(t, 9, function () { const g = 118 + Math.floor(t.r() * 36); return [g, g, g]; }, [78, 78, 78], 1.1);
    }],
    ['sand', function (t) { fill(t, [219, 207, 160], 0.08); speck(t, [198, 184, 138], 0.15, 0.08); }],
    ['gravel', function (t) {
      const cols = [[132, 126, 122], [104, 99, 97], [152, 146, 141], [122, 111, 100]];
      voronoi(t, 16, function (i) { return cols[i % 4]; }, [86, 82, 78], 0.8);
    }],
    ['water', function (t) {
      fill(t, [52, 96, 215], 0.08);
      for (let i = 0; i < 6; i++) {
        const y = Math.floor(t.r() * T), x = Math.floor(t.r() * T), len = 3 + Math.floor(t.r() * 5);
        for (let k = 0; k < len; k++) t.set(x + k, y, jit(t, [86, 136, 236], 0.05));
      }
    }],
    ['bedrock', function (t) {
      voronoi(t, 12, function () { const g = 40 + Math.floor(t.r() * 70); return [g, g, g]; }, [25, 25, 25], 1.2);
    }],
    ['oak_log', function (t) { barkLines(t, [106, 84, 52], [78, 60, 36]); }],
    ['oak_log_top', function (t) { logTop(t, [106, 84, 52], [174, 142, 88], [150, 120, 72]); }],
    ['oak_leaves', function (t) { leaves(t, [58, 124, 36], [36, 88, 22], [84, 152, 52]); }],
    ['birch_log', function (t) {
      fill(t, [218, 216, 206], 0.06);
      for (let i = 0; i < 9; i++) {
        const y = Math.floor(t.r() * T), x = Math.floor(t.r() * T), len = 2 + Math.floor(t.r() * 3);
        for (let k = 0; k < len; k++) t.set(x + k, y, jit(t, [48, 48, 44], 0.1));
      }
    }],
    ['birch_log_top', function (t) { logTop(t, [218, 216, 206], [196, 178, 124], [178, 160, 108]); }],
    ['birch_leaves', function (t) { leaves(t, [112, 158, 72], [80, 122, 50], [134, 178, 90]); }],
    ['spruce_log', function (t) { barkLines(t, [64, 46, 29], [44, 31, 19]); }],
    ['spruce_log_top', function (t) { logTop(t, [64, 46, 29], [126, 94, 58], [108, 80, 48]); }],
    ['spruce_leaves', function (t) { leaves(t, [44, 84, 52], [28, 60, 36], [60, 104, 66]); }],
    ['planks', function (t) { planks(t, [164, 132, 80], [118, 92, 54]); }],
    ['spruce_planks', function (t) { planks(t, [112, 84, 52], [78, 57, 34]); }],
    ['coal_ore', function (t) { ore(t, [38, 38, 38], 5); }],
    ['iron_ore', function (t) { ore(t, [218, 176, 146], 5); }],
    ['gold_ore', function (t) { ore(t, [250, 216, 62], 5); }],
    ['diamond_ore', function (t) { ore(t, [100, 232, 226], 4); }],
    ['snow', function (t) { fill(t, [240, 246, 250], 0.04); speck(t, [216, 228, 240], 0.12, 0.05); }],
    ['glass', function (t) {
      clear(t);
      for (let i = 0; i < T; i++) {
        t.set(i, 0, [206, 230, 238]); t.set(i, 15, [206, 230, 238]);
        t.set(0, i, [206, 230, 238]); t.set(15, i, [206, 230, 238]);
      }
      for (let k = 0; k < 4; k++) t.set(3 + k, 6 - k, [236, 248, 252]);
      for (let k = 0; k < 3; k++) t.set(9 + k, 12 - k, [236, 248, 252]);
    }],
    ['stone_bricks', function (t) { bricks(t, [130, 130, 130], [92, 92, 92], 8, 4, 0.12); }],
    ['bricks', function (t) { bricks(t, [152, 74, 58], [188, 178, 166], 8, 4, 0.18); }],
    ['crafting_table_top', function (t) {
      planks(t, [164, 132, 80], [118, 92, 54]);
      for (let i = 0; i < T; i++) { t.set(i, 0, [90, 66, 38]); t.set(i, 15, [90, 66, 38]); t.set(0, i, [90, 66, 38]); t.set(15, i, [90, 66, 38]); }
      line(t, 5, 2, 5, 13, [100, 76, 44]); line(t, 10, 2, 10, 13, [100, 76, 44]);
      line(t, 2, 5, 13, 5, [100, 76, 44]); line(t, 2, 10, 13, 10, [100, 76, 44]);
    }],
    ['crafting_table_side', function (t) {
      planks(t, [150, 118, 70], [106, 82, 48]);
      rect(t, 0, 0, 16, 3, [96, 72, 42], 0.1);
      line(t, 3, 5, 3, 13, [110, 110, 115]); rect(t, 2, 5, 3, 2, [140, 140, 150]);
      line(t, 9, 5, 13, 9, [180, 180, 190]); line(t, 9, 6, 12, 9, [150, 150, 160]); line(t, 12, 10, 13, 12, [96, 70, 40]);
    }],
    ['furnace_front', function (t) {
      fill(t, [118, 118, 118], 0.1);
      for (let i = 0; i < T; i++) { t.set(i, 0, [86, 86, 86]); t.set(i, 15, [86, 86, 86]); t.set(0, i, [86, 86, 86]); t.set(15, i, [86, 86, 86]); }
      rect(t, 4, 8, 8, 5, [30, 28, 26], 0.1);
      rect(t, 4, 11, 8, 2, [120, 60, 20], 0.2);
      rect(t, 3, 7, 10, 1, [96, 96, 96]);
    }],
    ['furnace_side', function (t) {
      fill(t, [122, 122, 122], 0.1);
      for (let i = 0; i < T; i++) { t.set(i, 0, [90, 90, 90]); t.set(i, 15, [90, 90, 90]); t.set(0, i, [90, 90, 90]); t.set(15, i, [90, 90, 90]); }
    }],
    ['furnace_top', function (t) { fill(t, [112, 112, 112], 0.1); rect(t, 5, 5, 6, 6, [96, 96, 96], 0.05); }],
    ['tall_grass', function (t) { clear(t); blades(t, [[88, 150, 50], [70, 128, 40], [104, 168, 62]], 11, 5, 13); }],
    ['flower_red', function (t) { flower(t, [214, 40, 40], [250, 210, 60]); }],
    ['flower_yellow', function (t) { flower(t, [248, 218, 52], [220, 120, 30]); }],
    ['wheat_0', function (t) { wheat(t, 0); }],
    ['wheat_1', function (t) { wheat(t, 1); }],
    ['wheat_2', function (t) { wheat(t, 2); }],
    ['wheat_3', function (t) { wheat(t, 3); }],
    ['farmland', function (t) {
      fill(t, [92, 62, 38], 0.14);
      for (let y = 1; y < T; y += 4) for (let x = 0; x < T; x++) t.set(x, y, jit(t, [66, 42, 26], 0.1));
    }],
    ['blue_wool', function (t) { fill(t, [52, 74, 176], 0.1); speck(t, [70, 96, 200], 0.2, 0.1); }],
    ['red_wool', function (t) { fill(t, [172, 40, 40], 0.1); speck(t, [196, 60, 56], 0.2, 0.1); }],
    ['white_wool', function (t) { fill(t, [232, 232, 232], 0.06); speck(t, [210, 210, 210], 0.2, 0.05); }],
    ['hay_top', function (t) {
      fill(t, [204, 172, 56], 0.14);
      for (let y = 0; y < T; y++) for (let x = 0; x < T; x++) {
        const d = Math.sqrt((x - 7.5) * (x - 7.5) + (y - 7.5) * (y - 7.5));
        if (Math.floor(d) % 3 === 0) t.set(x, y, jit(t, [176, 146, 44], 0.1));
      }
    }],
    ['hay_side', function (t) {
      for (let x = 0; x < T; x++) {
        const c = x % 2 ? [212, 182, 62] : [182, 152, 46];
        for (let y = 0; y < T; y++) t.set(x, y, jit(t, c, 0.1));
      }
      rect(t, 0, 3, 16, 2, [142, 64, 42], 0.1);
      rect(t, 0, 11, 16, 2, [142, 64, 42], 0.1);
    }],
    ['torch', function (t) {
      clear(t);
      rect(t, 7, 6, 2, 10, [124, 92, 52], 0.1);
      rect(t, 7, 3, 2, 3, [255, 196, 60]);
      t.set(7, 2, [255, 240, 150]); t.set(8, 3, [255, 236, 140]);
    }],
    ['chest_front', function (t) {
      fill(t, [162, 112, 48], 0.1);
      for (let i = 0; i < T; i++) { t.set(i, 0, [92, 60, 26]); t.set(i, 15, [92, 60, 26]); t.set(0, i, [92, 60, 26]); t.set(15, i, [92, 60, 26]); }
      rect(t, 1, 6, 14, 1, [92, 60, 26]);
      rect(t, 7, 5, 2, 4, [184, 184, 190]);
    }],
    ['chest_side', function (t) {
      fill(t, [150, 104, 44], 0.1);
      for (let i = 0; i < T; i++) { t.set(i, 0, [92, 60, 26]); t.set(i, 15, [92, 60, 26]); t.set(0, i, [92, 60, 26]); t.set(15, i, [92, 60, 26]); }
      rect(t, 1, 6, 14, 1, [92, 60, 26]);
    }],
    ['chest_top', function (t) {
      fill(t, [158, 110, 46], 0.1);
      for (let i = 0; i < T; i++) { t.set(i, 0, [92, 60, 26]); t.set(i, 15, [92, 60, 26]); t.set(0, i, [92, 60, 26]); t.set(15, i, [92, 60, 26]); }
    }],
    ['berry_bush', function (t) {
      clear(t);
      for (let y = 2; y < T; y++) for (let x = 0; x < T; x++) {
        const d = Math.sqrt((x - 7.5) * (x - 7.5) + (y - 9) * (y - 9) * 1.3);
        if (d < 7.5 && t.r() < 0.85) t.set(x, y, jit(t, t.r() < 0.5 ? [44, 100, 44] : [62, 124, 52], 0.15));
      }
      for (let i = 0; i < 9; i++) {
        const x = 2 + Math.floor(t.r() * 12), y = 4 + Math.floor(t.r() * 10);
        t.set(x, y, [206, 32, 44]); t.set(x + 1, y, [160, 20, 30]);
      }
    }],
    ['berry_bush_empty', function (t) {
      clear(t);
      for (let y = 2; y < T; y++) for (let x = 0; x < T; x++) {
        const d = Math.sqrt((x - 7.5) * (x - 7.5) + (y - 9) * (y - 9) * 1.3);
        if (d < 7.5 && t.r() < 0.8) t.set(x, y, jit(t, t.r() < 0.5 ? [44, 100, 44] : [62, 124, 52], 0.15));
      }
    }],
    ['mossy_cobblestone', function (t) {
      voronoi(t, 9, function () { const g = 118 + Math.floor(t.r() * 30); return [g, g, g]; }, [78, 78, 78], 1.1);
      speck(t, [82, 122, 52], 0.25, 0.2);
    }],
    ['gate_blue', function (t) { gate(t, [52, 82, 190]); }],
    ['gate_red', function (t) { gate(t, [182, 40, 40]); }],
    ['slate', function (t) { shingles(t, [74, 84, 108], [50, 58, 76]); }],
    ['roof_tiles', function (t) { shingles(t, [176, 80, 52], [128, 54, 34]); }],
    ['sapling', function (t) {
      clear(t);
      rect(t, 7, 9, 2, 7, [102, 76, 42], 0.1);
      for (let y = 1; y < 11; y++) for (let x = 2; x < 14; x++) {
        const d = Math.sqrt((x - 7.5) * (x - 7.5) + (y - 6) * (y - 6));
        if (d < 4.8 && t.r() < 0.85) t.set(x, y, jit(t, [62, 132, 42], 0.2));
      }
    }],
    ['iron_block', function (t) {
      fill(t, [222, 222, 222], 0.05);
      for (let i = 0; i < T; i++) { t.set(i, 0, [170, 170, 170]); t.set(i, 15, [150, 150, 150]); t.set(0, i, [190, 190, 190]); t.set(15, i, [150, 150, 150]); }
      rect(t, 2, 7, 12, 1, [196, 196, 196]);
    }],
    ['gold_block', function (t) {
      fill(t, [250, 216, 72], 0.06);
      for (let i = 0; i < T; i++) { t.set(i, 0, [210, 170, 44]); t.set(i, 15, [190, 150, 36]); t.set(0, i, [220, 180, 50]); t.set(15, i, [190, 150, 36]); }
    }],
    ['thatch', function (t) {
      for (let y = 0; y < T; y++) for (let x = 0; x < T; x++) {
        const c = ((x + y) % 3 === 0) ? [168, 138, 58] : [206, 176, 82];
        t.set(x, y, jit(t, c, 0.12));
      }
    }],
    ['sandstone_top', function (t) { fill(t, [220, 206, 158], 0.06); }],
    ['sandstone', function (t) {
      fill(t, [216, 202, 152], 0.06);
      rect(t, 0, 0, 16, 2, [230, 218, 172], 0.04);
      for (let y = 11; y < T; y++) for (let x = 0; x < T; x++) if (t.r() < 0.3) t.set(x, y, jit(t, [196, 180, 132], 0.05));
      rect(t, 0, 10, 16, 1, [190, 174, 126], 0.04);
    }],
    ['crack_0', function (t) { crack(t, 0); }],
    ['crack_1', function (t) { crack(t, 1); }],
    ['crack_2', function (t) { crack(t, 2); }],
    ['crack_3', function (t) { crack(t, 3); }],
    ['crack_4', function (t) { crack(t, 4); }],
    ['crack_5', function (t) { crack(t, 5); }],
    ['crack_6', function (t) { crack(t, 6); }],
    ['crack_7', function (t) { crack(t, 7); }],
    ['stone_brick_cracked', function (t) {
      bricks(t, [124, 124, 124], [92, 92, 92], 8, 4, 0.14);
      line(t, 3, 2, 7, 9, [70, 70, 70]); line(t, 7, 9, 12, 13, [70, 70, 70]);
    }]
  ];

  // ------------------------------------------------------------ Building

  const Textures = {
    TILE: T,
    COLS: COLS,
    SIZE: SIZE,
    index: {},
    names: [],
    canvas: null,
    texture: null,
    uv: null,
    avg: [],
    tileCanvases: {}
  };

  /** Paints every tile into the atlas canvas and uploads it as a texture. */
  Textures.build = function () {
    const canvas = document.createElement('canvas');
    canvas.width = SIZE;
    canvas.height = SIZE;
    const ctx = canvas.getContext('2d');
    Textures.uv = new Float32Array(COLS * COLS * 4);

    PAINTERS.forEach(function (entry, i) {
      const name = entry[0];
      const tile = new Tile(U.hashString(name) ^ 0x9e3779b9);
      entry[1](tile);
      const img = new ImageData(tile.d, T, T);
      const col = i % COLS, row = Math.floor(i / COLS);
      ctx.putImageData(img, col * T, row * T);
      Textures.index[name] = i;
      Textures.names[i] = name;

      // Average colour of non-transparent pixels (for maps and particles).
      let r = 0, g = 0, b = 0, n = 0;
      for (let p = 0; p < T * T; p++) {
        if (tile.d[p * 4 + 3] > 128) { r += tile.d[p * 4]; g += tile.d[p * 4 + 1]; b += tile.d[p * 4 + 2]; n++; }
      }
      Textures.avg[i] = n ? [r / n, g / n, b / n] : [128, 128, 128];

      // UV rectangle with a tiny inset to avoid sampling neighbouring tiles.
      const e = 0.02 / SIZE;
      Textures.uv[i * 4] = col / COLS + e;
      Textures.uv[i * 4 + 1] = 1 - (row + 1) / COLS + e;
      Textures.uv[i * 4 + 2] = (col + 1) / COLS - e;
      Textures.uv[i * 4 + 3] = 1 - row / COLS - e;
    });

    Textures.canvas = canvas;
    const tex = new THREE.CanvasTexture(canvas);
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestFilter;
    tex.generateMipmaps = false;
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    Textures.texture = tex;
  };

  /** Average colour [r,g,b] (0-255) of a named tile. */
  Textures.avgColor = function (name) {
    const i = Textures.index[name];
    return i === undefined ? [128, 128, 128] : Textures.avg[i];
  };

  /** Returns a cached 16x16 canvas containing a copy of a tile. */
  Textures.tileCanvas = function (name) {
    if (Textures.tileCanvases[name]) return Textures.tileCanvases[name];
    const i = Textures.index[name];
    const c = document.createElement('canvas');
    c.width = T; c.height = T;
    if (i !== undefined) {
      c.getContext('2d').drawImage(Textures.canvas, (i % COLS) * T, Math.floor(i / COLS) * T, T, T, 0, 0, T, T);
    }
    Textures.tileCanvases[name] = c;
    return c;
  };

  /** Pixel rectangle of a tile inside the atlas canvas. */
  Textures.tileRect = function (name) {
    const i = Textures.index[name];
    return { x: (i % COLS) * T, y: Math.floor(i / COLS) * T, w: T, h: T };
  };

  VK.Textures = Textures;
})(window.VK);
