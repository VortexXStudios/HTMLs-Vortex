/**
 * @file mesher.js
 * Converts chunk voxel data into renderable geometry.
 *
 * Full detail meshes:
 *   - hidden face culling against a padded copy of the chunk and neighbours
 *   - per-vertex ambient occlusion with anisotropy-correct quad flipping
 *   - smooth sky light (depth below the column's light blocker) and
 *     flood-filled block light from torches, both averaged per vertex
 *   - separate translucent water geometry with lowered surface
 *   - cross shaped billboards for plants and torches
 *
 * LOD meshes (distant chunks): the chunk is sampled in 2x2x2 cells and only
 * cell faces are emitted, roughly quartering the triangle count.
 *
 * Output is plain typed arrays; world.js turns them into THREE geometry.
 * The vertex attribute `aLight` holds (skyLight, blockLight) already
 * multiplied by face shade and ambient occlusion.
 */
(function (VK) {
  'use strict';

  const CS = VK.Config.CHUNK_SIZE;
  const H = VK.Config.WORLD_HEIGHT;
  const B = VK.Blocks;
  const SOLIDS = B.SOLID, OPAQUE = B.OPAQUE, LIQUID = B.LIQUID, CROSS = B.CROSS, SELFCULL = B.SELFCULL;

  // Padded voxel copy: chunk plus 2 blocks of every neighbour.
  const PAD = 2;
  const PW = CS + PAD * 2;
  const PAREA = PW * PW;
  const padded = new Uint8Array(PAREA * H);
  const padHeight = new Int16Array(PAREA);

  // Block light volume: chunk plus 15 blocks around it (torch light radius).
  const LM = 15;
  const LW = CS + LM * 2;
  const LAREA = LW * LW;
  const lightVol = new Uint8Array(LAREA * H);
  const bfsQueue = new Int32Array(LAREA * H);
  let lightActive = false;

  const AO_CURVE = [0.42, 0.62, 0.8, 1.0];
  const BL_CURVE = new Float32Array(16);
  for (let l = 0; l < 16; l++) BL_CURVE[l] = l === 0 ? 0 : Math.pow(0.86, 14 - Math.min(14, l));

  // Face definitions (see blocks.js for the face order).
  const FACE_DEFS = [
    { d: [1, 0, 0], c: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]], shade: 0.8 },
    { d: [-1, 0, 0], c: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]], shade: 0.8 },
    { d: [0, 1, 0], c: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]], shade: 1.0 },
    { d: [0, -1, 0], c: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]], shade: 0.55 },
    { d: [0, 0, 1], c: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], shade: 0.9 },
    { d: [0, 0, -1], c: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]], shade: 0.9 }
  ];
  // Per face/vertex in-plane offsets used for AO and light smoothing.
  const S1 = [], S2 = [];
  FACE_DEFS.forEach(function (fd, f) {
    const axis = fd.d[0] !== 0 ? 0 : (fd.d[1] !== 0 ? 1 : 2);
    const tang = [0, 1, 2].filter(function (a) { return a !== axis; });
    S1[f] = []; S2[f] = [];
    fd.c.forEach(function (c, v) {
      const s1 = [0, 0, 0], s2 = [0, 0, 0];
      s1[tang[0]] = c[tang[0]] === 1 ? 1 : -1;
      s2[tang[1]] = c[tang[1]] === 1 ? 1 : -1;
      S1[f][v] = s1; S2[f][v] = s2;
    });
  });
  const UV_U = [0, 1, 1, 0];
  const UV_V = [0, 0, 1, 1];

  // ------------------------------------------------------------ Buffers

  class GeoBuffer {
    constructor() {
      this.cap = 8192;
      this.pos = new Float32Array(this.cap * 3);
      this.uv = new Float32Array(this.cap * 2);
      this.light = new Float32Array(this.cap * 2);
      this.idx = new Uint32Array(this.cap * 2);
      this.vc = 0;
      this.ic = 0;
    }
    reset() { this.vc = 0; this.ic = 0; }
    ensure(n) {
      if (this.vc + n <= this.cap) return;
      let cap = this.cap * 2;
      while (cap < this.vc + n) cap *= 2;
      const pos = new Float32Array(cap * 3); pos.set(this.pos);
      const uv = new Float32Array(cap * 2); uv.set(this.uv);
      const light = new Float32Array(cap * 2); light.set(this.light);
      const idx = new Uint32Array(cap * 2); idx.set(this.idx);
      this.pos = pos; this.uv = uv; this.light = light; this.idx = idx;
      this.cap = cap;
    }
    vert(x, y, z, u, v, sky, blk) {
      const i = this.vc;
      this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
      this.uv[i * 2] = u; this.uv[i * 2 + 1] = v;
      this.light[i * 2] = sky; this.light[i * 2 + 1] = blk;
      this.vc++;
    }
    quadIndices(base, flip) {
      const I = this.idx;
      let k = this.ic;
      if (!flip) {
        I[k++] = base; I[k++] = base + 1; I[k++] = base + 2;
        I[k++] = base; I[k++] = base + 2; I[k++] = base + 3;
      } else {
        I[k++] = base + 1; I[k++] = base + 2; I[k++] = base + 3;
        I[k++] = base + 1; I[k++] = base + 3; I[k++] = base;
      }
      this.ic = k;
    }
    /** Copies the used part of the buffers into standalone arrays. */
    export() {
      if (this.vc === 0) return null;
      return {
        position: this.pos.slice(0, this.vc * 3),
        uv: this.uv.slice(0, this.vc * 2),
        light: this.light.slice(0, this.vc * 2),
        index: this.vc > 65535 ? this.idx.slice(0, this.ic) : Uint16Array.from(this.idx.subarray(0, this.ic)),
        vertexCount: this.vc
      };
    }
  }

  const opaqueBuf = new GeoBuffer();
  const waterBuf = new GeoBuffer();

  // ------------------------------------------------------- Padded copy

  function pidx(x, y, z) { return (x + PAD) + (z + PAD) * PW + y * PAREA; }

  /** Copies the chunk and a 2 block border of its neighbours into `padded`. */
  function fillPadded(world, chunk) {
    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        const c = (dx === 0 && dz === 0) ? chunk : world.chunks.get(VK.Util.chunkKey(chunk.cx + dx, chunk.cz + dz));
        const x0 = Math.max(-PAD, dx * CS), x1 = Math.min(CS + PAD - 1, dx * CS + CS - 1);
        const z0 = Math.max(-PAD, dz * CS), z1 = Math.min(CS + PAD - 1, dz * CS + CS - 1);
        for (let z = z0; z <= z1; z++) {
          for (let x = x0; x <= x1; x++) {
            const ph = (x + PAD) + (z + PAD) * PW;
            if (!c || !c.generated) {
              // Unknown neighbour: pretend it is solid so no border faces appear.
              for (let y = 0; y < H; y++) padded[ph + y * PAREA] = B.STONE;
              padHeight[ph] = H;
              continue;
            }
            const lx = x - dx * CS, lz = z - dz * CS;
            const col = lx | (lz << 4);
            const src = c.blocks;
            for (let y = 0; y < H; y++) padded[ph + y * PAREA] = src[col | (y << 8)];
            padHeight[ph] = c.heightMap[col];
          }
        }
      }
    }
  }

  function opq(x, y, z) {
    if (y < 0) return 1;
    if (y >= H) return 0;
    return OPAQUE[padded[(x + PAD) + (z + PAD) * PW + y * PAREA]];
  }

  /** Sky light at a cell: full above the column's light blocker, fading below it. */
  function skyAt(x, y, z) {
    if (y >= H) return 1;
    const h = padHeight[(x + PAD) + (z + PAD) * PW];
    if (y > h) return 1;
    const d = h - y;
    return d >= 7 ? 0.08 : 1 - d * 0.13;
  }

  function blAt(x, y, z) {
    if (!lightActive || y < 0 || y >= H) return 0;
    return BL_CURVE[lightVol[(x + LM) + (z + LM) * LW + y * LAREA]];
  }

  // ---------------------------------------------------------- Block light

  /** Flood fills torch light into the light volume around the chunk. */
  function computeBlockLight(world, chunk) {
    lightActive = false;
    const bx = chunk.cx * CS, bz = chunk.cz * CS;
    const sources = [];
    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        const c = world.chunks.get(VK.Util.chunkKey(chunk.cx + dx, chunk.cz + dz));
        if (!c || !c.torches.size) continue;
        c.torches.forEach(function (idx) {
          const lx = (idx & 15) + c.cx * CS - bx;
          const lz = ((idx >> 4) & 15) + c.cz * CS - bz;
          const y = idx >> 8;
          if (lx >= -LM && lx < CS + LM && lz >= -LM && lz < CS + LM) sources.push(lx, y, lz, B.LIGHT[c.blocks[idx]] || 14);
        });
      }
    }
    if (!sources.length) return;
    lightActive = true;
    lightVol.fill(0);
    let head = 0, tail = 0;
    for (let i = 0; i < sources.length; i += 4) {
      const li = (sources[i] + LM) + (sources[i + 2] + LM) * LW + sources[i + 1] * LAREA;
      lightVol[li] = sources[i + 3];
      bfsQueue[tail++] = li;
    }
    const blockAt = function (lx, y, lz) {
      if (lx >= -PAD && lx < CS + PAD && lz >= -PAD && lz < CS + PAD) return padded[pidx(lx, y, lz)];
      const id = world.peekBlock(bx + lx, y, bz + lz);
      return id < 0 ? B.STONE : id;
    };
    while (head < tail) {
      const i = bfsQueue[head++];
      const level = lightVol[i];
      if (level <= 1) continue;
      const y = Math.floor(i / LAREA);
      const rem = i - y * LAREA;
      const lz = Math.floor(rem / LW) - LM;
      const lx = (rem % LW) - LM;
      const nl = level - 1;
      // 6 neighbours
      for (let n = 0; n < 6; n++) {
        let nx = lx, ny = y, nz = lz;
        if (n === 0) nx++; else if (n === 1) nx--; else if (n === 2) ny++;
        else if (n === 3) ny--; else if (n === 4) nz++; else nz--;
        if (nx < -LM || nx >= CS + LM || nz < -LM || nz >= CS + LM || ny < 0 || ny >= H) continue;
        const ni = (nx + LM) + (nz + LM) * LW + ny * LAREA;
        if (lightVol[ni] >= nl) continue;
        if (OPAQUE[blockAt(nx, ny, nz)]) continue;
        lightVol[ni] = nl;
        bfsQueue[tail++] = ni;
      }
    }
  }

  // ------------------------------------------------------------- Emitters

  function faceVisible(id, nid) {
    if (nid === id && SELFCULL[id]) return false;
    if (OPAQUE[nid]) return false;
    if (LIQUID[id]) return !LIQUID[nid];
    return true;
  }

  function emitFace(buf, x, y, z, f, id, liquid, lowerTop) {
    const fd = FACE_DEFS[f];
    const fx = x + fd.d[0], fy = y + fd.d[1], fz = z + fd.d[2];
    const tile = B.faceTile[id * 6 + f];
    const UVT = VK.Textures.uv;
    const u0 = UVT[tile * 4], v0 = UVT[tile * 4 + 1], u1 = UVT[tile * 4 + 2], v1 = UVT[tile * 4 + 3];
    buf.ensure(4);
    const base = buf.vc;
    let ao0 = 3, ao1 = 3, ao2 = 3, ao3 = 3;
    const baseSky = skyAt(fx, fy, fz), baseBl = blAt(fx, fy, fz);
    for (let v = 0; v < 4; v++) {
      const c = fd.c[v];
      let py = y + c[1];
      if (lowerTop && c[1] === 1) py = y + 0.875;
      let sk = baseSky, bl = baseBl, aoF = 1;
      if (!liquid) {
        const s1 = S1[f][v], s2 = S2[f][v];
        const ax = fx + s1[0], ay = fy + s1[1], az = fz + s1[2];
        const bx2 = fx + s2[0], by = fy + s2[1], bz2 = fz + s2[2];
        const cx = ax + s2[0], cy = ay + s2[1], cz = az + s2[2];
        const oa = opq(ax, ay, az), ob = opq(bx2, by, bz2), oc = opq(cx, cy, cz);
        const ao = (oa && ob) ? 0 : 3 - (oa + ob + oc);
        aoF = AO_CURVE[ao];
        let n = 1;
        if (!oa) { sk += skyAt(ax, ay, az); bl += blAt(ax, ay, az); n++; }
        if (!ob) { sk += skyAt(bx2, by, bz2); bl += blAt(bx2, by, bz2); n++; }
        if (!oc && !(oa && ob)) { sk += skyAt(cx, cy, cz); bl += blAt(cx, cy, cz); n++; }
        sk /= n; bl /= n;
        if (v === 0) ao0 = ao; else if (v === 1) ao1 = ao; else if (v === 2) ao2 = ao; else ao3 = ao;
      }
      const sh = fd.shade * aoF;
      buf.vert(x + c[0], py, z + c[2], UV_U[v] ? u1 : u0, UV_V[v] ? v1 : v0, sk * sh, bl * sh);
    }
    buf.quadIndices(base, ao0 + ao2 < ao1 + ao3);
  }

  function emitCross(buf, x, y, z, id) {
    const tile = B.faceTile[id * 6];
    const UVT = VK.Textures.uv;
    const u0 = UVT[tile * 4], v0 = UVT[tile * 4 + 1], u1 = UVT[tile * 4 + 2], v1 = UVT[tile * 4 + 3];
    const sk = skyAt(x, y, z) * 0.95, bl = Math.max(blAt(x, y, z), id === B.TORCH ? 1 : 0) * 0.95;
    const a = 0.15, b = 0.85;
    const planes = [[a, a, b, b], [a, b, b, a]];
    buf.ensure(16);
    for (let p = 0; p < 2; p++) {
      const pl = planes[p];
      const x0 = x + pl[0], z0 = z + pl[1], x1 = x + pl[2], z1 = z + pl[3];
      let base = buf.vc;
      buf.vert(x0, y, z0, u0, v0, sk, bl);
      buf.vert(x1, y, z1, u1, v0, sk, bl);
      buf.vert(x1, y + 1, z1, u1, v1, sk, bl);
      buf.vert(x0, y + 1, z0, u0, v1, sk, bl);
      buf.quadIndices(base, false);
      base = buf.vc;
      buf.vert(x1, y, z1, u1, v0, sk, bl);
      buf.vert(x0, y, z0, u0, v0, sk, bl);
      buf.vert(x0, y + 1, z0, u0, v1, sk, bl);
      buf.vert(x1, y + 1, z1, u1, v1, sk, bl);
      buf.quadIndices(base, false);
    }
  }

  // ------------------------------------------------------------ Builders

  /** Full detail mesh for a chunk. */
  function buildFull(world, chunk) {
    fillPadded(world, chunk);
    computeBlockLight(world, chunk);
    opaqueBuf.reset();
    waterBuf.reset();
    const maxY = Math.min(H - 1, chunk.maxY);
    for (let y = 0; y <= maxY; y++) {
      for (let z = 0; z < CS; z++) {
        for (let x = 0; x < CS; x++) {
          const id = padded[(x + PAD) + (z + PAD) * PW + y * PAREA];
          if (id === 0) continue;
          if (CROSS[id]) { emitCross(opaqueBuf, x, y, z, id); continue; }
          const liquid = LIQUID[id];
          let lowerTop = false;
          if (liquid) {
            const above = y + 1 < H ? padded[pidx(x, y + 1, z)] : 0;
            lowerTop = !LIQUID[above];
          }
          for (let f = 0; f < 6; f++) {
            const d = FACE_DEFS[f].d;
            const ny = y + d[1];
            let nid;
            if (ny < 0) nid = B.BEDROCK;
            else if (ny >= H) nid = 0;
            else nid = padded[(x + d[0] + PAD) + (z + d[2] + PAD) * PW + ny * PAREA];
            if (!faceVisible(id, nid)) continue;
            emitFace(liquid ? waterBuf : opaqueBuf, x, y, z, f, id, liquid, lowerTop);
          }
        }
      }
    }
    return { opaque: opaqueBuf.export(), water: waterBuf.export() };
  }

  // Cell grid for LOD meshing (10 x 64 x 10 including a 1 cell border).
  const LG = 10;
  const lodCells = new Uint8Array(LG * LG * (H / 2));

  function lodSample(cx, cy, cz) {
    const x0 = cx * 2, y0 = cy * 2, z0 = cz * 2;
    let liquid = 0;
    for (let dy = 1; dy >= 0; dy--) {
      const y = y0 + dy;
      if (y >= H) continue;
      for (let dz = 0; dz < 2; dz++) {
        for (let dx = 0; dx < 2; dx++) {
          const id = padded[pidx(x0 + dx, y, z0 + dz)];
          if (id && !CROSS[id]) {
            if (LIQUID[id]) liquid = id; else return id;
          }
        }
      }
    }
    return liquid;
  }

  function cellAt(cx, cy, cz) {
    if (cy < 0) return B.BEDROCK;
    if (cy >= H / 2) return 0;
    return lodCells[(cx + 1) + (cz + 1) * LG + cy * LG * LG];
  }

  /** Half resolution mesh for distant chunks. */
  function buildLod(world, chunk) {
    fillPadded(world, chunk);
    opaqueBuf.reset();
    waterBuf.reset();
    const cyMax = Math.min(H / 2 - 1, (chunk.maxY >> 1) + 1);
    for (let cy = 0; cy <= cyMax; cy++) {
      for (let cz = -1; cz <= 8; cz++) {
        for (let cx = -1; cx <= 8; cx++) {
          lodCells[(cx + 1) + (cz + 1) * LG + cy * LG * LG] = lodSample(cx, cy, cz);
        }
      }
    }
    for (let cy = cyMax + 1; cy < Math.min(H / 2, cyMax + 2); cy++) {
      for (let i = 0; i < LG * LG; i++) lodCells[i + cy * LG * LG] = 0;
    }
    const UVT = VK.Textures.uv;
    for (let cy = 0; cy <= cyMax; cy++) {
      for (let cz = 0; cz < 8; cz++) {
        for (let cx = 0; cx < 8; cx++) {
          const id = cellAt(cx, cy, cz);
          if (!id) continue;
          const liquid = LIQUID[id];
          for (let f = 0; f < 6; f++) {
            const fd = FACE_DEFS[f];
            const n = cellAt(cx + fd.d[0], cy + fd.d[1], cz + fd.d[2]);
            if (liquid) { if (f !== 2 || n !== 0) continue; }
            else if (n !== 0 && !LIQUID[n]) continue;
            const buf = liquid ? waterBuf : opaqueBuf;
            const tile = B.faceTile[id * 6 + f];
            const u0 = UVT[tile * 4], v0 = UVT[tile * 4 + 1], u1 = UVT[tile * 4 + 2], v1 = UVT[tile * 4 + 3];
            const sky = f === 3 ? 0.5 : 1;
            buf.ensure(4);
            const base = buf.vc;
            for (let v = 0; v < 4; v++) {
              const c = fd.c[v];
              let py = (cy + c[1]) * 2;
              if (liquid && c[1] === 1) py -= 0.25;
              buf.vert((cx + c[0]) * 2, py, (cz + c[2]) * 2, UV_U[v] ? u1 : u0, UV_V[v] ? v1 : v0, sky * fd.shade, 0);
            }
            buf.quadIndices(base, false);
          }
        }
      }
    }
    return { opaque: opaqueBuf.export(), water: waterBuf.export() };
  }

  /**
   * Builds geometry data for a chunk at a detail level.
   * @param {World} world
   * @param {Chunk} chunk
   * @param {number} lod 0 = full detail, 1 = half resolution
   */
  function build(world, chunk, lod) {
    return lod === 0 ? buildFull(world, chunk) : buildLod(world, chunk);
  }

  VK.Mesher = { build: build, FACE_DEFS: FACE_DEFS, SOLIDS: SOLIDS };
})(window.VK);
