/**
 * @file main.js
 * Entry point: verifies that three.js and WebGL are available, builds the
 * procedural texture atlas and block tables, then starts the game.
 */
(function () {
  'use strict';

  function fatal(title, detail) {
    const f = document.getElementById('fatal');
    f.classList.remove('hidden');
    f.innerHTML = '<div class="panel"><h2></h2><p></p></div>';
    f.querySelector('h2').textContent = title;
    f.querySelector('p').textContent = detail;
  }

  if (typeof THREE === 'undefined') {
    fatal('three.js could not be loaded',
      'Voxel Kingdoms loads three.js from cdnjs.cloudflare.com. Check your internet connection (or content blockers) and reload the page.');
    return;
  }

  const probe = document.createElement('canvas');
  if (!(probe.getContext('webgl2') || probe.getContext('webgl'))) {
    fatal('WebGL is not available', 'Your browser or graphics driver does not support WebGL, which is required to render the voxel world.');
    return;
  }

  try {
    VK.Textures.build();
    VK.Blocks.init();
    new VK.Game();
  } catch (err) {
    console.error(err);
    fatal('Voxel Kingdoms failed to start', String(err && err.stack ? err.stack : err));
  }
})();
