/**
 * @file physics.js
 * Axis-aligned bounding box movement through the voxel grid, shared by the
 * player, NPCs, dropped items and siege engines.
 *
 * Entities expose: pos (feet centre, THREE.Vector3), vel, hw (half width),
 * h (height), factionId (for gate passability), onGround, hitWall, inWater.
 */
(function (VK) {
  'use strict';

  const B = VK.Blocks;
  const EPS = 1e-4;

  /** True if the box overlaps any block that blocks movement for the faction. */
  function overlaps(world, minX, minY, minZ, maxX, maxY, maxZ, fac) {
    const x0 = Math.floor(minX), x1 = Math.floor(maxX - 1e-7);
    const y0 = Math.floor(minY), y1 = Math.floor(maxY - 1e-7);
    const z0 = Math.floor(minZ), z1 = Math.floor(maxZ - 1e-7);
    for (let y = y0; y <= y1; y++) {
      for (let z = z0; z <= z1; z++) {
        for (let x = x0; x <= x1; x++) {
          if (B.blocksMovement(world.getBlock(x, y, z), fac)) return true;
        }
      }
    }
    return false;
  }

  function entityOverlaps(world, e) {
    const p = e.pos;
    return overlaps(world, p.x - e.hw, p.y, p.z - e.hw, p.x + e.hw, p.y + e.h, p.z + e.hw, e.factionId);
  }

  /**
   * Integrates velocity with collision response, axis by axis (y, x, z).
   * Large moves are split into sub-steps so nothing tunnels through blocks.
   */
  function move(world, e, dt) {
    let dx = e.vel.x * dt, dy = e.vel.y * dt, dz = e.vel.z * dt;
    const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy), Math.abs(dz)) / 0.4));
    dx /= steps; dy /= steps; dz /= steps;
    e.onGround = false;
    e.hitWall = false;
    const p = e.pos;
    for (let s = 0; s < steps; s++) {
      if (dy !== 0) {
        p.y += dy;
        if (entityOverlaps(world, e)) {
          if (dy < 0) { p.y = Math.floor(p.y) + 1 + EPS; e.onGround = true; }
          else { p.y = Math.floor(p.y + e.h - 1e-7) - e.h - EPS; }
          e.vel.y = 0; dy = 0;
        }
      }
      if (dx !== 0) {
        p.x += dx;
        if (entityOverlaps(world, e)) {
          if (dx > 0) p.x = Math.floor(p.x + e.hw - 1e-7) - e.hw - EPS;
          else p.x = Math.floor(p.x - e.hw) + 1 + e.hw + EPS;
          e.vel.x = 0; dx = 0; e.hitWall = true;
        }
      }
      if (dz !== 0) {
        p.z += dz;
        if (entityOverlaps(world, e)) {
          if (dz > 0) p.z = Math.floor(p.z + e.hw - 1e-7) - e.hw - EPS;
          else p.z = Math.floor(p.z - e.hw) + 1 + e.hw + EPS;
          e.vel.z = 0; dz = 0; e.hitWall = true;
        }
      }
    }
    // A resting entity is on the ground if the block just below its feet is solid.
    if (!e.onGround && e.vel.y <= 0) {
      if (overlaps(world, p.x - e.hw, p.y - 0.05, p.z - e.hw, p.x + e.hw, p.y, p.z + e.hw, e.factionId)) e.onGround = true;
    }
    const feet = world.getBlock(Math.floor(p.x), Math.floor(p.y + 0.1), Math.floor(p.z));
    const body = world.getBlock(Math.floor(p.x), Math.floor(p.y + e.h * 0.55), Math.floor(p.z));
    e.inWater = feet === B.WATER || body === B.WATER;
  }

  /** True if an entity box placed at (x,y,z) would overlap a blocking voxel. */
  function boxBlocked(world, x, y, z, hw, h, fac) {
    return overlaps(world, x - hw, y, z - hw, x + hw, y + h, z + hw, fac);
  }

  /**
   * True if the block cell (bx,by,bz) intersects the entity's box.
   * @param {number} [shrink] ignore overlaps smaller than this (in blocks)
   */
  function cellIntersects(e, bx, by, bz, shrink) {
    const p = e.pos;
    const hw = e.hw - (shrink || 0);
    return p.x + hw > bx && p.x - hw < bx + 1 &&
      p.y + e.h > by && p.y < by + 1 &&
      p.z + hw > bz && p.z - hw < bz + 1;
  }

  VK.Physics = { move: move, overlaps: overlaps, boxBlocked: boxBlocked, cellIntersects: cellIntersects, entityOverlaps: entityOverlaps };
})(window.VK);
