/**
 * @file input.js
 * Keyboard, mouse and pointer-lock handling. Keeps continuous state
 * ("is W held") plus per-frame edge events ("was E pressed this frame").
 */
(function (VK) {
  'use strict';

  class Input {
    constructor(canvas) {
      this.canvas = canvas;
      this.keys = new Set();
      this.pressed = new Set();
      this.released = new Set();
      this.buttons = [false, false, false];
      this.buttonsPressed = [false, false, false];
      this.buttonsReleased = [false, false, false];
      this.dx = 0;
      this.dy = 0;
      this.wheel = 0;
      this.locked = false;
      this.enabled = true;
      this.onLockChange = null;
      this.lastKeyTime = {};
      this.doubleTap = new Set();

      window.addEventListener('keydown', (e) => {
        if (this.isTyping(e)) return;
        if (['Space', 'Tab', 'F1', 'F3', 'F5', 'ArrowUp', 'ArrowDown', 'Slash'].indexOf(e.code) >= 0) e.preventDefault();
        if ((e.ctrlKey || e.metaKey) && ['KeyW', 'KeyS', 'KeyD', 'KeyQ'].indexOf(e.code) >= 0 && this.locked) e.preventDefault();
        if (!this.keys.has(e.code)) {
          this.pressed.add(e.code);
          const now = performance.now();
          if (now - (this.lastKeyTime[e.code] || 0) < 280) this.doubleTap.add(e.code);
          this.lastKeyTime[e.code] = now;
        }
        this.keys.add(e.code);
      });
      window.addEventListener('keyup', (e) => {
        this.keys.delete(e.code);
        this.released.add(e.code);
      });
      window.addEventListener('blur', () => {
        this.keys.clear();
        this.buttons = [false, false, false];
      });
      document.addEventListener('mousedown', (e) => {
        if (e.button > 2) return;
        this.buttons[e.button] = true;
        this.buttonsPressed[e.button] = true;
      });
      document.addEventListener('mouseup', (e) => {
        if (e.button > 2) return;
        this.buttons[e.button] = false;
        this.buttonsReleased[e.button] = true;
      });
      document.addEventListener('mousemove', (e) => {
        if (!this.locked) return;
        // Ignore absurd spikes some browsers produce right after locking.
        if (Math.abs(e.movementX) > 300 || Math.abs(e.movementY) > 300) return;
        this.dx += e.movementX;
        this.dy += e.movementY;
      });
      document.addEventListener('wheel', (e) => {
        if (!this.locked) return;
        this.wheel += Math.sign(e.deltaY);
      }, { passive: true });
      document.addEventListener('contextmenu', (e) => { if (this.locked || e.target === canvas) e.preventDefault(); });
      document.addEventListener('pointerlockchange', () => {
        this.locked = document.pointerLockElement === canvas;
        if (!this.locked) { this.buttons = [false, false, false]; this.keys.clear(); }
        if (this.onLockChange) this.onLockChange(this.locked);
      });
    }

    isTyping(e) {
      const t = e.target;
      return t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT');
    }

    requestLock() {
      if (this.locked) return;
      try {
        const p = this.canvas.requestPointerLock();
        if (p && p.catch) p.catch(function () { /* user must click again; handled by the resume overlay */ });
      } catch (err) {
        /* Pointer lock may be refused right after an unlock; the pause menu offers a resume button. */
      }
    }

    exitLock() { if (document.pointerLockElement) document.exitPointerLock(); }

    down(code) { return this.keys.has(code); }
    wasPressed(code) { return this.pressed.has(code); }
    wasDoubleTapped(code) { return this.doubleTap.has(code); }
    mouseDown(b) { return this.buttons[b]; }
    mousePressed(b) { return this.buttonsPressed[b]; }
    mouseReleased(b) { return this.buttonsReleased[b]; }

    /** Returns and clears the accumulated mouse movement. */
    takeMouse() {
      const r = { x: this.dx, y: this.dy };
      this.dx = 0; this.dy = 0;
      return r;
    }
    takeWheel() { const w = this.wheel; this.wheel = 0; return w; }

    /** Clears per-frame edge state; call at the end of every frame. */
    endFrame() {
      this.pressed.clear();
      this.released.clear();
      this.doubleTap.clear();
      this.buttonsPressed = [false, false, false];
      this.buttonsReleased = [false, false, false];
    }
  }

  VK.Input = Input;
})(window.VK);
