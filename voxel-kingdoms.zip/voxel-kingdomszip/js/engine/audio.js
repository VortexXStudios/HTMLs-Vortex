/**
 * @file audio.js
 * Procedurally synthesised sound effects (Web Audio API). No sound files:
 * every effect is a short recipe of noise bursts, filtered tones and
 * envelopes. Positional sounds are attenuated by distance to the camera.
 */
(function (VK) {
  'use strict';

  const MAX_DIST = 44;

  class AudioSystem {
    constructor(game) {
      this.game = game;
      this.ctx = null;
      this.master = null;
      this.noise = null;
      this.volume = 0.6;
      this.recent = new Map(); // name -> last play time, to avoid stacking
    }

    /** Must be called from a user gesture (browser autoplay policy). */
    unlock() {
      if (this.ctx) {
        if (this.ctx.state === 'suspended') this.ctx.resume();
        return;
      }
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume;
      this.master.connect(this.ctx.destination);
      const len = this.ctx.sampleRate;
      this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noise.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }

    setVolume(v) {
      this.volume = v;
      if (this.master) this.master.gain.value = v;
    }

    noiseBurst(t, dur, type, freq, q, gain, dest) {
      const src = this.ctx.createBufferSource();
      src.buffer = this.noise;
      const f = this.ctx.createBiquadFilter();
      f.type = type; f.frequency.value = freq; f.Q.value = q;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(gain, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      src.connect(f); f.connect(g); g.connect(dest);
      src.start(t, Math.random() * 0.5);
      src.stop(t + dur + 0.02);
    }

    tone(t, dur, type, f0, f1, gain, dest) {
      const o = this.ctx.createOscillator();
      o.type = type;
      o.frequency.setValueAtTime(f0, t);
      o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(gain, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      o.connect(g); g.connect(dest);
      o.start(t);
      o.stop(t + dur + 0.02);
    }

    /**
     * Plays a named effect.
     * @param {string} name
     * @param {{x,y,z}} [pos] world position for distance attenuation
     */
    play(name, pos) {
      if (!this.ctx || this.volume <= 0) return;
      let vol = 1;
      if (pos && this.game.camera) {
        const c = this.game.camera.position;
        const dx = pos.x - c.x, dy = pos.y - c.y, dz = pos.z - c.z;
        const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d > MAX_DIST) return;
        vol = Math.pow(1 - d / MAX_DIST, 2);
      }
      const now = this.ctx.currentTime;
      const last = this.recent.get(name) || 0;
      if (now - last < 0.03) return;
      this.recent.set(name, now);
      const out = this.ctx.createGain();
      out.gain.value = vol;
      out.connect(this.master);
      const t = now + 0.005;
      switch (name) {
        case 'break':
          this.noiseBurst(t, 0.16, 'lowpass', 900, 0.8, 0.5, out);
          this.tone(t, 0.08, 'square', 140, 90, 0.05, out);
          break;
        case 'dig':
          this.noiseBurst(t, 0.07, 'lowpass', 700, 0.7, 0.25, out);
          break;
        case 'place':
          this.noiseBurst(t, 0.07, 'lowpass', 600, 0.8, 0.4, out);
          this.tone(t, 0.06, 'square', 190, 120, 0.04, out);
          break;
        case 'step':
          this.noiseBurst(t, 0.05, 'lowpass', 480, 0.6, 0.12, out);
          break;
        case 'hit':
          this.tone(t, 0.14, 'sine', 140, 55, 0.5, out);
          this.noiseBurst(t, 0.07, 'bandpass', 1400, 1.2, 0.25, out);
          break;
        case 'clang':
          this.tone(t, 0.12, 'square', 1100, 820, 0.08, out);
          this.noiseBurst(t, 0.06, 'highpass', 3000, 0.7, 0.2, out);
          break;
        case 'hurt':
          this.tone(t, 0.22, 'square', 320, 150, 0.12, out);
          break;
        case 'swing':
          this.noiseBurst(t, 0.14, 'bandpass', 1800, 2.0, 0.18, out);
          break;
        case 'bow':
          this.tone(t, 0.18, 'triangle', 420, 110, 0.25, out);
          this.noiseBurst(t, 0.05, 'highpass', 2500, 0.8, 0.1, out);
          break;
        case 'arrow':
          this.noiseBurst(t, 0.06, 'highpass', 1800, 0.8, 0.25, out);
          this.tone(t, 0.05, 'square', 400, 300, 0.03, out);
          break;
        case 'boom':
          this.noiseBurst(t, 0.9, 'lowpass', 320, 0.7, 1.0, out);
          this.tone(t, 0.7, 'sine', 70, 28, 0.8, out);
          break;
        case 'catapult':
          this.noiseBurst(t, 0.3, 'lowpass', 500, 0.8, 0.4, out);
          this.tone(t, 0.3, 'sawtooth', 90, 50, 0.15, out);
          break;
        case 'pickup':
          this.tone(t, 0.09, 'sine', 620, 940, 0.18, out);
          break;
        case 'eat':
          for (let i = 0; i < 3; i++) this.noiseBurst(t + i * 0.09, 0.06, 'bandpass', 900 + i * 200, 1.5, 0.2, out);
          break;
        case 'click':
          this.tone(t, 0.04, 'square', 820, 700, 0.06, out);
          break;
        case 'coin':
          this.tone(t, 0.08, 'square', 988, 988, 0.08, out);
          this.tone(t + 0.08, 0.25, 'square', 1319, 1319, 0.08, out);
          break;
        case 'death':
          this.tone(t, 0.55, 'sawtooth', 210, 55, 0.18, out);
          break;
        case 'horn': {
          const o = this.ctx.createOscillator();
          o.type = 'sawtooth';
          o.frequency.setValueAtTime(98, t);
          o.frequency.linearRampToValueAtTime(110, t + 0.3);
          o.frequency.setValueAtTime(110, t + 1.4);
          o.frequency.linearRampToValueAtTime(92, t + 1.9);
          const f = this.ctx.createBiquadFilter();
          f.type = 'lowpass'; f.frequency.value = 700;
          const g = this.ctx.createGain();
          g.gain.setValueAtTime(0.001, t);
          g.gain.linearRampToValueAtTime(0.28, t + 0.25);
          g.gain.setValueAtTime(0.28, t + 1.5);
          g.gain.exponentialRampToValueAtTime(0.001, t + 2.0);
          o.connect(f); f.connect(g); g.connect(out);
          o.start(t); o.stop(t + 2.05);
          break;
        }
        case 'bell':
          this.tone(t, 1.6, 'sine', 880, 870, 0.18, out);
          this.tone(t, 1.2, 'sine', 1320, 1310, 0.08, out);
          break;
        case 'splash':
          this.noiseBurst(t, 0.35, 'lowpass', 1200, 0.6, 0.35, out);
          break;
        default:
          break;
      }
    }
  }

  VK.AudioSystem = AudioSystem;
})(window.VK);
