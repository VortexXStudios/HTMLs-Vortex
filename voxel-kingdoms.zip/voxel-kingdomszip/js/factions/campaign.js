/**
 * @file campaign.js
 * A military campaign against an enemy settlement:
 *
 *   muster  - field squads gather at a rally point on the home border
 *   march   - the army moves as a group to a staging point outside the target
 *   siege   - trebuchets bombard towers, walls and the keep; archers skirmish
 *   assault - melee troops storm the core, breaking through gates/walls
 *   retreat - survivors return home when the army is broken or time runs out
 *
 * The settlement itself decides when it is captured (settlement.js).
 */
(function (VK) {
  'use strict';

  const U = VK.Util;

  class Campaign {
    constructor(faction, target, squads) {
      this.id = U.uid();
      this.faction = faction;
      this.target = target;
      this.squads = squads.slice();
      this.stage = 'muster';
      this.stageT = 0;
      this.ended = false;
      const home = faction.nearestSettlement(target.center) || faction.capital;
      this.home = home;
      const world = VK.game.world;
      const dx = target.center.x - home.center.x, dz = target.center.z - home.center.z;
      const d = Math.sqrt(dx * dx + dz * dz) || 1;
      const ux = dx / d, uz = dz / d;
      const rx = home.center.x + ux * Math.min(d * 0.4, home.radius + 10);
      const rz = home.center.z + uz * Math.min(d * 0.4, home.radius + 10);
      this.rally = { x: Math.floor(rx), y: world.groundY(rx, rz), z: Math.floor(rz) };
      const sx = target.center.x - ux * (target.radius + 12), sz = target.center.z - uz * (target.radius + 12);
      this.staging = { x: Math.floor(sx), y: world.groundY(sx, sz), z: Math.floor(sz) };
      this.squads.forEach((sq) => { sq.campaign = this; });
      this.initialStrength = this.strength();
      this.hasSiege = this.squads.some(function (sq) { return sq.type === 'siege' && sq.size > 0; });
      this.setOrders('rally', this.rally);
    }

    units() {
      let n = 0;
      this.squads.forEach(function (sq) { n += sq.size; });
      return n;
    }

    strength() {
      let s = 0;
      this.squads.forEach(function (sq) { s += sq.strength(); });
      return s;
    }

    setOrders(type, point) {
      this.squads.forEach((sq) => {
        if (sq.type === 'siege' && (type === 'assault' || type === 'bombard')) {
          sq.setOrder({ type: 'bombard', point: this.staging, campaign: this, building: this.nextSiegeTarget(sq.leader) });
        } else {
          sq.setOrder({ type: type, point: point, campaign: this });
        }
      });
    }

    /** Best building to bombard: defences first, then the core. */
    nextSiegeTarget(npc) {
      const t = this.target;
      if (t.faction === this.faction) return null;
      const from = npc ? npc.pos : this.staging;
      let best = null, bs = Infinity;
      t.buildings.forEach(function (b) {
        if (b.removed || b.destroyed || b.state === 'construction' || b.integrity < 0.25) return;
        let pr = 3;
        if (b.type === 'wall' && b.params && b.params.gate) pr = 0;
        else if (b.type === 'tower' || b.type === 'wall') pr = 1;
        else if (b.info.core) pr = 2;
        const c = b.centerPoint();
        const score = pr * 60 + U.dist2(from.x, from.z, c.x, c.z);
        if (score < bs) { bs = score; best = b; }
      });
      return best;
    }

    /** Where melee troops storm to. */
    assaultPoint() {
      const core = this.target.core;
      if (core) return core.interiorPoint();
      return this.target.center;
    }

    update(dt) {
      if (this.ended) return;
      this.stageT += dt;
      this.squads = this.squads.filter(function (sq) { return sq.size > 0; });
      const g = VK.game;
      const f = this.faction;
      if (!this.squads.length) { this.end('destroyed'); return; }
      if (this.target.faction === f) { this.end('victory'); return; }
      if (this.target.removed) { this.end('abandoned'); return; }
      const str = this.strength();
      if (this.stage !== 'muster' && this.stage !== 'retreat' && str < this.initialStrength * 0.3) {
        this.beginRetreat('broken');
        return;
      }
      switch (this.stage) {
        case 'muster': {
          let gathered = 0, total = 0;
          this.squads.forEach((sq) => { gathered += sq.gatheredAt(this.rally, 16) * sq.size; total += sq.size; });
          if ((total && gathered / total >= 0.75) || this.stageT > 90) {
            this.stage = 'march';
            this.stageT = 0;
            this.setOrders('march', this.staging);
            g.log('The army of ' + f.shortName + ' marches on ' + this.target.name + '!', f.id, 'war');
            g.audio.play('horn', this.rally);
            if (g.player && g.player.faction === this.target.faction.id) g.ui.hud.centerMessage(f.shortName + ' is marching on ' + this.target.name + '!', 'Prepare the defences', 4);
          }
          break;
        }
        case 'march': {
          let arrived = 0;
          this.squads.forEach((sq) => { if (sq.gatheredAt(this.staging, 22) > 0.5) arrived++; });
          if (arrived >= Math.ceil(this.squads.length * 0.6) || this.stageT > 240) {
            this.stage = 'siege';
            this.stageT = 0;
            this.setOrders('bombard', this.staging);
            g.log(f.shortName + ' lays siege to ' + this.target.name + '!', f.id, 'war');
            g.audio.play('horn', this.staging);
          }
          break;
        }
        case 'siege': {
          // With siege engines the army waits until the defences are knocked
          // out (or patience runs out); without them it storms quickly.
          const core = this.target.core;
          const breached = !core || core.integrity < 0.8 || this.gateBroken();
          const defencesDown = !this.target.buildings.some(function (b) {
            return (b.type === 'tower' || b.info.core) && b.functional && b.integrity > 0.6;
          });
          const siegeActive = this.squads.some(function (sq) { return sq.type === 'siege' && sq.size > 0; });
          const patience = siegeActive ? 160 : 15;
          if (this.stageT > patience || (siegeActive && defencesDown && this.stageT > 30) || (!siegeActive && breached && this.stageT > 10)) {
            this.stage = 'assault';
            this.stageT = 0;
            const p = this.assaultPoint();
            this.setOrders('assault', p);
            g.log(f.shortName + ' storms ' + this.target.name + '!', f.id, 'war');
            g.audio.play('horn', this.staging);
          }
          break;
        }
        case 'assault': {
          if (this.stageT > 320) { this.beginRetreat('stalled'); break; }
          // Keep the storming point up to date (the core may have fallen).
          if (Math.floor(this.stageT) % 15 === 0) {
            const p = this.assaultPoint();
            this.squads.forEach(function (sq) {
              if (sq.order && sq.order.type === 'assault') sq.order.point = p;
            });
          }
          break;
        }
        case 'retreat': {
          let home = 0;
          this.squads.forEach((sq) => { if (sq.gatheredAt(this.home.center, this.home.radius) > 0.6) home++; });
          if (home >= this.squads.length || this.stageT > 120) this.end('retreated');
          break;
        }
      }
    }

    /** Adds fresh troops to a running campaign with orders for the current stage. */
    addSquad(sq) {
      if (this.ended || this.stage === 'retreat' || this.squads.indexOf(sq) >= 0) return;
      sq.campaign = this;
      sq.defending = null;
      this.squads.push(sq);
      this.initialStrength += sq.strength() * 0.5;
      if (sq.type === 'siege') {
        if (this.stage === 'siege' || this.stage === 'assault') sq.setOrder({ type: 'bombard', point: this.staging, campaign: this, building: this.nextSiegeTarget(sq.leader) });
        else sq.setOrder({ type: 'march', point: this.staging, campaign: this });
        return;
      }
      if (this.stage === 'muster') sq.setOrder({ type: 'rally', point: this.rally, campaign: this });
      else if (this.stage === 'assault') sq.setOrder({ type: 'assault', point: this.assaultPoint(), campaign: this });
      else sq.setOrder({ type: 'march', point: this.staging, campaign: this });
    }

    gateBroken() {
      const gate = this.target.buildings.find(function (b) { return b.type === 'wall' && b.params.gate && !b.removed; });
      return !gate || gate.integrity < 0.85 || gate.state === 'construction';
    }

    beginRetreat(reason) {
      if (this.stage === 'retreat') return;
      this.stage = 'retreat';
      this.stageT = 0;
      const home = this.faction.nearestSettlement(this.target.center) || this.home;
      this.home = home;
      this.setOrders('return', { x: home.center.x, y: home.center.y, z: home.center.z });
      VK.game.log('The ' + this.faction.shortName + ' army retreats from ' + this.target.name + (reason === 'broken' ? ' after heavy losses.' : '.'), this.faction.id, 'war');
    }

    /** Ends the campaign; squads go back under the leader's control. */
    end(result) {
      if (this.ended) return;
      this.ended = true;
      const f = this.faction;
      const target = this.target;
      let garrisoned = false;
      this.squads.forEach(function (sq) {
        sq.campaign = null;
        sq.order = null;
        // After a victory the strongest melee squad stays to hold the prize.
        if (result === 'victory' && !garrisoned && sq.type === 'field' && sq.size >= 2 && target.faction === f) {
          garrisoned = true;
          sq.type = 'garrison';
          sq.settlement = target;
          sq.members.forEach(function (m) { m.settlement = target; });
        }
      });
      f.campaign = null;
      f.lastCampaignEnd = VK.game.elapsed;
      f.stats.campaigns++;
      if (result === 'victory') f.stats.victories++;
      if (result === 'destroyed') VK.game.log('The ' + f.shortName + ' army sent against ' + this.target.name + ' was destroyed.', f.id, 'war');
    }
  }

  VK.Campaign = Campaign;
})(window.VK);
