/**
 * @file squad.js
 * A squad is a small group of soldiers sharing orders, a leader, a marching
 * formation and a pool of known enemy positions (when one member spots an
 * enemy the whole squad knows about it).
 *
 * Squad types:
 *   garrison - holds posts at the settlement core/gate
 *   patrol   - walks a loop around the territory and toward the border
 *   field    - field army, trains near the barracks until a campaign
 *   siege    - trebuchets
 *   player   - soldiers following the player
 *
 * Order types: garrison, patrol, rally, march, defend, assault, bombard,
 * return, follow.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;

  class Squad {
    constructor(o) {
      this.id = o.id || U.uid();
      U.setUidFloor(this.id);
      this.faction = o.faction;
      this.settlement = o.settlement || null;
      this.type = o.type || 'field';
      this.members = [];
      this.order = null;
      this.knownEnemies = new Map();
      this.leaderArrived = false;
      this.campaign = null;
      this.defending = null;
    }

    get size() { return this.members.length; }

    /** Captains lead; otherwise the first member. */
    get leader() {
      let best = null;
      for (let i = 0; i < this.members.length; i++) {
        const m = this.members[i];
        if (m.dead) continue;
        if (m.type === 'captain') return m;
        if (!best) best = m;
      }
      return best;
    }

    add(npc) {
      if (npc.squad === this) return;
      if (npc.squad) npc.squad.remove(npc);
      this.members.push(npc);
      npc.squad = this;
    }

    remove(npc) {
      const i = this.members.indexOf(npc);
      if (i >= 0) this.members.splice(i, 1);
      if (npc.squad === this) npc.squad = null;
    }

    setOrder(order) {
      this.order = order;
      this.leaderArrived = false;
      for (let i = 0; i < this.members.length; i++) this.members[i].nav.stop();
    }

    reportEnemies(list) {
      const t = VK.game.elapsed;
      for (let i = 0; i < list.length; i++) this.knownEnemies.set(list[i], t);
    }

    nearestKnownEnemy(pos, maxD) {
      const now = VK.game.elapsed;
      let best = null, bd = maxD;
      this.knownEnemies.forEach((t, e) => {
        if (e.dead || now - t > 8) { this.knownEnemies.delete(e); return; }
        const d = U.dist2(pos.x, pos.z, e.pos.x, e.pos.z);
        if (d < bd) { bd = d; best = e; }
      });
      return best;
    }

    /** Formation slot behind the leader: rows of four. */
    slotPosition(npc, leader) {
      leader = leader || this.leader;
      let i = 0;
      for (let k = 0; k < this.members.length; k++) {
        const m = this.members[k];
        if (m === npc) break;
        if (m !== leader && !m.dead) i++;
      }
      const row = Math.floor(i / 4), col = (i % 4) - 1.5;
      const h = Squad.headingOf(leader);
      const fx = Math.sin(h), fz = Math.cos(h);
      const rx = Math.cos(h), rz = -Math.sin(h);
      const sp = npc.isSiege ? 3.5 : 1.9;
      const x = leader.pos.x - fx * (row + 1) * sp + rx * col * sp;
      const z = leader.pos.z - fz * (row + 1) * sp + rz * col * sp;
      return { x: x, y: Math.floor(leader.pos.y), z: z };
    }

    /** How far the most distant member is from the leader (for waiting). */
    maxLag() {
      const l = this.leader;
      if (!l) return 0;
      let m = 0;
      for (let i = 0; i < this.members.length; i++) {
        const n = this.members[i];
        if (n === l || n.dead) continue;
        m = Math.max(m, U.dist2(n.pos.x, n.pos.z, l.pos.x, l.pos.z));
      }
      return m;
    }

    /** Guard post for a member in a garrison order. */
    postFor(npc) {
      const o = this.order;
      if (!o || !o.posts || !o.posts.length) return null;
      const i = this.members.indexOf(npc);
      const p = o.posts[Math.max(0, i) % o.posts.length];
      const k = Math.floor(Math.max(0, i) / o.posts.length);
      return k ? { x: p.x + (k % 2 ? 1 : -1), y: p.y, z: p.z + (k > 1 ? 1 : 0) } : p;
    }

    /** Estimated fighting power. */
    strength() {
      let s = 0;
      for (let i = 0; i < this.members.length; i++) {
        const m = this.members[i];
        if (!m.dead) s += m.stats.power * (0.4 + 0.6 * m.hp / m.maxHp);
      }
      return s;
    }

    /** Fraction of members within `r` of a point. */
    gatheredAt(p, r) {
      if (!this.members.length) return 1;
      let n = 0;
      for (let i = 0; i < this.members.length; i++) {
        if (U.dist2(this.members[i].pos.x, this.members[i].pos.z, p.x, p.z) < r) n++;
      }
      return n / this.members.length;
    }

    centroid() {
      let x = 0, z = 0, n = 0;
      this.members.forEach(function (m) { if (!m.dead) { x += m.pos.x; z += m.pos.z; n++; } });
      return n ? { x: x / n, z: z / n } : null;
    }

    update() {
      for (let i = this.members.length - 1; i >= 0; i--) if (this.members[i].dead) this.remove(this.members[i]);
      const o = this.order;
      if (o && o.type === 'patrol' && this.leaderArrived && o.points && o.points.length) {
        o.index = (o.index + 1) % o.points.length;
        o.point = o.points[o.index];
        this.leaderArrived = false;
      }
    }

    serialize() {
      const o = this.order;
      let order = null;
      if (o && !this.campaign && o.type !== 'defend' && o.type !== 'follow') {
        order = { type: o.type, point: o.point, points: o.points, index: o.index, posts: o.posts, facing: o.facing };
      }
      return { id: this.id, faction: this.faction.id, settlement: this.settlement ? this.settlement.id : null, type: this.type === 'player' ? 'field' : this.type, order: order };
    }
  }

  /** Heading of an entity in NPC convention (forward = (sin h, cos h)). */
  Squad.headingOf = function (ent) {
    if (!ent) return 0;
    return ent.isPlayer ? ent.yaw + Math.PI : ent.yaw;
  };

  VK.Squad = Squad;
})(window.VK);
