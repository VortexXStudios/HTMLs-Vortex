/**
 * @file building.js
 * A placed building instance: position/rotation of a blueprint in the
 * world, its construction task list (site clearing, foundation, then the
 * blueprint bottom-up), delivered material stock, structural integrity
 * (share of blueprint blocks still intact), repair planning, banners and
 * defensive firing points.
 */
(function (VK) {
  'use strict';

  const B = VK.Blocks;
  const U = VK.Util;
  const BP = VK.Blueprints;
  const MATS = ['wood', 'stone', 'food', 'iron', 'gold'];

  function emptyRes() { return { wood: 0, stone: 0, food: 0, iron: 0, gold: 0 }; }

  class Building {
    /**
     * @param {object} o {id, type, settlement, style, params, origin, rot, state}
     */
    constructor(o) {
      this.id = o.id || U.uid();
      U.setUidFloor(this.id);
      this.type = o.type;
      this.info = BP.TYPES[o.type];
      this.settlement = o.settlement;
      this.style = o.style;
      this.params = o.params || {};
      this.origin = { x: o.origin.x, y: o.origin.y, z: o.origin.z };
      this.rot = o.rot || 0;
      this.state = o.state || 'planned';
      this.tasks = [];
      this.taskIndex = 0;
      this.deferred = [];
      this.stock = Object.assign(emptyRes(), o.stock || {});
      this.incoming = emptyRes();
      this.remaining = emptyRes();
      this.integrity = this.state === 'planned' || this.state === 'construction' ? 0 : 1;
      this.destroyed = !!o.destroyed;
      this.removed = false;
      this.dirty = true;
      this.checkT = Math.random() * 2;
      this.banners = [];
      this.defenseCd = [];
      this.waitingFor = null;
      this.lastDamageT = -100;
      this.created = VK.game ? VK.game.elapsed : 0;
      const bp = BP.create(this.type, this.style, this.style, this.params);
      this.w = bp.w; this.d = bp.d; this.h = bp.h;
      this.rw = this.rot % 2 ? this.d : this.w;
      this.rd = this.rot % 2 ? this.w : this.d;
      this.bbox = {
        minX: this.origin.x - 1, maxX: this.origin.x + this.rw,
        minY: this.origin.y - 10, maxY: this.origin.y + this.h + 1,
        minZ: this.origin.z - 1, maxZ: this.origin.z + this.rd
      };
      this._blocks = null;
      this._blocksOwner = null;
      this.structural = [];
      this._entrance = null;
    }

    get owner() { return this.settlement.faction; }
    get label() { return this.info.label; }

    /** Operational: finished (or being repaired) and not too damaged. */
    get functional() {
      if (this.state !== 'complete' && this.state !== 'repair') return false;
      return this.integrity >= (this.type === 'farm' ? 0.35 : 0.5);
    }

    blueprint() { return BP.create(this.type, this.style, this.owner.id, this.params); }

    /** Local blueprint (x, z) to world (x, z) under the building rotation. */
    tx(lx, lz) {
      const w = this.w, d = this.d;
      let rx, rz;
      switch (this.rot) {
        case 1: rx = d - 1 - lz; rz = lx; break;
        case 2: rx = w - 1 - lx; rz = d - 1 - lz; break;
        case 3: rx = lz; rz = w - 1 - lx; break;
        default: rx = lx; rz = lz;
      }
      return [this.origin.x + rx, this.origin.z + rz];
    }

    toWorld(p) {
      const r = this.tx(p.x, p.z);
      return { x: r[0], y: this.origin.y + p.y, z: r[1] };
    }

    get entrance() {
      if (!this._entrance) this._entrance = this.toWorld(this.blueprint().entrance);
      return this._entrance;
    }

    interiorPoint() { return this.toWorld(this.blueprint().interior); }

    /**
     * A standable spot just outside the footprint within reach of a task,
     * so builders do not wall themselves in or stand where blocks go.
     */
    outsideStandPoint(world, task, factionId) {
      const x0 = this.origin.x - 1, z0 = this.origin.z - 1;
      const x1 = this.origin.x + this.rw, z1 = this.origin.z + this.rd;
      let best = null, bd = Infinity;
      for (let ring = 0; ring < 2; ring++) {
        const ax = x0 - ring, az = z0 - ring, bx = x1 + ring, bz = z1 + ring;
        for (let x = ax; x <= bx; x++) {
          for (let z = az; z <= bz; z++) {
            if (x !== ax && x !== bx && z !== az && z !== bz) continue;
            const d = Math.sqrt((x - task.x) * (x - task.x) + (z - task.z) * (z - task.z));
            // Not right next to the block (we would stand in its way), but within reach.
            if (d > 4.0 || d < 1.9 || d >= bd) continue;
            const s = world.surface(x, z);
            if (s.water || !world.isStandable(x, s.y, z, factionId)) continue;
            best = { x: x, y: s.y, z: z };
            bd = d;
          }
        }
      }
      return best;
    }
    siteEntrance() { return this.entrance; }
    centerPoint() { return { x: this.origin.x + this.rw / 2, y: this.origin.y + 1, z: this.origin.z + this.rd / 2 }; }

    contains(x, y, z) {
      const b = this.bbox;
      return x >= b.minX && x <= b.maxX && z >= b.minZ && z <= b.maxZ && y >= b.minY && y <= b.maxY;
    }

    /** Blueprint blocks in world coordinates (owner colours). */
    worldBlocks() {
      const oid = this.owner.id;
      if (this._blocks && this._blocksOwner === oid) return this._blocks;
      const list = this.blueprint().list();
      const out = new Array(list.length);
      for (let i = 0; i < list.length; i++) {
        const b = list[i];
        const r = this.tx(b.x, b.z);
        out[i] = { x: r[0], y: this.origin.y + b.y, z: r[1], id: b.id };
      }
      this._blocks = out;
      this._blocksOwner = oid;
      this.structural = out.filter(function (b) { return B.SOLID[b.id] === 1; });
      return out;
    }

    /** World positions of farm crop cells. */
    cropCells() {
      if (this._crops) return this._crops;
      this._crops = this.blueprint().farmCells.map((c) => this.toWorld({ x: c.x, y: 1, z: c.z }));
      return this._crops;
    }

    /** World positions archers on the building shoot from. */
    defensePoints() {
      if (this._defense) return this._defense;
      this._defense = this.blueprint().defense.map((p) => {
        const w = this.toWorld({ x: p.x, y: 0, z: p.z });
        return { x: w.x + 0.5, y: this.origin.y + p.y, z: w.z + 0.5 };
      });
      this.defenseCd = this._defense.map(function () { return Math.random() * 2; });
      return this._defense;
    }

    // ---------------------------------------------------- Construction

    /**
     * Builds the ordered task list.
     * @param {boolean} repair only restore missing structural blocks
     */
    createTasks(world, repair) {
      const blocks = this.worldBlocks();
      const tasks = [];
      if (!repair) {
        const occupied = new Set();
        for (let i = 0; i < blocks.length; i++) occupied.add(U.posKey(blocks[i].x, blocks[i].y, blocks[i].z));
        const top = Math.min(VK.Config.WORLD_HEIGHT - 1, this.origin.y + this.h + 2);
        const trim = BP.STYLES[this.style].trim;
        const found = [];
        for (let y = top; y >= this.origin.y; y--) {
          for (let rz = 0; rz < this.rd; rz++) {
            for (let rx = 0; rx < this.rw; rx++) {
              const x = this.origin.x + rx, z = this.origin.z + rz;
              if (occupied.has(U.posKey(x, y, z))) continue;
              const id = world.getBlock(x, y, z);
              if (id !== 0 && id !== B.BEDROCK) tasks.push({ x: x, y: y, z: z, id: 0 });
            }
          }
        }
        for (let rz = 0; rz < this.rd; rz++) {
          for (let rx = 0; rx < this.rw; rx++) {
            const x = this.origin.x + rx, z = this.origin.z + rz;
            for (let y = this.origin.y - 1; y >= Math.max(1, this.origin.y - 10); y--) {
              const id = world.getBlock(x, y, z);
              if (B.SOLID[id]) break;
              found.push({ x: x, y: y, z: z, id: trim });
            }
          }
        }
        found.sort(function (a, b) { return a.y - b.y; });
        for (let i = 0; i < found.length; i++) tasks.push(found[i]);
      }
      for (let i = 0; i < blocks.length; i++) {
        const b = blocks[i];
        if (repair) {
          if (!B.SOLID[b.id] && b.id !== B.WATER) continue;
          const cur = world.getBlock(b.x, b.y, b.z);
          if (cur === b.id || (b.id === B.STONE_BRICKS && cur === B.CRACKED_BRICKS)) continue;
        }
        tasks.push(b);
      }
      this.tasks = tasks;
      this.taskIndex = 0;
      this.deferred = [];
      this.remaining = emptyRes();
      for (let i = 0; i < tasks.length; i++) {
        const m = B.material(tasks[i].id);
        if (m) this.remaining[m]++;
      }
      return tasks;
    }

    /** Places the whole building instantly (world creation, revival camps). */
    prebuild(world) {
      const tasks = this.createTasks(world, false);
      for (let i = 0; i < tasks.length; i++) {
        const t = tasks[i];
        let id = t.id;
        if (id === B.WHEAT_0) id = B.WHEAT_0 + Math.floor(Math.random() * 4);
        world.setBlock(t.x, t.y, t.z, id, { cause: 'prebuild' });
      }
      this.tasks = [];
      this.taskIndex = 0;
      this.state = 'complete';
      this.integrity = 1;
      this.remaining = emptyRes();
      this.dirty = false;
    }

    startConstruction(world) {
      this.createTasks(world, false);
      this.state = 'construction';
    }

    hasWork() { return this.state === 'construction' || this.state === 'repair'; }

    /** Next task that still needs doing (already satisfied ones are skipped). */
    peekTask(world) {
      for (let guard = 0; guard < 2; guard++) {
        while (this.taskIndex < this.tasks.length) {
          const t = this.tasks[this.taskIndex];
          const cur = world.getBlock(t.x, t.y, t.z);
          if (cur === t.id || (t.id >= B.WHEAT_0 && t.id <= B.WHEAT_3 && cur >= B.WHEAT_0 && cur <= B.WHEAT_3)) {
            const m = B.material(t.id);
            if (m) this.remaining[m] = Math.max(0, this.remaining[m] - 1);
            this.taskIndex++;
            continue;
          }
          return t;
        }
        if (!this.deferred.length) break;
        this.tasks = this.deferred;
        this.deferred = [];
        this.taskIndex = 0;
      }
      if (this.hasWork()) this.finish();
      return null;
    }

    advanceTask(mat) {
      if (mat) this.remaining[mat] = Math.max(0, this.remaining[mat] - 1);
      this.taskIndex++;
      this.waitingFor = null;
    }

    deferTask() {
      this.deferred.push(this.tasks[this.taskIndex]);
      this.taskIndex++;
    }

    /** Material still to be delivered for the remaining tasks. */
    need(mat) { return this.remaining[mat] - this.stock[mat] - this.incoming[mat]; }

    progress() {
      if (!this.hasWork()) return 1;
      const total = this.tasks.length + this.deferred.length;
      return total ? this.taskIndex / total : 1;
    }

    finish() {
      const wasRepair = this.state === 'repair';
      this.state = 'complete';
      this.tasks = [];
      this.deferred = [];
      this.taskIndex = 0;
      const owner = this.owner;
      MATS.forEach((m) => {
        if (this.stock[m] > 0) { owner.resources[m] += this.stock[m]; this.stock[m] = 0; }
      });
      this.dirty = true;
      this.destroyed = false;
      this.computeIntegrity(VK.game.world);
      this.settlement.onBuildingComplete(this, wasRepair);
    }

    /** Switches to repair mode if blocks are missing. */
    planRepair(world) {
      if (this.hasWork()) return false;
      const t = this.createTasks(world, true);
      if (!t.length) return false;
      this.state = 'repair';
      return true;
    }

    // --------------------------------------------------------- Integrity

    computeIntegrity(world) {
      this.worldBlocks();
      const s = this.structural;
      if (!s.length) { this.integrity = 1; return 1; }
      let ok = 0;
      for (let i = 0; i < s.length; i++) {
        const b = s[i];
        const id = world.getBlock(b.x, b.y, b.z);
        if (id === b.id || (b.id === B.STONE_BRICKS && id === B.CRACKED_BRICKS)) ok++;
      }
      this.integrity = ok / s.length;
      this.dirty = false;
      if (this.state === 'complete' || this.state === 'repair') this.destroyed = this.integrity < 0.2;
      return this.integrity;
    }

    /** A random still-standing structural block (siege engines aim at these). */
    randomSolidBlock(world) {
      this.worldBlocks();
      const s = this.structural;
      if (!s.length) return null;
      for (let i = 0; i < 16; i++) {
        const b = s[Math.floor(Math.random() * s.length)];
        if (B.SOLID[world.getBlock(b.x, b.y, b.z)]) return b;
      }
      return null;
    }

    // ------------------------------------------------------ Ownership

    /** Recolours tapestries and gates after a capture. */
    recolor(world, oldOwnerId, newOwnerId) {
      const from = BP.OWNER[oldOwnerId], to = BP.OWNER[newOwnerId];
      if (!from || !to) return;
      const bp = BP.create(this.type, this.style, oldOwnerId, this.params);
      bp.list().forEach((b) => {
        if (b.id !== from.wool && b.id !== from.gate) return;
        const r = this.tx(b.x, b.z);
        const y = this.origin.y + b.y;
        const cur = world.getBlock(r[0], y, r[1]);
        if (cur === from.wool) world.setBlock(r[0], y, r[1], to.wool, { cause: 'capture' });
        else if (cur === from.gate) world.setBlock(r[0], y, r[1], to.gate, { cause: 'capture' });
      });
      this._blocks = null;
      this.banners.forEach(function (h) { VK.game.banners.setFaction(h, newOwnerId); });
      this.dirty = true;
    }

    spawnBanners() {
      if (this.banners.length) return;
      this.blueprint().banners.forEach((p) => {
        const w = this.toWorld(p);
        this.banners.push(VK.game.banners.add(w.x + 0.5, w.y, w.z + 0.5, this.owner.id, p.scale || 1));
      });
    }

    removeBanners() {
      this.banners.forEach(function (h) { VK.game.banners.remove(h); });
      this.banners = [];
    }

    dispose() {
      this.removeBanners();
      this.removed = true;
    }

    serialize() {
      return {
        id: this.id, type: this.type, style: this.style, params: this.params,
        origin: this.origin, rot: this.rot, state: this.state, stock: this.stock,
        destroyed: this.destroyed
      };
    }
  }

  Building.MATS = MATS;
  Building.emptyRes = emptyRes;
  VK.Building = Building;
})(window.VK);
