/**
 * @file settlement.js
 * A settlement (capital castle or outpost town) of a faction: its buildings,
 * construction projects, resource logistics (stockpiles, storage, hauling
 * jobs), quarry, known trees and berry bushes, farm crop reservations,
 * unit training queue, housing, tower defences and the capture mechanic.
 */
(function (VK) {
  'use strict';

  const B = VK.Blocks;
  const U = VK.Util;
  const BP = VK.Blueprints;
  const LOGS = [B.OAK_LOG, B.BIRCH_LOG, B.SPRUCE_LOG];
  const LEAVES = [B.OAK_LEAVES, B.BIRCH_LEAVES, B.SPRUCE_LEAVES];
  const MAX_PILES = 8;
  const CAPTURE_POINTS = 45;

  /** Unit vector of a compass direction. */
  function dirVec(dir) {
    switch (dir) {
      case 'east': return [1, 0];
      case 'west': return [-1, 0];
      case 'north': return [0, -1];
      default: return [0, 1];
    }
  }
  /** Rotation that makes a blueprint's front face a direction. */
  function rotFacing(dx, dz) {
    if (Math.abs(dx) > Math.abs(dz)) return dx > 0 ? 3 : 1;
    return dz >= 0 ? 0 : 2;
  }

  class Settlement {
    /**
     * @param {object} o {id, name, faction, center, radius, isCapital, gateDir}
     */
    constructor(o) {
      this.id = o.id || U.uid();
      U.setUidFloor(this.id);
      this.name = o.name;
      this.faction = o.faction;
      this.center = { x: Math.floor(o.center.x), y: Math.floor(o.center.y), z: Math.floor(o.center.z) };
      this.radius = o.radius;
      this.isCapital = !!o.isCapital;
      this.gateDir = o.gateDir || 'south';
      this.founded = o.founded !== undefined ? o.founded : (VK.game ? VK.game.elapsed : 0);
      this.buildings = [];
      this.stockpiles = [];
      this.trees = [];
      this.bushes = [];
      this.quarry = o.quarry || null;
      this.reservedCrops = new Set();
      this.reservedQuarry = new Set();
      this.training = o.training || [];
      this.fortPlan = o.fortPlan || null;
      this.captureProgress = 0;
      this.captor = null;
      this.underAttack = false;
      this.enemiesNear = 0;
      this.defendersNear = 0;
      this.lastAttackT = -100;
      this.timers = { integrity: Math.random(), capture: Math.random(), trees: 0, bushes: 0, homes: 0, pop: 0 };
      this.popCache = 0;
      this.removed = false;
    }

    // ------------------------------------------------------- Accessors

    get core() {
      for (let i = 0; i < this.buildings.length; i++) {
        const b = this.buildings[i];
        if (b.info.core && !b.removed) return b;
      }
      return null;
    }

    get storages() {
      return this.buildings.filter(function (b) { return b.info.storage && b.functional; });
    }

    get popCap() {
      let cap = 4;
      for (let i = 0; i < this.buildings.length; i++) {
        const b = this.buildings[i];
        if (b.functional) cap += b.info.popCap || 0;
      }
      return cap;
    }

    members() {
      const out = [];
      const list = this.faction.npcs;
      for (let i = 0; i < list.length; i++) if (list[i].settlement === this && !list[i].dead) out.push(list[i]);
      return out;
    }

    get population() { return this.popCache; }

    count(type, includeUnfinished) {
      let n = 0;
      for (let i = 0; i < this.buildings.length; i++) {
        const b = this.buildings[i];
        if (b.type === type && !b.removed && (includeUnfinished || b.state === 'complete' || b.state === 'repair')) n++;
      }
      return n;
    }

    has(type, includeUnfinished) { return this.count(type, includeUnfinished) > 0; }

    projects() { return this.buildings.filter(function (b) { return b.hasWork() && !b.removed; }); }

    countJob(job) {
      let n = 0;
      const list = this.faction.npcs;
      for (let i = 0; i < list.length; i++) if (list[i].settlement === this && list[i].job === job && !list[i].dead) n++;
      return n;
    }

    contains(x, z) { return U.dist2(x, z, this.center.x, this.center.z) <= this.radius; }

    // ---------------------------------------------------------- Buildings

    /**
     * Adds a building. Prebuilt buildings appear instantly, others become
     * construction projects for builders.
     */
    addBuilding(type, origin, rot, params, prebuilt, style) {
      const b = new VK.Building({
        type: type, settlement: this, style: style || this.faction.id, params: params,
        origin: origin, rot: rot, state: prebuilt ? 'complete' : 'construction'
      });
      this.buildings.push(b);
      const world = VK.game.world;
      if (prebuilt) {
        b.prebuild(world);
        this.onBuildingComplete(b, false, true);
      } else {
        b.startConstruction(world);
      }
      return b;
    }

    removeBuilding(b) {
      const i = this.buildings.indexOf(b);
      if (i >= 0) this.buildings.splice(i, 1);
      b.dispose();
    }

    /** Called by Building.finish() and for prebuilt buildings. */
    onBuildingComplete(b, wasRepair, silent) {
      b.spawnBanners();
      const g = VK.game;
      if (!silent) {
        if (wasRepair) g.log(this.faction.shortName + ' repaired the ' + b.label.toLowerCase() + ' at ' + this.name + '.', this.faction.id);
        else {
          this.faction.stats.built++;
          g.log(this.faction.shortName + ' completed a ' + b.label.toLowerCase() + ' at ' + this.name + '.', this.faction.id);
        }
        const e = b.entrance;
        if (g.particles) g.particles.sparkle(e.x + 0.5, e.y + 0.5, e.z + 0.5, 1, 0.9, 0.4, 24);
        if (g.audio) g.audio.play('bell', e);
      }
      if (b.type === 'house') this.timers.homes = 0;
    }

    /** Evaluates a rectangular site for building. */
    evaluateSite(ox, oz, w, d, type) {
      const k = VK.game.kingdoms;
      const Z = VK.Config.WAR_ZONE;
      if (ox < Z.minX || oz < Z.minZ || ox + w > Z.maxX || oz + d > Z.maxZ) return null;
      if (k.rectBlocked(ox - 2, oz - 2, ox + w + 1, oz + d + 1)) return null;
      if (this.quarry) {
        const q = this.quarry;
        if (ox <= q.x0 + q.size + 2 && ox + w >= q.x0 - 2 && oz <= q.z0 + q.size + 2 && oz + d >= q.z0 - 2) return null;
      }
      const other = k.settlementAt(ox + w / 2, oz + d / 2);
      if (other && other.faction !== this.faction) return null;
      const world = VK.game.world;
      const pts = [[0, 0], [w - 1, 0], [0, d - 1], [w - 1, d - 1], [w >> 1, d >> 1], [w >> 1, 0], [w >> 1, d - 1], [0, d >> 1], [w - 1, d >> 1]];
      const ys = [];
      for (let i = 0; i < pts.length; i++) {
        const s = world.surface(ox + pts[i][0], oz + pts[i][1]);
        if (s.water) return null;
        ys.push(s.y - 1);
      }
      ys.sort(function (a, b) { return a - b; });
      const rough = ys[ys.length - 1] - ys[0];
      if (rough > (type === 'farm' ? 2 : (type === 'house' ? 3 : 4))) return null;
      return { y: ys[4], roughness: rough };
    }

    /** Searches rings around the centre for a place for a new building. */
    findSite(type, params, rMin, rMax) {
      const size = BP.size(type, params);
      let best = null, bestScore = Infinity;
      for (let r = rMin; r <= rMax; r += 3) {
        const steps = Math.max(8, Math.floor(r * 0.8));
        const off = Math.random() * Math.PI * 2;
        for (let a = 0; a < steps; a++) {
          const ang = off + a / steps * Math.PI * 2;
          const cx = this.center.x + Math.cos(ang) * r, cz = this.center.z + Math.sin(ang) * r;
          const rot = rotFacing(this.center.x - cx, this.center.z - cz);
          const rw = rot % 2 ? size.d : size.w, rd = rot % 2 ? size.w : size.d;
          const ox = Math.floor(cx - rw / 2), oz = Math.floor(cz - rd / 2);
          const s = this.evaluateSite(ox, oz, rw, rd, type);
          if (!s) continue;
          const score = s.roughness * 3 + r * 0.12 + Math.random() * 1.5;
          if (score < bestScore) { bestScore = score; best = { origin: { x: ox, y: s.y, z: oz }, rot: rot }; }
        }
        if (best && bestScore < r * 0.12 + 3) break;
      }
      return best;
    }

    /** Plans a new construction project; returns the building or null. */
    planBuilding(type, params) {
      if (this.fortPlan && (type === 'tower' || type === 'wall')) {
        const next = this.fortPlan.find((p) => !p.built && p.type === type);
        if (next) {
          next.built = true;
          return this.addBuilding(next.type, next.origin, next.rot, next.params, false);
        }
      }
      let rMin = 8, rMax = this.radius - 4;
      if (this.isCapital) {
        rMin = 27; rMax = this.radius + 6;
        if (type === 'tower') { rMin = this.radius - 6; rMax = this.radius + 10; }
      } else if (type === 'tower') { rMin = 10; rMax = this.radius; }
      const site = this.findSite(type, params, rMin, rMax);
      if (!site) return null;
      return this.addBuilding(type, site.origin, site.rot, params, false);
    }

    /**
     * Lays out a capital: keep, storehouse, barracks and well inside the
     * future curtain wall, and remembers the wall/tower plan.
     */
    layoutCapital(prebuiltExtras) {
      const C = this.center;
      const g = dirVec(this.gateDir);
      const s = [-g[1], g[0]];
      const rot = rotFacing(g[0], g[1]);
      const place = (type, cx, cz, params, prebuilt) => {
        const size = BP.size(type, params);
        const rw = rot % 2 ? size.d : size.w, rd = rot % 2 ? size.w : size.d;
        const ox = Math.floor(cx - rw / 2), oz = Math.floor(cz - rd / 2);
        const s2 = this.evaluateSite(ox, oz, rw, rd, 'keep');
        const y = s2 ? s2.y : VK.game.world.groundY(cx, cz) - 1;
        return this.addBuilding(type, { x: ox, y: y, z: oz }, rot, params, prebuilt);
      };
      place('keep', C.x, C.z, null, true);
      place('storage', C.x + s[0] * 12 - g[0] * 3, C.z + s[1] * 12 - g[1] * 3, null, true);
      place('barracks', C.x - s[0] * 13 - g[0] * 2, C.z - s[1] * 13 - g[1] * 2, null, true);
      place('well', C.x + g[0] * 12 + s[0] * 5, C.z + g[1] * 12 + s[1] * 5, null, true);
      this.fortPlan = this.makeFortPlan(21);
      if (prebuiltExtras) {
        for (let i = 0; i < 3; i++) {
          const site = this.findSite('house', null, 27, 44);
          if (site) this.addBuilding('house', site.origin, site.rot, null, true);
        }
        for (let i = 0; i < 2; i++) {
          const site = this.findSite('farm', null, 28, 50);
          if (site) this.addBuilding('farm', site.origin, site.rot, null, true);
        }
      }
    }

    /** Four corner towers and four curtain walls (gate on the front side). */
    makeFortPlan(R) {
      const C = this.center;
      const world = VK.game.world;
      const plan = [];
      const L = 2 * R - 5;
      const groundAt = function (x0, z0, w, d) {
        const ys = [];
        for (let i = 0; i < 5; i++) {
          const x = x0 + Math.floor(w * i / 4), z = z0 + Math.floor(d * i / 4);
          ys.push(world.groundY(Math.min(x, x0 + w - 1), Math.min(z, z0 + d - 1)) - 1);
        }
        ys.sort(function (a, b) { return a - b; });
        return ys[2];
      };
      [[1, -1], [-1, -1], [1, 1], [-1, 1]].forEach(function (c) {
        const cx = C.x + c[0] * R, cz = C.z + c[1] * R;
        const rot = rotFacing(-c[0] * 0.9, -c[1]);
        plan.push({ type: 'tower', origin: { x: cx - 2, y: groundAt(cx - 2, cz - 2, 5, 5), z: cz - 2 }, rot: rot, params: null });
      });
      const sides = [
        { dir: 'north', rot: 2, x: C.x - R + 3, z: C.z - R, w: L, d: 2 },
        { dir: 'south', rot: 0, x: C.x - R + 3, z: C.z + R - 1, w: L, d: 2 },
        { dir: 'west', rot: 1, x: C.x - R, z: C.z - R + 3, w: 2, d: L },
        { dir: 'east', rot: 3, x: C.x + R - 1, z: C.z - R + 3, w: 2, d: L }
      ];
      const gateDir = this.gateDir;
      // The gate side is fortified first.
      sides.sort(function (a, b) { return (b.dir === gateDir) - (a.dir === gateDir); });
      sides.forEach(function (sd) {
        plan.push({ type: 'wall', origin: { x: sd.x, y: groundAt(sd.x, sd.z, sd.w, sd.d), z: sd.z }, rot: sd.rot, params: { length: L, gate: sd.dir === gateDir } });
      });
      return plan;
    }

    // ------------------------------------------------------- Logistics

    nearestStorage(pos) {
      let best = null, bd = Infinity;
      const list = this.storages;
      for (let i = 0; i < list.length; i++) {
        const e = list[i].entrance;
        const d = U.dist2(pos.x, pos.z, e.x, e.z);
        if (d < bd) { bd = d; best = list[i]; }
      }
      return best;
    }

    /** Entrance of the storage closest to a building (or to the centre). */
    storagePoint(nearBuilding) {
      const ref = nearBuilding ? nearBuilding.entrance : this.center;
      const st = this.nearestStorage(ref);
      if (st) return st.entrance;
      const core = this.core;
      if (core) return core.entrance;
      return { x: this.center.x, y: VK.game.world.groundY(this.center.x, this.center.z), z: this.center.z };
    }

    /** Where a gatherer should bring what it carries. */
    dropoffFor(npc) {
      const st = this.nearestStorage(npc.pos);
      if (st) {
        const e = st.entrance;
        const d = U.dist2(npc.pos.x, npc.pos.z, e.x, e.z);
        // Remote wood and stone go to field stockpiles for the porters;
        // food from the farms is always brought straight to storage.
        if (d > 22 && npc.carry.type !== 'food' && this.countJob('hauler') > 0) {
          const pile = this.pileFor(npc.pos, npc.carry.type);
          if (pile) return { kind: 'pile', pile: pile, x: pile.x, y: pile.y, z: pile.z };
        }
        return { kind: 'storage', x: e.x, y: e.y, z: e.z, building: st };
      }
      const p = this.storagePoint();
      return { kind: 'storage', x: p.x, y: p.y, z: p.z, building: null };
    }

    /** Hands the NPC's cargo over to storage or a stockpile. */
    deposit(drop, npc) {
      const c = npc.carry;
      if (!c.amount) return;
      if (drop.kind === 'pile' && drop.pile && !drop.pile.removed && drop.pile.type === c.type) {
        drop.pile.amount += c.amount;
        drop.pile.bonus.iron += c.bonus.iron;
        drop.pile.bonus.gold += c.bonus.gold;
        this.updatePile(drop.pile);
      } else {
        const r = this.faction.resources;
        r[c.type] += c.amount;
        r.iron += c.bonus.iron;
        r.gold += c.bonus.gold;
        this.faction.stats.gathered += c.amount;
      }
      c.amount = 0; c.type = null; c.bonus.iron = 0; c.bonus.gold = 0;
    }

    /** Drops cargo into a stockpile at the NPC's position. */
    depositHere(npc) {
      const pile = this.pileFor(npc.pos, npc.carry.type, true);
      if (pile) this.deposit({ kind: 'pile', pile: pile }, npc);
      else this.deposit({ kind: 'storage' }, npc);
    }

    pileFor(pos, type, force) {
      let best = null, bd = 14;
      for (let i = 0; i < this.stockpiles.length; i++) {
        const p = this.stockpiles[i];
        if (p.removed || p.type !== type || p.amount > 80) continue;
        const d = U.dist2(pos.x, pos.z, p.x, p.z);
        if (d < bd) { bd = d; best = p; }
      }
      if (best) return best;
      if (this.stockpiles.length >= MAX_PILES && !force) return null;
      const world = VK.game.world;
      const x = Math.floor(pos.x), z = Math.floor(pos.z);
      const y = world.groundY(x, z);
      const pile = { id: U.uid(), x: x, y: y, z: z, type: type, amount: 0, bonus: { iron: 0, gold: 0 }, reservedBy: null, removed: false, model: new VK.Models.PileModel(type) };
      pile.model.root.position.set(x + 0.5, y, z + 0.5);
      VK.game.kingdoms.group.add(pile.model.root);
      this.stockpiles.push(pile);
      return pile;
    }

    updatePile(pile) {
      pile.model.setAmount(pile.amount);
      if (pile.amount <= 0 && !pile.reservedBy) {
        pile.removed = true;
        VK.game.kingdoms.group.remove(pile.model.root);
        const i = this.stockpiles.indexOf(pile);
        if (i >= 0) this.stockpiles.splice(i, 1);
      }
    }

    /** Next transport job for a hauler (deliveries to building sites first). */
    pickHaulJob(npc) {
      const f = this.faction;
      // Scarce goods waiting in the field come first.
      let urgent = null;
      for (let i = 0; i < this.stockpiles.length; i++) {
        const p = this.stockpiles[i];
        if (p.removed || p.reservedBy || p.amount < 8) continue;
        if (f.resources[p.type] < 40 && (!urgent || p.amount > urgent.amount)) urgent = p;
      }
      if (urgent) return { kind: 'collect', pile: urgent };
      const projects = this.projects();
      projects.sort(function (a, b) { return a.created - b.created; });
      for (let i = 0; i < projects.length; i++) {
        const b = projects[i];
        for (let m = 0; m < VK.Building.MATS.length; m++) {
          const mat = VK.Building.MATS[m];
          const need = b.need(mat);
          if (need <= 0) continue;
          // Prefer a field stockpile of the material, else the storehouse.
          let pile = null;
          for (let k = 0; k < this.stockpiles.length; k++) {
            const p = this.stockpiles[k];
            if (p.removed || p.reservedBy || p.type !== mat || p.amount < Math.min(need, 8)) continue;
            if (!pile || p.amount > pile.amount) pile = p;
          }
          if (pile) {
            const amount = Math.min(24, need, pile.amount);
            pile.reservedBy = npc;
            b.incoming[mat] += amount;
            return { kind: 'deliver', building: b, material: mat, amount: amount, source: pile };
          }
          if (f.resources[mat] < 1) continue;
          const amount = Math.min(20, need, Math.floor(f.resources[mat]));
          b.incoming[mat] += amount;
          return { kind: 'deliver', building: b, material: mat, amount: amount, source: null };
        }
      }
      let best = null;
      for (let i = 0; i < this.stockpiles.length; i++) {
        const p = this.stockpiles[i];
        if (p.removed || p.reservedBy || p.amount <= 0) continue;
        if (!best || p.amount > best.amount) best = p;
      }
      return best ? { kind: 'collect', pile: best } : null;
    }

    /** Chooses a construction project for a builder (at most 3 per site). */
    pickProject(npc) {
      const projects = this.projects();
      if (!projects.length) return null;
      projects.sort(function (a, b) {
        const pa = a.state === 'repair' ? -1000 : 0, pb = b.state === 'repair' ? -1000 : 0;
        return (pa + a.created) - (pb + b.created);
      });
      const counts = new Map();
      this.faction.npcs.forEach(function (n) {
        if (n.job === 'builder' && n.workProject) counts.set(n.workProject, (counts.get(n.workProject) || 0) + 1);
      });
      for (let i = 0; i < projects.length; i++) {
        const p = projects[i];
        if ((counts.get(p) || 0) < 3) { npc.workProject = p; return p; }
      }
      npc.workProject = projects[0];
      return projects[0];
    }

    // ------------------------------------------------------ Gathering

    /** Samples the surroundings for tree trunks. */
    scanTrees() {
      const world = VK.game.world;
      const R = this.radius + 38;
      const known = new Set(this.trees.map(function (t) { return U.posKey(t.x, t.y, t.z); }));
      for (let i = 0; i < 160 && this.trees.length < 40; i++) {
        const a = Math.random() * Math.PI * 2, r = 6 + Math.random() * R;
        const x = Math.floor(this.center.x + Math.cos(a) * r), z = Math.floor(this.center.z + Math.sin(a) * r);
        const c = world.chunks.get(U.chunkKey(x >> 4, z >> 4));
        if (!c) continue;
        const col = (x & 15) | ((z & 15) << 4);
        const top = c.topMap[col];
        if (top < 1) continue;
        const topId = c.blocks[col | (top << 8)];
        if (LEAVES.indexOf(topId) < 0 && LOGS.indexOf(topId) < 0) continue;
        // Look for a trunk in this and the neighbouring columns.
        for (let dz = -2; dz <= 2; dz++) {
          for (let dx = -2; dx <= 2; dx++) {
            const tx = x + dx, tz = z + dz;
            for (let y = top; y > top - 14 && y > 1; y--) {
              const id = world.getBlock(tx, y, tz);
              if (LOGS.indexOf(id) < 0) continue;
              const below = world.getBlock(tx, y - 1, tz);
              if (below === B.GRASS || below === B.DIRT || below === B.SNOW) {
                const k = U.posKey(tx, y, tz);
                if (!known.has(k) && !VK.game.kingdoms.insideAnyBuilding(tx, y, tz)) {
                  known.add(k);
                  this.trees.push({ x: tx, y: y, z: tz, reservedBy: null });
                }
              }
              break;
            }
          }
        }
      }
    }

    findTree(npc) {
      this.timers.trees -= 1;
      if (this.trees.filter(function (t) { return !t.reservedBy; }).length < 3 || this.timers.trees <= 0) {
        this.scanTrees();
        this.timers.trees = 20;
      }
      let best = null, bd = Infinity;
      for (let i = 0; i < this.trees.length; i++) {
        const t = this.trees[i];
        if (t.reservedBy && !t.reservedBy.dead) continue;
        const d = U.dist2(npc.pos.x, npc.pos.z, t.x, t.z);
        if (d < bd) { bd = d; best = t; }
      }
      if (best) best.reservedBy = npc;
      return best;
    }

    releaseTree(t, gone) {
      if (!t) return;
      if (gone) {
        const i = this.trees.indexOf(t);
        if (i >= 0) this.trees.splice(i, 1);
      } else t.reservedBy = null;
    }

    /**
     * Creates a terraced quarry near the settlement. Each layer is inset by
     * one block so the pit forms one-block steps that NPCs can climb.
     */
    createQuarry() {
      const world = VK.game.world;
      const size = 15;
      let best = null, bestScore = Infinity;
      for (let attempt = 0; attempt < 40; attempt++) {
        const a = Math.random() * Math.PI * 2;
        const r = (this.isCapital ? 30 : 12) + Math.random() * (this.radius * 0.6);
        const ox = Math.floor(this.center.x + Math.cos(a) * r - size / 2), oz = Math.floor(this.center.z + Math.sin(a) * r - size / 2);
        if (VK.game.kingdoms.rectBlocked(ox - 3, oz - 3, ox + size + 2, oz + size + 2)) continue;
        let minY = 999, maxY = -1, stone = 0, bad = false;
        for (let i = 0; i < 9 && !bad; i++) {
          const x = ox + (i % 3) * 7, z = oz + Math.floor(i / 3) * 7;
          const s = world.surface(x, z);
          if (s.water) bad = true;
          minY = Math.min(minY, s.y - 1); maxY = Math.max(maxY, s.y - 1);
          if (s.ground === B.STONE) stone++;
        }
        if (bad || maxY - minY > 3 || minY < VK.Config.SEA_LEVEL - 2) continue;
        const score = -stone * 3 + (maxY - minY) + r * 0.05 - (minY - VK.Config.SEA_LEVEL) * 0.2;
        if (score < bestScore) { bestScore = score; best = { x0: ox, z0: oz, size: size, y0: minY, top: maxY, depth: Math.min(7, minY - 8), layer: -1, done: false }; }
      }
      this.quarry = best;
      this.reservedQuarry.clear();
      return best;
    }

    nextQuarryBlock() {
      const world = VK.game.world;
      let q = this.quarry;
      if (!q || q.done) { q = this.createQuarry(); if (!q) return null; }
      for (let guard = 0; guard < 16; guard++) {
        let anyLeft = false;
        let found = null;
        if (q.layer < 0) {
          for (let y = q.top + 1; y > q.y0 && !found; y--) {
            for (let z = q.z0; z < q.z0 + q.size && !found; z++) {
              for (let x = q.x0; x < q.x0 + q.size; x++) {
                const id = world.getBlock(x, y, z);
                if (id === 0 || B.CROSS[id]) continue;
                if (B.LIQUID[id]) { q.done = true; return null; }
                anyLeft = true;
                const k = U.posKey(x, y, z);
                if (!this.reservedQuarry.has(k)) { found = { x: x, y: y, z: z }; break; }
              }
            }
          }
        } else {
          const y = q.y0 - q.layer, L = q.layer;
          for (let z = q.z0 + L; z < q.z0 + q.size - L && !found; z++) {
            for (let x = q.x0 + L; x < q.x0 + q.size - L; x++) {
              const id = world.getBlock(x, y, z);
              if (id === 0 || B.CROSS[id]) continue;
              if (B.LIQUID[id] || id === B.BEDROCK) { q.done = true; return null; }
              anyLeft = true;
              const k = U.posKey(x, y, z);
              if (!this.reservedQuarry.has(k)) { found = { x: x, y: y, z: z }; break; }
            }
          }
        }
        if (found) { this.reservedQuarry.add(U.posKey(found.x, found.y, found.z)); return found; }
        if (anyLeft) return null;
        q.layer++;
        if (q.layer > q.depth || q.size - 2 * q.layer < 1) { q.done = true; return null; }
      }
      return null;
    }

    releaseQuarryBlock(b, bad) {
      if (!b) return;
      this.reservedQuarry.delete(U.posKey(b.x, b.y, b.z));
      if (bad && this.quarry) this.quarry.failures = (this.quarry.failures || 0) + 1;
      if (this.quarry && this.quarry.failures > 12) this.quarry.done = true;
    }

    scanBushes() {
      const world = VK.game.world;
      const R = this.radius + 30;
      for (let i = 0; i < 120 && this.bushes.length < 16; i++) {
        const a = Math.random() * Math.PI * 2, r = 5 + Math.random() * R;
        const x = Math.floor(this.center.x + Math.cos(a) * r), z = Math.floor(this.center.z + Math.sin(a) * r);
        const c = world.chunks.get(U.chunkKey(x >> 4, z >> 4));
        if (!c) continue;
        const col = (x & 15) | ((z & 15) << 4);
        const top = c.topMap[col];
        if (top > 0 && c.blocks[col | (top << 8)] === B.BERRY_BUSH) {
          if (!this.bushes.some(function (b) { return b.x === x && b.z === z; })) this.bushes.push({ x: x, y: top, z: z });
        }
      }
    }

    /** A ripe/empty crop cell or a berry bush for a farmer. */
    findCropTask(npc) {
      const world = VK.game.world;
      let best = null, bd = Infinity;
      for (let i = 0; i < this.buildings.length; i++) {
        const f = this.buildings[i];
        if (f.type !== 'farm' || !f.functional) continue;
        const cells = f.cropCells();
        for (let k = 0; k < cells.length; k++) {
          const c = cells[k];
          const key = U.posKey(c.x, c.y, c.z);
          if (this.reservedCrops.has(key)) continue;
          const id = world.getBlock(c.x, c.y, c.z);
          const ripe = id === B.WHEAT_3;
          const empty = id === 0 && world.getBlock(c.x, c.y - 1, c.z) === B.FARMLAND;
          if (!ripe && !empty) continue;
          const d = U.dist2(npc.pos.x, npc.pos.z, c.x, c.z) - (ripe ? 30 : 0);
          if (d < bd) { bd = d; best = c; }
        }
      }
      if (!best) {
        this.timers.bushes -= 1;
        if (this.timers.bushes <= 0) { this.scanBushes(); this.timers.bushes = 15; }
        for (let i = this.bushes.length - 1; i >= 0; i--) {
          const b = this.bushes[i];
          const id = world.getBlock(b.x, b.y, b.z);
          if (id !== B.BERRY_BUSH && id !== B.BERRY_BUSH_EMPTY) { this.bushes.splice(i, 1); continue; }
          if (id !== B.BERRY_BUSH || this.reservedCrops.has(U.posKey(b.x, b.y, b.z))) continue;
          const d = U.dist2(npc.pos.x, npc.pos.z, b.x, b.z);
          if (d < bd) { bd = d; best = b; }
        }
      }
      if (best) this.reservedCrops.add(U.posKey(best.x, best.y, best.z));
      return best ? { x: best.x, y: best.y, z: best.z } : null;
    }

    releaseCrop(c) { if (c) this.reservedCrops.delete(U.posKey(c.x, c.y, c.z)); }

    // ------------------------------------------------------ Population

    /** Gives homeless villagers a bed in a house with room. */
    assignHomes() {
      const houses = this.buildings.filter(function (b) { return b.type === 'house' && b.functional; });
      const members = this.members();
      const occupancy = new Map();
      members.forEach(function (n) {
        if (n.home && houses.indexOf(n.home) >= 0) occupancy.set(n.home, (occupancy.get(n.home) || 0) + 1);
        else n.home = null;
      });
      members.forEach(function (n) {
        if (!n.isVillager || n.home) return;
        for (let i = 0; i < houses.length; i++) {
          const c = occupancy.get(houses[i]) || 0;
          if (c < 4) { n.home = houses[i]; occupancy.set(houses[i], c + 1); break; }
        }
      });
    }

    /** Spawns a newborn villager at a house (or the core). */
    birthVillager(job) {
      const houses = this.buildings.filter(function (b) { return b.type === 'house' && b.functional; });
      const at = houses.length ? U.pick(houses) : this.core;
      if (!at) return null;
      const e = at.entrance;
      const n = this.faction.spawnUnit('villager', e.x + 0.5, e.y + 0.1, e.z + 0.5, this, job);
      this.faction.stats.born++;
      return n;
    }

    queueUnit(type) {
      const costs = VK.NPC.UNIT_COSTS[type];
      const r = this.faction.resources;
      for (const k in costs) if (r[k] < costs[k]) return false;
      for (const k in costs) r[k] -= costs[k];
      this.training.push({ type: type, t: VK.NPC.TRAIN_TIME[type], total: VK.NPC.TRAIN_TIME[type] });
      return true;
    }

    // ---------------------------------------------------------- Update

    update(dt) {
      const g = VK.game;
      const world = g.world;

      // Integrity and building state.
      this.timers.integrity -= dt;
      if (this.timers.integrity <= 0) {
        this.timers.integrity = 2;
        for (let i = 0; i < this.buildings.length; i++) {
          const b = this.buildings[i];
          if (b.dirty && b.state !== 'construction') {
            const wasFunctional = b.functional;
            b.computeIntegrity(world);
            if (wasFunctional && !b.functional) {
              b.removeBanners();
              g.log(this.faction.shortName + "'s " + b.label.toLowerCase() + ' at ' + this.name + ' has been destroyed!', this.faction.id, 'war');
            } else if (!wasFunctional && b.functional) b.spawnBanners();
          }
        }
        this.popCache = this.members().length;
      }

      // Homes
      this.timers.homes -= dt;
      if (this.timers.homes <= 0) { this.timers.homes = 10; this.assignHomes(); }

      // Training
      if (this.training.length) {
        const barracks = this.buildings.find(function (b) { return b.type === 'barracks' && b.functional; });
        if (barracks) {
          const item = this.training[0];
          item.t -= dt;
          if (item.t <= 0) {
            this.training.shift();
            const e = barracks.entrance;
            const n = this.faction.spawnUnit(item.type, e.x + 0.5, e.y + 0.1, e.z + 0.5, this);
            this.faction.stats.trained++;
            if (n && (item.type === 'trebuchet' || item.type === 'captain')) {
              g.log(this.faction.shortName + ' ' + (item.type === 'trebuchet' ? 'built a trebuchet' : 'promoted ' + n.displayName) + ' at ' + this.name + '.', this.faction.id);
            }
          }
        }
      }

      // Capture and threat assessment.
      this.timers.capture -= dt;
      if (this.timers.capture <= 0) {
        this.timers.capture = 1;
        this.updateCapture(1);
      }

      this.updateDefenses(dt);
    }

    updateCapture(dt) {
      const g = VK.game;
      const list = g.entities.queryRadius(this.center.x, this.center.z, this.radius, []);
      const R = this.radius * 0.7;
      let attackers = 0, defenders = 0, enemies = 0, attackerFaction = null;
      for (let i = 0; i < list.length; i++) {
        const n = list[i];
        if (n.isVillager || n.dead) continue;
        if (n.faction === this.faction) { defenders++; continue; }
        enemies++;
        if (U.dist2(n.pos.x, n.pos.z, this.center.x, this.center.z) < R) { attackers++; attackerFaction = n.faction; }
      }
      const p = g.player;
      if (p && !p.dead && !p.spectator && p.faction && p.faction !== this.faction.id &&
        U.dist2(p.pos.x, p.pos.z, this.center.x, this.center.z) < R) {
        attackers++;
        enemies++;
        attackerFaction = attackerFaction || g.kingdoms.factions[p.faction];
      }
      this.enemiesNear = enemies;
      this.defendersNear = defenders;
      const wasUnderAttack = this.underAttack;
      this.underAttack = enemies > 0;
      if (this.underAttack) {
        this.lastAttackT = g.elapsed;
        if (!wasUnderAttack && enemies >= 3) g.log(this.name + ' is under attack!', this.faction.id, 'war');
      }
      const core = this.core;
      const coreWeak = !core || core.integrity < 0.55;
      if (attackers > 0 && defenders === 0 && attackerFaction && attackerFaction !== this.faction && (coreWeak || attackers >= 4)) {
        if (this.captor !== attackerFaction) { this.captor = attackerFaction; this.captureProgress = 0; }
        this.captureProgress += dt * Math.min(3, attackers);
        if (this.captureProgress >= CAPTURE_POINTS) g.kingdoms.captureSettlement(this, attackerFaction);
      } else {
        this.captureProgress = Math.max(0, this.captureProgress - dt * 2);
        if (this.captureProgress === 0) this.captor = null;
      }
    }

    /** Towers, keeps and gatehouses shoot arrows at enemies in range. */
    updateDefenses(dt) {
      const g = VK.game;
      for (let i = 0; i < this.buildings.length; i++) {
        const b = this.buildings[i];
        if (!b.info.defense || !b.functional) continue;
        const pts = b.defensePoints();
        for (let k = 0; k < pts.length; k++) {
          b.defenseCd[k] -= dt;
          if (b.defenseCd[k] > 0) continue;
          const target = this.findDefenseTarget(pts[k], 30);
          if (!target) { b.defenseCd[k] = 1 + Math.random(); continue; }
          VK.Combat.towerShoot(pts[k], target, this.faction);
          b.defenseCd[k] = 3.0 + Math.random() * 0.9;
        }
      }
    }

    findDefenseTarget(p, range) {
      const g = VK.game;
      const list = g.entities.queryRadius(p.x, p.z, range, []);
      let best = null, bd = Infinity;
      for (let i = 0; i < list.length; i++) {
        const n = list[i];
        if (n.faction === this.faction || n.dead) continue;
        const d = U.dist2(p.x, p.z, n.pos.x, n.pos.z);
        if (d >= bd || d < 3) continue;
        if (!g.world.lineOfSight(p.x, p.y, p.z, n.pos.x, n.pos.y + 1.2, n.pos.z)) continue;
        best = n; bd = d;
      }
      const pl = g.player;
      if (pl && !pl.dead && !pl.spectator && VK.Diplomacy.playerHostileTo(this.faction.id)) {
        const d = U.dist2(p.x, p.z, pl.pos.x, pl.pos.z);
        if (d < range && d < bd && g.world.lineOfSight(p.x, p.y, p.z, pl.pos.x, pl.pos.y + 1.2, pl.pos.z)) best = pl;
      }
      return best;
    }

    /** Hands the settlement to another faction. */
    transferTo(newFaction) {
      const world = VK.game.world;
      const old = this.faction;
      this.faction = newFaction;
      this.buildings.forEach(function (b) { b.recolor(world, old.id, newFaction.id); });
      this.training = [];
      this.captureProgress = 0;
      this.captor = null;
      this.stockpiles.forEach((p) => { p.amount = 0; p.reservedBy = null; this.updatePile(p); });
      this.trees.forEach(function (t) { t.reservedBy = null; });
      this.reservedCrops.clear();
      this.reservedQuarry.clear();
      this.buildings.forEach(function (b) {
        if (b.hasWork()) { b.incoming = VK.Building.emptyRes(); }
      });
    }

    destroy() {
      this.removed = true;
      this.buildings.forEach(function (b) { b.dispose(); });
      this.stockpiles.forEach(function (p) { VK.game.kingdoms.group.remove(p.model.root); });
      this.stockpiles = [];
    }

    serialize() {
      return {
        id: this.id, name: this.name, faction: this.faction.id, center: this.center, radius: this.radius,
        isCapital: this.isCapital, gateDir: this.gateDir, founded: this.founded,
        quarry: this.quarry, training: this.training,
        fortPlan: this.fortPlan,
        buildings: this.buildings.filter(function (b) { return !b.removed; }).map(function (b) { return b.serialize(); }),
        stockpiles: this.stockpiles.filter(function (p) { return !p.removed && p.amount > 0; }).map(function (p) { return { x: p.x, y: p.y, z: p.z, type: p.type, amount: p.amount, bonus: p.bonus }; })
      };
    }

    /** Restores a settlement from save data (buildings are not rebuilt). */
    static deserialize(d, faction) {
      const s = new Settlement({
        id: d.id, name: d.name, faction: faction, center: d.center, radius: d.radius,
        isCapital: d.isCapital, gateDir: d.gateDir, founded: d.founded, quarry: d.quarry,
        training: d.training, fortPlan: d.fortPlan
      });
      (d.buildings || []).forEach(function (bd) {
        const b = new VK.Building({
          id: bd.id, type: bd.type, settlement: s, style: bd.style, params: bd.params,
          origin: bd.origin, rot: bd.rot, state: bd.state, stock: bd.stock, destroyed: bd.destroyed
        });
        s.buildings.push(b);
        if (b.state === 'construction') b.createTasks(VK.game.world, false);
        else if (b.state === 'repair') b.createTasks(VK.game.world, true);
        b.dirty = true;
      });
      (d.stockpiles || []).forEach(function (p) {
        const pile = s.pileFor({ x: p.x, z: p.z }, p.type, true);
        pile.amount = p.amount;
        pile.bonus = p.bonus || { iron: 0, gold: 0 };
        s.updatePile(pile);
      });
      return s;
    }
  }

  Settlement.dirVec = dirVec;
  Settlement.rotFacing = rotFacing;
  VK.Settlement = Settlement;
})(window.VK);
