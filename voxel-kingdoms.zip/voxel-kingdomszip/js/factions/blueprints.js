/**
 * @file blueprints.js
 * Procedural medieval architecture. Each blueprint is a sparse 3D map of
 * blocks in local coordinates plus metadata (entrance, interior point,
 * banner poles, defensive firing points, farm cells).
 *
 * Local frame: x in [0,w), z in [0,d), y = 0 is the floor that replaces the
 * terrain surface. The front (door/gate side) faces +z.
 *
 * Two architectural styles:
 *   ironhold - grey stone bricks, cobblestone, slate roofs, spruce timber
 *   redmoor  - red bricks, sandstone, clay tile roofs, oak timber
 * Wool tapestries and gates always use the *owner's* colours, so captured
 * buildings keep their style but change allegiance.
 */
(function (VK) {
  'use strict';

  const B = VK.Blocks;

  const STYLES = {
    ironhold: { wall: B.STONE_BRICKS, wall2: B.COBBLESTONE, trim: B.COBBLESTONE, roof: B.SLATE, wood: B.SPRUCE_PLANKS, log: B.SPRUCE_LOG, floor: B.SPRUCE_PLANKS, window: B.GLASS },
    redmoor: { wall: B.BRICKS, wall2: B.SANDSTONE, trim: B.SANDSTONE, roof: B.ROOF_TILES, wood: B.PLANKS, log: B.OAK_LOG, floor: B.PLANKS, window: B.GLASS }
  };
  const OWNER = {
    ironhold: { wool: B.BLUE_WOOL, gate: B.GATE_BLUE },
    redmoor: { wool: B.RED_WOOL, gate: B.GATE_RED }
  };

  /** Static information about every building type. */
  const TYPES = {
    keep: { label: 'Castle Keep', core: true, storage: true, popCap: 10, defense: true, priority: 0 },
    hall: { label: 'Town Hall', core: true, storage: true, popCap: 6, defense: true, priority: 0 },
    storage: { label: 'Storehouse', storage: true, popCap: 0 },
    house: { label: 'House', popCap: 4 },
    barracks: { label: 'Barracks', popCap: 6, trains: true },
    farm: { label: 'Farm', popCap: 0, farm: true },
    tower: { label: 'Tower', popCap: 0, defense: true },
    wall: { label: 'Wall', popCap: 0, defense: true },
    well: { label: 'Well', popCap: 0 }
  };

  class Blueprint {
    constructor(type, w, d, h) {
      this.type = type;
      this.w = w; this.d = d; this.h = h;
      this.map = new Map();
      this.banners = [];
      this.defense = [];
      this.farmCells = [];
      this.entrance = { x: Math.floor(w / 2), y: 1, z: d };
      this.interior = { x: Math.floor(w / 2), y: 1, z: Math.floor(d / 2) };
      this._list = null;
    }
    key(x, y, z) { return (y * 128 + z) * 128 + x; }
    set(x, y, z, id) {
      if (x < 0 || z < 0 || x >= this.w || z >= this.d || y < 0 || y >= this.h) return;
      this.map.set(this.key(x, y, z), id);
    }
    del(x, y, z) { this.map.delete(this.key(x, y, z)); }
    get(x, y, z) { const v = this.map.get(this.key(x, y, z)); return v === undefined ? -1 : v; }
    fill(x0, y0, z0, x1, y1, z1, id) {
      for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) this.set(x, y, z, id);
    }
    /** Vertical walls around the rectangle (hollow). */
    ring(x0, y0, z0, x1, y1, z1, id) {
      for (let y = y0; y <= y1; y++) {
        for (let x = x0; x <= x1; x++) { this.set(x, y, z0, id); this.set(x, y, z1, id); }
        for (let z = z0; z <= z1; z++) { this.set(x0, y, z, id); this.set(x1, y, z, id); }
      }
    }
    /** Alternating battlements on the rim of a rectangle. */
    crenels(x0, y, z0, x1, z1, id) {
      for (let x = x0; x <= x1; x++) {
        for (let z = z0; z <= z1; z++) {
          const edge = x === x0 || x === x1 || z === z0 || z === z1;
          if (edge && (x + z) % 2 === 0) this.set(x, y, z, id);
        }
      }
    }
    /** Blocks sorted bottom-up, then row by row. */
    list() {
      if (this._list) return this._list;
      const out = [];
      this.map.forEach((id, k) => {
        const x = k % 128, z = Math.floor(k / 128) % 128, y = Math.floor(k / 16384);
        out.push({ x: x, y: y, z: z, id: id });
      });
      out.sort(function (a, b) { return a.y - b.y || a.z - b.z || a.x - b.x; });
      this._list = out;
      return out;
    }
    /** Material cost of the whole blueprint. */
    cost() {
      const c = { wood: 0, stone: 0, food: 0, iron: 0, gold: 0 };
      this.list().forEach(function (b) { const m = B.material(b.id); if (m) c[m]++; });
      return c;
    }
  }

  // ------------------------------------------------------------ Designs

  function keep(S, O) {
    const bp = new Blueprint('keep', 13, 13, 15);
    bp.fill(0, 0, 0, 12, 0, 12, S.trim);
    bp.fill(1, 0, 1, 11, 0, 11, S.floor);
    bp.ring(0, 1, 0, 12, 9, 12, S.wall);
    // Corner turrets
    [[0, 0], [10, 0], [0, 10], [10, 10]].forEach(function (c) {
      bp.fill(c[0], 1, c[1], c[0] + 2, 11, c[1] + 2, S.wall);
      bp.crenels(c[0], 12, c[1], c[0] + 2, c[1] + 2, S.wall);
      bp.set(c[0] + 1, 12, c[1] + 1, S.wall2);
    });
    // Upper floor and roof
    bp.fill(1, 5, 1, 11, 5, 11, S.floor);
    bp.del(5, 5, 5); bp.del(6, 5, 5);
    bp.fill(1, 9, 1, 11, 9, 11, S.wall2);
    bp.crenels(0, 10, 0, 12, 12, S.wall);
    // Gate and windows
    bp.fill(5, 1, 12, 7, 4, 12, O.gate);
    [3, 9].forEach(function (k) {
      bp.set(k, 6, 0, S.window); bp.set(k, 7, 0, S.window);
      bp.set(0, 6, k, S.window); bp.set(0, 7, k, S.window);
      bp.set(12, 6, k, S.window); bp.set(12, 7, k, S.window);
      bp.set(k, 7, 12, S.window);
    });
    // Tapestries in owner colours
    [3, 9].forEach(function (x) { for (let y = 2; y <= 5; y++) bp.set(x, y, 12, O.wool); });
    for (let y = 2; y <= 6; y++) bp.set(6, y, 0, O.wool);
    // Interior
    bp.set(2, 1, 3, B.CHEST); bp.set(10, 1, 3, B.CHEST); bp.set(3, 1, 3, B.CRAFTING_TABLE); bp.set(9, 1, 3, B.FURNACE);
    bp.set(6, 1, 3, B.GOLD_BLOCK); bp.set(6, 2, 3, O.wool);
    bp.set(3, 1, 7, B.TORCH); bp.set(9, 1, 7, B.TORCH); bp.set(6, 1, 9, B.TORCH);
    bp.set(3, 6, 7, B.TORCH); bp.set(9, 6, 7, B.TORCH);
    bp.banners.push({ x: 1, y: 13, z: 1 }, { x: 11, y: 13, z: 1 }, { x: 1, y: 13, z: 11 }, { x: 11, y: 13, z: 11 }, { x: 6, y: 10, z: 6, scale: 1.6 });
    // Archers man the two front turrets and the gate parapet.
    bp.defense.push({ x: 1, y: 13.5, z: 11 }, { x: 11, y: 13.5, z: 11 }, { x: 6, y: 11, z: 12 });
    bp.entrance = { x: 6, y: 1, z: 13 };
    bp.interior = { x: 6, y: 1, z: 7 };
    return bp;
  }

  function hall(S, O) {
    const bp = new Blueprint('hall', 7, 7, 9);
    bp.fill(0, 0, 0, 6, 0, 6, S.trim);
    bp.fill(1, 0, 1, 5, 0, 5, S.floor);
    bp.ring(0, 1, 0, 6, 5, 6, S.wall);
    bp.fill(1, 5, 1, 5, 5, 5, S.wall2);
    bp.crenels(0, 6, 0, 6, 6, S.wall);
    [[0, 0], [6, 0], [0, 6], [6, 6]].forEach(function (c) { bp.set(c[0], 6, c[1], S.wall); bp.set(c[0], 7, c[1], S.wall); });
    bp.fill(3, 1, 6, 3, 3, 6, O.gate);
    bp.set(0, 3, 3, S.window); bp.set(6, 3, 3, S.window); bp.set(3, 3, 0, S.window);
    for (let y = 2; y <= 4; y++) { bp.set(1, y, 6, O.wool); bp.set(5, y, 6, O.wool); }
    bp.set(1, 1, 1, B.CHEST); bp.set(5, 1, 1, B.CHEST); bp.set(3, 1, 1, B.CRAFTING_TABLE);
    bp.set(1, 1, 4, B.TORCH); bp.set(5, 1, 4, B.TORCH);
    bp.banners.push({ x: 3, y: 6, z: 3, scale: 1.3 });
    bp.defense.push({ x: 3, y: 7, z: 3 });
    bp.entrance = { x: 3, y: 1, z: 7 };
    bp.interior = { x: 3, y: 1, z: 3 };
    return bp;
  }

  function tower(S, O) {
    const bp = new Blueprint('tower', 5, 5, 14);
    bp.fill(0, 0, 0, 4, 0, 4, S.trim);
    bp.ring(0, 1, 0, 4, 10, 4, S.wall);
    bp.set(2, 1, 4, O.gate); bp.set(2, 2, 4, O.gate);
    [5, 8].forEach(function (y) { bp.del(2, y, 0); bp.del(0, y, 2); bp.del(4, y, 2); bp.del(2, y + 1, 4); });
    bp.fill(0, 11, 0, 4, 11, 4, S.wall2);
    bp.crenels(0, 12, 0, 4, 4, S.wall);
    for (let y = 6; y <= 9; y++) bp.set(2, y, 4, O.wool);
    bp.set(1, 1, 1, B.TORCH);
    bp.banners.push({ x: 2, y: 12, z: 2 });
    bp.defense.push({ x: 2, y: 12.8, z: 2 });
    bp.entrance = { x: 2, y: 1, z: 5 };
    bp.interior = { x: 2, y: 1, z: 2 };
    return bp;
  }

  function wall(S, O, params) {
    const L = params.length || 16;
    const bp = new Blueprint('wall', L, 2, 8);
    for (let x = 0; x < L; x++) {
      bp.set(x, 0, 0, S.trim); bp.set(x, 0, 1, S.trim);
      for (let y = 1; y <= 5; y++) { bp.set(x, y, 0, S.wall); bp.set(x, y, 1, S.wall); }
      if (x % 2 === 0) bp.set(x, 6, 1, S.wall);
    }
    const c = Math.floor(L / 2);
    if (params.gate) {
      for (let x = c - 1; x <= c + 1; x++) {
        for (let y = 1; y <= 4; y++) { bp.set(x, y, 1, O.gate); bp.del(x, y, 0); }
      }
      for (let y = 2; y <= 4; y++) { bp.set(c - 3, y, 1, O.wool); bp.set(c + 3, y, 1, O.wool); }
      bp.banners.push({ x: c - 2, y: 6, z: 0 }, { x: c + 2, y: 6, z: 0 });
      bp.defense.push({ x: c, y: 7, z: 0 });
      bp.entrance = { x: c, y: 1, z: -1 };
    } else {
      bp.entrance = { x: c, y: 1, z: -1 };
      if (L > 20) bp.defense.push({ x: c, y: 7, z: 0 });
    }
    bp.interior = { x: c, y: 1, z: -1 };
    return bp;
  }

  function house(S, O) {
    const bp = new Blueprint('house', 5, 7, 8);
    bp.fill(0, 0, 0, 4, 0, 6, S.trim);
    bp.fill(1, 0, 1, 3, 0, 5, S.floor);
    bp.ring(0, 1, 0, 4, 3, 6, S.wood);
    for (let z = 0; z <= 6; z++) { bp.set(0, 1, z, S.wall2); bp.set(4, 1, z, S.wall2); }
    for (let x = 0; x <= 4; x++) { bp.set(x, 1, 0, S.wall2); bp.set(x, 1, 6, S.wall2); }
    [[0, 0], [4, 0], [0, 6], [4, 6]].forEach(function (c) { for (let y = 1; y <= 3; y++) bp.set(c[0], y, c[1], S.log); });
    bp.del(2, 1, 6); bp.del(2, 2, 6);
    bp.set(0, 2, 2, S.window); bp.set(0, 2, 4, S.window); bp.set(4, 2, 2, S.window); bp.set(4, 2, 4, S.window); bp.set(2, 2, 0, S.window);
    // Gabled roof along z
    for (let z = 0; z <= 6; z++) {
      bp.set(0, 4, z, S.roof); bp.set(4, 4, z, S.roof);
      bp.set(1, 5, z, S.roof); bp.set(3, 5, z, S.roof);
      bp.set(2, 6, z, S.roof);
    }
    [0, 6].forEach(function (z) { bp.set(1, 4, z, S.wood); bp.set(2, 4, z, S.wood); bp.set(3, 4, z, S.wood); bp.set(2, 5, z, S.wood); });
    bp.set(3, 1, 1, O.wool); bp.set(1, 1, 1, B.CHEST); bp.set(1, 1, 5, B.TORCH);
    bp.entrance = { x: 2, y: 1, z: 7 };
    bp.interior = { x: 2, y: 1, z: 3 };
    return bp;
  }

  function storage(S, O) {
    const bp = new Blueprint('storage', 7, 7, 9);
    bp.fill(0, 0, 0, 6, 0, 6, S.trim);
    bp.fill(1, 0, 1, 5, 0, 5, S.floor);
    bp.ring(0, 1, 0, 6, 4, 6, S.wood);
    for (let i = 0; i <= 6; i++) { bp.set(i, 1, 0, S.wall2); bp.set(0, 1, i, S.wall2); bp.set(6, 1, i, S.wall2); bp.set(i, 1, 6, S.wall2); }
    [[0, 0], [6, 0], [0, 6], [6, 6]].forEach(function (c) { for (let y = 1; y <= 4; y++) bp.set(c[0], y, c[1], S.log); });
    for (let x = 2; x <= 4; x++) for (let y = 1; y <= 3; y++) bp.del(x, y, 6);
    bp.set(0, 3, 3, S.window); bp.set(6, 3, 3, S.window);
    for (let z = 0; z <= 6; z++) {
      bp.set(0, 5, z, S.roof); bp.set(6, 5, z, S.roof);
      bp.set(1, 6, z, S.roof); bp.set(5, 6, z, S.roof);
      bp.set(2, 7, z, S.roof); bp.set(4, 7, z, S.roof);
      bp.set(3, 8, z, S.roof);
    }
    [0, 6].forEach(function (z) {
      for (let x = 1; x <= 5; x++) bp.set(x, 5, z, S.wood);
      for (let x = 2; x <= 4; x++) bp.set(x, 6, z, S.wood);
      bp.set(3, 7, z, S.wood);
    });
    [[1, 1], [2, 1], [4, 1], [5, 1], [1, 3], [5, 3]].forEach(function (c) { bp.set(c[0], 1, c[1], B.CHEST); });
    bp.set(1, 1, 5, B.HAY); bp.set(5, 1, 5, B.HAY); bp.set(5, 2, 5, B.HAY);
    for (let y = 2; y <= 3; y++) { bp.set(1, y, 6, O.wool); bp.set(5, y, 6, O.wool); }
    bp.set(3, 1, 3, B.TORCH);
    bp.entrance = { x: 3, y: 1, z: 7 };
    bp.interior = { x: 3, y: 1, z: 4 };
    return bp;
  }

  function barracks(S, O) {
    const bp = new Blueprint('barracks', 9, 11, 11);
    bp.fill(0, 0, 0, 8, 0, 10, S.trim);
    bp.fill(1, 0, 1, 7, 0, 9, S.floor);
    bp.ring(0, 1, 0, 8, 2, 10, S.wall);
    bp.ring(0, 3, 0, 8, 4, 10, S.wood);
    [[0, 0], [8, 0], [0, 10], [8, 10]].forEach(function (c) { for (let y = 1; y <= 4; y++) bp.set(c[0], y, c[1], S.log); });
    bp.del(4, 1, 10); bp.del(4, 2, 10);
    [3, 7].forEach(function (z) { bp.set(0, 3, z, S.window); bp.set(8, 3, z, S.window); });
    for (let y = 2; y <= 3; y++) { bp.set(2, y, 10, O.wool); bp.set(6, y, 10, O.wool); }
    for (let z = 0; z <= 10; z++) {
      bp.set(0, 5, z, S.roof); bp.set(8, 5, z, S.roof);
      bp.set(1, 6, z, S.roof); bp.set(7, 6, z, S.roof);
      bp.set(2, 7, z, S.roof); bp.set(6, 7, z, S.roof);
      bp.set(3, 8, z, S.roof); bp.set(5, 8, z, S.roof);
      bp.set(4, 9, z, S.roof);
    }
    [0, 10].forEach(function (z) {
      for (let x = 1; x <= 7; x++) bp.set(x, 5, z, S.wood);
      for (let x = 2; x <= 6; x++) bp.set(x, 6, z, S.wood);
      for (let x = 3; x <= 5; x++) bp.set(x, 7, z, S.wood);
      bp.set(4, 8, z, S.wood);
    });
    [2, 4, 6].forEach(function (z) { bp.set(1, 1, z, O.wool); bp.set(7, 1, z, O.wool); });
    bp.set(4, 1, 1, B.IRON_BLOCK); bp.set(3, 1, 1, B.CRAFTING_TABLE); bp.set(5, 1, 1, B.CHEST);
    bp.set(1, 1, 8, B.TORCH); bp.set(7, 1, 8, B.TORCH);
    bp.banners.push({ x: 4, y: 10, z: 5, scale: 1.2 });
    bp.entrance = { x: 4, y: 1, z: 11 };
    bp.interior = { x: 4, y: 1, z: 6 };
    return bp;
  }

  function farm(S, O, params) {
    const bp = new Blueprint('farm', 9, 9, 3);
    for (let z = 0; z < 9; z++) {
      for (let x = 0; x < 9; x++) {
        const edge = x === 0 || x === 8 || z === 0 || z === 8;
        if (edge) bp.set(x, 0, z, S.trim);
        else if (x === 4) bp.set(x, 0, z, B.WATER);
        else {
          bp.set(x, 0, z, B.FARMLAND);
          bp.set(x, 1, z, B.WHEAT_0);
          bp.farmCells.push({ x: x, z: z });
        }
      }
    }
    bp.set(0, 1, 0, B.HAY); bp.set(8, 1, 8, B.HAY); bp.set(8, 1, 0, B.HAY);
    bp.entrance = { x: 4, y: 1, z: 9 };
    bp.interior = { x: 2, y: 1, z: 4 };
    return bp;
  }

  function well(S) {
    const bp = new Blueprint('well', 3, 3, 5);
    bp.ring(0, 0, 0, 2, 0, 2, S.trim);
    bp.set(1, 0, 1, B.WATER);
    [[0, 0], [2, 0], [0, 2], [2, 2]].forEach(function (c) { bp.set(c[0], 1, c[1], S.log); bp.set(c[0], 2, c[1], S.log); });
    bp.fill(0, 3, 0, 2, 3, 2, S.roof);
    bp.entrance = { x: 1, y: 1, z: 3 };
    bp.interior = { x: 1, y: 1, z: 3 };
    return bp;
  }

  const DESIGNS = { keep: keep, hall: hall, tower: tower, wall: wall, house: house, storage: storage, barracks: barracks, farm: farm, well: well };

  const cache = new Map();

  /**
   * Creates (or returns a cached) blueprint.
   * @param {string} type
   * @param {string} styleId faction whose architecture is used
   * @param {string} ownerId faction whose colours are used
   * @param {object} [params] e.g. {length, gate} for walls
   */
  function create(type, styleId, ownerId, params) {
    params = params || {};
    const key = type + '|' + styleId + '|' + ownerId + '|' + (params.length || 0) + '|' + (params.gate ? 1 : 0);
    let bp = cache.get(key);
    if (!bp) {
      const S = STYLES[styleId] || STYLES.ironhold;
      const O = OWNER[ownerId] || OWNER[styleId] || OWNER.ironhold;
      bp = DESIGNS[type](S, O, params);
      cache.set(key, bp);
    }
    return bp;
  }

  /** Footprint of a building type before rotation. */
  function size(type, params) {
    const bp = create(type, 'ironhold', 'ironhold', params);
    return { w: bp.w, d: bp.d, h: bp.h };
  }

  VK.Blueprints = { STYLES: STYLES, OWNER: OWNER, TYPES: TYPES, Blueprint: Blueprint, create: create, size: size };
})(window.VK);
