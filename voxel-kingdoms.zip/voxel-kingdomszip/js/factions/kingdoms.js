/**
 * @file kingdoms.js
 * World-level faction manager: places the two capitals, builds the initial
 * castles and populations, routes block changes to buildings, handles
 * captures, defeats and the rise of exiled kingdoms, founds new
 * settlements, pins the simulated region in memory and (de)serialises the
 * whole political state.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;
  const C = VK.Config;
  const BP = VK.Blueprints;

  const START_VILLAGERS = ['woodcutter', 'woodcutter', 'woodcutter', 'woodcutter', 'miner', 'miner', 'miner',
    'farmer', 'farmer', 'farmer', 'builder', 'builder', 'builder', 'hauler', 'hauler', 'hauler'];
  const START_SOLDIERS = ['captain', 'swordsman', 'swordsman', 'swordsman', 'swordsman', 'spearman', 'spearman',
    'archer', 'archer', 'archer', 'crossbowman'];

  class Kingdoms {
    constructor(game) {
      this.game = game;
      this.factions = { ironhold: new VK.Faction('ironhold'), redmoor: new VK.Faction('redmoor') };
      this.list = [this.factions.ironhold, this.factions.redmoor];
      this.list.forEach((f) => { f.kingdoms = this; });
      this.group = new THREE.Group();
      game.scene.add(this.group);
      this.pinT = 0;
      this.capitalSites = null;
    }

    enemyOf(f) { return f === this.factions.ironhold ? this.factions.redmoor : this.factions.ironhold; }

    get settlements() {
      const out = [];
      this.list.forEach(function (f) { f.settlements.forEach(function (s) { out.push(s); }); });
      return out;
    }

    totalNPCs() { return this.list.reduce(function (a, f) { return a + f.npcs.length; }, 0); }

    // ---------------------------------------------------------- Setup

    /**
     * Picks capital sites from the seed and levels the terrain there.
     * Must be called before any chunk is generated.
     */
    planCapitals(terrain, seed) {
      const rng = new U.RNG((seed ^ 0xcafe) >>> 0);
      const D = C.CAPITAL_DISTANCE;
      const a = terrain.findSiteNear(-D + rng.int(-15, 15), rng.int(-40, 40), 40);
      const b = terrain.findSiteNear(D + rng.int(-15, 15), rng.int(-40, 40), 40);
      this.applyCapitalSites({ ironhold: a, redmoor: b }, terrain);
      return this.capitalSites;
    }

    applyCapitalSites(sites, terrain) {
      this.capitalSites = sites;
      terrain.addSite(sites.ironhold.x, sites.ironhold.z, C.CAPITAL_FLATTEN_RADIUS, sites.ironhold.h);
      terrain.addSite(sites.redmoor.x, sites.redmoor.z, C.CAPITAL_FLATTEN_RADIUS, sites.redmoor.h);
    }

    /** Builds both capitals and their starting populations. */
    async initNewWorld(progress) {
      let step = 0;
      for (const f of this.list) {
        const site = this.capitalSites[f.id];
        const s = new VK.Settlement({
          name: f.capitalName, faction: f, center: { x: site.x, y: site.h + 1, z: site.z },
          radius: 46, isCapital: true, gateDir: f.id === 'ironhold' ? 'east' : 'west', founded: 0
        });
        f.settlements.push(s);
        s.layoutCapital(true);
        step++;
        if (progress) progress(step / 4);
        await U.nextFrame();
        this.spawnPopulation(f, s, START_VILLAGERS, START_SOLDIERS);
        step++;
        if (progress) progress(step / 4);
        await U.nextFrame();
      }
      this.updatePinned();
    }

    spawnPopulation(f, s, villagers, soldiers) {
      villagers.forEach((job) => {
        const p = this.randomSpawnPoint(s, f);
        f.spawnUnit('villager', p.x + 0.5, p.y + 0.05, p.z + 0.5, s, job);
      });
      soldiers.forEach((type) => {
        const p = this.randomSpawnPoint(s, f);
        f.spawnUnit(type, p.x + 0.5, p.y + 0.05, p.z + 0.5, s);
      });
      s.assignHomes();
    }

    randomSpawnPoint(s, f) {
      const world = this.game.world;
      for (let i = 0; i < 40; i++) {
        const a = Math.random() * Math.PI * 2, r = 8 + Math.random() * 10;
        const x = Math.floor(s.center.x + Math.cos(a) * r), z = Math.floor(s.center.z + Math.sin(a) * r);
        const y = world.groundY(x, z);
        if (this.insideAnyBuilding(x, y, z)) continue;
        const p = world.findStandableNear(x, y, z, 2, f.id);
        if (p) return p;
      }
      return { x: s.center.x, y: world.groundY(s.center.x, s.center.z), z: s.center.z };
    }

    /** Creates a new settlement with its town hall (prebuilt or as a project). */
    foundSettlement(f, site, prebuilt) {
      const name = f.towns.length ? f.towns.shift() : f.shortName + ' Outpost';
      const world = this.game.world;
      const s = new VK.Settlement({ name: name, faction: f, center: { x: site.x, y: site.y, z: site.z }, radius: 30, isCapital: false });
      f.settlements.push(s);
      const enemy = this.enemyOf(f);
      const es = enemy.nearestSettlement(site);
      const rot = es ? VK.Settlement.rotFacing(es.center.x - site.x, es.center.z - site.z) : 0;
      const ox = Math.floor(site.x - 3), oz = Math.floor(site.z - 3);
      const ev = s.evaluateSite(ox, oz, 7, 7, 'keep');
      const y = ev ? ev.y : world.groundY(site.x, site.z) - 1;
      s.center.y = y + 1;
      s.addBuilding('hall', { x: ox, y: y, z: oz }, rot, null, prebuilt);
      return s;
    }

    /** Checks a potential town site using the terrain function only (no chunk generation). */
    siteScore(x, z) {
      const t = this.game.world.terrain;
      let min = 999, max = -999;
      for (let i = 0; i < 9; i++) {
        const c = t.sample(x + ((i % 3) - 1) * 11, z + (Math.floor(i / 3) - 1) * 11);
        if (c.h <= C.SEA_LEVEL + 1 || c.riverT < 0.9) return null;
        min = Math.min(min, c.h); max = Math.max(max, c.h);
      }
      if (max - min > 6) return null;
      return { rough: max - min, h: Math.round((min + max) / 2) };
    }

    findExpansionSite(f) {
      const Z = C.WAR_ZONE;
      const enemy = this.enemyOf(f);
      const all = this.settlements;
      let best = null, bs = Infinity;
      for (let i = 0; i < 160; i++) {
        const x = Math.floor(U.rand(Z.minX + 40, Z.maxX - 40)), z = Math.floor(U.rand(Z.minZ + 40, Z.maxZ - 40));
        const own = f.nearestSettlement({ x: x, z: z });
        if (!own) continue;
        const dOwn = U.dist2(x, z, own.center.x, own.center.z);
        if (dOwn < 62 || dOwn > 120) continue;
        if (all.some(function (s) { return U.dist2(x, z, s.center.x, s.center.z) < 64; })) continue;
        const es = enemy.nearestSettlement({ x: x, z: z });
        if (es && U.dist2(x, z, es.center.x, es.center.z) < 85) continue;
        const sc = this.siteScore(x, z);
        if (!sc) continue;
        const score = sc.rough * 5 + Math.abs(dOwn - 78) * 0.3 + Math.random() * 6;
        if (score < bs) { bs = score; best = { x: x, y: sc.h + 1, z: z }; }
      }
      return best;
    }

    findRevivalSite(f) {
      const Z = C.WAR_ZONE;
      const enemy = this.enemyOf(f);
      const home = this.capitalSites[f.id];
      let best = null, bs = Infinity;
      for (let i = 0; i < 220; i++) {
        const x = i === 0 ? home.x : Math.floor(U.rand(Z.minX + 30, Z.maxX - 30));
        const z = i === 0 ? home.z + 60 : Math.floor(U.rand(Z.minZ + 30, Z.maxZ - 30));
        const es = enemy.nearestSettlement({ x: x, z: z });
        const dE = es ? U.dist2(x, z, es.center.x, es.center.z) : 999;
        if (dE < 95) continue;
        if (this.settlements.some(function (s) { return U.dist2(x, z, s.center.x, s.center.z) < 60; })) continue;
        const sc = this.siteScore(x, z);
        if (!sc) continue;
        const score = sc.rough * 6 - Math.min(dE, 220) * 0.2 + U.dist2(x, z, home.x, home.z) * 0.05;
        if (score < bs) { bs = score; best = { x: x, y: sc.h + 1, z: z }; }
      }
      return best;
    }

    // ------------------------------------------------------- Queries

    rectBlocked(x0, z0, x1, z1) {
      const ss = this.settlements;
      for (let i = 0; i < ss.length; i++) {
        const s = ss[i];
        for (let k = 0; k < s.buildings.length; k++) {
          const b = s.buildings[k].bbox;
          if (x0 <= b.maxX && x1 >= b.minX && z0 <= b.maxZ && z1 >= b.minZ) return true;
        }
        const q = s.quarry;
        if (q && !q.done && x0 <= q.x0 + q.size && x1 >= q.x0 && z0 <= q.z0 + q.size && z1 >= q.z0) return true;
        if (s.fortPlan) {
          for (let k = 0; k < s.fortPlan.length; k++) {
            const p = s.fortPlan[k];
            if (p.built) continue;
            const sw = p.type === 'tower' ? 5 : p.params.length, sd = p.type === 'tower' ? 5 : 2;
            const w = p.rot % 2 ? sd : sw, d = p.rot % 2 ? sw : sd;
            if (x0 <= p.origin.x + w && x1 >= p.origin.x - 1 && z0 <= p.origin.z + d && z1 >= p.origin.z - 1) return true;
          }
        }
      }
      return false;
    }

    buildingAt(x, y, z) {
      const ss = this.settlements;
      for (let i = 0; i < ss.length; i++) {
        const bs = ss[i].buildings;
        for (let k = 0; k < bs.length; k++) if (bs[k].contains(x, y, z)) return bs[k];
      }
      return null;
    }

    insideAnyBuilding(x, y, z) { return this.buildingAt(x, y, z) !== null; }

    /** Settlement whose territory contains the point (closest centre wins). */
    settlementAt(x, z) {
      let best = null, bd = Infinity;
      this.settlements.forEach(function (s) {
        const d = U.dist2(x, z, s.center.x, s.center.z);
        if (d <= s.radius && d < bd) { bd = d; best = s; }
      });
      return best;
    }

    /** Routes voxel changes to the buildings they belong to. */
    onBlockChanged(x, y, z, oldId, newId, cause) {
      if (cause === 'prebuild') return;
      const ss = this.settlements;
      for (let i = 0; i < ss.length; i++) {
        const bs = ss[i].buildings;
        for (let k = 0; k < bs.length; k++) {
          const b = bs[k];
          if (!b.contains(x, y, z)) continue;
          b.dirty = true;
          if (cause === 'siege' || cause === 'player') b.lastDamageT = this.game.elapsed;
        }
      }
    }

    // ------------------------------------------------- War outcomes

    captureSettlement(s, newF) {
      const old = s.faction;
      const g = this.game;
      if (old === newF) return;
      const wasCapital = s.isCapital;
      old.settlements.splice(old.settlements.indexOf(s), 1);
      s.transferTo(newF);
      s.isCapital = false;
      newF.settlements.push(s);
      old.stats.lost++;
      newF.stats.captured++;
      const refuge = old.nearestSettlement(s.center);
      old.npcs.forEach(function (n) {
        if (n.settlement !== s) return;
        n.settlement = refuge;
        n.home = null;
        n.brain.halt();
      });
      old.squads.forEach(function (sq) {
        if (sq.settlement !== s) return;
        sq.settlement = refuge;
        if (!sq.campaign) sq.order = null;
      });
      if (wasCapital && old.settlements.length) {
        const next = old.settlements.slice().sort(function (a, b) { return b.popCap - a.popCap; })[0];
        next.isCapital = true;
        g.log(old.shortName + ' moves its court to ' + next.name + '.', old.id, 'war');
      }
      g.log(newF.shortName + ' has captured ' + s.name + ' from ' + old.shortName + '!', newF.id, 'war');
      g.ui.hud.centerMessage(s.name + ' has fallen!', 'Captured by the ' + newF.name, 5);
      g.audio.play('horn');
      g.audio.play('bell');
      if (!old.settlements.length) this.defeatFaction(old, newF);
    }

    defeatFaction(f, by) {
      const g = this.game;
      f.defeated = true;
      f.reviveT = C.REVIVE_TIME;
      f.stats.defeats++;
      if (f.campaign) f.campaign.end('defeat');
      f.npcs.slice().forEach(function (n) {
        g.particles.smoke(n.pos.x, n.pos.y + 1, n.pos.z, 6);
        n.brain.halt();
        f.removeNPC(n);
        g.entities.remove(n);
      });
      f.squads = [];
      g.log('The ' + f.name + ' has fallen to ' + by.shortName + '! Its survivors scatter into exile.', f.id, 'war');
      g.ui.hud.centerMessage('The ' + f.name + ' has fallen!', 'Its people flee into exile... for now', 6);
    }

    /** An exiled kingdom returns and founds a new capital far from its enemy. */
    reviveFaction(f) {
      const g = this.game;
      const site = this.findRevivalSite(f);
      if (!site) { f.reviveT = 60; return; }
      f.defeated = false;
      f.resources = { wood: 150, stone: 120, food: 150, iron: 26, gold: 12 };
      f.lastCampaignEnd = g.elapsed;
      const s = this.foundSettlement(f, site, true);
      s.isCapital = true;
      s.radius = 34;
      for (let i = 0; i < 2; i++) {
        const hs = s.findSite('house', null, 9, 24);
        if (hs) s.addBuilding('house', hs.origin, hs.rot, null, true);
      }
      const fs = s.findSite('farm', null, 10, 28);
      if (fs) s.addBuilding('farm', fs.origin, fs.rot, null, true);
      this.spawnPopulation(f, s,
        ['builder', 'builder', 'woodcutter', 'woodcutter', 'farmer', 'farmer', 'miner', 'miner', 'hauler'],
        ['captain', 'swordsman', 'swordsman', 'archer', 'archer']);
      g.log('Rising from exile, the ' + f.name + ' has founded ' + s.name + '!', f.id, 'war');
      g.ui.hud.centerMessage('The ' + f.name + ' rises again!', 'A new capital: ' + s.name, 5);
      g.audio.play('horn');
    }

    // --------------------------------------------------------- Update

    update(dt) {
      for (let i = 0; i < this.list.length; i++) this.list[i].update(dt);
      this.pinT -= dt;
      if (this.pinT <= 0) { this.pinT = 5; this.updatePinned(); }
    }

    /** Keeps settlement areas and chunks around NPCs resident in memory. */
    updatePinned() {
      const set = new Set();
      this.settlements.forEach(function (s) {
        const r = s.radius + 40;
        for (let cz = Math.floor((s.center.z - r) / 16); cz <= Math.floor((s.center.z + r) / 16); cz++) {
          for (let cx = Math.floor((s.center.x - r) / 16); cx <= Math.floor((s.center.x + r) / 16); cx++) set.add(U.chunkKey(cx, cz));
        }
      });
      this.list.forEach(function (f) {
        f.npcs.forEach(function (n) {
          const cx = Math.floor(n.pos.x / 16), cz = Math.floor(n.pos.z / 16);
          for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) set.add(U.chunkKey(cx + dx, cz + dz));
        });
      });
      this.game.world.pinned = set;
    }

    // ---------------------------------------------------- Persistence

    serialize() {
      return { capitalSites: this.capitalSites, factions: this.list.map(function (f) { return f.serialize(); }) };
    }

    deserialize(data) {
      const world = this.game.world;
      const settlementsById = new Map();
      data.factions.forEach((fd) => {
        const f = this.factions[fd.id];
        f.resources = fd.resources;
        Object.assign(f.stats, fd.stats);
        f.defeated = fd.defeated;
        f.reviveT = fd.reviveT;
        f.lastCampaignEnd = fd.lastCampaignEnd;
        if (fd.towns) f.towns = fd.towns;
        f.settlements = fd.settlements.map(function (sd) {
          const s = VK.Settlement.deserialize(sd, f);
          settlementsById.set(s.id, s);
          return s;
        });
      });
      data.factions.forEach((fd) => {
        const f = this.factions[fd.id];
        f.squads = (fd.squads || []).map(function (q) {
          const sq = new VK.Squad({ id: q.id, faction: f, settlement: settlementsById.get(q.settlement) || f.capital, type: q.type });
          sq.order = q.order;
          return sq;
        });
      });
      const buildingsById = new Map();
      this.settlements.forEach(function (s) { s.buildings.forEach(function (b) { buildingsById.set(b.id, b); }); });
      data.factions.forEach((fd) => {
        const f = this.factions[fd.id];
        fd.npcs.forEach(function (nd) {
          const s = settlementsById.get(nd.s) || f.capital;
          const n = f.spawnUnit(nd.type, nd.x, nd.y, nd.z, s, nd.job, { id: nd.id, name: nd.name, hp: nd.hp, noSquad: true });
          if (!n) return;
          if (nd.sq) {
            const sq = f.squads.find(function (q) { return q.id === nd.sq; });
            if (sq) sq.add(n);
          }
          if (nd.home) n.home = buildingsById.get(nd.home) || null;
        });
      });
      this.settlements.forEach(function (s) {
        s.buildings.forEach(function (b) {
          b.computeIntegrity(world);
          if (b.functional) b.spawnBanners();
        });
        s.popCache = s.members().length;
      });
      this.updatePinned();
    }
  }

  VK.Kingdoms = Kingdoms;
})(window.VK);
