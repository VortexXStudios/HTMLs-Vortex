/**
 * @file faction.js
 * A kingdom: identity (names, colours, ruler, temperament), economy
 * (resources, food upkeep), population (NPC list), squads, settlements,
 * war statistics and its leader AI.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;
  const C = VK.Config;

  const DEFS = {
    ironhold: {
      name: 'Kingdom of Ironhold', shortName: 'Ironhold', color: 0x3b5bd6, css: '#3b5bd6',
      ruler: 'King Aldric Stormhelm', aggression: 0.45, capitalName: 'Ironhold Keep',
      towns: ['Stonewatch', 'Greyford', 'Frostmere', 'Anvil Hill', 'Highmarch', 'Coldharbor', 'Irongate', 'Silverbrook'],
      motto: 'Stone endures.'
    },
    redmoor: {
      name: 'Kingdom of Redmoor', shortName: 'Redmoor', color: 0xc83232, css: '#c83232',
      ruler: 'Queen Morwen Ashvale', aggression: 0.7, capitalName: 'Redmoor Castle',
      towns: ['Emberfall', 'Crimson Vale', 'Ashbourne', 'Rosehollow', 'Scarlet Ford', 'Cinderhold', 'Redwater', 'Blazeholm'],
      motto: 'Fire and glory.'
    }
  };

  class Faction {
    constructor(id) {
      const d = DEFS[id];
      this.id = id;
      this.name = d.name;
      this.shortName = d.shortName;
      this.color = d.color;
      this.css = d.css;
      this.ruler = d.ruler;
      this.aggression = d.aggression;
      this.capitalName = d.capitalName;
      this.towns = d.towns.slice();
      this.motto = d.motto;
      this.resources = { wood: 180, stone: 200, food: 170, iron: 40, gold: 24 };
      this.settlements = [];
      this.npcs = [];
      this.squads = [];
      this.campaign = null;
      this.lastCampaignEnd = -1000;
      this.defeated = false;
      this.reviveT = 0;
      this.foodT = 0;
      this.starveLogT = 0;
      this.sightings = [];
      this.stats = { kills: 0, losses: 0, built: 0, captured: 0, lost: 0, trained: 0, born: 0, gathered: 0, campaigns: 0, victories: 0, defeats: 0 };
      this.leader = new VK.FactionLeader(this);
      this.kingdoms = null;
    }

    get enemy() { return this.kingdoms ? this.kingdoms.enemyOf(this) : null; }

    get capital() {
      return this.settlements.find(function (s) { return s.isCapital; }) || this.settlements[0] || null;
    }

    get priority() { return this.defeated ? 'In exile' : this.leader.priority; }

    nearestSettlement(pos) {
      let best = null, bd = Infinity;
      this.settlements.forEach(function (s) {
        const d = U.dist2(pos.x, pos.z, s.center.x, s.center.z);
        if (d < bd) { bd = d; best = s; }
      });
      return best;
    }

    inTerritory(x, z) { return this.settlements.some(function (s) { return s.contains(x, z); }); }

    /** Creates an NPC for this faction and registers it everywhere. */
    spawnUnit(type, x, y, z, settlement, job, extra) {
      if (this.npcs.length >= C.MAX_NPCS_PER_FACTION && !extra) return null;
      const o = Object.assign({ faction: this, type: type, job: job, x: x, y: y, z: z, settlement: settlement }, extra || {});
      const npc = new VK.NPC(o);
      this.npcs.push(npc);
      VK.game.entities.add(npc);
      if (npc.isSoldier && !(extra && extra.noSquad)) this.leader.assignSquad(npc);
      return npc;
    }

    /** Removes a unit without a death (disbanded after defeat). */
    removeNPC(npc) {
      const i = this.npcs.indexOf(npc);
      if (i >= 0) this.npcs.splice(i, 1);
      if (npc.squad) npc.squad.remove(npc);
    }

    onUnitDeath(npc, killer) {
      this.removeNPC(npc);
      this.stats.losses++;
      const kf = killer && killer.faction && killer.faction !== this ? killer.faction : null;
      if (kf && kf.stats) kf.stats.kills++;
      if (killer && killer.isPlayer && VK.game.player.faction && VK.game.player.faction !== this.id) {
        const pf = this.kingdoms.factions[VK.game.player.faction];
        if (pf) pf.stats.kills++;
      }
      if (npc.type === 'captain' || npc.isSiege) {
        const who = killer && killer.isPlayer ? 'you' : (kf ? kf.shortName : 'the enemy');
        VK.game.log(npc.displayName + ' of ' + this.shortName + ' was slain by ' + who + '.', this.id, 'war');
      }
    }

    reportSighting(pos, count) {
      if (!this.inTerritory(pos.x, pos.z)) return;
      const t = VK.game.elapsed;
      this.sightings.push({ x: pos.x, z: pos.z, t: t, count: count });
      if (this.sightings.length > 30) this.sightings.splice(0, this.sightings.length - 30);
    }

    soldiers() { return this.npcs.filter(function (n) { return n.isSoldier && !n.isSiege; }); }
    villagers() { return this.npcs.filter(function (n) { return n.isVillager; }); }

    militaryStrength() {
      let s = 0;
      for (let i = 0; i < this.npcs.length; i++) {
        const n = this.npcs[i];
        if (n.isSoldier) s += n.stats.power * (0.4 + 0.6 * n.hp / n.maxHp);
      }
      return s;
    }

    update(dt) {
      const g = VK.game;
      if (this.defeated) {
        this.reviveT -= dt;
        if (this.reviveT <= 0) this.kingdoms.reviveFaction(this);
        return;
      }
      // Everybody eats.
      this.foodT += dt;
      if (this.foodT >= C.FOOD_UPKEEP_INTERVAL) {
        this.foodT = 0;
        const need = this.npcs.filter(function (n) { return !n.isSiege; }).length;
        if (this.resources.food >= need) this.resources.food -= need;
        else {
          this.resources.food = 0;
          const victims = U.shuffle(this.npcs.slice()).slice(0, 3);
          victims.forEach(function (n) { if (!n.isSiege) VK.Combat.applyDamage(n, 3, null, 'starve'); });
          if (g.elapsed - this.starveLogT > 120) {
            this.starveLogT = g.elapsed;
            g.log('The people of ' + this.shortName + ' are starving!', this.id, 'war');
          }
        }
      }
      for (let i = 0; i < this.settlements.length; i++) this.settlements[i].update(dt);
      for (let i = 0; i < this.squads.length; i++) this.squads[i].update(dt);
      if (this.campaign) this.campaign.update(dt);
      this.leader.update(dt);
    }

    serialize() {
      return {
        id: this.id,
        resources: this.resources,
        stats: this.stats,
        defeated: this.defeated,
        reviveT: this.reviveT,
        lastCampaignEnd: this.lastCampaignEnd,
        towns: this.towns,
        settlements: this.settlements.map(function (s) { return s.serialize(); }),
        squads: this.squads.map(function (sq) { return sq.serialize(); }),
        npcs: this.npcs.filter(function (n) { return !n.dead; }).map(function (n) { return n.serialize(); })
      };
    }
  }

  Faction.DEFS = DEFS;
  VK.Faction = Faction;
})(window.VK);
