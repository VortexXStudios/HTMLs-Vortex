/**
 * @file leader.js
 * The faction leader AI: the ruler of a kingdom who, every few seconds,
 * weighs the situation and decides priorities:
 *
 *   - Defence   : sends nearby squads to settlements under attack
 *   - Economy   : balances villager jobs against resource shortages
 *   - Growth    : new villagers while food and housing allow
 *   - Building  : repairs first, then houses, farms, barracks, fortifications
 *   - Military  : trains a balanced army and organises it into squads
 *   - War       : launches campaigns when the field army is strong enough
 *   - Expansion : founds new outposts when rich and populous
 *
 * The current top priority is exposed for the UI (`priority`).
 */
(function (VK) {
  'use strict';

  const U = VK.Util;
  const C = VK.Config;
  const JOBS = ['woodcutter', 'miner', 'farmer', 'builder', 'hauler'];

  class FactionLeader {
    constructor(faction) {
      this.f = faction;
      this.thinkT = Math.random() * 2;
      this.priority = 'Economy';
      this.readiness = 0;
      this.lastExpansion = -1000;
      this.orderT = 0;
    }

    update(dt) {
      this.thinkT -= dt;
      if (this.thinkT > 0) return;
      this.thinkT = 3;
      if (this.f.defeated) return;
      this.think();
    }

    think() {
      const threat = this.manageDefence();
      this.manageJobs();
      this.managePopulation();
      this.manageConstruction(threat);
      this.manageMilitary(threat);
      this.organiseSquads();
      const war = this.manageWar(threat);
      const expand = this.manageExpansion(threat);
      if (threat) this.priority = 'Defence';
      else if (this.f.campaign) this.priority = 'War';
      else if (expand) this.priority = 'Expansion';
      else if (war) this.priority = 'Mustering';
      else if (this.f.resources.food < this.f.npcs.length * 3) this.priority = 'Food';
      else if (this.f.settlements.some(function (s) { return s.projects().length > 0; })) this.priority = 'Building';
      else this.priority = 'Economy';
    }

    // ------------------------------------------------------------ Defence

    /** Sends squads to settlements under attack; returns true if threatened. */
    manageDefence() {
      const f = this.f;
      let threatened = false;
      const g = VK.game;
      f.settlements.forEach((s) => {
        if (!s.underAttack) {
          // Stand down squads that were defending this settlement.
          f.squads.forEach((sq) => {
            if (sq.defending === s && g.elapsed - s.lastAttackT > 15) {
              sq.defending = null;
              this.defaultOrder(sq);
            }
          });
          return;
        }
        threatened = true;
        // Where is the enemy?
        const list = g.entities.queryRadius(s.center.x, s.center.z, s.radius + 8, []);
        let ex = 0, ez = 0, n = 0;
        list.forEach(function (e) { if (e.faction !== f && !e.isVillager) { ex += e.pos.x; ez += e.pos.z; n++; } });
        const p = g.player;
        if (p && !p.dead && VK.Diplomacy.playerHostileTo(f.id) && s.contains(p.pos.x, p.pos.z)) { ex += p.pos.x; ez += p.pos.z; n++; }
        if (!n) return;
        const point = { x: Math.floor(ex / n), y: 0, z: Math.floor(ez / n) };
        point.y = g.world.groundY(point.x, point.z);
        f.squads.forEach((sq) => {
          if (sq.campaign || sq.type === 'player' || sq.type === 'siege' || !sq.size) return;
          const c = sq.centroid();
          if (!c || U.dist2(c.x, c.z, s.center.x, s.center.z) > 140) return;
          if (sq.type === 'garrison' && sq.settlement === s && s.enemiesNear < 3) return;
          sq.defending = s;
          if (!sq.order || sq.order.type !== 'defend' || U.dist2(sq.order.point.x, sq.order.point.z, point.x, point.z) > 8) {
            sq.setOrder({ type: 'defend', point: point });
          }
        });
        // Recall a campaign if the capital itself is in serious danger.
        if (f.campaign && s.isCapital && s.enemiesNear >= 6) {
          f.campaign.beginRetreat('recalled');
          g.log(f.shortName + ' recalls its army to defend ' + s.name + '.', f.id, 'war');
        }
      });
      return threatened;
    }

    // ------------------------------------------------------------ Economy

    /** Rebalances villager jobs in every settlement. */
    manageJobs() {
      const f = this.f;
      const r = f.resources;
      f.settlements.forEach(function (s) {
        const villagers = s.members().filter(function (n) { return n.isVillager; });
        const n = villagers.length;
        if (!n) return;
        const projects = s.projects();
        const want = { woodcutter: 0, miner: 0, farmer: 0, builder: 0, hauler: 0 };
        want.builder = projects.length ? Math.min(s.isCapital ? 4 : 2, 1 + projects.length) : (n > 8 ? 1 : 0);
        want.builder = Math.min(want.builder, Math.max(1, Math.floor(n * 0.3)));
        const piled = s.stockpiles.reduce(function (a, p) { return a + p.amount; }, 0);
        want.hauler = n >= 4 ? Math.max(1, Math.round(n * 0.17)) + Math.min(2, Math.floor(piled / 70)) : 0;
        let rest = n - want.builder - want.hauler;
        if (rest < 0) { want.hauler = Math.max(0, want.hauler + rest); rest = 0; }
        // Shortages steer the gatherer split.
        let needWood = 0, needStone = 0;
        projects.forEach(function (b) { needWood += Math.max(0, b.need('wood')); needStone += Math.max(0, b.need('stone')); });
        const pop = f.npcs.length;
        const wW = Math.max(0.2, (220 - r.wood + needWood) / 220);
        const wS = Math.max(0.2, (200 - r.stone + needStone) / 200) + (r.iron < 25 ? 0.3 : 0);
        const farms = s.count('farm');
        const wF = Math.max(0.25, (pop * 7 - r.food) / Math.max(40, pop * 7)) + 0.2;
        const tot = wW + wS + wF;
        want.farmer = Math.min(Math.round(rest * wF / tot), farms * 3 + 1);
        want.miner = Math.round(rest * wS / tot);
        want.woodcutter = Math.max(0, rest - want.farmer - want.miner);
        const have = {};
        JOBS.forEach(function (j) { have[j] = 0; });
        villagers.forEach(function (v) { have[v.job] = (have[v.job] || 0) + 1; });
        // Move idle-handed villagers from over-staffed to under-staffed jobs.
        villagers.forEach(function (v) {
          if (v.carry.amount > 0) return;
          if (have[v.job] <= want[v.job]) return;
          const target = JOBS.find(function (j) { return have[j] < want[j]; });
          if (!target) return;
          have[v.job]--;
          have[target]++;
          v.brain.halt();
          v.setJob(target);
        });
      });
    }

    managePopulation() {
      const f = this.f;
      const g = VK.game;
      // Resettle villagers into empty or captured settlements.
      const byVillagers = f.settlements.map(function (s) {
        return { s: s, v: s.members().filter(function (n) { return n.isVillager; }) };
      });
      byVillagers.forEach(function (e) {
        if (e.v.length >= 4 || e.s.underAttack) return;
        const donor = byVillagers.filter(function (o) { return o !== e && o.v.length > 10; }).sort(function (a, b) { return b.v.length - a.v.length; })[0];
        if (!donor) return;
        const wanted = ['builder', 'hauler', 'farmer', 'woodcutter'];
        let moved = 0;
        wanted.forEach(function (job) {
          const m = donor.v.find(function (n) { return n.job === job && !n.carry.amount && n.settlement === donor.s; });
          if (!m) return;
          m.settlement = e.s;
          m.home = null;
          m.brain.halt();
          moved++;
        });
        if (moved) g.log('Settlers from ' + donor.s.name + ' head to ' + e.s.name + '.', f.id);
      });
      if (f.npcs.length >= C.MAX_NPCS_PER_FACTION) return;
      f.settlements.forEach(function (s) {
        s.timers.birth = (s.timers.birth || 0) - 3;
        if (s.timers.birth > 0) return;
        if (s.population >= s.popCap) return;
        const villagers = s.members().filter(function (n) { return n.isVillager; }).length;
        const want = s.isCapital ? 26 : 12;
        if (villagers >= want) return;
        if (f.resources.food < 25 + f.npcs.length * 0.8) return;
        f.resources.food -= 10;
        s.birthVillager(villagers < 3 ? 'builder' : 'hauler');
        s.timers.birth = villagers < 6 ? 12 : 22;
        if (g.player && s.contains(g.player.pos.x, g.player.pos.z) && Math.random() < 0.3) g.log('A new villager joined ' + s.name + '.', f.id);
      });
    }

    // ----------------------------------------------------------- Building

    canAfford(type, params, fraction) {
      const cost = VK.Blueprints.create(type, this.f.id, this.f.id, params).cost();
      const r = this.f.resources;
      for (const k in cost) if (cost[k] > 0 && r[k] < cost[k] * fraction) return false;
      return true;
    }

    manageConstruction(threat) {
      const f = this.f;
      const g = VK.game;
      f.settlements.forEach((s) => {
        const projects = s.projects();
        const builders = s.countJob('builder');
        const maxProjects = Math.min(3, 1 + Math.floor(builders / 2));
        // Repairs have priority once the fighting stops.
        if (g.elapsed - s.lastAttackT > 20) {
          const damaged = s.buildings.filter(function (b) {
            return !b.removed && b.state === 'complete' && b.integrity < 0.94;
          }).sort(function (a, b) { return (b.info.core ? 1 : 0) - (a.info.core ? 1 : 0) || a.integrity - b.integrity; });
          if (damaged.length && projects.length < maxProjects + 1) {
            if (damaged[0].planRepair(g.world)) return;
          }
        }
        if (projects.length >= maxProjects) return;
        if (s.underAttack) return;
        const pop = s.population;
        const houses = s.count('house', true);
        const farms = s.count('farm', true);
        const wantFarms = Math.max(s.isCapital ? 2 : 1, Math.ceil(pop / 13));
        const plan = (type, params, frac) => {
          if (!this.canAfford(type, params, frac)) return false;
          return !!s.planBuilding(type, params);
        };
        if (!s.core) { plan(s.isCapital ? 'keep' : 'hall', null, 0.2); return; }
        if (pop >= s.popCap - 2 && houses < (s.isCapital ? 12 : 6) && plan('house', null, 0.5)) return;
        if (farms < wantFarms && f.resources.food < pop * 10 + 60 && plan('farm', null, 0.3)) return;
        if (!s.has('barracks', true) && (s.isCapital || pop >= 10) && plan('barracks', null, 0.5)) return;
        if (!s.isCapital && !s.has('storage', true) && pop >= 12 && plan('storage', null, 0.5)) return;
        if (s.fortPlan && s.fortPlan.some(function (p) { return !p.built; })) {
          const rich = f.resources.stone > 180 && f.resources.wood > 60;
          if (threat || rich || (g.elapsed > 420 && f.resources.stone > 60)) {
            const next = s.fortPlan.find(function (p) { return !p.built; });
            if (plan(next.type, next.params, 0.35)) return;
          }
        }
        if (!s.isCapital && !s.has('tower', true) && pop >= 6 && plan('tower', null, 0.5)) return;
        if (houses < 4 && pop >= s.popCap - 4 && plan('house', null, 0.5)) return;
      });
    }

    // ----------------------------------------------------------- Military

    manageMilitary(threat) {
      const f = this.f;
      if (f.npcs.length >= C.MAX_NPCS_PER_FACTION) return;
      // Keep a food reserve for the people unless the realm is in danger.
      if (!threat && f.resources.food < f.npcs.length * 1.2 + 12) return;
      const soldiers = f.npcs.filter(function (n) { return n.isSoldier && !n.isSiege; });
      let queued = 0, queuedSiege = 0;
      f.settlements.forEach(function (s) {
        s.training.forEach(function (t) { if (t.type === 'trebuchet') queuedSiege++; else queued++; });
      });
      const totalPop = f.npcs.length;
      let target = U.clamp(Math.round(totalPop * 0.5), 10, 50);
      if (threat) target += 6;
      if (this.priority === 'Mustering' || this.priority === 'War') target += 4;
      const barracksSettlements = f.settlements.filter(function (s) { return s.buildings.some(function (b) { return b.type === 'barracks' && b.functional; }); });
      if (!barracksSettlements.length) return;
      const s = barracksSettlements.find(function (x) { return x.isCapital; }) || barracksSettlements[0];
      const housing = f.settlements.reduce(function (a, x) { return a + x.popCap; }, 0);
      if (totalPop + queued >= housing + 6) return;
      if (s.training.length >= 3) return;
      if (soldiers.length + queued < target) {
        const counts = { swordsman: 0, spearman: 0, archer: 0, crossbowman: 0, captain: 0 };
        soldiers.forEach(function (n) { counts[n.type]++; });
        f.settlements.forEach(function (x) { x.training.forEach(function (t) { if (counts[t.type] !== undefined) counts[t.type]++; }); });
        const n = soldiers.length + queued + 1;
        let type = 'swordsman';
        if (counts.captain < Math.max(1, Math.floor(n / 8))) type = 'captain';
        else if (counts.archer < n * 0.3) type = 'archer';
        else if (counts.spearman < n * 0.2) type = 'spearman';
        else if (counts.crossbowman < n * 0.12) type = 'crossbowman';
        if (!s.queueUnit(type)) {
          // Fall back to something affordable.
          ['archer', 'spearman', 'swordsman'].some(function (t) { return s.queueUnit(t); });
        }
      }
      // Siege engines for the coming war.
      const enemy = f.enemy;
      const trebs = f.npcs.filter(function (x) { return x.isSiege; }).length + queuedSiege;
      const fortified = enemy && enemy.settlements.some(function (es) { return es.count('tower') + es.count('wall') > 0; });
      if (fortified && trebs < 2 && soldiers.length >= 10 && f.resources.wood > 80) s.queueUnit('trebuchet');
    }

    /** Puts unassigned soldiers into squads and gives idle squads orders. */
    organiseSquads() {
      const f = this.f;
      f.npcs.forEach((n) => { if (n.isSoldier && !n.squad) this.assignSquad(n); });
      f.squads = f.squads.filter(function (sq) { return sq.size > 0 || sq.type === 'player'; });
      f.squads.forEach((sq) => {
        if (!sq.order && !sq.campaign && sq.type !== 'player') this.defaultOrder(sq);
      });
    }

    /** Chooses a squad for a new soldier (garrison, patrol, field or siege). */
    assignSquad(npc) {
      const f = this.f;
      let s = npc.settlement;
      if (!s || s.faction !== f) s = npc.settlement = f.nearestSettlement(npc.pos) || f.capital;
      if (!s) return;
      const find = function (type, max) {
        return f.squads.find(function (sq) { return sq.type === type && sq.settlement === s && !sq.campaign && sq.size < max; });
      };
      let type, max;
      if (npc.isSiege) { type = 'siege'; max = 4; }
      else {
        const garrisonSize = f.squads.filter(function (sq) { return sq.type === 'garrison' && sq.settlement === s; }).reduce(function (a, sq) { return a + sq.size; }, 0);
        const patrolSize = f.squads.filter(function (sq) { return sq.type === 'patrol' && sq.settlement === s; }).reduce(function (a, sq) { return a + sq.size; }, 0);
        if (garrisonSize < (s.isCapital ? 6 : 3)) { type = 'garrison'; max = s.isCapital ? 6 : 3; }
        else if (s.isCapital && patrolSize < 5) { type = 'patrol'; max = 5; }
        else { type = 'field'; max = 8; }
      }
      let sq = find(type, max);
      if (!sq) {
        sq = new VK.Squad({ faction: f, settlement: s, type: type });
        f.squads.push(sq);
      }
      sq.add(npc);
      if (!sq.order) this.defaultOrder(sq);
    }

    /** Peace-time orders for a squad. */
    defaultOrder(sq) {
      const s = sq.settlement && sq.settlement.faction === this.f ? sq.settlement : (sq.settlement = this.f.nearestSettlement(sq.leader ? sq.leader.pos : { x: 0, z: 0 }));
      if (!s) { sq.setOrder(null); return; }
      const world = VK.game.world;
      const snap = function (x, z) { x = Math.floor(x); z = Math.floor(z); return { x: x, y: world.groundY(x, z), z: z }; };
      if (sq.type === 'patrol') {
        const pts = [];
        for (let i = 0; i < 6; i++) {
          const a = i / 6 * Math.PI * 2;
          pts.push(snap(s.center.x + Math.cos(a) * s.radius * 0.9, s.center.z + Math.sin(a) * s.radius * 0.9));
        }
        const enemy = this.f.enemy;
        const es = enemy && enemy.nearestSettlement(s.center);
        if (es) {
          // Border patrols range toward the enemy, which leads to skirmishes.
          const dx = es.center.x - s.center.x, dz = es.center.z - s.center.z;
          const d = Math.sqrt(dx * dx + dz * dz) || 1;
          const reach = Math.min(d * 0.46, s.radius + 64);
          pts.splice(1, 0, snap(s.center.x + dx / d * (s.radius + 20), s.center.z + dz / d * (s.radius + 20)));
          pts.splice(2, 0, snap(s.center.x + dx / d * reach - dz / d * 12, s.center.z + dz / d * reach + dx / d * 12));
          pts.splice(3, 0, snap(s.center.x + dx / d * reach + dz / d * 12, s.center.z + dz / d * reach - dx / d * 12));
        }
        sq.setOrder({ type: 'patrol', points: pts, index: 0, point: pts[0] });
        return;
      }
      if (sq.type === 'garrison') {
        const core = s.core;
        const posts = [];
        if (core) {
          const e = core.entrance;
          posts.push({ x: e.x - 2, y: e.y, z: e.z }, { x: e.x + 2, y: e.y, z: e.z });
        }
        const gate = s.buildings.find(function (b) { return b.type === 'wall' && b.params.gate && b.functional; });
        if (gate) { const p = gate.interiorPoint(); posts.push({ x: p.x - 1, y: p.y, z: p.z }, { x: p.x + 1, y: p.y, z: p.z }); }
        for (let i = 0; i < 4; i++) {
          const a = i / 4 * Math.PI * 2 + 0.4;
          posts.push(snap(s.center.x + Math.cos(a) * 10, s.center.z + Math.sin(a) * 10));
        }
        const d = VK.Settlement.dirVec(s.gateDir);
        sq.setOrder({ type: 'garrison', posts: posts.map((p) => this.standable(p)), facing: Math.atan2(d[0], d[1]) });
        return;
      }
      // Field army and siege engines camp by the barracks.
      const bar = s.buildings.find(function (b) { return b.type === 'barracks' && !b.removed; }) || s.core;
      const base = bar ? bar.entrance : s.center;
      const posts = [];
      for (let i = 0; i < 8; i++) {
        const a = i / 8 * Math.PI * 2;
        posts.push(snap(base.x + Math.cos(a) * (sq.type === 'siege' ? 7 : 4), base.z + Math.sin(a) * (sq.type === 'siege' ? 7 : 4)));
      }
      sq.setOrder({ type: 'garrison', posts: posts.map((p) => this.standable(p)) });
    }

    standable(p) {
      const s = VK.game.world.findStandableNear(p.x, p.y, p.z, 3, this.f.id);
      return s || p;
    }

    // ---------------------------------------------------------------- War

    /** Launches a campaign when the field army is strong enough. */
    manageWar(threat) {
      const f = this.f;
      const g = VK.game;
      if (f.campaign && !threat) {
        // Reinforce the army in the field with newly trained squads.
        f.squads.forEach(function (sq) {
          if ((sq.type === 'field' || sq.type === 'siege') && !sq.campaign && !sq.defending && sq.size >= (sq.type === 'siege' ? 1 : 3)) f.campaign.addSquad(sq);
        });
        return false;
      }
      if (f.campaign || threat) return false;
      const enemy = f.enemy;
      if (!enemy || enemy.defeated || !enemy.settlements.length) return false;
      if (g.elapsed < C.FIRST_CAMPAIGN_DELAY) return false;
      if (g.elapsed - f.lastCampaignEnd < C.CAMPAIGN_COOLDOWN) return false;
      const squads = f.squads.filter(function (sq) {
        return (sq.type === 'field' || sq.type === 'siege' || sq.type === 'patrol') && sq.size > 0 && !sq.campaign && !sq.defending;
      });
      const units = squads.reduce(function (a, sq) { return a + sq.size; }, 0);
      const myStr = squads.reduce(function (a, sq) { return a + sq.strength(); }, 0);
      const enemyStr = enemy.militaryStrength();
      this.readiness = myStr / Math.max(5, enemyStr * 0.55);
      if (units < 10) return false;
      if (this.readiness < 1.3 - f.aggression * 0.5) return true;
      // Pick a target: close, weakly defended settlements first.
      let target = null, best = Infinity;
      enemy.settlements.forEach(function (es) {
        const own = f.nearestSettlement(es.center);
        if (!own) return;
        const d = U.dist2(own.center.x, own.center.z, es.center.x, es.center.z);
        const def = (es.count('tower') + es.count('wall')) * 18 + (es.isCapital ? 40 : 0);
        const score = d + def;
        if (score < best) { best = score; target = es; }
      });
      if (!target) return false;
      f.campaign = new VK.Campaign(f, target, squads);
      g.log(f.ruler + ' of ' + f.shortName + ' declares a campaign against ' + target.name + '!', f.id, 'war');
      g.audio.play('horn', g.camera.position);
      return true;
    }

    // ---------------------------------------------------------- Expansion

    manageExpansion(threat) {
      const f = this.f;
      const g = VK.game;
      if (threat || f.campaign) return false;
      if (f.settlements.length >= C.MAX_SETTLEMENTS_PER_FACTION) return false;
      if (g.elapsed - this.lastExpansion < 240 || g.elapsed < 200) return false;
      if (f.npcs.length < 24) return false;
      const r = f.resources;
      if (r.wood < 110 || r.stone < 90 || r.food < 70) return true;
      const site = g.kingdoms.findExpansionSite(f);
      this.lastExpansion = g.elapsed;
      if (!site) return false;
      const from = f.nearestSettlement(site) || f.capital;
      const s = g.kingdoms.foundSettlement(f, site, false);
      if (!s) return false;
      const hall = s.core;
      if (hall) {
        const give = { wood: 60, stone: 50, food: 20 };
        for (const k in give) { const a = Math.min(give[k], r[k]); r[k] -= a; hall.stock[k] += a; }
      }
      // The expedition: builders, gatherers, a porter and an escort.
      const members = from.members();
      const pickJob = function (job, n) {
        members.filter(function (m) { return m.isVillager && m.job === job && !m.carry.amount; }).slice(0, n).forEach(function (m) {
          m.settlement = s; m.home = null; m.brain.halt();
        });
      };
      pickJob('builder', 2); pickJob('woodcutter', 1); pickJob('farmer', 1); pickJob('hauler', 1); pickJob('miner', 1);
      const escortSquad = f.squads.find(function (sq) { return sq.type === 'field' && sq.settlement === from && !sq.campaign && sq.size >= 3; });
      if (escortSquad) {
        const sq = new VK.Squad({ faction: f, settlement: s, type: 'garrison' });
        f.squads.push(sq);
        escortSquad.members.slice(0, 4).forEach(function (m) { sq.add(m); m.settlement = s; });
        this.defaultOrder(sq);
        if (!sq.order || !sq.order.posts || !sq.order.posts.length) sq.setOrder({ type: 'march', point: { x: s.center.x, y: s.center.y, z: s.center.z } });
      }
      g.log(f.shortName + ' founded the outpost of ' + s.name + '.', f.id);
      return true;
    }
  }

  VK.FactionLeader = FactionLeader;
})(window.VK);
