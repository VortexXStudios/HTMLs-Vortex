/**
 * @file pathfinder.js
 * A* path finding on the voxel grid for walking NPCs.
 *
 * Nodes are "feet cells": two passable blocks with support below (or water).
 * Moves: 8 directions without corner cutting, 1 block step-ups, drops of up
 * to 3 blocks, swimming (vertical moves in water, higher cost).
 * Faction gates are passable for their owners only.
 * Siege mode lets attackers plan paths *through* enemy structures: blocked
 * cells become passable at a cost proportional to their hit points and the
 * resulting nodes are flagged so the navigator knows to break them.
 *
 * Search state lives in preallocated typed arrays with an indexed binary
 * heap (true decrease-key); a PathService queue spreads requests over frames.
 */
(function (VK) {
  'use strict';

  const B = VK.Blocks;
  const U = VK.Util;
  const SOLID = B.SOLID, GROUND = B.GROUND;
  const WATER = B.WATER, BEDROCK = B.BEDROCK, GATE_BLUE = B.GATE_BLUE, GATE_RED = B.GATE_RED;

  const POOL = 60000;
  const NX = new Int32Array(POOL), NY = new Int16Array(POOL), NZ = new Int32Array(POOL);
  const G = new Float32Array(POOL), F = new Float32Array(POOL), HH = new Float32Array(POOL);
  const PARENT = new Int32Array(POOL), FLAG = new Uint8Array(POOL), CLOSED = new Uint8Array(POOL);
  const HPOS = new Int32Array(POOL);
  const HEAP = new Int32Array(POOL);
  let heapN = 0;
  let used = 0;

  // Open addressing hash table (position key -> node index). A generation
  // stamp invalidates all entries between searches without clearing.
  const HSIZE = 1 << 17, HMASK = HSIZE - 1;
  const HKEY = new Int32Array(HSIZE), HVAL = new Int32Array(HSIZE), HSTAMP = new Int32Array(HSIZE);
  let stamp = 0;

  const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
  const MAX_DROP = 3;

  // Search context
  let W = null, FAC = null, BREACH = false;
  let GX = 0, GY = 0, GZ = 0, RADIUS = 0, YRANGE = 2;
  let SX = 0, SZ = 0;

  // Direct-indexed chunk cache around the search start (avoids Map lookups).
  const CG = 9, CGW = CG * 2 + 1;
  const cgrid = new Array(CGW * CGW);
  let CCX = 0, CCZ = 0;

  /** Block id with a per-search chunk cache. */
  function blk(x, y, z) {
    if (y < 0) return BEDROCK;
    if (y >= 128) return 0;
    const gx = (x >> 4) - CCX + CG, gz = (z >> 4) - CCZ + CG;
    if (gx < 0 || gz < 0 || gx >= CGW || gz >= CGW) return W.getBlock(x, y, z);
    const gi = gx + gz * CGW;
    let c = cgrid[gi];
    if (c === undefined) {
      c = W.chunks.get(U.chunkKey(x >> 4, z >> 4)) || W.ensureChunk(x >> 4, z >> 4);
      cgrid[gi] = c;
    }
    return c.blocks[(x & 15) | ((z & 15) << 4) | (y << 8)];
  }

  /** Small integer node key relative to the search start (fast Map key). */
  function localKey(x, y, z) {
    return (((x - SX + 1024) & 2047) * 2048 + ((z - SZ + 1024) & 2047)) * 128 + y;
  }

  // ------------------------------------------------------------ Heap

  function siftUp(i) {
    const n = HEAP[i], f = F[n];
    while (i > 0) {
      const p = (i - 1) >> 1;
      const pn = HEAP[p];
      if (F[pn] <= f) break;
      HEAP[i] = pn; HPOS[pn] = i; i = p;
    }
    HEAP[i] = n; HPOS[n] = i;
  }
  function siftDown(i) {
    const n = HEAP[i], f = F[n];
    for (;;) {
      const l = i * 2 + 1;
      if (l >= heapN) break;
      const r = l + 1;
      const c = (r < heapN && F[HEAP[r]] < F[HEAP[l]]) ? r : l;
      if (F[HEAP[c]] >= f) break;
      HEAP[i] = HEAP[c]; HPOS[HEAP[c]] = i; i = c;
    }
    HEAP[i] = n; HPOS[n] = i;
  }
  function push(n) { HEAP[heapN] = n; HPOS[n] = heapN; heapN++; siftUp(heapN - 1); }
  function pop() {
    const top = HEAP[0];
    HPOS[top] = -1;
    heapN--;
    if (heapN > 0) { HEAP[0] = HEAP[heapN]; HPOS[HEAP[0]] = 0; siftDown(0); }
    return top;
  }

  // ----------------------------------------------------- Passability

  function blocks(id) {
    if (!SOLID[id]) return false;
    if (id === GATE_BLUE) return FAC !== 'ironhold';
    if (id === GATE_RED) return FAC !== 'redmoor';
    return true;
  }
  function free(x, y, z) { return !blocks(blk(x, y, z)); }
  function standable(x, y, z) {
    const a = blk(x, y, z);
    if (blocks(a) || blocks(blk(x, y + 1, z))) return false;
    if (a === WATER) return true;
    const below = blk(x, y - 1, z);
    return SOLID[below] === 1 || below === WATER;
  }
  /** Cost of breaking through a block in siege mode (Infinity = impossible). */
  function breachCost(id) {
    if (!blocks(id)) return 0;
    if (id === BEDROCK) return Infinity;
    if (GROUND[id]) return 40;
    return 4 + B.defs[id].siegeHp / 4;
  }

  function heuristic(x, y, z) {
    const dx = Math.abs(x - GX), dz = Math.abs(z - GZ);
    const oct = Math.max(dx, dz) + 0.414 * Math.min(dx, dz);
    return (oct + Math.abs(y - GY) * 0.5) * 1.35;
  }

  function isGoal(x, y, z) {
    if (RADIUS > 0) {
      const dx = x - GX, dz = z - GZ;
      return dx * dx + dz * dz <= RADIUS * RADIUS && Math.abs(y - GY) <= YRANGE;
    }
    return x === GX && z === GZ && Math.abs(y - GY) <= 1;
  }

  /** Finds or creates the node for a cell (-1 when the pool is exhausted). */
  function nodeFor(x, y, z) {
    const k = localKey(x, y, z);
    let h = (Math.imul(k, 0x9E3779B1) >>> 13) & HMASK;
    while (HSTAMP[h] === stamp) {
      if (HKEY[h] === k) return HVAL[h];
      h = (h + 1) & HMASK;
    }
    if (used >= POOL) return -1;
    const n = used++;
    HSTAMP[h] = stamp; HKEY[h] = k; HVAL[h] = n;
    NX[n] = x; NY[n] = y; NZ[n] = z;
    G[n] = Infinity; F[n] = Infinity; HH[n] = heuristic(x, y, z);
    PARENT[n] = -1; FLAG[n] = 0; CLOSED[n] = 0; HPOS[n] = -1;
    return n;
  }

  function relax(from, x, y, z, cost, flag) {
    if (y < 1 || y > 125) return;
    const n = nodeFor(x, y, z);
    if (n < 0 || CLOSED[n]) return;
    const g = G[from] + cost;
    if (g >= G[n]) return;
    G[n] = g;
    F[n] = g + HH[n];
    PARENT[n] = from;
    FLAG[n] = flag;
    if (HPOS[n] >= 0) siftUp(HPOS[n]); else push(n);
  }

  function expand(n) {
    const x = NX[n], y = NY[n], z = NZ[n];
    const inWater = blk(x, y, z) === WATER;
    for (let d = 0; d < 8; d++) {
      const dx = DIRS[d][0], dz = DIRS[d][1];
      const nx = x + dx, nz = z + dz;
      const diag = dx !== 0 && dz !== 0;
      if (diag && !(free(x + dx, y, z) && free(x + dx, y + 1, z) && free(x, y, z + dz) && free(x, y + 1, z + dz))) continue;
      const base = diag ? 1.414 : 1;
      if (standable(nx, y, nz)) {
        relax(n, nx, y, nz, base * (blk(nx, y, nz) === WATER ? 3 : 1), 0);
        continue;
      }
      if (free(x, y + 2, z) && standable(nx, y + 1, nz)) {
        relax(n, nx, y + 1, nz, base + 0.6, 0);
        continue;
      }
      if (free(nx, y, nz) && free(nx, y + 1, nz)) {
        for (let k = 1; k <= MAX_DROP; k++) {
          if (standable(nx, y - k, nz)) { relax(n, nx, y - k, nz, base + k * 0.4, 0); break; }
          if (!free(nx, y - k, nz)) break;
        }
        continue;
      }
      if (BREACH && !diag) {
        const below = blk(nx, y - 1, nz);
        if (!SOLID[below]) continue;
        const c = breachCost(blk(nx, y, nz)) + breachCost(blk(nx, y + 1, nz));
        if (c < Infinity) relax(n, nx, y, nz, base + c, 1);
      }
    }
    if (inWater) {
      if (blk(x, y + 1, z) === WATER && standable(x, y + 1, z)) relax(n, x, y + 1, z, 1.5, 0);
      if (standable(x, y - 1, z) && blk(x, y - 1, z) === WATER) relax(n, x, y - 1, z, 1.5, 0);
    }
  }

  // Incremental search state (one search is active at a time).
  let S_START = -1, S_BEST = -1, S_BESTH = 0, S_EXPANDED = 0, S_FOUND = -1, S_MAX = 2500, S_DONE = true;

  /**
   * Starts an A* search. Call step() until it returns true, then result().
   * @param {World} world
   * @param {{x,y,z}} start integer feet cell
   * @param {{x,y,z}} goal integer target cell
   * @param {object} opts {faction, radius, yRange, maxNodes, breach}
   */
  function begin(world, start, goal, opts) {
    W = world;
    FAC = opts.faction || null;
    BREACH = !!opts.breach;
    GX = goal.x; GY = goal.y; GZ = goal.z;
    SX = start.x; SZ = start.z;
    CCX = start.x >> 4; CCZ = start.z >> 4;
    cgrid.fill(undefined);
    RADIUS = opts.radius || 0;
    YRANGE = opts.yRange === undefined ? 2 : opts.yRange;
    S_MAX = opts.maxNodes || 2500;
    stamp++;
    if (stamp > 2000000000) { HSTAMP.fill(0); stamp = 1; }
    used = 0;
    heapN = 0;
    let sx = start.x, sy = start.y, sz = start.z;
    if (!standable(sx, sy, sz)) {
      const alts = [[0, -1, 0], [0, 1, 0], [0, -2, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]];
      for (let i = 0; i < alts.length; i++) {
        if (standable(sx + alts[i][0], sy + alts[i][1], sz + alts[i][2])) { sx += alts[i][0]; sy += alts[i][1]; sz += alts[i][2]; break; }
      }
    }
    S_START = nodeFor(sx, sy, sz);
    G[S_START] = 0; F[S_START] = HH[S_START];
    push(S_START);
    S_BEST = S_START; S_BESTH = HH[S_START];
    S_EXPANDED = 0; S_FOUND = -1;
    S_DONE = false;
  }

  /** Expands up to `budget` nodes. Returns true when the search is finished. */
  function step(budget) {
    if (S_DONE) return true;
    let k = 0;
    while (heapN > 0 && S_EXPANDED < S_MAX && k < budget) {
      const n = pop();
      if (CLOSED[n]) continue;
      CLOSED[n] = 1;
      S_EXPANDED++;
      k++;
      if (isGoal(NX[n], NY[n], NZ[n])) { S_FOUND = n; S_DONE = true; return true; }
      if (HH[n] < S_BESTH) { S_BESTH = HH[n]; S_BEST = n; }
      expand(n);
      if (used >= POOL - 64) { S_DONE = true; return true; }
    }
    if (heapN === 0 || S_EXPANDED >= S_MAX) S_DONE = true;
    return S_DONE;
  }

  /** Path of the finished search (partial toward the goal if not found). */
  function result() {
    const end = S_FOUND >= 0 ? S_FOUND : S_BEST;
    const path = [];
    let cur = end;
    while (cur >= 0 && cur !== S_START) {
      path.push({ x: NX[cur], y: NY[cur], z: NZ[cur], b: FLAG[cur] });
      cur = PARENT[cur];
    }
    path.reverse();
    W = null;
    return { path: path, complete: S_FOUND >= 0, expanded: S_EXPANDED };
  }

  /** Synchronous A* (used by tools and tests). */
  function find(world, start, goal, opts) {
    begin(world, start, goal, opts);
    step(Infinity);
    return result();
  }

  // ----------------------------------------------------- Path service

  /**
   * Queues path requests and processes them within a per-frame budget so a
   * whole army asking for routes at once does not stall the game.
   */
  class PathService {
    constructor(world) {
      this.world = world;
      this.queue = [];
      this.pending = new Map(); // requester id -> request
      this.stats = { solved: 0, lastMs: 0, queued: 0 };
      this.active = null;
    }

    request(requester, start, goal, opts, cb) {
      const old = this.pending.get(requester.id);
      if (old) old.cancelled = true;
      const req = { requester: requester, start: start, goal: goal, opts: opts, cb: cb, cancelled: false };
      this.pending.set(requester.id, req);
      this.queue.push(req);
      return req;
    }

    cancel(requester) {
      const old = this.pending.get(requester.id);
      if (old) { old.cancelled = true; this.pending.delete(requester.id); }
    }

    /** Works on queued searches for up to `budgetMs` milliseconds. */
    process(budgetMs) {
      const t0 = performance.now();
      while (performance.now() - t0 < budgetMs) {
        if (!this.active) {
          let req = null;
          while (this.queue.length && !req) {
            const r = this.queue.shift();
            if (!r.cancelled && !r.requester.dead) req = r;
          }
          if (!req) break;
          this.active = req;
          begin(this.world, req.start, req.goal, req.opts);
        }
        const req = this.active;
        if (req.cancelled || req.requester.dead) { this.active = null; continue; }
        if (step(250)) {
          this.active = null;
          if (this.pending.get(req.requester.id) === req) this.pending.delete(req.requester.id);
          const res = result();
          this.stats.solved++;
          req.cb(res);
        }
      }
      this.stats.lastMs = performance.now() - t0;
      this.stats.queued = this.queue.length + (this.active ? 1 : 0);
    }

    clear() { this.queue.length = 0; this.pending.clear(); this.active = null; }
  }

  VK.Pathfinder = { find: find, begin: begin, step: step, result: result, PathService: PathService };
})(window.VK);
