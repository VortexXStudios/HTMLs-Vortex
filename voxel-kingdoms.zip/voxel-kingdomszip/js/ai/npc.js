/**
 * @file npc.js
 * Non-player characters: villagers (with jobs), soldiers (swordsmen,
 * spearmen, archers, crossbowmen, captains) and trebuchets.
 *
 * Each NPC combines:
 *   - perception: vision cone + range (shorter at night), line of sight,
 *     enemy sharing with its squad and nearby allies
 *   - a goal-based Brain (goals.js) and a Navigator (navigator.js)
 *   - voxel physics (gravity, swimming, step jumping, crowd separation)
 *   - an animated model with distance based LOD for both rendering and
 *     AI tick rate
 */
(function (VK) {
  'use strict';

  const U = VK.Util;

  /** Unit statistics. power = contribution to army strength estimates. */
  const UNIT_TYPES = {
    villager: { label: 'Villager', hp: 16, speed: 3.2, vision: 18, armor: 0, power: 0.2 },
    swordsman: { label: 'Swordsman', hp: 28, speed: 3.7, vision: 28, armor: 0.15, shield: 0.5, melee: { damage: 5, reach: 2.0, cooldown: 0.95 }, power: 1.0 },
    spearman: { label: 'Spearman', hp: 26, speed: 3.6, vision: 28, armor: 0.1, shield: 0.4, melee: { damage: 6, reach: 2.9, cooldown: 1.2 }, power: 1.0 },
    archer: { label: 'Archer', hp: 18, speed: 3.7, vision: 36, armor: 0, ranged: { damage: 4, range: 30, cooldown: 1.8, speed: 34, projectile: 'arrow', spread: 0.035 }, power: 0.9 },
    crossbowman: { label: 'Crossbowman', hp: 22, speed: 3.4, vision: 36, armor: 0.1, ranged: { damage: 8, range: 34, cooldown: 3.0, speed: 44, projectile: 'bolt', spread: 0.02 }, power: 1.1 },
    captain: { label: 'Captain', hp: 42, speed: 3.7, vision: 32, armor: 0.25, shield: 0.55, melee: { damage: 7, reach: 2.1, cooldown: 0.9 }, power: 2.0 },
    trebuchet: { label: 'Trebuchet', hp: 70, speed: 1.7, vision: 48, armor: 0.3, siege: { damage: 12, range: 50, minRange: 16, cooldown: 9, speed: 30, blast: 2.3, power: 70 }, power: 2.5 }
  };

  /** Resource cost to recruit/build each unit. */
  const UNIT_COSTS = {
    villager: { food: 15 },
    swordsman: { food: 12, iron: 3, wood: 1 },
    spearman: { food: 10, iron: 1, wood: 3 },
    archer: { food: 10, wood: 5 },
    crossbowman: { food: 12, wood: 3, iron: 3 },
    captain: { food: 20, iron: 6, gold: 3 },
    trebuchet: { wood: 45, stone: 15, iron: 6 }
  };

  const TRAIN_TIME = { villager: 18, swordsman: 14, spearman: 14, archer: 14, crossbowman: 16, captain: 22, trebuchet: 35 };

  const JOB_TOOLS = { woodcutter: 'axe', miner: 'pickaxe', farmer: 'hoe', builder: 'hammer', hauler: null };
  const JOB_TITLES = { woodcutter: 'Woodcutter', miner: 'Miner', farmer: 'Farmer', builder: 'Builder', hauler: 'Porter' };

  const NAMES = ['Aldric', 'Bran', 'Cedric', 'Doran', 'Edric', 'Fenwick', 'Gareth', 'Hollis', 'Ivo', 'Jorund', 'Kael',
    'Leofric', 'Marek', 'Nolan', 'Osric', 'Perrin', 'Rowan', 'Soren', 'Tobin', 'Ulric', 'Wystan', 'Alden', 'Baldwin',
    'Ada', 'Brienne', 'Cecily', 'Dora', 'Elspeth', 'Freya', 'Gwen', 'Hilde', 'Isolde', 'Joan', 'Kara', 'Lysa', 'Maud',
    'Nell', 'Odette', 'Petra', 'Rosalind', 'Sybil', 'Tamsin', 'Wren', 'Agnes', 'Beatrix', 'Corwin', 'Emeric', 'Godric'];

  const ANIM = { speed: 0, aiming: false, carrying: null, combat: false, headYaw: 0, headPitch: 0 };

  class NPC {
    /**
     * @param {object} o {faction, type, job, x, y, z, settlement, id, name, hp}
     */
    constructor(o) {
      this.id = o.id || U.uid();
      U.setUidFloor(this.id);
      this.type = o.type;
      this.stats = UNIT_TYPES[o.type];
      this.faction = o.faction;
      this.settlement = o.settlement || null;
      this.job = o.type === 'villager' ? (o.job || 'hauler') : null;
      this.isVillager = o.type === 'villager';
      this.isSiege = o.type === 'trebuchet';
      this.isSoldier = !this.isVillager;
      this.isPlayer = false;
      this.name = o.name || U.pick(NAMES);
      this.maxHp = this.stats.hp;
      this.hp = o.hp !== undefined ? o.hp : this.maxHp;
      this.pos = new THREE.Vector3(o.x, o.y, o.z);
      this.vel = new THREE.Vector3();
      this.yaw = Math.random() * Math.PI * 2;
      this.faceYaw = this.yaw;
      this.faceHoldT = 0;
      this.hw = this.isSiege ? 1.0 : 0.3;
      this.h = this.isSiege ? 3.2 : 1.8;
      this.eyeH = this.isSiege ? 2.6 : 1.6;
      this.onGround = false;
      this.hitWall = false;
      this.inWater = false;
      this.carry = { type: null, amount: 0, bonus: { iron: 0, gold: 0 } };
      this.squad = null;
      this.home = null;
      this.target = null;
      this.targetSeenAt = -100;
      this.visibleEnemies = [];
      this.threat = null;
      this.lastAttacker = null;
      this.lastAttackedAt = -100;
      this.attackCd = 0;
      this.aiming = false;
      this.inCombat = false;
      this.alertT = 0;
      this.perceiveT = Math.random() * 0.4;
      this.aiAccum = 0;
      this.camD2 = 0;
      this.dead = false;
      this.deathT = 0;
      this.asleep = false;
      this.talkingTo = null;
      this.kills = 0;
      this.nav = new VK.Navigator(this);
      this.brain = new VK.AI.Brain(this, VK.AI.goalsFor(this));
      const seed = (this.id * 2654435761) >>> 0;
      if (this.isSiege) this.model = new VK.Models.TrebuchetModel(this.faction.id);
      else {
        this.model = new VK.Models.HumanoidModel(VK.Models.appearanceFor(this.type, this.job, this.faction.id, U.mulberry32(seed)));
      }
      this.syncModel();
    }

    get factionId() { return this.faction ? this.faction.id : null; }

    get title() {
      if (this.isVillager) return JOB_TITLES[this.job] || 'Villager';
      return this.stats.label;
    }

    get displayName() {
      if (this.type === 'captain') return 'Captain ' + this.name;
      if (this.isSiege) return this.faction.shortName + ' Trebuchet';
      return this.name + ' the ' + this.title;
    }

    // --------------------------------------------------------- Helpers

    setJob(job) {
      if (!this.isVillager || job === this.job) return;
      this.job = job;
      if (this.model.setRightItem) this.model.setRightItem(JOB_TOOLS[job] || null);
    }

    addCarry(type, amount) {
      if (!this.carry.amount) this.carry.type = type;
      if (this.carry.type === type) this.carry.amount += amount;
      else this.faction.resources[type] += amount;
    }

    faceTowards(x, z) {
      this.faceYaw = Math.atan2(x - this.pos.x, z - this.pos.z);
      this.faceHoldT = 0.6;
    }

    faceYawTo(yaw) {
      this.faceYaw = yaw;
      this.faceHoldT = 0.6;
    }

    eyePos() { return { x: this.pos.x, y: this.pos.y + this.eyeH, z: this.pos.z }; }

    /** Where the NPC hangs around when idle. */
    anchorPoint() {
      const sq = this.squad;
      if (sq && sq.order && sq.order.type === 'garrison') {
        const p = sq.postFor(this);
        if (p) return { x: p.x, z: p.z, r: 3 };
      }
      if (this.home && this.home.functional && this.isVillager) {
        const e = this.home.entrance;
        return { x: e.x, z: e.z, r: 6 };
      }
      if (this.settlement) return { x: this.settlement.center.x, z: this.settlement.center.z, r: 10 };
      return { x: this.pos.x, z: this.pos.z, r: 6 };
    }

    /** Safe place to run to when threatened. */
    refugePoint() {
      const s = this.settlement;
      if (!s) return null;
      const core = s.core;
      if (core && core.functional) return core.interiorPoint();
      return s.center;
    }

    /** Area the NPC may not chase enemies out of, depending on its orders. */
    leashAnchor() {
      const sq = this.squad;
      const o = sq && sq.order;
      if (!o) return null;
      if (o.type === 'garrison') {
        const p = sq.postFor(this);
        return p ? { x: p.x, z: p.z, r: 30 } : null;
      }
      if (o.type === 'march' || o.type === 'rally' || o.type === 'return') {
        const l = sq.leader;
        return l ? { x: l.pos.x, z: l.pos.z, r: 34 } : null;
      }
      if (o.type === 'follow') {
        const p = VK.game.player;
        return { x: p.pos.x, z: p.pos.z, r: 26 };
      }
      return null;
    }

    /** Picks (and remembers) the enemy to fight. */
    chooseTarget() {
      const now = VK.game.elapsed;
      const t = this.target;
      if (t && !t.dead && !t.asleep && now - this.targetSeenAt < 4 && VK.Diplomacy.isHostile(this, t)) return t;
      if (this.visibleEnemies.length) {
        this.target = this.visibleEnemies[0];
        this.targetSeenAt = now;
        return this.target;
      }
      if (this.squad) {
        const e = this.squad.nearestKnownEnemy(this.pos, 40);
        if (e && VK.Diplomacy.isHostile(this, e)) { this.target = e; this.targetSeenAt = now - 2; return e; }
      }
      const a = this.lastAttacker;
      if (a && !a.dead && now - this.lastAttackedAt < 6 && VK.Diplomacy.isHostile(this, a)) {
        this.target = a;
        this.targetSeenAt = now - 2;
        return a;
      }
      this.target = null;
      return null;
    }

    // ------------------------------------------------------ Perception

    perceive() {
      const g = VK.game;
      const range = this.stats.vision * (g.isNight() ? 0.65 : 1);
      const list = g.entities.queryRadius(this.pos.x, this.pos.z, range);
      const ex = this.pos.x, ey = this.pos.y + this.eyeH, ez = this.pos.z;
      const fx = Math.sin(this.yaw), fz = Math.cos(this.yaw);
      const found = [];
      const self = this;
      const alert = this.alertT > 0;
      function consider(e) {
        if (e === self || e.dead || e.asleep) return;
        if (!VK.Diplomacy.isHostile(self, e)) return;
        const dx = e.pos.x - ex, dz = e.pos.z - ez;
        let d = Math.sqrt(dx * dx + dz * dz);
        const eff = e.isPlayer && e.sneaking ? d * 2 : d;
        if (eff > range) return;
        if (d > 7 && !alert && (dx * fx + dz * fz) / (d || 1) < -0.15) return;
        if (!g.world.lineOfSight(ex, ey, ez, e.pos.x, e.pos.y + (e.isSiege ? 1.5 : 1.5), e.pos.z)) return;
        found.push([e, d]);
      }
      for (let i = 0; i < list.length; i++) consider(list[i]);
      if (g.player) consider(g.player);
      found.sort(function (a, b) { return a[1] - b[1]; });
      this.visibleEnemies.length = 0;
      this.threat = null;
      for (let i = 0; i < found.length; i++) {
        const e = found[i][0];
        this.visibleEnemies.push(e);
        if (!this.threat && (e.isPlayer || e.isSoldier)) this.threat = { e: e, d: found[i][1] };
      }
      if (this.target && this.visibleEnemies.indexOf(this.target) >= 0) this.targetSeenAt = g.elapsed;
      if (found.length) {
        this.alertT = 10;
        if (this.squad) this.squad.reportEnemies(this.visibleEnemies);
        this.faction.reportSighting(this.visibleEnemies[0].pos, found.length, this);
        if (this.isVillager && this.threat) g.entities.alertAllies(this, this.threat.e, 20);
      }
    }

    /** Reaction to being hit. */
    onDamaged(attacker) {
      if (!attacker || attacker === this) return;
      this.lastAttacker = attacker;
      this.lastAttackedAt = VK.game.elapsed;
      this.alertT = 10;
      if (this.squad) this.squad.reportEnemies([attacker]);
      VK.game.entities.alertAllies(this, attacker, 18);
      if (this.isVillager && !this.threat) this.threat = { e: attacker, d: U.dist2(this.pos.x, this.pos.z, attacker.pos.x, attacker.pos.z) };
      if (this.asleep) this.wake();
    }

    // --------------------------------------------------------- Sleeping

    sleep() {
      if (this.asleep) return;
      this.asleep = true;
      this.nav.stop();
      this.vel.set(0, 0, 0);
      this.model.root.visible = false;
    }

    wake() {
      if (!this.asleep) return;
      this.asleep = false;
      if (this.home) {
        const e = this.home.entrance;
        this.pos.set(e.x + 0.5, e.y + 0.05, e.z + 0.5);
      }
      this.model.root.visible = true;
      this.model.lod = -1;
    }

    teleport(x, y, z) {
      this.pos.set(x, y, z);
      this.vel.set(0, 0, 0);
      this.nav.stop();
    }

    // ---------------------------------------------------------- Update

    /** @returns {boolean} false when the NPC should be removed */
    update(dt) {
      const g = VK.game;
      if (this.dead) {
        this.deathT += dt;
        this.model.update(dt, ANIM);
        this.syncModel();
        return this.deathT < 5;
      }
      const cam = g.camera.position;
      const cdx = this.pos.x - cam.x, cdz = this.pos.z - cam.z;
      this.camD2 = cdx * cdx + cdz * cdz;

      if (this.asleep) {
        this.aiAccum += dt;
        if (this.aiAccum > 1.5) { this.brain.update(this.aiAccum); this.aiAccum = 0; }
        return true;
      }

      this.aiAccum += dt;
      const interval = this.camD2 > 140 * 140 ? 0.3 : (this.camD2 > 70 * 70 ? 0.12 : 0);
      if (this.aiAccum >= interval) {
        const adt = this.aiAccum;
        this.aiAccum = 0;
        this.think(adt);
      }
      if (this.asleep) return true;
      this.move(dt);
      this.animate(dt);
      return true;
    }

    think(dt) {
      this.attackCd -= dt;
      this.alertT -= dt;
      this.perceiveT -= dt;
      if (this.perceiveT <= 0) {
        this.perceiveT = (this.camD2 > 120 * 120 ? 0.8 : 0.4) + Math.random() * 0.2;
        this.perceive();
      }
      this.brain.update(dt);
      this.nav.update(dt);
      const b = this.nav.breach;
      if (b && this.attackCd <= 0) {
        this.faceTowards(b.x + 0.5, b.z + 0.5);
        this.model.playAction('swing', 0.4);
        const dmg = (this.stats.melee ? this.stats.melee.damage : 2.5) * 1.6;
        VK.game.world.damageBlock(b.x, b.y, b.z, dmg, 'siege');
        VK.game.audio.play('hit', this.pos);
        this.attackCd = this.stats.melee ? this.stats.melee.cooldown : 1.2;
      }
    }

    move(dt) {
      const g = VK.game;
      const nav = this.nav;
      nav.follow();
      const speed = this.stats.speed * nav.speedMul * (this.inWater ? 0.55 : 1) * (this.carry.amount ? 0.92 : 1);
      const tx = nav.desiredX * speed, tz = nav.desiredZ * speed;
      const k = Math.min(1, (this.onGround ? 12 : 3) * dt);
      this.vel.x += (tx - this.vel.x) * k;
      this.vel.z += (tz - this.vel.z) * k;
      const sep = g.entities.separation(this);
      this.vel.x += sep.x * dt * 6;
      this.vel.z += sep.z * dt * 6;
      if (this.inWater) {
        this.vel.y = Math.min(this.vel.y + 24 * dt, 2.2);
        if (nav.wantJump) this.vel.y = Math.max(this.vel.y, 4);
      } else {
        this.vel.y -= VK.Config.GRAVITY * dt;
        if (nav.wantJump && this.onGround) this.vel.y = 8.3;
      }
      if (this.vel.y < -40) this.vel.y = -40;
      VK.Physics.move(g.world, this, dt);
      if (this.pos.y < -4) this.returnHome();

      if (this.faceHoldT > 0) this.faceHoldT -= dt;
      else {
        const hs = Math.abs(this.vel.x) + Math.abs(this.vel.z);
        if (hs > 0.5) this.faceYaw = Math.atan2(this.vel.x, this.vel.z);
      }
      this.yaw = U.turnToward(this.yaw, this.faceYaw, dt * (this.isSiege ? 1.5 : 9));
    }

    returnHome() {
      const s = this.settlement;
      const c = s ? s.center : { x: this.pos.x, z: this.pos.z };
      const y = VK.game.world.groundY(c.x, c.z);
      this.teleport(c.x + 0.5, y + 0.1, c.z + 0.5);
    }

    syncModel() {
      const r = this.model.root;
      r.position.copy(this.pos);
      r.rotation.y = this.yaw;
    }

    animate(dt) {
      const R = VK.Config.NPC_RENDER_DISTANCE, D = VK.Config.NPC_DETAIL_DISTANCE;
      const d2 = this.camD2;
      const lod = d2 > R * R ? 2 : (d2 > D * D ? 1 : 0);
      this.model.setLOD(lod);
      if (lod === 2) return;
      this.syncModel();
      ANIM.speed = Math.sqrt(this.vel.x * this.vel.x + this.vel.z * this.vel.z);
      ANIM.aiming = this.aiming;
      ANIM.carrying = this.carry.amount > 0 ? this.carry.type : null;
      ANIM.combat = this.inCombat;
      ANIM.headYaw = 0;
      if (this.talkingTo) {
        const p = this.talkingTo.pos;
        ANIM.headYaw = U.wrapAngle(Math.atan2(p.x - this.pos.x, p.z - this.pos.z) - this.yaw);
      }
      this.model.update(dt, ANIM);
      const showHp = this.hp < this.maxHp && d2 < 30 * 30 && VK.game.elapsed - this.lastAttackedAt < 12;
      this.model.setHealth(this.hp / this.maxHp, showHp);
    }

    /** Called by Combat when hit points reach zero. */
    die(killer) {
      if (this.dead) return;
      this.dead = true;
      this.hp = 0;
      this.deathT = 0;
      this.brain.halt();
      this.nav.stop();
      VK.game.paths.cancel(this);
      this.model.setDead();
      if (this.asleep) { this.asleep = false; this.model.root.visible = true; }
      if (this.squad) this.squad.remove(this);
      this.faction.onUnitDeath(this, killer);
      VK.game.audio.play('death', this.pos);
    }

    serialize() {
      return {
        id: this.id, type: this.type, job: this.job, f: this.faction.id,
        s: this.settlement ? this.settlement.id : null,
        sq: this.squad ? this.squad.id : null,
        home: this.home ? this.home.id : null,
        x: +this.pos.x.toFixed(2), y: +this.pos.y.toFixed(2), z: +this.pos.z.toFixed(2),
        hp: +this.hp.toFixed(1), name: this.name
      };
    }
  }

  NPC.UNIT_TYPES = UNIT_TYPES;
  NPC.UNIT_COSTS = UNIT_COSTS;
  NPC.TRAIN_TIME = TRAIN_TIME;
  NPC.JOB_TITLES = JOB_TITLES;
  VK.NPC = NPC;
})(window.VK);
