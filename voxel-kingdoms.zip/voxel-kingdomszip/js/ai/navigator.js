/**
 * @file navigator.js
 * Turns destinations into steering for an NPC: requests A* paths from the
 * PathService, follows waypoints, jumps up steps, detects being stuck,
 * re-plans, splits very long journeys into legs and, in siege mode, stops
 * in front of flagged waypoints so the NPC can break through walls/gates.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;
  const B = VK.Blocks;
  const LEG = 48;       // max straight-line length of one planned leg
  const LONG = 60;      // journeys longer than this are split into legs

  class Navigator {
    constructor(npc) {
      this.npc = npc;
      this.status = 'idle';      // idle | waiting | moving | arrived | failed | direct
      this.path = null;
      this.index = 0;
      this.target = null;
      this.opts = null;
      this.leg = null;
      this.partial = false;
      this.repaths = 0;
      this.desiredX = 0;
      this.desiredZ = 0;
      this.speedMul = 1;
      this.wantJump = false;
      this.breach = null;        // {x,y,z} block that must be broken to continue
      this.progressT = 0;
      this.lastX = 0;
      this.lastZ = 0;
      this.stuckCount = 0;
      this.failedAt = -100;
    }

    /**
     * Starts moving to a destination.
     * @param {object} [opts] {radius, yRange, breach, maxNodes, speed}
     */
    goTo(x, y, z, opts) {
      opts = opts || {};
      const t = this.target;
      const near = t && Math.abs(t.x - x) < 1.2 && Math.abs(t.z - z) < 1.2 && Math.abs(t.y - y) < 2;
      const same = near && (this.status === 'moving' || this.status === 'waiting' || this.status === 'arrived');
      this.speedMul = opts.speed || 1;
      if (same) {
        if (this.status === 'arrived' && this.distTo(x, y, z) > (opts.radius || 1.5) + 1.5) this.plan();
        return;
      }
      // Do not hammer the path finder with a destination that just failed.
      if (near && this.status === 'failed' && VK.game.elapsed - this.failedAt < 4) return;
      this.target = { x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) };
      this.opts = {
        radius: opts.radius === undefined ? 1.5 : opts.radius,
        yRange: opts.yRange === undefined ? 2 : opts.yRange,
        breach: !!opts.breach,
        maxNodes: opts.maxNodes || 2500
      };
      this.repaths = 0;
      this.stuckCount = 0;
      this.plan();
    }

    distTo(x, y, z) {
      const p = this.npc.pos;
      return U.dist2(p.x, p.z, x + 0.5, z + 0.5);
    }

    /** Requests a path for the next leg of the journey. */
    plan() {
      const npc = this.npc;
      const t = this.target;
      const start = { x: Math.floor(npc.pos.x), y: U.clamp(Math.floor(npc.pos.y + 0.05), 1, 125), z: Math.floor(npc.pos.z) };
      const dist = U.dist2(start.x, start.z, t.x, t.z);
      let goal = t, radius = this.opts.radius, yRange = this.opts.yRange;
      if (dist > LONG) {
        const f = LEG / dist;
        const gx = Math.floor(start.x + (t.x - start.x) * f), gz = Math.floor(start.z + (t.z - start.z) * f);
        goal = { x: gx, y: VK.game.world.groundY(gx, gz), z: gz };
        radius = 6;
        yRange = 6;
        this.leg = goal;
      } else this.leg = null;
      this.status = 'waiting';
      const self = this;
      VK.game.paths.request(npc, start, goal, {
        faction: npc.faction ? npc.faction.id : null,
        radius: radius, yRange: yRange,
        maxNodes: this.opts.maxNodes, breach: this.opts.breach
      }, function (res) { self.onPath(res); });
    }

    onPath(res) {
      if (this.status !== 'waiting') return;
      if (!res.path.length) {
        if (res.complete) {
          if (this.leg) { this.plan(); return; }
          this.status = 'arrived';
          return;
        }
        this.repaths++;
        if (this.repaths > 3) { this.fail(); return; }
        // Treat as an empty partial path: the next update re-plans.
        this.status = 'moving';
        this.path = [];
        this.index = 0;
        this.partial = true;
        return;
      }
      this.path = res.path;
      this.index = 0;
      this.partial = !res.complete;
      this.status = 'moving';
      this.progressT = 0;
      this.lastX = this.npc.pos.x;
      this.lastZ = this.npc.pos.z;
    }

    fail() {
      this.status = 'failed';
      this.failedAt = VK.game.elapsed;
      this.path = null;
      this.desiredX = this.desiredZ = 0;
    }

    /** Stops all movement. */
    stop() {
      if (this.status === 'waiting') VK.game.paths.cancel(this.npc);
      this.status = 'idle';
      this.path = null;
      this.target = null;
      this.desiredX = this.desiredZ = 0;
      this.breach = null;
    }

    /** Direct steering toward a point for this frame (no path). */
    steer(x, z, speedMul) {
      if (this.status === 'waiting') VK.game.paths.cancel(this.npc);
      this.status = 'direct';
      this.target = null;
      this.path = null;
      const p = this.npc.pos;
      const dx = x - p.x, dz = z - p.z;
      const d = Math.sqrt(dx * dx + dz * dz);
      this.speedMul = speedMul || 1;
      if (d < 0.2) { this.desiredX = this.desiredZ = 0; return; }
      this.desiredX = dx / d;
      this.desiredZ = dz / d;
      // Jump over one block obstacles while steering directly.
      const npc = this.npc;
      if (npc.hitWall && npc.onGround) this.wantJump = true;
    }

    get active() { return this.status === 'moving' || this.status === 'waiting'; }

    /**
     * Per-frame path following: advances reached waypoints and points the
     * desired direction at the next one. Runs every frame (even when the
     * NPC's AI ticks less often) so NPCs never overshoot their waypoints.
     */
    follow() {
      const npc = this.npc;
      if (this.status !== 'moving') return;
      this.wantJump = false;
      this.breach = null;
      this.endReached = false;
      let wp = null;
      for (let guard = 0; guard < 4; guard++) {
        wp = this.path[this.index];
        if (!wp) break;
        const dx = wp.x + 0.5 - npc.pos.x, dz = wp.z + 0.5 - npc.pos.z;
        const d2 = dx * dx + dz * dz;
        const next = this.path[this.index + 1];
        let skip = d2 < 0.12 && Math.abs(wp.y - npc.pos.y) < 1.1;
        if (!skip && next && !next.b && !wp.b && next.y === wp.y && Math.abs(wp.y - npc.pos.y) < 0.6) {
          const nx = next.x + 0.5 - npc.pos.x, nz = next.z + 0.5 - npc.pos.z;
          if (nx * nx + nz * nz < d2 && d2 < 1.5) skip = true;
        }
        if (skip) { this.index++; continue; }
        break;
      }
      if (!wp) {
        this.desiredX = this.desiredZ = 0;
        this.endReached = true;
        return;
      }

      // Siege: break the blocks of a flagged waypoint before stepping in.
      if (wp.b) {
        const w = VK.game.world;
        const fac = npc.faction ? npc.faction.id : null;
        let block = null;
        if (B.blocksMovement(w.getBlock(wp.x, wp.y + 1, wp.z), fac)) block = { x: wp.x, y: wp.y + 1, z: wp.z };
        if (B.blocksMovement(w.getBlock(wp.x, wp.y, wp.z), fac)) block = { x: wp.x, y: wp.y, z: wp.z };
        if (block) {
          const d = U.dist2(npc.pos.x, npc.pos.z, wp.x + 0.5, wp.z + 0.5);
          if (d < 1.9) {
            this.breach = block;
            this.desiredX = this.desiredZ = 0;
            this.progressT = 0;
            return;
          }
        } else wp.b = 0;
      }

      const dx = wp.x + 0.5 - npc.pos.x, dz = wp.z + 0.5 - npc.pos.z;
      const d = Math.sqrt(dx * dx + dz * dz);
      if (d > 0.01) { this.desiredX = dx / d; this.desiredZ = dz / d; }
      if (wp.y > npc.pos.y + 0.4 && d < 1.6 && npc.onGround) this.wantJump = true;
      if (npc.hitWall && npc.onGround) this.wantJump = true;
    }

    /** AI-rate update: end of path handling, re-planning and stuck detection. */
    update(dt) {
      const npc = this.npc;
      if (this.status === 'direct') {
        // Direct steering must be renewed each think step.
        this.status = 'idle';
        this.wantJump = npc.hitWall && npc.onGround;
        return;
      }
      if (this.status !== 'moving') { this.desiredX = this.desiredZ = 0; this.wantJump = false; this.breach = null; return; }
      this.follow();
      if (this.endReached) {
        if (this.leg) { this.plan(); return; }
        if (this.partial) {
          this.repaths++;
          if (this.repaths > 4) { this.fail(); return; }
          this.plan();
          return;
        }
        this.status = 'arrived';
        return;
      }
      if (this.breach) return;

      // Stuck detection.
      this.progressT += dt;
      if (this.progressT > 1.2) {
        const moved = U.dist2(npc.pos.x, npc.pos.z, this.lastX, this.lastZ);
        this.lastX = npc.pos.x; this.lastZ = npc.pos.z;
        this.progressT = 0;
        if (moved < 0.35) {
          this.stuckCount++;
          if (this.stuckCount >= 3) {
            this.stuckCount = 0;
            this.repaths++;
            if (this.repaths > 5) { this.fail(); return; }
            this.plan();
          }
        } else this.stuckCount = 0;
      }
    }
  }

  VK.Navigator = Navigator;
})(window.VK);
