/**
 * @file goals.js
 * Goal-based behaviour system. Every NPC owns a Brain holding a set of
 * Goals; a few times per second the brain asks each goal how desirable it
 * is right now (priority) and runs the best one. Goals are small state
 * machines that drive the Navigator and combat actions.
 *
 * Priorities (higher wins):
 *   100 Talk      - standing still while the player talks/trades
 *    90 Flee      - villagers escaping danger, badly wounded soldiers
 *    80 Combat    - fighting a visible or reported enemy
 *    60 Siege     - trebuchets bombarding a target
 *    50 Order     - following squad orders (garrison, patrol, march, assault...)
 *    45 Sleep     - villagers go home at night
 *    40 Work      - villager jobs (see jobs.js)
 *    30 Return    - wandered too far from home
 *     1 Idle      - loiter near home
 */
(function (VK) {
  'use strict';

  const U = VK.Util;
  const RUNNING = 0, DONE = 1, FAILED = 2;

  class Goal {
    constructor(npc) { this.npc = npc; }
    priority() { return 0; }
    start() {}
    update() { return RUNNING; }
    stop() {}
  }

  /** Selects and runs the most desirable goal. */
  class Brain {
    constructor(npc, goals) {
      this.npc = npc;
      this.goals = goals;
      this.current = null;
      this.currentP = 0;
      this.timer = Math.random() * 0.3;
    }
    get currentName() { return this.current ? this.current.constructor.name.replace('Goal', '') : 'None'; }
    update(dt) {
      this.timer -= dt;
      if (this.timer <= 0 || !this.current) {
        this.timer = 0.35 + Math.random() * 0.2;
        this.select();
      }
      if (this.current) {
        const r = this.current.update(dt);
        if (r !== RUNNING) {
          this.current.stop(r === DONE ? 'done' : 'failed');
          this.current = null;
          this.timer = 0;
        }
      }
    }
    select() {
      let best = null, bp = 0;
      for (let i = 0; i < this.goals.length; i++) {
        const p = this.goals[i].priority();
        if (p > bp) { bp = p; best = this.goals[i]; }
      }
      if (best === this.current) { this.currentP = bp; return; }
      const cp = this.current ? this.current.priority() : 0;
      if (!this.current || cp <= 0 || bp > cp + 2) {
        if (this.current) this.current.stop('switch');
        this.current = best;
        this.currentP = bp;
        if (best) best.start();
      }
    }
    /** Stops the running goal (death, capture, teleports). */
    halt() {
      if (this.current) this.current.stop('halt');
      this.current = null;
    }
  }

  // --------------------------------------------------------------- Talk

  class TalkGoal extends Goal {
    priority() { return this.npc.talkingTo ? 100 : 0; }
    start() { this.npc.nav.stop(); }
    update() {
      const p = this.npc.talkingTo;
      if (!p) return DONE;
      this.npc.faceTowards(p.pos.x, p.pos.z);
      return RUNNING;
    }
  }

  // --------------------------------------------------------------- Flee

  class FleeGoal extends Goal {
    constructor(npc) { super(npc); this.active = false; this.lastThreatT = -100; }
    priority() {
      const n = this.npc;
      if (n.isSiege) return 0;
      const th = n.threat;
      if (n.isVillager) {
        if (th && th.d < 16) return 90;
        if (this.active && VK.game.elapsed - this.lastThreatT < 6) return 88;
        return 0;
      }
      if (n.hp < n.maxHp * 0.22 && th && th.d < 12) {
        const o = n.squad && n.squad.order;
        if (o && (o.type === 'assault' || o.type === 'defend' || o.type === 'garrison' || o.type === 'follow')) return 0;
        return 72;
      }
      return 0;
    }
    start() {
      this.active = true;
      this.lastThreatT = VK.game.elapsed;
      this.replanT = 0;
      this.plan();
    }
    plan() {
      const n = this.npc;
      const refuge = n.refugePoint();
      if (refuge && U.dist2(n.pos.x, n.pos.z, refuge.x, refuge.z) > 3) {
        n.nav.goTo(refuge.x, refuge.y, refuge.z, { radius: 2, speed: 1.3 });
      }
    }
    update(dt) {
      const n = this.npc;
      const th = n.threat;
      if (th) this.lastThreatT = VK.game.elapsed;
      this.replanT -= dt;
      const st = n.nav.status;
      if (st === 'arrived' || st === 'failed' || st === 'idle' || st === 'direct') {
        if (th && th.d < 9) {
          const dx = n.pos.x - th.e.pos.x, dz = n.pos.z - th.e.pos.z;
          const d = Math.sqrt(dx * dx + dz * dz) || 1;
          n.nav.steer(n.pos.x + dx / d * 4, n.pos.z + dz / d * 4, 1.3);
        } else if (this.replanT <= 0 && st === 'failed') {
          this.replanT = 3;
          this.plan();
        }
      }
      if (VK.game.elapsed - this.lastThreatT > 6) return DONE;
      return RUNNING;
    }
    stop() { this.active = false; this.npc.nav.stop(); }
  }

  // ------------------------------------------------------------- Combat

  class CombatGoal extends Goal {
    priority() {
      const n = this.npc;
      if (!n.isSoldier || n.isSiege) return 0;
      return n.chooseTarget() ? 80 : 0;
    }
    start() { this.repathT = 0; }
    update(dt) {
      const n = this.npc;
      const t = n.target;
      if (!t || t.dead || !VK.Diplomacy.isHostile(n, t)) { n.target = null; return DONE; }
      const leash = n.leashAnchor();
      if (leash && U.dist2(t.pos.x, t.pos.z, leash.x, leash.z) > leash.r) { n.target = null; return DONE; }
      const dx = t.pos.x - n.pos.x, dz = t.pos.z - n.pos.z, dy = t.pos.y - n.pos.y;
      const d = Math.sqrt(dx * dx + dz * dz);
      const visible = n.visibleEnemies.indexOf(t) >= 0;
      n.inCombat = true;
      this.repathT -= dt;
      if (n.stats.melee) {
        const reach = n.stats.melee.reach + (t.hw || 0.3);
        if (d <= reach && Math.abs(dy) < 2.2) {
          n.nav.stop();
          n.faceTowards(t.pos.x, t.pos.z);
          if (n.attackCd <= 0) {
            VK.Combat.melee(n, t);
            n.attackCd = n.stats.melee.cooldown * U.rand(0.9, 1.15);
          }
        } else if (d < 9 && Math.abs(dy) < 1.5 && visible) {
          n.nav.steer(t.pos.x, t.pos.z, 1.25);
        } else if (this.repathT <= 0 || !n.nav.active) {
          n.nav.goTo(t.pos.x, t.pos.y, t.pos.z, { radius: 1.5, speed: 1.2, maxNodes: 1600 });
          this.repathT = 1.2;
        }
      } else if (n.stats.ranged) {
        const r = n.stats.ranged;
        const meleeThreat = t.isPlayer || (t.stats && t.stats.melee);
        if (d < 5.5 && meleeThreat) {
          n.aiming = false;
          n.nav.steer(n.pos.x - dx, n.pos.z - dz, 1.1);
        } else if (d > r.range * 0.92 || !visible) {
          n.aiming = false;
          if (this.repathT <= 0 || !n.nav.active) {
            n.nav.goTo(t.pos.x, t.pos.y, t.pos.z, { radius: Math.min(14, r.range * 0.5), speed: 1.1, maxNodes: 1600 });
            this.repathT = 1.5;
          }
        } else {
          n.nav.stop();
          n.faceTowards(t.pos.x, t.pos.z);
          n.aiming = true;
          if (n.attackCd <= 0) {
            VK.Combat.shoot(n, t, r);
            n.attackCd = r.cooldown * U.rand(0.9, 1.2);
          }
        }
      }
      return RUNNING;
    }
    stop() {
      this.npc.aiming = false;
      this.npc.inCombat = false;
      this.npc.nav.stop();
    }
  }

  // -------------------------------------------------------------- Siege

  class SiegeGoal extends Goal {
    priority() {
      const n = this.npc;
      const o = n.squad && n.squad.order;
      return n.isSiege && o && o.type === 'bombard' ? 60 : 0;
    }
    start() { this.aimPoint = null; this.moveT = 0; }
    update(dt) {
      const n = this.npc;
      const o = n.squad.order;
      let b = o.building;
      if (!b || b.destroyed || b.settlement.faction === n.faction) {
        b = o.building = o.campaign ? o.campaign.nextSiegeTarget(n) : null;
        this.aimPoint = null;
        if (!b) { n.nav.stop(); return RUNNING; }
      }
      if (!this.aimPoint) this.aimPoint = b.randomSolidBlock(VK.game.world);
      if (!this.aimPoint) { b.destroyed = true; return RUNNING; }
      const s = n.stats.siege;
      const tp = this.aimPoint;
      const d = U.dist2(n.pos.x, n.pos.z, tp.x + 0.5, tp.z + 0.5);
      this.moveT -= dt;
      if (d > s.range * 0.88) {
        if (this.moveT <= 0 || !n.nav.active) {
          const f = (s.range * 0.7) / d;
          const gx = tp.x + (n.pos.x - tp.x) * f, gz = tp.z + (n.pos.z - tp.z) * f;
          n.nav.goTo(gx, VK.game.world.groundY(gx, gz), gz, { radius: 4, maxNodes: 3000 });
          this.moveT = 3;
        }
      } else if (d < s.minRange) {
        n.nav.steer(n.pos.x - (tp.x - n.pos.x), n.pos.z - (tp.z - n.pos.z), 1);
      } else {
        n.nav.stop();
        n.faceTowards(tp.x + 0.5, tp.z + 0.5);
        if (n.attackCd <= 0 && Math.abs(U.wrapAngle(n.yaw - n.faceYaw)) < 0.2) {
          VK.Combat.launchBoulder(n, tp, s);
          n.attackCd = s.cooldown * U.rand(0.9, 1.2);
          this.aimPoint = Math.random() < 0.6 ? this.aimPoint : null;
        }
      }
      return RUNNING;
    }
    stop() { this.npc.nav.stop(); }
  }

  // -------------------------------------------------------------- Order

  class OrderGoal extends Goal {
    priority() {
      const sq = this.npc.squad;
      return sq && sq.order ? 50 : 0;
    }
    start() { this.goal = null; this.goalT = 0; }

    goToward(p, opts, minMove) {
      const n = this.npc;
      this.goalT -= this.dt;
      if (!this.goal || U.dist2(this.goal.x, this.goal.z, p.x, p.z) > (minMove || 2) ||
        (n.nav.status === 'failed' && this.goalT <= 0) || n.nav.status === 'idle') {
        this.goal = { x: p.x, y: p.y, z: p.z };
        this.goalT = 4;
        n.nav.goTo(p.x, p.y, p.z, opts);
      }
    }

    update(dt) {
      this.dt = dt;
      const n = this.npc;
      const sq = n.squad;
      const o = sq && sq.order;
      if (!o) return DONE;
      n.inCombat = false;
      n.aiming = false;
      switch (o.type) {
        case 'garrison': {
          const post = sq.postFor(n);
          if (!post) return RUNNING;
          if (U.dist2(n.pos.x, n.pos.z, post.x + 0.5, post.z + 0.5) > 1.6) this.goToward(post, { radius: 1, maxNodes: 2000 }, 1);
          else { n.nav.stop(); if (o.facing !== undefined) n.faceYawTo(o.facing); }
          return RUNNING;
        }
        case 'defend':
          if (U.dist2(n.pos.x, n.pos.z, o.point.x, o.point.z) > 5) this.goToward(o.point, { radius: 4, speed: 1.2 }, 3);
          else n.nav.stop();
          return RUNNING;
        case 'assault':
          return this.assault(o);
        case 'bombard':
          if (n.isSiege) return RUNNING;
          return this.formation(o.point);
        case 'follow': {
          const p = VK.game.player;
          if (!p || p.dead) return RUNNING;
          return this.formation({ x: p.pos.x, y: p.pos.y, z: p.pos.z }, p);
        }
        default:
          return this.formation(o.point);
      }
    }

    /** Keeps formation around the squad leader (or the player). */
    formation(point, followEntity) {
      const n = this.npc;
      const sq = n.squad;
      const leader = followEntity || sq.leader;
      if (!leader || !point) return RUNNING;
      if (leader === n) {
        const d = U.dist2(n.pos.x, n.pos.z, point.x, point.z);
        if (d > 3) {
          const lag = sq.maxLag();
          this.goToward(point, { radius: 2.5, speed: lag > 12 ? 0.5 : (lag > 7 ? 0.75 : 0.95), maxNodes: 3000 }, 3);
        } else {
          n.nav.stop();
          sq.leaderArrived = true;
        }
        return RUNNING;
      }
      const slot = sq.slotPosition(n, leader);
      const d = U.dist2(n.pos.x, n.pos.z, slot.x, slot.z);
      if (d > 4) this.goToward(slot, { radius: 1.5, speed: 1.2, maxNodes: 1200 }, 3);
      else if (d > 0.7) { this.goal = null; n.nav.steer(slot.x, slot.z, d > 2 ? 1.15 : 0.8); }
      else { this.goal = null; n.nav.stop(); n.faceYawTo(VK.Squad.headingOf(leader)); }
      return RUNNING;
    }

    /** Storms the target: melee units break through, ranged units cover. */
    assault(o) {
      const n = this.npc;
      const p = o.point;
      const d = U.dist2(n.pos.x, n.pos.z, p.x, p.z);
      if (n.stats.ranged || n.isSiege) {
        if (d > 22) this.goToward(p, { radius: 16, maxNodes: 3000 }, 4);
        else n.nav.stop();
        return RUNNING;
      }
      if (d > 2.5) this.goToward(p, { radius: 2, breach: true, maxNodes: 4000, speed: 1.1 }, 3);
      else n.nav.stop();
      return RUNNING;
    }

    stop() { this.npc.nav.stop(); }
  }

  // --------------------------------------------------------------- Sleep

  class SleepGoal extends Goal {
    priority() {
      const n = this.npc;
      if (!n.isVillager || !n.home || !n.home.functional || n.home.settlement !== n.settlement) return 0;
      if (!VK.game.isNight()) return 0;
      if (n.settlement && n.settlement.underAttack) return 0;
      return 45;
    }
    start() {
      const e = this.npc.home.entrance;
      this.npc.nav.goTo(e.x, e.y, e.z, { radius: 1.3 });
    }
    update() {
      const n = this.npc;
      if (n.asleep) return n.home.functional ? RUNNING : DONE;
      const e = n.home.entrance;
      const st = n.nav.status;
      if (st === 'arrived' || U.dist2(n.pos.x, n.pos.z, e.x + 0.5, e.z + 0.5) < 1.8) { n.nav.stop(); n.sleep(); return RUNNING; }
      if (st === 'failed') { n.sleep(); return RUNNING; }
      return RUNNING;
    }
    stop() { if (this.npc.asleep) this.npc.wake(); this.npc.nav.stop(); }
  }

  // ---------------------------------------------------------------- Work

  class WorkGoal extends Goal {
    constructor(npc) { super(npc); this.state = {}; }
    priority() {
      const n = this.npc;
      if (!n.isVillager || !n.job || !n.settlement) return 0;
      return VK.game.isNight() ? 22 : 40;
    }
    start() { this.state = { job: this.npc.job }; }
    update(dt) {
      const n = this.npc;
      const handler = VK.Jobs[n.job];
      if (!handler) return FAILED;
      if (this.state.job !== n.job) {
        const old = VK.Jobs[this.state.job];
        if (old && old.release) old.release(n, this.state);
        this.state = { job: n.job };
      }
      handler.update(n, this.state, dt);
      return RUNNING;
    }
    stop() {
      const h = VK.Jobs[this.state.job];
      if (h && h.release) h.release(this.npc, this.state);
      this.state = { job: this.npc.job };
      this.npc.nav.stop();
    }
  }

  // -------------------------------------------------------------- Return

  class ReturnGoal extends Goal {
    priority() {
      const n = this.npc;
      if (n.squad && n.squad.order) return 0;
      const s = n.settlement;
      if (!s) return 0;
      return U.dist2(n.pos.x, n.pos.z, s.center.x, s.center.z) > s.radius + 24 ? 30 : 0;
    }
    start() {
      const s = this.npc.settlement;
      this.npc.nav.goTo(s.center.x, s.center.y, s.center.z, { radius: 8 });
    }
    update() {
      const st = this.npc.nav.status;
      if (st === 'arrived') return DONE;
      if (st === 'failed' || st === 'idle') { this.start(); }
      return RUNNING;
    }
    stop() { this.npc.nav.stop(); }
  }

  // ---------------------------------------------------------------- Idle

  class IdleGoal extends Goal {
    priority() { return 1; }
    start() { this.t = U.rand(1, 4); }
    update(dt) {
      const n = this.npc;
      this.t -= dt;
      if (this.t <= 0) {
        this.t = U.rand(4, 9);
        const a = n.anchorPoint();
        if (a && Math.random() < 0.7) {
          const r = a.r || 7;
          const x = a.x + U.rand(-r, r), z = a.z + U.rand(-r, r);
          n.nav.goTo(x, VK.game.world.groundY(x, z), z, { radius: 1.5, speed: 0.55, maxNodes: 600 });
        } else if (n.isVillager && Math.random() < 0.3 && n.model.playAction) {
          n.model.playAction('wave', 1.2);
        }
      }
      return RUNNING;
    }
    stop() { this.npc.nav.stop(); }
  }

  /** Creates the goal set appropriate for an NPC. */
  function goalsFor(npc) {
    if (npc.isSiege) return [new SiegeGoal(npc), new OrderGoal(npc), new ReturnGoal(npc), new IdleGoal(npc)];
    if (npc.isSoldier) return [new TalkGoal(npc), new FleeGoal(npc), new CombatGoal(npc), new OrderGoal(npc), new ReturnGoal(npc), new IdleGoal(npc)];
    return [new TalkGoal(npc), new FleeGoal(npc), new SleepGoal(npc), new WorkGoal(npc), new ReturnGoal(npc), new IdleGoal(npc)];
  }

  VK.AI = {
    RUNNING: RUNNING, DONE: DONE, FAILED: FAILED,
    Goal: Goal, Brain: Brain, goalsFor: goalsFor,
    TalkGoal: TalkGoal, FleeGoal: FleeGoal, CombatGoal: CombatGoal, SiegeGoal: SiegeGoal,
    OrderGoal: OrderGoal, SleepGoal: SleepGoal, WorkGoal: WorkGoal, ReturnGoal: ReturnGoal, IdleGoal: IdleGoal
  };
})(window.VK);
