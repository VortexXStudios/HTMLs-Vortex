/**
 * @file jobs.js
 * Villager work behaviours used by WorkGoal. Each job is a small state
 * machine stored in `st` (per NPC) and updated every AI tick:
 *
 *   woodcutter - finds trees, fells them (whole trunk + canopy), replants a
 *                sapling and brings the wood to a stockpile/storage
 *   miner      - digs a terraced quarry layer by layer; stone plus
 *                occasional iron/gold ore
 *   farmer     - harvests ripe wheat in faction farms and replants,
 *                picks berry bushes when farms are empty
 *   hauler     - carries construction materials from storage to building
 *                sites and empties field stockpiles into storage
 *   builder    - constructs and repairs buildings block by block
 */
(function (VK) {
  'use strict';

  const B = VK.Blocks;
  const U = VK.Util;
  const CARRY_MAX = 16;

  function near(npc, x, y, z, r, ry) {
    return U.dist2(npc.pos.x, npc.pos.z, x + 0.5, z + 0.5) <= r && Math.abs(npc.pos.y - y) <= (ry || 3);
  }

  // ------------------------------------------------------ World helpers

  const LOGS = [B.OAK_LOG, B.BIRCH_LOG, B.SPRUCE_LOG];
  const LEAVES = [B.OAK_LEAVES, B.BIRCH_LEAVES, B.SPRUCE_LEAVES];

  /**
   * Fells a tree: removes the connected trunk and the surrounding canopy.
   * @returns {number} number of logs removed
   */
  function fellTree(world, x, y, z) {
    const stack = [[x, y, z]];
    const seen = new Set();
    let logs = 0, minX = x, maxX = x, minZ = z, maxZ = z, maxY = y;
    while (stack.length && logs < 48) {
      const p = stack.pop();
      const k = U.posKey(p[0], p[1], p[2]);
      if (seen.has(k)) continue;
      seen.add(k);
      const id = world.getBlock(p[0], p[1], p[2]);
      if (LOGS.indexOf(id) < 0) continue;
      world.setBlock(p[0], p[1], p[2], 0, { cause: 'npc' });
      logs++;
      minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]);
      minZ = Math.min(minZ, p[2]); maxZ = Math.max(maxZ, p[2]);
      maxY = Math.max(maxY, p[1]);
      for (let dy = 0; dy <= 1; dy++) {
        for (let dz = -1; dz <= 1; dz++) {
          for (let dx = -1; dx <= 1; dx++) {
            if (dx || dy || dz) stack.push([p[0] + dx, p[1] + dy, p[2] + dz]);
          }
        }
      }
    }
    // Canopy
    for (let yy = y + 1; yy <= maxY + 3; yy++) {
      for (let zz = minZ - 3; zz <= maxZ + 3; zz++) {
        for (let xx = minX - 3; xx <= maxX + 3; xx++) {
          if (LEAVES.indexOf(world.getBlock(xx, yy, zz)) >= 0) world.setBlock(xx, yy, zz, 0, { cause: 'npc' });
        }
      }
    }
    if (VK.game.particles) VK.game.particles.blockBurst(x, y + 2, z, B.OAK_LEAVES, 24);
    return logs;
  }

  /** Walks to a drop-off point and hands over the carried resources. */
  function deliver(npc, st, next) {
    const s = npc.settlement;
    if (!npc.carry.amount) { st.phase = next; st.drop = null; return; }
    if (!st.drop) {
      st.drop = s.dropoffFor(npc, npc.carry.type);
      if (!st.drop) { st.phase = next; return; }
      npc.nav.goTo(st.drop.x, st.drop.y, st.drop.z, { radius: 2.2, yRange: 3 });
    }
    const d = st.drop;
    if (npc.nav.status === 'arrived' || near(npc, d.x, d.y, d.z, 2.8)) {
      s.deposit(d, npc);
      st.drop = null;
      st.phase = next;
      npc.nav.stop();
    } else if (npc.nav.status === 'failed') {
      // Could not reach storage: leave the goods in a field stockpile here.
      s.depositHere(npc);
      st.drop = null;
      st.phase = next;
    }
  }

  function wander(npc, st, dt) {
    st.wait -= dt;
    if (st.wait <= 0) { st.phase = 'find'; return; }
    if (!npc.nav.active && Math.random() < dt * 0.3) {
      const a = npc.anchorPoint();
      const x = a.x + U.rand(-6, 6), z = a.z + U.rand(-6, 6);
      npc.nav.goTo(x, VK.game.world.groundY(x, z), z, { radius: 1.5, speed: 0.5, maxNodes: 500 });
    }
  }

  // ------------------------------------------------------------ Jobs

  const Jobs = {};

  Jobs.woodcutter = {
    update: function (npc, st, dt) {
      const s = npc.settlement;
      const world = VK.game.world;
      switch (st.phase) {
        case 'walk': {
          const t = st.tree;
          if (LOGS.indexOf(world.getBlock(t.x, t.y, t.z)) < 0) { s.releaseTree(t, true); st.tree = null; st.phase = 'find'; break; }
          if (npc.nav.status === 'arrived' || near(npc, t.x, t.y, t.z, 1.9)) { npc.nav.stop(); st.phase = 'chop'; st.t = 0; st.swing = 0; }
          else if (npc.nav.status === 'failed') { s.releaseTree(t, true); st.tree = null; st.phase = 'find'; }
          break;
        }
        case 'chop': {
          const t = st.tree;
          npc.faceTowards(t.x + 0.5, t.z + 0.5);
          st.t += dt; st.swing -= dt;
          if (st.swing <= 0) {
            st.swing = 0.65;
            npc.model.playAction('chop', 0.6);
            VK.game.particles.blockBurst(t.x, t.y + 1, t.z, world.getBlock(t.x, t.y, t.z) || B.OAK_LOG, 3);
            VK.game.audio.play('dig', npc.pos);
          }
          if (st.t > 4.2) {
            const logs = fellTree(world, t.x, t.y, t.z);
            s.releaseTree(t, true);
            const below = world.getBlock(t.x, t.y - 1, t.z);
            if ((below === B.GRASS || below === B.DIRT) && Math.random() < 0.85) world.setBlock(t.x, t.y, t.z, B.SAPLING, { cause: 'npc' });
            npc.addCarry('wood', logs * 3);
            st.tree = null;
            st.phase = npc.carry.amount >= CARRY_MAX ? 'deliver' : 'find';
          }
          break;
        }
        case 'deliver': deliver(npc, st, 'find'); break;
        case 'wait': wander(npc, st, dt); break;
        default: {
          if (npc.carry.amount >= CARRY_MAX) { st.phase = 'deliver'; break; }
          const t = s.findTree(npc);
          if (!t) { st.phase = npc.carry.amount ? 'deliver' : 'wait'; st.wait = 6; break; }
          st.tree = t;
          npc.nav.goTo(t.x, t.y, t.z, { radius: 1.6, yRange: 2 });
          st.phase = 'walk';
        }
      }
    },
    release: function (npc, st) { if (st.tree) npc.settlement && npc.settlement.releaseTree(st.tree, false); st.tree = null; }
  };

  Jobs.miner = {
    update: function (npc, st, dt) {
      const s = npc.settlement;
      const world = VK.game.world;
      switch (st.phase) {
        case 'walk': {
          const b = st.block;
          if (world.getBlock(b.x, b.y, b.z) === 0) { s.releaseQuarryBlock(b); st.block = null; st.phase = 'find'; break; }
          const d3 = Math.sqrt(Math.pow(npc.pos.x - b.x - 0.5, 2) + Math.pow(npc.pos.y + 1 - b.y - 0.5, 2) + Math.pow(npc.pos.z - b.z - 0.5, 2));
          if (npc.nav.status === 'arrived' || d3 < 3.2) { npc.nav.stop(); st.phase = 'mine'; st.t = 0; st.swing = 0; }
          else if (npc.nav.status === 'failed') { s.releaseQuarryBlock(b, true); st.block = null; st.phase = 'find'; }
          break;
        }
        case 'mine': {
          const b = st.block;
          const id = world.getBlock(b.x, b.y, b.z);
          if (id === 0 || B.LIQUID[id]) { s.releaseQuarryBlock(b); st.block = null; st.phase = 'find'; break; }
          npc.faceTowards(b.x + 0.5, b.z + 0.5);
          st.t += dt; st.swing -= dt;
          if (st.swing <= 0) {
            st.swing = 0.55;
            npc.model.playAction('swing', 0.5);
            VK.game.particles.blockBurst(b.x, b.y, b.z, id, 3);
            VK.game.audio.play('dig', npc.pos);
          }
          const need = Math.max(0.5, B.defs[id].hardness * 0.9);
          if (st.t >= need) {
            world.setBlock(b.x, b.y, b.z, 0, { cause: 'npc' });
            VK.game.particles.blockBurst(b.x, b.y, b.z, id, 8);
            s.releaseQuarryBlock(b);
            const mat = B.defs[id].material;
            if (mat === 'stone' || mat === 'iron' || mat === 'gold') {
              npc.addCarry('stone', 2);
              if (id === B.IRON_ORE || Math.random() < 0.12) npc.carry.bonus.iron += id === B.IRON_ORE ? 2 : 1;
              if (id === B.GOLD_ORE || id === B.DIAMOND_ORE || Math.random() < 0.03) npc.carry.bonus.gold += (id === B.GOLD_ORE || id === B.DIAMOND_ORE) ? 3 : 1;
            } else if (B.defs[id].material === 'wood') npc.addCarry('wood', 1);
            else if (B.GROUND[id]) npc.addCarry('stone', 1); // rubble and clay for mortar
            st.block = null;
            st.phase = npc.carry.amount >= 12 ? 'deliver' : 'find';
          }
          break;
        }
        case 'deliver': deliver(npc, st, 'find'); break;
        case 'wait': wander(npc, st, dt); break;
        default: {
          if (npc.carry.amount >= 12) { st.phase = 'deliver'; break; }
          const b = s.nextQuarryBlock(npc);
          if (!b) { st.phase = npc.carry.amount ? 'deliver' : 'wait'; st.wait = 5; break; }
          st.block = b;
          npc.nav.goTo(b.x, b.y + 1, b.z, { radius: 2.6, yRange: 3 });
          st.phase = 'walk';
        }
      }
    },
    release: function (npc, st) { if (st.block && npc.settlement) npc.settlement.releaseQuarryBlock(st.block); st.block = null; }
  };

  Jobs.farmer = {
    update: function (npc, st, dt) {
      const s = npc.settlement;
      const world = VK.game.world;
      switch (st.phase) {
        case 'walk': {
          const c = st.crop;
          if (npc.nav.status === 'arrived' || near(npc, c.x, c.y, c.z, 1.8)) { npc.nav.stop(); st.phase = 'work'; st.t = 0; npc.model.playAction('harvest', 1.0); }
          else if (npc.nav.status === 'failed') { s.releaseCrop(c); st.crop = null; st.phase = 'find'; }
          break;
        }
        case 'work': {
          const c = st.crop;
          npc.faceTowards(c.x + 0.5, c.z + 0.5);
          st.t += dt;
          if (st.t > 1.0) {
            const id = world.getBlock(c.x, c.y, c.z);
            const below = world.getBlock(c.x, c.y - 1, c.z);
            if (id === B.WHEAT_3) {
              world.setBlock(c.x, c.y, c.z, B.WHEAT_0, { cause: 'npc' });
              npc.addCarry('food', 3);
              VK.game.particles.blockBurst(c.x, c.y, c.z, B.WHEAT_3, 5);
            } else if (id === B.BERRY_BUSH) {
              world.setBlock(c.x, c.y, c.z, B.BERRY_BUSH_EMPTY, { cause: 'npc' });
              npc.addCarry('food', 2);
            } else if (id === 0 && below === B.FARMLAND) {
              world.setBlock(c.x, c.y, c.z, B.WHEAT_0, { cause: 'npc' });
            }
            s.releaseCrop(c);
            st.crop = null;
            st.phase = npc.carry.amount >= 12 ? 'deliver' : 'find';
          }
          break;
        }
        case 'deliver': deliver(npc, st, 'find'); break;
        case 'wait': wander(npc, st, dt); break;
        default: {
          if (npc.carry.amount >= 12) { st.phase = 'deliver'; break; }
          const c = s.findCropTask(npc);
          if (!c) { st.phase = npc.carry.amount ? 'deliver' : 'wait'; st.wait = 5; break; }
          st.crop = c;
          npc.nav.goTo(c.x, c.y, c.z, { radius: 1.5, yRange: 2 });
          st.phase = 'walk';
        }
      }
    },
    release: function (npc, st) { if (st.crop && npc.settlement) npc.settlement.releaseCrop(st.crop); st.crop = null; }
  };

  Jobs.hauler = {
    update: function (npc, st, dt) {
      const s = npc.settlement;
      const f = npc.faction;
      switch (st.phase) {
        case 'toStorage': {
          const p = st.storage;
          const job = st.haul;
          const src = job.source;
          if (src && src.removed) {
            job.building.incoming[job.material] -= job.amount;
            st.haul = null; st.phase = 'find';
            break;
          }
          if (npc.nav.status === 'arrived' || near(npc, p.x, p.y, p.z, 2.8)) {
            npc.nav.stop();
            const available = src ? src.amount : Math.floor(f.resources[job.material]);
            const amt = Math.min(job.amount, available);
            if (amt <= 0 || job.building.state === 'complete' || job.building.removed) {
              job.building.incoming[job.material] -= job.amount;
              if (src) src.reservedBy = null;
              st.haul = null; st.phase = 'find';
              break;
            }
            if (src) {
              // Taking from a field stockpile: ore bonuses go to the treasury.
              src.amount -= amt;
              f.resources.iron += src.bonus.iron; f.resources.gold += src.bonus.gold;
              src.bonus.iron = 0; src.bonus.gold = 0;
              src.reservedBy = null;
              s.updatePile(src);
            } else f.resources[job.material] -= amt;
            job.building.incoming[job.material] -= (job.amount - amt);
            job.amount = amt;
            npc.carry.type = job.material; npc.carry.amount = amt;
            const e = job.building.siteEntrance();
            npc.nav.goTo(e.x, e.y, e.z, { radius: 3.5, yRange: 6 });
            st.phase = 'toSite';
          } else if (npc.nav.status === 'failed') {
            job.building.incoming[job.material] -= job.amount;
            if (src) src.reservedBy = null;
            st.haul = null; st.phase = 'wait'; st.wait = 3;
          }
          break;
        }
        case 'toSite': {
          const job = st.haul;
          const e = job.building.siteEntrance();
          if (npc.nav.status === 'arrived' || near(npc, e.x, e.y, e.z, 4.5, 8) || npc.nav.status === 'failed') {
            npc.nav.stop();
            if (npc.nav.status === 'failed' && !near(npc, e.x, e.y, e.z, 9, 10)) {
              // Unreachable site: the goods go back into the treasury.
              f.resources[job.material] += npc.carry.amount;
            } else {
              job.building.stock[job.material] += npc.carry.amount;
            }
            job.building.incoming[job.material] -= job.amount;
            npc.carry.amount = 0; npc.carry.type = null;
            st.haul = null; st.phase = 'find';
          }
          break;
        }
        case 'toPile': {
          const pile = st.pile;
          if (pile.removed) { st.pile = null; st.phase = 'find'; break; }
          if (npc.nav.status === 'arrived' || near(npc, pile.x, pile.y, pile.z, 2.4)) {
            npc.nav.stop();
            const take = Math.min(30, pile.amount);
            pile.amount -= take;
            npc.carry.type = pile.type; npc.carry.amount = take;
            npc.carry.bonus.iron += pile.bonus.iron; npc.carry.bonus.gold += pile.bonus.gold;
            pile.bonus.iron = 0; pile.bonus.gold = 0;
            pile.reservedBy = null;
            s.updatePile(pile);
            st.pile = null;
            st.phase = 'deliver';
          } else if (npc.nav.status === 'failed') { pile.reservedBy = null; st.pile = null; st.phase = 'wait'; st.wait = 3; }
          break;
        }
        case 'deliver': deliver(npc, st, 'find'); break;
        case 'wait': wander(npc, st, dt); break;
        default: {
          if (npc.carry.amount) { st.phase = 'deliver'; break; }
          const job = s.pickHaulJob(npc);
          if (!job) { st.phase = 'wait'; st.wait = 3; break; }
          if (job.kind === 'deliver') {
            st.haul = job;
            st.storage = job.source ? { x: job.source.x, y: job.source.y, z: job.source.z } : s.storagePoint(job.building);
            npc.nav.goTo(st.storage.x, st.storage.y, st.storage.z, { radius: 2.2, yRange: 3 });
            st.phase = 'toStorage';
          } else {
            st.pile = job.pile;
            job.pile.reservedBy = npc;
            npc.nav.goTo(job.pile.x, job.pile.y, job.pile.z, { radius: 1.8, yRange: 3 });
            st.phase = 'toPile';
          }
        }
      }
    },
    release: function (npc, st) {
      if (st.haul) {
        st.haul.building.incoming[st.haul.material] -= st.haul.amount;
        if (st.haul.source && st.phase === 'toStorage') st.haul.source.reservedBy = null;
        if (st.phase === 'toSite' && npc.carry.amount) npc.faction.resources[st.haul.material] += npc.carry.amount;
        if (st.phase === 'toSite') { npc.carry.amount = 0; npc.carry.type = null; }
        st.haul = null;
      }
      if (st.pile) { st.pile.reservedBy = null; st.pile = null; }
    }
  };

  Jobs.builder = {
    update: function (npc, st, dt) {
      const s = npc.settlement;
      const world = VK.game.world;
      switch (st.phase) {
        case 'approach': {
          const b = st.project;
          if (!b || b.removed || !b.hasWork()) { st.phase = 'find'; break; }
          const task = b.peekTask(world);
          if (!task) { st.phase = 'find'; break; }
          // Work from outside the footprint when possible (no walling yourself in).
          let stand = (st.approaches || 0) < 2 ? b.outsideStandPoint(world, task, npc.faction.id) : null;
          st.allowInside = !stand;
          if (!stand) {
            const gy = world.groundY(task.x, task.z);
            stand = world.findStandableNear(task.x, Math.min(task.y, gy), task.z, 5, npc.faction.id) || b.siteEntrance();
          }
          npc.nav.goTo(stand.x, stand.y, stand.z, { radius: 0.5, yRange: 4, maxNodes: 3000 });
          st.phase = 'walk';
          st.walkT = 0;
          break;
        }
        case 'walk': {
          const b = st.project;
          const task = b && !b.removed ? b.peekTask(world) : null;
          if (!task) { st.phase = 'find'; break; }
          st.walkT += dt;
          const inside = npc.pos.x >= b.origin.x && npc.pos.x <= b.origin.x + b.rw && npc.pos.z >= b.origin.z && npc.pos.z <= b.origin.z + b.rd;
          const arrived = npc.nav.status === 'arrived';
          if (Jobs.builder.inReach(npc, task) && (arrived || st.allowInside || !inside)) {
            npc.nav.stop(); st.phase = 'build'; st.t = 0; st.waitT = 0; st.approaches = 0;
            break;
          }
          if (arrived) {
            // Arrived but still out of reach: after two tries go right up to the task.
            st.approaches = (st.approaches || 0) + 1;
            st.phase = 'approach';
            break;
          }
          if (npc.nav.status === 'failed' || st.walkT > 40) {
            st.fails = (st.fails || 0) + 1;
            if (st.fails >= 3) {
              // Builders climb scaffolding in reality; here they hop to the site entrance.
              const e = b.siteEntrance();
              npc.pos.set(e.x + 0.5, e.y + 0.05, e.z + 0.5);
              st.fails = 0;
            }
            st.phase = 'approach';
          }
          break;
        }
        case 'build': {
          const b = st.project;
          if (!b || b.removed) { st.phase = 'find'; break; }
          st.t += dt;
          if (st.t < 0.34) break;
          st.t = 0;
          const task = b.peekTask(world);
          if (!task) { st.phase = 'find'; break; }
          if (!Jobs.builder.inReach(npc, task)) { st.phase = 'approach'; break; }
          const mat = B.material(task.id);
          if (mat && b.stock[mat] < 1) {
            st.waitT += 0.34;
            b.waitingFor = mat;
            if (st.waitT > 30) { st.project = null; st.phase = 'find'; st.cooldown = 10; }
            break;
          }
          st.waitT = 0;
          if (task.id !== 0 && B.SOLID[task.id] && VK.game.entities.cellOccupied(task.x, task.y, task.z)) {
            if (VK.Physics.cellIntersects(npc, task.x, task.y, task.z, 0.1)) {
              // Standing on our own work site: step outside first.
              st.phase = 'approach';
              break;
            }
            b.deferTask();
            break;
          }
          npc.faceTowards(task.x + 0.5, task.z + 0.5);
          npc.model.playAction('build', 0.34);
          const old = world.getBlock(task.x, task.y, task.z);
          if (task.id === 0 && old !== 0 && VK.game.particles) VK.game.particles.blockBurst(task.x, task.y, task.z, old, 4);
          world.setBlock(task.x, task.y, task.z, task.id, { cause: 'build' });
          if (task.id !== 0 && Math.random() < 0.35) VK.game.audio.play('place', { x: task.x, y: task.y, z: task.z });
          if (mat) b.stock[mat] -= 1;
          b.advanceTask(mat);
          break;
        }
        case 'wait': wander(npc, st, dt); break;
        default: {
          if (st.cooldown > 0) { st.cooldown -= dt; wander(npc, st, dt); break; }
          const p = s.pickProject(npc);
          if (!p) { st.phase = 'wait'; st.wait = 5; break; }
          st.project = p;
          st.phase = 'approach';
        }
      }
    },
    inReach: function (npc, task) {
      const d = U.dist2(npc.pos.x, npc.pos.z, task.x + 0.5, task.z + 0.5);
      return d < 4.9 && task.y - npc.pos.y < 16 && npc.pos.y - task.y < 6;
    },
    release: function (npc, st) { st.project = null; npc.workProject = null; }
  };

  VK.Jobs = Jobs;
  VK.WorkOps = { fellTree: fellTree };
})(window.VK);
