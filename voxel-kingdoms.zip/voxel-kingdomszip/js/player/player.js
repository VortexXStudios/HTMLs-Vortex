/**
 * @file player.js
 * The player: Minecraft-style first person controls (walk, sprint, sneak
 * with edge protection, jump, swim, fall damage), block breaking with tool
 * speeds and crack overlay, block placement, melee with attack cooldown and
 * criticals, bows with draw strength, shields, eating, health / hunger /
 * stamina / air, death and respawn, first person hand rendering, third
 * person camera, spectator flight and commanding a squad of soldiers.
 */
(function (VK) {
  'use strict';

  const B = VK.Blocks;
  const U = VK.Util;
  const Items = VK.Items;

  const WALK = 4.317, SPRINT = 5.612, SNEAK = 1.31, SWIM = 2.2;
  const JUMP = 8.4;
  const BLOCK_REACH = 5, ENTITY_REACH = 3.6;

  class Player {
    constructor(game) {
      this.game = game;
      this.isPlayer = true;
      this.id = -1;
      this.pos = new THREE.Vector3(0, 80, 0);
      this.vel = new THREE.Vector3();
      this.yaw = 0;
      this.pitch = 0;
      this.hw = 0.3;
      this.h = 1.8;
      this.onGround = false;
      this.inWater = false;
      this.eyeInWater = false;
      this.hitWall = false;
      this.health = 20;
      this.maxHealth = 20;
      this.hunger = 20;
      this.saturation = 5;
      this.exhaustion = 0;
      this.stamina = 100;
      this.air = 10;
      this.dead = false;
      this.deathCause = '';
      this.spectator = false;
      this.sneaking = false;
      this.sprinting = false;
      this.blocking = false;
      this.faction = null;
      this.rep = { ironhold: 0, redmoor: 0 };
      this.aggro = { ironhold: 0, redmoor: 0 };
      this.inventory = new VK.Inventory(36);
      this.selected = 0;
      this.spawnPoint = null;
      this.airMaxY = 0;
      this.wasOnGround = true;
      this.regenT = 0;
      this.starveT = 0;
      this.drownT = 0;
      this.hurtCooldown = 0;
      this.hurtTilt = 0;
      this.breaking = null;
      this.digSoundT = 0;
      this.attackT = 10;
      this.eatT = -1;
      this.bowCharge = -1;
      this.swingT = 1;
      this.target = { block: null, entity: null };
      this.viewMode = 0;
      this.bobPhase = 0;
      this.stepDist = 0;
      this.fov = 75;
      this.fuelPoints = 0;
      this.followers = null;
      this.jumpCd = 0;
      this.lastHeldId = undefined;

      this.buildOverlays();
      this.buildHand();
      this.model = new VK.Models.HumanoidModel(VK.Models.playerAppearance());
      this.model.root.visible = false;
      game.scene.add(this.model.root);
    }

    get factionId() { return this.spectator ? null : this.faction; }
    get heldStack() { return this.inventory.slots[this.selected]; }
    get heldDef() { const s = this.heldStack; return s ? Items.get(s.id) : null; }

    eyePos() { return { x: this.pos.x, y: this.pos.y + (this.sneaking ? 1.5 : 1.62), z: this.pos.z }; }

    lookDir() {
      const cp = Math.cos(this.pitch);
      return { x: -Math.sin(this.yaw) * cp, y: Math.sin(this.pitch), z: -Math.cos(this.yaw) * cp };
    }

    // ------------------------------------------------------------ Setup

    buildOverlays() {
      const scene = this.game.scene;
      const edges = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.004, 1.004, 1.004));
      this.selection = new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.55 }));
      this.selection.visible = false;
      scene.add(this.selection);
      const crackGeo = new THREE.BoxGeometry(1.006, 1.006, 1.006);
      this.crackMat = new THREE.MeshBasicMaterial({ map: VK.Textures.texture, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
      this.crack = new THREE.Mesh(crackGeo, this.crackMat);
      this.crack.visible = false;
      this.crackStage = -1;
      scene.add(this.crack);
    }

    setCrackStage(stage) {
      if (stage === this.crackStage) return;
      this.crackStage = stage;
      const tile = VK.Textures.index['crack_' + stage];
      const UVT = VK.Textures.uv;
      const u0 = UVT[tile * 4], v0 = UVT[tile * 4 + 1], u1 = UVT[tile * 4 + 2], v1 = UVT[tile * 4 + 3];
      const uv = this.crack.geometry.attributes.uv;
      const base = [0, 1, 1, 1, 0, 0, 1, 0];
      for (let i = 0; i < uv.count; i++) {
        const k = i % 4;
        uv.setXY(i, base[k * 2] ? u1 : u0, base[k * 2 + 1] ? v1 : v0);
      }
      uv.needsUpdate = true;
    }

    buildHand() {
      this.handScene = new THREE.Scene();
      this.handCam = new THREE.PerspectiveCamera(70, 1, 0.01, 10);
      this.handAmbient = new THREE.AmbientLight(0xffffff, 0.55);
      this.handDir = new THREE.DirectionalLight(0xffffff, 0.6);
      this.handDir.position.set(0.3, 1, 0.6);
      this.handScene.add(this.handAmbient, this.handDir);
      this.handRoot = new THREE.Group();
      this.handScene.add(this.handRoot);
      this.handItem = null;
      this.armMesh = new THREE.Mesh(
        VK.Models.buildBoxes([VK.Models.box(-0.09, -0.09, -0.4, 0.09, 0.09, 0.3, [220, 172, 130]), VK.Models.box(-0.095, -0.095, 0.05, 0.095, 0.095, 0.3, [60, 150, 170])]),
        VK.Models.material()
      );
      this.handMats = new Map();
    }

    /** Rebuilds the item shown in the first person hand. */
    updateHandItem() {
      const st = this.heldStack;
      const id = st ? st.id : null;
      if (id === this.lastHeldId) return;
      this.lastHeldId = id;
      if (this.handItem) this.handRoot.remove(this.handItem);
      this.handItem = null;
      if (!id) {
        this.handItem = this.armMesh;
        this.armMesh.rotation.set(-0.25, 0.2, 0);
        this.armMesh.position.set(0.1, -0.05, 0.1);
      } else {
        const def = Items.get(id);
        if (def && def.block !== null && !B.CROSS[def.block] && B.defs[def.block].tex) {
          const m = new THREE.Mesh(this.game.entities.drops.cubeGeometry(def.block), this.game.entities.drops.cubeMat);
          m.scale.setScalar(1.45);
          m.rotation.set(0.1, 0.75, 0);
          this.handItem = m;
        } else {
          let mat = this.handMats.get(id);
          if (!mat) {
            const tex = new THREE.CanvasTexture(VK.Icons.canvas(id));
            tex.magFilter = THREE.NearestFilter; tex.minFilter = THREE.NearestFilter; tex.generateMipmaps = false;
            mat = new THREE.MeshLambertMaterial({ map: tex, transparent: true, alphaTest: 0.5, side: THREE.DoubleSide });
            this.handMats.set(id, mat);
          }
          const m = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.62), mat);
          m.rotation.set(0, -1.1, 0.35);
          this.handItem = m;
        }
      }
      this.handRoot.add(this.handItem);
      // Third person model item
      const map = { sword: 'sword', pickaxe: 'pickaxe', axe: 'axe', hoe: 'hoe', spear: 'spear' };
      let tp = null;
      if (id) {
        for (const k in map) if (id.indexOf(k) >= 0) tp = map[k];
      }
      this.model.setRightItem(tp);
    }

    // ------------------------------------------------------------- Update

    update(dt) {
      const g = this.game;
      const input = g.input;
      const ui = g.ui;
      const active = input.locked && !ui.isOpen();
      this.hurtCooldown -= dt;
      this.attackT += dt;
      this.jumpCd -= dt;
      this.hurtTilt *= Math.max(0, 1 - dt * 8);
      if (this.dead) { this.updateCamera(dt); return; }

      // Look
      const m = input.takeMouse();
      if (active) {
        const sens = 0.0022 * g.settings.mouseSensitivity;
        this.yaw -= m.x * sens;
        this.pitch -= m.y * sens * (g.settings.invertY ? -1 : 1);
        this.pitch = U.clamp(this.pitch, -Math.PI / 2 + 0.01, Math.PI / 2 - 0.01);
      }

      // Hotbar
      if (active) {
        const w = input.takeWheel();
        if (w) this.selected = ((this.selected + w) % 9 + 9) % 9;
        for (let i = 1; i <= 9; i++) if (input.wasPressed('Digit' + i)) this.selected = i - 1;
      } else input.takeWheel();
      this.updateHandItem();

      // Keys
      let fwd = 0, str = 0, up = 0;
      if (active) {
        if (input.down('KeyW')) fwd += 1;
        if (input.down('KeyS')) fwd -= 1;
        if (input.down('KeyD')) str += 1;
        if (input.down('KeyA')) str -= 1;
        if (input.down('Space')) up += 1;
        if (input.down('ShiftLeft') || input.down('ShiftRight')) up -= 1;
        if (input.wasPressed('KeyQ')) this.dropSelected(input.down('ShiftLeft') || input.down('ShiftRight'));
        if (input.wasPressed('F5')) { this.viewMode = (this.viewMode + 1) % 3; }
        if (input.wasPressed('KeyG')) this.toggleFollowers();
        if (input.wasPressed('F4')) this.setSpectator(!this.spectator);
      }
      this.sneaking = active && !this.spectator && (input.down('ShiftLeft') || input.down('ShiftRight'));
      const def = this.heldDef;
      this.blocking = active && !this.spectator && !!(def && def.shield) && input.mouseDown(2) && this.stamina > 2;
      // Sprint: double-tap W or hold R (Ctrl is avoided because Ctrl+W closes browser tabs).
      if (active && fwd > 0 && (input.down('KeyR') || input.wasDoubleTapped('KeyW')) && !this.sneaking) {
        if (this.stamina > 10 && this.hunger > 6) this.sprinting = true;
      }
      if (fwd <= 0 || this.sneaking || this.stamina <= 0 || this.hunger <= 6 || this.blocking || (this.hitWall && this.onGround)) this.sprinting = false;

      if (this.spectator) this.flyMove(dt, fwd, str, up);
      else this.walkMove(dt, fwd, str, active && input.down('Space'));

      this.updateTarget();
      if (!this.spectator) {
        this.updateInteraction(dt, active);
        this.updateStats(dt);
      }
      this.updateCamera(dt);
      this.updateOverlays();
    }

    walkMove(dt, fwd, str, jump) {
      const world = this.game.world;
      let speed = this.inWater ? SWIM : (this.sneaking ? SNEAK : (this.sprinting ? SPRINT : WALK));
      if (this.blocking || this.eatT >= 0 || this.bowCharge >= 0) speed *= 0.35;
      const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
      const rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);
      let wx = fx * fwd + rx * str, wz = fz * fwd + rz * str;
      const len = Math.sqrt(wx * wx + wz * wz);
      if (len > 1) { wx /= len; wz /= len; }
      const accel = this.onGround ? 14 : (this.inWater ? 6 : 2.6);
      const k = Math.min(1, accel * dt);
      this.vel.x += (wx * speed - this.vel.x) * k;
      this.vel.z += (wz * speed - this.vel.z) * k;
      if (this.inWater) {
        this.vel.y -= 9 * dt;
        this.vel.y *= Math.max(0, 1 - 2.5 * dt);
        if (jump) this.vel.y = Math.min(this.vel.y + 24 * dt, 3.4);
      } else {
        this.vel.y -= VK.Config.GRAVITY * dt;
        if (jump && this.onGround && this.jumpCd <= 0) {
          this.vel.y = JUMP;
          this.jumpCd = 0.25;
          this.stamina -= 3;
          this.exhaustion += this.sprinting ? 0.2 : 0.05;
          if (this.sprinting) { this.vel.x += fx * 1.6; this.vel.z += fz * 1.6; }
        }
      }
      if (this.vel.y < -55) this.vel.y = -55;
      // Sneaking stops you from walking off edges.
      if (this.sneaking && this.onGround && !this.inWater) {
        const P = VK.Physics;
        const y = this.pos.y;
        if (!P.overlaps(world, this.pos.x + this.vel.x * dt - this.hw, y - 0.6, this.pos.z - this.hw, this.pos.x + this.vel.x * dt + this.hw, y - 0.01, this.pos.z + this.hw, this.faction)) this.vel.x = 0;
        if (!P.overlaps(world, this.pos.x - this.hw, y - 0.6, this.pos.z + this.vel.z * dt - this.hw, this.pos.x + this.hw, y - 0.01, this.pos.z + this.vel.z * dt + this.hw, this.faction)) this.vel.z = 0;
      }
      const oldX = this.pos.x, oldZ = this.pos.z;
      VK.Physics.move(world, this, dt);
      const moved = Math.sqrt(Math.pow(this.pos.x - oldX, 2) + Math.pow(this.pos.z - oldZ, 2));
      this.exhaustion += moved * (this.sprinting ? 0.1 : 0.01);
      const eye = this.eyePos();
      this.eyeInWater = world.getBlock(Math.floor(eye.x), Math.floor(eye.y), Math.floor(eye.z)) === B.WATER;

      // Fall damage
      if (this.onGround && !this.wasOnGround) {
        const fall = this.airMaxY - this.pos.y;
        if (fall > 3.4 && !this.inWater) this.hurt(Math.floor(fall - 3), null, 'fall');
        if (fall > 1.2) this.game.audio.play('step');
      }
      if (this.onGround || this.inWater) this.airMaxY = this.pos.y;
      else this.airMaxY = Math.max(this.airMaxY, this.pos.y);
      this.wasOnGround = this.onGround;

      // Footsteps
      if (this.onGround && moved > 0) {
        this.stepDist += moved;
        if (this.stepDist > (this.sprinting ? 2.6 : 2.0)) { this.stepDist = 0; this.game.audio.play('step'); }
      }
      if (this.pos.y < -20) this.hurt(100, null, 'void');
    }

    flyMove(dt, fwd, str, up) {
      const speed = this.game.input.down('KeyR') ? 28 : 12;
      const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
      const rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);
      const k = Math.min(1, 8 * dt);
      this.vel.x += ((fx * fwd + rx * str) * speed - this.vel.x) * k;
      this.vel.z += ((fz * fwd + rz * str) * speed - this.vel.z) * k;
      this.vel.y += (up * speed * 0.8 - this.vel.y) * k;
      this.pos.addScaledVector(this.vel, dt);
      this.pos.y = U.clamp(this.pos.y, 1, 200);
      this.onGround = false;
      this.inWater = false;
      this.eyeInWater = false;
    }

    setSpectator(on) {
      this.spectator = on;
      this.vel.set(0, 0, 0);
      this.breaking = null;
      this.game.ui.hud.toast(on ? 'Spectator mode: fly freely, NPCs ignore you (F4 to return)' : 'Survival mode');
      if (!on) {
        const s = this.game.world.surface(Math.floor(this.pos.x), Math.floor(this.pos.z));
        if (this.pos.y < s.y) this.pos.y = s.y + 0.1;
        this.airMaxY = this.pos.y;
      }
    }

    // ----------------------------------------------------------- Target

    updateTarget() {
      const g = this.game;
      if (this.spectator) { this.target.block = null; this.target.entity = null; return; }
      const e = this.eyePos();
      const d = this.lookDir();
      const hit = g.world.raycast(e.x, e.y, e.z, d.x, d.y, d.z, BLOCK_REACH, function (id) { return !B.LIQUID[id]; });
      const def = this.heldDef;
      const reach = def && def.weapon && def.weapon.reach ? def.weapon.reach : ENTITY_REACH;
      const eh = g.entities.raycastEntities(e, d, reach);
      this.target.block = hit;
      this.target.entity = eh && (!hit || eh.t < hit.t) ? eh.entity : null;
      this.target.entityT = eh ? eh.t : Infinity;
      // Entities a bit further away can still be talked to.
      this.target.talk = null;
      if (!this.target.entity) {
        const far = g.entities.raycastEntities(e, d, 5);
        if (far && (!hit || far.t < hit.t)) this.target.talk = far.entity;
      }
    }

    // ------------------------------------------------------ Interaction

    updateInteraction(dt, active) {
      const g = this.game;
      const input = g.input;
      const def = this.heldDef;
      this.swingT = Math.min(1, this.swingT + dt * 4);

      // Left mouse: attack or dig
      if (active && input.mouseDown(0) && this.eatT < 0) {
        const ent = this.target.entity;
        if (ent) {
          this.breaking = null;
          const cd = def && def.weapon ? def.weapon.cooldown : 0.4;
          if (input.mousePressed(0) || this.attackT >= cd) this.attack(ent);
        } else if (this.target.block) {
          const b = this.target.block;
          if (!this.breaking || this.breaking.x !== b.x || this.breaking.y !== b.y || this.breaking.z !== b.z) {
            this.breaking = { x: b.x, y: b.y, z: b.z, id: b.id, progress: 0 };
          }
          const t = B.breakTime(b.id, def);
          if (t !== Infinity) {
            this.breaking.progress += dt / t;
            this.digSoundT -= dt;
            if (this.digSoundT <= 0) {
              this.digSoundT = 0.24;
              this.swingT = 0;
              g.audio.play('dig', { x: b.x + 0.5, y: b.y + 0.5, z: b.z + 0.5 });
              g.particles.blockBurst(b.x, b.y, b.z, b.id, 2);
            }
            if (this.breaking.progress >= 1) this.breakBlock(b);
          }
        } else if (input.mousePressed(0)) {
          this.swingT = 0;
        }
      } else this.breaking = null;

      // Right mouse
      if (active && input.mousePressed(2)) this.use();
      // Eating
      if (this.eatT >= 0) {
        if (!(active && input.mouseDown(2)) || !def || !def.food) this.eatT = -1;
        else {
          this.eatT += dt;
          if (Math.floor(this.eatT / 0.3) !== Math.floor((this.eatT - dt) / 0.3)) g.audio.play('eat');
          if (this.eatT >= 1.6) {
            this.hunger = Math.min(20, this.hunger + def.food.hunger);
            this.saturation = Math.min(this.hunger, this.saturation + def.food.saturation);
            this.inventory.takeFrom(this.selected, 1);
            this.eatT = -1;
            g.audio.play('pickup');
          }
        }
      }
      // Bow
      if (this.bowCharge >= 0) {
        if (!def || def.ranged !== 'bow') this.bowCharge = -1;
        else if (active && input.mouseDown(2)) this.bowCharge += dt;
        else {
          if (this.bowCharge > 0.15) this.fireBow(Math.min(1, this.bowCharge));
          this.bowCharge = -1;
        }
      }
      if (this.blocking) this.stamina -= 5 * dt;
    }

    attack(ent) {
      const g = this.game;
      const def = this.heldDef;
      const w = def && def.weapon ? def.weapon : { damage: 1, cooldown: 0.4 };
      const charge = U.clamp(this.attackT / w.cooldown, 0.2, 1);
      let dmg = w.damage * charge;
      const crit = !this.onGround && this.vel.y < 0 && charge > 0.9;
      if (crit) {
        dmg *= 1.5;
        g.particles.sparkle(ent.pos.x, ent.pos.y + 1, ent.pos.z, 1, 1, 0.6, 10);
      }
      if (this.sprinting && charge > 0.9) {
        ent.vel.x += -Math.sin(this.yaw) * 3;
        ent.vel.z += -Math.cos(this.yaw) * 3;
      }
      VK.Combat.applyDamage(ent, dmg, this, 'melee');
      this.attackT = 0;
      this.swingT = 0;
      this.exhaustion += 0.1;
      this.stamina -= 3;
      g.audio.play('swing');
      if (def && (def.weapon || def.tool)) this.damageHeld(def.tool && !/sword|spear/.test(def.id) ? 2 : 1);
    }

    breakBlock(b) {
      const g = this.game;
      const world = g.world;
      const def = this.heldDef;
      const id = world.getBlock(b.x, b.y, b.z);
      if (id === 0) { this.breaking = null; return; }
      const building = g.kingdoms.buildingAt(b.x, b.y, b.z);
      if (building && building.owner) {
        if (B.SOLID[id]) VK.Diplomacy.onPlayerBreakStructure(building);
        else if (building.type === 'farm' && id >= B.WHEAT_0 && id <= B.WHEAT_3 && !VK.Diplomacy.playerHostileTo(building.owner.id) && this.faction !== building.owner.id) {
          VK.Diplomacy.changeRep(building.owner.id, -1, null);
        }
      }
      world.spillChest(b.x, b.y, b.z, id);
      const drops = B.rollDrops(id, def);
      drops.forEach(function (d) { g.entities.drops.spawn(VK.Items.stack(d[0], d[1]), b.x + 0.5, b.y + 0.4, b.z + 0.5); });
      world.setBlock(b.x, b.y, b.z, 0, { cause: 'player', urgent: true });
      g.particles.blockBurst(b.x, b.y, b.z, id, 16);
      g.audio.play('break', { x: b.x + 0.5, y: b.y + 0.5, z: b.z + 0.5 });
      if (def && def.tool && B.defs[id].hardness > 0) this.damageHeld(def.tool.type === B.defs[id].tool ? 1 : 2);
      else if (def && def.weapon && B.defs[id].hardness > 0) this.damageHeld(2);
      this.exhaustion += 0.005;
      this.breaking = null;
      this.swingT = 0;
    }

    /** Right click: talk, open stations, eat, draw bow, till, plant, place. */
    use() {
      const g = this.game;
      const world = g.world;
      const def = this.heldDef;
      const talk = this.target.entity || this.target.talk;
      if (talk && !talk.dead) {
        g.ui.openNPC(talk);
        return;
      }
      const b = this.target.block;
      if (b && !this.sneaking) {
        switch (b.id) {
          case B.CRAFTING_TABLE: g.ui.openCrafting(3); return;
          case B.FURNACE: g.ui.openFurnace(); return;
          case B.CHEST: {
            const bld = g.kingdoms.buildingAt(b.x, b.y, b.z);
            if (bld && bld.owner && this.faction !== bld.owner.id) { g.ui.hud.toast('This chest belongs to the ' + bld.owner.name + '.'); return; }
            g.ui.openChest(b.x, b.y, b.z);
            return;
          }
          case B.BERRY_BUSH:
            world.setBlock(b.x, b.y, b.z, B.BERRY_BUSH_EMPTY, { cause: 'player', urgent: true });
            this.inventory.add('berries', U.randInt(1, 3));
            g.audio.play('pickup');
            this.swingT = 0;
            return;
        }
      }
      if (!def) return;
      if (def.food && this.hunger < 20 && !(def.placeWithSneakOnly && this.sneaking)) { this.eatT = 0; return; }
      if (def.ranged === 'bow') {
        if (this.inventory.has('arrow')) this.bowCharge = 0;
        else g.ui.hud.toast('You need arrows.');
        return;
      }
      if (def.shield) return;
      if (def.tool && def.tool.type === 'hoe' && b && (b.id === B.GRASS || b.id === B.DIRT) && world.getBlock(b.x, b.y + 1, b.z) === 0) {
        world.setBlock(b.x, b.y, b.z, B.FARMLAND, { cause: 'player', urgent: true });
        g.audio.play('dig', b);
        this.damageHeld(1);
        this.swingT = 0;
        return;
      }
      if (def.block !== null && b) this.placeBlock(b, def);
    }

    placeBlock(b, def) {
      const g = this.game;
      const world = g.world;
      if (def.placeWithSneakOnly && !this.sneaking) return;
      let px, py, pz;
      if (B.REPLACEABLE[b.id] && b.id !== 0) { px = b.x; py = b.y; pz = b.z; }
      else { px = b.x + b.nx; py = b.y + b.ny; pz = b.z + b.nz; }
      const cur = world.getBlock(px, py, pz);
      if (!B.REPLACEABLE[cur]) return;
      if (def.placeOn && def.placeOn.indexOf(world.getBlock(px, py - 1, pz)) < 0) return;
      const id = def.block;
      if (B.SOLID[id]) {
        if (VK.Physics.cellIntersects(this, px, py, pz)) return;
        if (g.entities.cellOccupied(px, py, pz)) return;
      }
      if (B.CROSS[id] && !B.SOLID[world.getBlock(px, py - 1, pz)]) return;
      world.setBlock(px, py, pz, id, { cause: 'player', urgent: true });
      this.inventory.takeFrom(this.selected, 1);
      g.audio.play('place', { x: px + 0.5, y: py + 0.5, z: pz + 0.5 });
      this.swingT = 0;
    }

    fireBow(charge) {
      const g = this.game;
      if (!this.inventory.remove('arrow', 1)) return;
      const e = this.eyePos();
      const d = this.lookDir();
      const speed = 14 + 30 * charge;
      g.entities.projectiles.spawn('arrow', e.x + d.x * 0.5, e.y + d.y * 0.5 - 0.1, e.z + d.z * 0.5,
        d.x * speed, d.y * speed, d.z * speed,
        { owner: this, factionId: this.faction, damage: 2 + 7 * charge * charge });
      g.audio.play('bow');
      this.damageHeld(1);
      this.exhaustion += 0.05;
    }

    /** Wears down the held tool; breaks it at zero durability. */
    damageHeld(n) {
      const s = this.heldStack;
      if (!s || s.dur === undefined) return;
      s.dur -= n;
      if (s.dur <= 0) {
        this.inventory.set(this.selected, null);
        this.game.audio.play('break');
        this.game.ui.hud.toast('Your ' + Items.name(s.id) + ' broke!');
      } else this.inventory.changed();
    }

    dropSelected(all) {
      const s = this.heldStack;
      if (!s) return;
      const st = this.inventory.takeFrom(this.selected, all ? s.count : 1);
      const e = this.eyePos();
      const d = this.lookDir();
      const drop = this.game.entities.drops.spawn(st, e.x + d.x * 0.4, e.y - 0.3, e.z + d.z * 0.4, d.x * 5, d.y * 5 + 2, d.z * 5);
      if (drop) drop.pickupDelay = 1.5;
    }

    // ------------------------------------------------------------ Stats

    updateStats(dt) {
      // Passive hunger drain plus exhaustion from actions.
      this.exhaustion += dt * 0.012;
      while (this.exhaustion >= 4) {
        this.exhaustion -= 4;
        if (this.saturation > 0) this.saturation = Math.max(0, this.saturation - 1);
        else this.hunger = Math.max(0, this.hunger - 1);
      }
      if (this.hunger >= 18 && this.health < this.maxHealth) {
        this.regenT += dt;
        if (this.regenT >= 3.5) { this.regenT = 0; this.health = Math.min(this.maxHealth, this.health + 1); this.exhaustion += 3; }
      } else this.regenT = 0;
      if (this.hunger <= 0) {
        this.starveT += dt;
        if (this.starveT >= 4) { this.starveT = 0; if (this.health > 1) this.hurt(1, null, 'starve'); }
      }
      // Stamina
      if (this.sprinting) this.stamina -= 11 * dt;
      else if (!this.blocking && this.hunger > 0) this.stamina += (this.onGround ? 18 : 8) * dt;
      this.stamina = U.clamp(this.stamina, 0, 100);
      // Air
      if (this.eyeInWater) {
        this.air -= dt;
        if (this.air <= 0) {
          this.drownT += dt;
          if (this.drownT >= 1) { this.drownT = 0; this.hurt(2, null, 'drown'); }
        }
      } else this.air = Math.min(10, this.air + dt * 4);
    }

    /** Damage to the player. Shields block frontal melee and arrows. */
    hurt(amount, attacker, kind) {
      if (this.dead || this.spectator) return 0;
      const g = this.game;
      if (this.hurtCooldown > 0 && kind !== 'starve' && kind !== 'drown' && kind !== 'void') return 0;
      let dmg = amount;
      if (this.blocking && attacker && attacker.pos && (kind === 'melee' || kind === 'arrow')) {
        const dx = attacker.pos.x - this.pos.x, dz = attacker.pos.z - this.pos.z;
        const d = Math.sqrt(dx * dx + dz * dz) || 1;
        const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
        if ((dx * fx + dz * fz) / d > 0.3) {
          dmg *= 0.1;
          g.audio.play('clang');
          g.particles.hit(this.pos.x + fx * 0.6, this.pos.y + 1.2, this.pos.z + fz * 0.6, true);
          this.damageHeld(1);
          this.stamina -= 8;
        }
      }
      this.health -= dmg;
      this.hurtCooldown = 0.45;
      this.hurtTilt = 0.12 * (Math.random() < 0.5 ? -1 : 1);
      this.exhaustion += 0.1;
      if (dmg >= 0.5) {
        g.audio.play('hurt');
        g.ui.hud.damageFlash();
      }
      if (attacker && attacker.pos && kind !== 'starve') {
        const dx = this.pos.x - attacker.pos.x, dz = this.pos.z - attacker.pos.z;
        const d = Math.sqrt(dx * dx + dz * dz) || 1;
        const kb = kind === 'blast' ? 9 : 4;
        this.vel.x += dx / d * kb;
        this.vel.z += dz / d * kb;
        if (this.onGround) this.vel.y = Math.max(this.vel.y, 4.5);
      }
      if (this.health <= 0) this.die(attacker, kind);
      return dmg;
    }

    die(attacker, kind) {
      const g = this.game;
      this.dead = true;
      this.health = 0;
      this.breaking = null;
      this.eatT = -1;
      this.bowCharge = -1;
      let cause = 'You died.';
      if (attacker && attacker.displayName) cause = 'You were slain by ' + attacker.displayName + ' of ' + attacker.faction.shortName + '.';
      else if (kind === 'fall') cause = 'You fell from a high place.';
      else if (kind === 'drown') cause = 'You drowned.';
      else if (kind === 'starve') cause = 'You starved to death.';
      else if (kind === 'arrow') cause = 'You were shot by a tower archer.';
      else if (kind === 'void') cause = 'You fell out of the world.';
      else if (kind === 'blast') cause = 'You were crushed by a trebuchet boulder.';
      this.deathCause = cause;
      // Drop everything.
      this.inventory.slots.forEach((s, i) => {
        if (s) g.entities.drops.spawn(s, this.pos.x, this.pos.y + 1, this.pos.z, U.rand(-3, 3), U.rand(2, 5), U.rand(-3, 3));
        this.inventory.slots[i] = null;
      });
      this.inventory.changed();
      this.releaseFollowers(true);
      g.audio.play('death');
      g.log(cause, 'player', 'war');
      g.ui.showDeath(cause);
    }

    respawn() {
      const g = this.game;
      const sp = this.spawnPoint || g.worldSpawn;
      const y = g.world.groundY(Math.floor(sp.x), Math.floor(sp.z));
      this.pos.set(sp.x, y + 0.1, sp.z);
      this.vel.set(0, 0, 0);
      this.health = this.maxHealth;
      this.hunger = 20;
      this.saturation = 5;
      this.stamina = 100;
      this.air = 10;
      this.dead = false;
      this.airMaxY = this.pos.y;
      this.hurtCooldown = 2;
    }

    // --------------------------------------------------------- Soldiers

    toggleFollowers() {
      const g = this.game;
      if (this.followers && this.followers.size) { this.releaseFollowers(false); return; }
      if (!this.faction) { g.ui.hud.toast('Only sworn members of a kingdom can command soldiers.'); return; }
      if (this.rep[this.faction] < 30) { g.ui.hud.toast('You need 30 reputation to command soldiers.'); return; }
      const f = g.kingdoms.factions[this.faction];
      const list = g.entities.queryRadius(this.pos.x, this.pos.z, 22, []).filter(function (n) {
        return n.faction === f && n.isSoldier && !n.isSiege && !n.dead && !(n.squad && n.squad.campaign);
      }).slice(0, 6);
      if (!list.length) { g.ui.hud.toast('No free soldiers of your kingdom nearby.'); return; }
      const sq = new VK.Squad({ faction: f, settlement: f.nearestSettlement(this.pos), type: 'player' });
      f.squads.push(sq);
      list.forEach(function (n) { sq.add(n); n.brain.halt(); });
      sq.setOrder({ type: 'follow', point: null });
      this.followers = sq;
      g.ui.hud.toast(list.length + ' soldiers now follow you. Press G to dismiss them.');
      g.audio.play('horn');
    }

    releaseFollowers(silent) {
      const sq = this.followers;
      if (!sq) return;
      const f = sq.faction;
      sq.members.slice().forEach(function (m) { sq.remove(m); f.leader.assignSquad(m); });
      const i = f.squads.indexOf(sq);
      if (i >= 0) f.squads.splice(i, 1);
      this.followers = null;
      if (!silent) this.game.ui.hud.toast('Your soldiers return to their posts.');
    }

    // ------------------------------------------------------------ Camera

    updateCamera(dt) {
      const g = this.game;
      const cam = g.camera;
      const e = this.eyePos();
      const hs = Math.sqrt(this.vel.x * this.vel.x + this.vel.z * this.vel.z);
      let bobX = 0, bobY = 0;
      if (g.settings.viewBobbing && this.onGround && hs > 0.5 && !this.spectator && this.viewMode === 0) {
        this.bobPhase += hs * dt * 1.9;
        bobY = Math.abs(Math.sin(this.bobPhase)) * 0.06;
        bobX = Math.cos(this.bobPhase) * 0.035;
      }
      const targetFov = g.settings.fov + (this.sprinting ? 8 : 0) - (this.bowCharge > 0 ? Math.min(1, this.bowCharge) * 10 : 0);
      this.fov += (targetFov - this.fov) * Math.min(1, dt * 10);
      if (Math.abs(cam.fov - this.fov) > 0.01) { cam.fov = this.fov; cam.updateProjectionMatrix(); }

      if (this.dead) {
        cam.position.set(e.x, this.pos.y + 0.4, e.z);
        cam.rotation.set(this.pitch, this.yaw, 0.6, 'YXZ');
        this.model.root.visible = false;
        return;
      }
      const d = this.lookDir();
      if (this.viewMode === 0) {
        cam.position.set(e.x + Math.cos(this.yaw) * bobX, e.y + bobY, e.z - Math.sin(this.yaw) * bobX);
        cam.rotation.set(this.pitch, this.yaw, this.hurtTilt, 'YXZ');
      } else {
        const back = this.viewMode === 1 ? -1 : 1;
        const hit = g.world.raycast(e.x, e.y, e.z, d.x * back, d.y * back, d.z * back, 4.5, function (id) { return B.SOLID[id] === 1; });
        const dist = hit ? Math.max(0.5, hit.t - 0.3) : 4.2;
        cam.position.set(e.x + d.x * back * dist, e.y + d.y * back * dist, e.z + d.z * back * dist);
        if (this.viewMode === 1) cam.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
        else cam.rotation.set(-this.pitch, this.yaw + Math.PI, 0, 'YXZ');
      }
      // Third person body
      const m = this.model;
      m.root.visible = this.viewMode !== 0 && !this.spectator;
      if (m.root.visible) {
        m.root.position.copy(this.pos);
        m.root.rotation.y = this.yaw + Math.PI;
        if (this.swingT < 0.05 && !m.action) m.playAction('swing', 0.3);
        m.update(dt, { speed: hs, aiming: this.bowCharge >= 0, carrying: null, combat: this.blocking, headYaw: 0, headPitch: -this.pitch * 0.8 });
      }
      // First person hand
      this.handCam.aspect = cam.aspect;
      this.handCam.fov = 70;
      this.handCam.updateProjectionMatrix();
      const day = g.sky ? g.sky.daylight : 1;
      const light = this.localLight();
      this.handAmbient.intensity = 0.25 + 0.55 * Math.max(day * light.sky, light.block);
      this.handDir.intensity = 0.2 + 0.5 * day * light.sky;
      const hr = this.handRoot;
      const sw = Math.sin(Math.min(1, this.swingT) * Math.PI);
      hr.position.set(0.55 - sw * 0.2, -0.52 - sw * 0.12 + bobY * 0.5, -0.85 - sw * 0.1);
      hr.rotation.set(-sw * 0.9, sw * 0.4, 0);
      if (this.eatT >= 0) { hr.position.set(0.25, -0.35 + Math.sin(this.eatT * 18) * 0.03, -0.6); hr.rotation.set(0.2, 0.6, 0.2); }
      if (this.bowCharge >= 0) { hr.position.set(0.2, -0.35, -0.7 + Math.min(1, this.bowCharge) * 0.15); hr.rotation.set(0, 0.3, 0.2); }
      if (this.blocking) { hr.position.set(0.15, -0.4, -0.65); hr.rotation.set(0, 0.9, 0); }
      if (this.breaking) { hr.position.y += Math.sin(g.elapsed * 30) * 0.02; }
    }

    /** Approximate light at the player (for the first person hand). */
    localLight() {
      const w = this.game.world;
      const x = Math.floor(this.pos.x), y = Math.floor(this.pos.y + 1), z = Math.floor(this.pos.z);
      const c = w.chunks.get(U.chunkKey(x >> 4, z >> 4));
      let sky = 1;
      if (c) {
        const h = c.heightMap[(x & 15) | ((z & 15) << 4)];
        if (y <= h) sky = Math.max(0.1, 1 - (h - y) * 0.13);
      }
      let block = 0;
      if (this.heldStack && this.heldStack.id === 'torch') block = 0.9;
      return { sky: sky, block: block };
    }

    updateOverlays() {
      const b = this.target.block;
      const g = this.game;
      if (b && !this.dead && !g.ui.isOpen()) {
        this.selection.visible = true;
        this.selection.position.set(b.x + 0.5, b.y + 0.5, b.z + 0.5);
      } else this.selection.visible = false;
      if (this.breaking && this.breaking.progress > 0.02) {
        this.crack.visible = true;
        this.crack.position.set(this.breaking.x + 0.5, this.breaking.y + 0.5, this.breaking.z + 0.5);
        this.setCrackStage(Math.min(7, Math.floor(this.breaking.progress * 8)));
      } else this.crack.visible = false;
    }

    // ------------------------------------------------------- Persistence

    serialize() {
      return {
        pos: [this.pos.x, this.pos.y, this.pos.z], yaw: this.yaw, pitch: this.pitch,
        health: this.health, hunger: this.hunger, saturation: this.saturation, stamina: this.stamina,
        inventory: this.inventory.serialize(), selected: this.selected, faction: this.faction,
        rep: this.rep, spawnPoint: this.spawnPoint, fuelPoints: this.fuelPoints, spectator: this.spectator
      };
    }

    deserialize(d) {
      this.pos.set(d.pos[0], d.pos[1], d.pos[2]);
      this.yaw = d.yaw; this.pitch = d.pitch;
      this.health = d.health; this.hunger = d.hunger; this.saturation = d.saturation; this.stamina = d.stamina;
      this.inventory.deserialize(d.inventory);
      this.selected = d.selected || 0;
      this.faction = d.faction || null;
      this.rep = Object.assign({ ironhold: 0, redmoor: 0 }, d.rep);
      this.spawnPoint = d.spawnPoint || null;
      this.fuelPoints = d.fuelPoints || 0;
      this.spectator = !!d.spectator;
      this.airMaxY = this.pos.y;
      if (this.health <= 0) this.health = 1;
    }
  }

  VK.Player = Player;
})(window.VK);
