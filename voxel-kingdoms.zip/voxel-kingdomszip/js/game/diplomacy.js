/**
 * @file diplomacy.js
 * Hostility rules and the player's reputation with each kingdom.
 *
 *   - The two kingdoms are always hostile: members that see each other fight.
 *   - The player is hostile to a kingdom if they swore fealty to its enemy,
 *     if their reputation is at or below -25, or for a while after
 *     attacking one of its people.
 *   - Reputation (-100..100) changes with kills, attacks, vandalism, trade
 *     and service. It sets trade prices and how NPCs treat the player.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;
  const HOSTILE = -25;
  const FRIENDLY = 25;
  const HONORED = 60;

  const Diplomacy = {
    HOSTILE: HOSTILE,
    FRIENDLY: FRIENDLY,
    HONORED: HONORED,
    warnT: 0,

    /** Are these two entities enemies? */
    isHostile(a, b) {
      if (!a || !b || a === b) return false;
      if (a.isPlayer || b.isPlayer) {
        const npc = a.isPlayer ? b : a;
        if (npc.isPlayer) return false;
        return Diplomacy.playerHostileTo(npc.faction.id);
      }
      return a.faction !== b.faction;
    },

    playerHostileTo(fid) {
      const p = VK.game.player;
      if (!p || p.dead || p.spectator) return false;
      if (p.faction === fid) return false;
      if (p.faction) return true;
      if (p.aggro[fid] > VK.game.elapsed) return true;
      return p.rep[fid] <= HOSTILE;
    },

    /** Human readable standing. */
    standing(fid) {
      const p = VK.game.player;
      if (p.faction === fid) return 'Sworn Member';
      if (p.faction && p.faction !== fid) return 'Enemy of the Realm';
      const r = p.rep[fid];
      if (r <= HOSTILE) return 'Hostile';
      if (r < 0) return 'Unfriendly';
      if (r < FRIENDLY) return 'Neutral';
      if (r < HONORED) return 'Friendly';
      return 'Honored';
    },

    /** Price multiplier for trading with a kingdom (lower is better). */
    priceFactor(fid) {
      const p = VK.game.player;
      if (p.faction === fid) return 0.7;
      const r = p.rep[fid];
      if (r >= HONORED) return 0.75;
      if (r >= FRIENDLY) return 0.85;
      if (r < 0) return 1.25;
      return 1;
    },

    changeRep(fid, delta, reason) {
      const p = VK.game.player;
      const before = p.rep[fid];
      p.rep[fid] = U.clamp(before + delta, -100, 100);
      const f = VK.game.kingdoms.factions[fid];
      const g = VK.game;
      if (p.faction === fid && p.rep[fid] <= HOSTILE) {
        // Members who keep harming their own kingdom are banished.
        p.faction = null;
        g.log('You have been banished from the ' + f.name + '!', 'player', 'war');
        g.ui.hud.centerMessage('Banished from ' + f.shortName, 'Its soldiers now hunt you', 4);
        return;
      }
      if (before > HOSTILE && p.rep[fid] <= HOSTILE && !p.faction) {
        g.log('The ' + f.name + ' now considers you an enemy!', 'player', 'war');
        g.ui.hud.centerMessage(f.shortName + ' is now hostile to you', null, 3);
      } else if (before < FRIENDLY && p.rep[fid] >= FRIENDLY) {
        g.log('You are now a friend of the ' + f.name + '.', 'player');
      } else if (before < HONORED && p.rep[fid] >= HONORED) {
        g.log('You are honored by the ' + f.name + '.', 'player');
      }
      if (reason && Math.abs(delta) >= 3) g.ui.hud.toast((delta > 0 ? '+' : '') + Math.round(delta) + ' reputation with ' + f.shortName + ' (' + reason + ')');
    },

    /** The player struck an NPC. */
    onPlayerHitNPC(npc) {
      const p = VK.game.player;
      const fid = npc.faction.id;
      if (Diplomacy.playerHostileTo(fid)) return;
      const g = VK.game;
      p.aggro[fid] = g.elapsed + 30;
      Diplomacy.changeRep(fid, p.faction === fid ? -6 : -4, null);
      if (g.elapsed - Diplomacy.warnT > 4) {
        Diplomacy.warnT = g.elapsed;
        g.ui.hud.centerMessage('You attacked a subject of ' + npc.faction.shortName + '!', 'Its guards will defend them', 2.5);
      }
    },

    /** The player killed an NPC: reputation and bounties. */
    onPlayerKillNPC(npc) {
      const p = VK.game.player;
      const fid = npc.faction.id;
      const enemy = VK.game.kingdoms.enemyOf(npc.faction);
      const value = npc.isVillager ? 1 : (npc.type === 'captain' ? 4 : (npc.isSiege ? 5 : 2));
      if (p.faction === fid) {
        Diplomacy.changeRep(fid, -30, 'treason');
      } else {
        Diplomacy.changeRep(fid, npc.isVillager ? -15 : -8, npc.isVillager ? 'murder' : 'killed a soldier');
        if (!npc.isVillager) Diplomacy.changeRep(enemy.id, 2 + value, 'slew an enemy');
      }
      // Bounty paid by the rival kingdom to its sworn members.
      if (p.faction === enemy.id && !npc.isVillager) {
        const coins = value * 2;
        const left = p.inventory.add('coin', coins);
        if (left < coins) VK.game.ui.hud.toast('Bounty: +' + (coins - left) + ' gold coins');
        VK.game.audio.play('coin');
      }
    },

    /** The player broke a block belonging to a faction building. */
    onPlayerBreakStructure(building) {
      const fid = building.owner.id;
      if (Diplomacy.playerHostileTo(fid)) return;
      Diplomacy.changeRep(fid, -0.6, null);
      const g = VK.game;
      if (g.elapsed - Diplomacy.warnT > 6) {
        Diplomacy.warnT = g.elapsed;
        g.ui.hud.toast('Vandalising ' + building.owner.shortName + ' property harms your reputation');
      }
    },

    onTrade(fid) { Diplomacy.changeRep(fid, 0.6, null); },

    /** Swears the player into a kingdom (possibly betraying the other). */
    joinFaction(fid) {
      const g = VK.game;
      const p = g.player;
      const f = g.kingdoms.factions[fid];
      const other = g.kingdoms.enemyOf(f);
      if (p.faction === other.id) {
        p.rep[other.id] = Math.min(p.rep[other.id], -70);
        g.log('You betrayed the ' + other.name + '!', 'player', 'war');
      }
      p.faction = fid;
      p.rep[fid] = Math.max(p.rep[fid], 50);
      p.rep[other.id] = Math.min(p.rep[other.id], -40);
      p.aggro[fid] = 0;
      const cap = f.capital;
      if (cap) p.spawnPoint = { x: cap.center.x + 0.5, y: g.world.groundY(cap.center.x, cap.center.z + 12), z: cap.center.z + 12.5 };
      g.log('You swore fealty to ' + f.ruler + ' of the ' + f.name + '.', 'player', 'war');
      g.ui.hud.centerMessage('You joined the ' + f.name, f.motto, 4);
      g.audio.play('bell');
      p.inventory.add('coin', 10);
    },

    /** Leaves the current kingdom (reputation suffers a little). */
    leaveFaction() {
      const g = VK.game;
      const p = g.player;
      if (!p.faction) return;
      const f = g.kingdoms.factions[p.faction];
      p.rep[p.faction] = Math.min(p.rep[p.faction], 10);
      g.log('You renounced your oath to the ' + f.name + '.', 'player');
      p.faction = null;
    }
  };

  VK.Diplomacy = Diplomacy;
})(window.VK);
