/**
 * @file game.js
 * The Game object ties every subsystem together: renderer, scene and
 * camera, settings, world creation/loading/saving, the fixed-step
 * simulation (kingdoms, NPCs, projectiles), day/night time, the chronicle
 * (event log), pause handling and the render loop.
 */
(function (VK) {
  'use strict';

  const C = VK.Config;
  const U = VK.Util;

  class Game {
    constructor() {
      VK.game = this;
      this.canvas = document.getElementById('game-canvas');
      this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: false, powerPreference: 'high-performance' });
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
      this.renderer.setSize(window.innerWidth, window.innerHeight);
      this.renderer.info.autoReset = false;
      this.scene = new THREE.Scene();
      this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.08, 200);
      this.camera.rotation.order = 'YXZ';
      this.settings = this.loadSettings();
      this.input = new VK.Input(this.canvas);
      this.audio = new VK.AudioSystem(this);
      this.audio.setVolume(this.settings.volume);
      this.ui = new VK.UI(this);
      this.state = 'menu';
      this.paused = false;
      this.elapsed = 0;
      this.time = { t: 0.05, day: 1 };
      this.logEntries = [];
      this.fps = 60;
      this.last = performance.now();
      this.autosaveT = C.AUTOSAVE_INTERVAL;
      this.errorCount = 0;
      this.world = null;

      window.addEventListener('resize', () => this.onResize());
      this.input.onLockChange = (locked) => this.onLockChange(locked);
      document.addEventListener('pointerlockerror', () => {
        if (this.state === 'playing' && !this.ui.screen && !this.ui.menus.current) this.ui.menus.showClickToPlay('Paused');
      });
      window.addEventListener('beforeunload', () => {
        if (this.state === 'playing') this.save();
      });
      this.loop = this.loop.bind(this);
      requestAnimationFrame(this.loop);
      this.ui.hud.setVisible(false);
      this.ui.menus.showMain();
    }

    // -------------------------------------------------------- Settings

    loadSettings() {
      let s = {};
      try { s = JSON.parse(localStorage.getItem(C.SETTINGS_KEY) || '{}') || {}; } catch (e) { s = {}; }
      return Object.assign({}, VK.DefaultSettings, s);
    }

    saveSettings() {
      try { localStorage.setItem(C.SETTINGS_KEY, JSON.stringify(this.settings)); } catch (e) { /* storage unavailable */ }
    }

    applyRenderDistance(v) {
      if (this.world) this.world.setRenderDistance(v);
      this.camera.far = v * 16 + 64;
      this.camera.updateProjectionMatrix();
    }

    onResize() {
      this.renderer.setSize(window.innerWidth, window.innerHeight);
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
    }

    onLockChange(locked) {
      const menus = this.ui.menus;
      if (locked) {
        if (menus.current === 'click' || menus.current === 'pause') menus.clear();
        this.paused = false;
      } else if (this.state === 'playing' && !this.ui.screen && !menus.current && this.player && !this.player.dead) {
        menus.showPause();
      }
    }

    isNight() { return this.time.t > 0.53 && this.time.t < 0.97; }

    /** Adds an entry to the chronicle and the on-screen log. */
    log(text, cls, kind) {
      const e = { text: text, cls: cls || '', kind: kind || '', day: this.time.day, clock: U.formatClock(this.time.t) };
      this.logEntries.push(e);
      if (this.logEntries.length > 200) this.logEntries.shift();
      if (this.state === 'playing') this.ui.hud.addLog(e);
    }

    // --------------------------------------------------- World lifecycle

    createWorld(seed) {
      this.disposeWorld();
      this.seed = seed >>> 0;
      this.world = new VK.World(this, this.seed);
      this.sky = new VK.Sky(this);
      this.particles = new VK.Particles(this);
      this.banners = new VK.BannerManager(this);
      this.entities = new VK.EntityManager(this);
      this.paths = new VK.Pathfinder.PathService(this.world);
      this.kingdoms = new VK.Kingdoms(this);
      this.player = new VK.Player(this);
      this.world.onBlockChanged = (x, y, z, o, n, c) => this.kingdoms.onBlockChanged(x, y, z, o, n, c);
      this.applyRenderDistance(this.settings.renderDistance);
      this.elapsed = 0;
      this.time = { t: 0.05, day: 1 };
      this.logEntries = [];
      this.autosaveT = C.AUTOSAVE_INTERVAL;
    }

    disposeWorld() {
      if (!this.world) return;
      this.entities.clear();
      this.banners.clear();
      this.world.dispose();
      while (this.scene.children.length) this.scene.remove(this.scene.children[0]);
      this.world = null;
      this.player = null;
      this.kingdoms = null;
      this.entities = null;
    }

    /** A dry, gentle spot between the two kingdoms. */
    findSpawn() {
      const t = this.world.terrain;
      const B = VK.TerrainGenerator.BIOME;
      for (let r = 0; r < 240; r += 4) {
        for (let a = 0; a < 16; a++) {
          const x = Math.round(Math.cos(a / 16 * Math.PI * 2) * r), z = Math.round(Math.sin(a / 16 * Math.PI * 2) * r) + 12;
          const c = t.sample(x, z);
          if (c.h > C.SEA_LEVEL + 1 && c.biome !== B.MOUNTAINS && c.riverT > 0.95) return { x: x + 0.5, z: z + 0.5 };
        }
      }
      return { x: 0.5, z: 0.5 };
    }

    async newWorld(seedStr) {
      const menus = this.ui.menus;
      this.audio.unlock();
      let seed;
      if (!seedStr) seed = (Math.random() * 4294967296) >>> 0;
      else if (/^-?\d+$/.test(seedStr)) seed = Number(seedStr) >>> 0;
      else seed = U.hashString(seedStr);
      this.state = 'loading';
      menus.showLoading('Shaping the land...');
      await U.nextFrame();
      this.createWorld(seed);
      const sites = this.kingdoms.planCapitals(this.world.terrain, seed);
      this.worldSpawn = this.findSpawn();
      const areas = [[this.worldSpawn.x, this.worldSpawn.z, 4], [sites.ironhold.x, sites.ironhold.z, 4], [sites.redmoor.x, sites.redmoor.z, 4]];
      for (let i = 0; i < areas.length; i++) {
        await this.world.pregenerate(areas[i][0], areas[i][1], areas[i][2], function (p) {
          menus.setProgress((i + p) / areas.length * 0.6, 'Generating terrain...');
        });
      }
      menus.setProgress(0.62, 'Raising the castles of Ironhold and Redmoor...');
      await U.nextFrame();
      await this.kingdoms.initNewWorld(function (p) { menus.setProgress(0.62 + p * 0.3, 'Gathering the people of the realm...'); });
      const p = this.player;
      const y = this.world.groundY(Math.floor(this.worldSpawn.x), Math.floor(this.worldSpawn.z));
      p.pos.set(this.worldSpawn.x, y + 0.1, this.worldSpawn.z);
      p.airMaxY = p.pos.y;
      p.yaw = Math.PI / 2;
      p.inventory.add('coin', 5);
      p.inventory.add('bread', 3);
      menus.setProgress(0.96, 'Preparing the view...');
      await U.nextFrame();
      this.world.meshAround(p.pos.x, p.pos.z, 3);
      this.log('Day 1. The kingdoms of Ironhold (west) and Redmoor (east) eye each other across the land.', 'player');
      this.startPlaying('Welcome, traveller');
    }

    async loadWorld() {
      const menus = this.ui.menus;
      this.audio.unlock();
      this.state = 'loading';
      menus.showLoading('Reading the chronicles...');
      await U.nextFrame();
      const data = await VK.Save.read();
      if (!data) {
        this.state = 'menu';
        menus.showMain();
        this.ui.hud.setVisible(false);
        return;
      }
      this.createWorld(data.seed);
      this.world.deserialize(data.world);
      this.kingdoms.applyCapitalSites(data.kingdoms.capitalSites, this.world.terrain);
      this.worldSpawn = data.worldSpawn || this.findSpawn();
      this.time = data.time || { t: 0.05, day: 1 };
      this.elapsed = data.elapsed || 0;
      this.logEntries = data.log || [];
      this.player.deserialize(data.player);
      const areas = [[this.player.pos.x, this.player.pos.z, 4]];
      data.kingdoms.factions.forEach(function (f) { f.settlements.forEach(function (s) { areas.push([s.center.x, s.center.z, 3]); }); });
      for (let i = 0; i < areas.length; i++) {
        await this.world.pregenerate(areas[i][0], areas[i][1], areas[i][2], function (p) {
          menus.setProgress((i + p) / areas.length * 0.8, 'Restoring the land...');
        });
      }
      menus.setProgress(0.85, 'Waking the kingdoms...');
      await U.nextFrame();
      this.kingdoms.deserialize(data.kingdoms);
      this.world.meshAround(this.player.pos.x, this.player.pos.z, 3);
      this.startPlaying('Welcome back');
    }

    startPlaying(title) {
      this.state = 'playing';
      this.paused = false;
      this.ui.hud.setVisible(true);
      this.ui.hud.logEl.innerHTML = '';
      this.ui.hud.logEls = [];
      this.logEntries.slice(-4).forEach((e) => this.ui.hud.addLog(e));
      this.ui.menus.showClickToPlay(title);
    }

    serialize() {
      return {
        version: 1,
        seed: this.seed,
        time: this.time,
        elapsed: this.elapsed,
        worldSpawn: this.worldSpawn,
        world: this.world.serialize(),
        kingdoms: this.kingdoms.serialize(),
        player: this.player.serialize(),
        log: this.logEntries.slice(-80)
      };
    }

    async save() {
      if (this.state !== 'playing' || !this.world) return { ok: false, error: 'no world loaded' };
      const r = await VK.Save.write(this.serialize(), { time: Date.now(), day: this.time.day, seed: this.seed });
      this.log(r.ok ? 'The chronicle has been saved.' : 'Saving failed: ' + r.error, 'player');
      return r;
    }

    quitToTitle() {
      this.ui.close(true);
      this.input.exitLock();
      this.disposeWorld();
      this.state = 'menu';
      this.paused = false;
      this.ui.hud.setVisible(false);
      this.ui.menus.showMain();
    }

    // ------------------------------------------------------------ Loop

    loop(now) {
      requestAnimationFrame(this.loop);
      let dt = (now - this.last) / 1000;
      this.last = now;
      if (dt <= 0) return;
      if (dt > 0.1) dt = 0.1;
      this.fps = this.fps * 0.95 + (1 / dt) * 0.05;
      if (this.state === 'playing' && this.world) {
        try {
          this.frame(dt);
        } catch (err) {
          this.errorCount++;
          if (this.errorCount < 20) console.error(err);
        }
      }
      this.input.endFrame();
    }

    frame(dt) {
      const p = this.player;
      if (!this.paused) {
        p.update(dt);
        let sim = dt * this.settings.worldSpeed;
        while (sim > 1e-6) {
          const s = Math.min(sim, 0.1);
          this.simulate(s);
          sim -= s;
        }
        this.paths.process(this.settings.worldSpeed > 1 ? 6 : 4);
        this.autosaveT -= dt;
        if (this.autosaveT <= 0) { this.autosaveT = C.AUTOSAVE_INTERVAL; this.save(); }
      }
      const cam = this.camera.position;
      this.world.update(dt, cam.x, cam.z);
      this.sky.update(dt, this.time.t, this.camera, p.eyeInWater && p.viewMode === 0 && !p.dead);
      this.particles.update(dt, this.camera, this.renderer);
      this.banners.update(dt, cam);
      this.ui.update(dt);
      this.render();
    }

    simulate(dt) {
      this.elapsed += dt;
      this.time.t += dt / C.DAY_LENGTH;
      if (this.time.t >= 1) {
        this.time.t -= 1;
        this.time.day++;
        this.log('Dawn breaks on day ' + this.time.day + '.', '');
      }
      this.kingdoms.update(dt);
      this.entities.update(dt);
    }

    render() {
      const r = this.renderer;
      r.info.reset();
      r.render(this.scene, this.camera);
      const p = this.player;
      if (p && p.viewMode === 0 && !p.dead && !p.spectator && !this.ui.hud.hidden) {
        r.autoClear = false;
        r.clearDepth();
        r.render(p.handScene, p.handCam);
        r.autoClear = true;
      }
    }
  }

  VK.Game = Game;
})(window.VK);
