/**
 * @file save.js
 * Saving and loading with localStorage. The world state is serialised to
 * JSON, gzip-compressed with the browser's CompressionStream (when
 * available) and stored as base64. A small metadata record is kept
 * separately so the title screen can describe the save without loading it.
 */
(function (VK) {
  'use strict';

  const KEY = VK.Config.SAVE_KEY;
  const META = KEY + '.meta';

  function toBase64(buf) {
    const bytes = new Uint8Array(buf);
    let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) {
      s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    }
    return btoa(s);
  }

  function fromBase64(str) {
    const bin = atob(str);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  async function gzip(text) {
    const stream = new Blob([text]).stream().pipeThrough(new CompressionStream('gzip'));
    return new Response(stream).arrayBuffer();
  }

  async function gunzip(bytes) {
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
    return new Response(stream).text();
  }

  const Save = {
    /** Metadata of the stored save or null. */
    meta() {
      try {
        const m = localStorage.getItem(META);
        return m && localStorage.getItem(KEY) ? JSON.parse(m) : null;
      } catch (e) {
        return null;
      }
    },

    /**
     * Writes a save.
     * @returns {Promise<{ok: boolean, size?: number, error?: string}>}
     */
    async write(data, meta) {
      try {
        const json = JSON.stringify(data);
        let payload;
        if (window.CompressionStream) payload = 'gz:' + toBase64(await gzip(json));
        else payload = 'js:' + json;
        localStorage.setItem(KEY, payload);
        localStorage.setItem(META, JSON.stringify(meta));
        return { ok: true, size: payload.length };
      } catch (e) {
        const quota = e && (e.name === 'QuotaExceededError' || e.code === 22);
        return { ok: false, error: quota ? 'browser storage is full' : String(e && e.message ? e.message : e) };
      }
    },

    /** Reads and decodes the save (or null). */
    async read() {
      let payload;
      try { payload = localStorage.getItem(KEY); } catch (e) { return null; }
      if (!payload) return null;
      try {
        if (payload.startsWith('gz:')) return JSON.parse(await gunzip(fromBase64(payload.slice(3))));
        if (payload.startsWith('js:')) return JSON.parse(payload.slice(3));
        return JSON.parse(payload);
      } catch (e) {
        console.error('Save data is corrupt', e);
        return null;
      }
    },

    clear() {
      try { localStorage.removeItem(KEY); localStorage.removeItem(META); } catch (e) { /* storage unavailable */ }
    }
  };

  VK.Save = Save;
})(window.VK);
