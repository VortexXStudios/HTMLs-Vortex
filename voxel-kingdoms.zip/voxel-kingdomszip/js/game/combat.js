/**
 * @file combat.js
 * Damage resolution shared by NPCs, towers, siege engines and the player:
 * shields (frontal blocks), armour, knockback, hit effects, deaths, loot,
 * plus the helpers that fire arrows, bolts and boulders with ballistic aim.
 */
(function (VK) {
  'use strict';

  const U = VK.Util;

  function gauss() { return (Math.random() + Math.random() + Math.random() - 1.5) / 1.5; }

  const Combat = {
    /**
     * Applies damage to an NPC or the player.
     * @param {string} kind melee | arrow | blast | starve | fall
     */
    applyDamage(target, amount, attacker, kind) {
      if (!target || target.dead || amount <= 0) return 0;
      if (target.isPlayer) return target.hurt(amount, attacker, kind);
      const g = VK.game;
      const st = target.stats;
      let dmg = amount;
      let blocked = false;
      if (st.shield && attacker && attacker.pos && (kind === 'melee' || kind === 'arrow')) {
        const dx = attacker.pos.x - target.pos.x, dz = attacker.pos.z - target.pos.z;
        const d = Math.sqrt(dx * dx + dz * dz) || 1;
        const facing = (dx * Math.sin(target.yaw) + dz * Math.cos(target.yaw)) / d;
        if (facing > 0.35 && Math.random() < 0.65) { dmg *= 1 - st.shield; blocked = true; }
      }
      dmg *= 1 - (st.armor || 0);
      target.hp -= dmg;
      target.model.flashHurt();
      if (kind !== 'starve') {
        g.particles.hit(target.pos.x, target.pos.y + target.h * 0.6, target.pos.z, blocked);
        g.audio.play(blocked ? 'clang' : 'hit', target.pos);
      }
      if (attacker && attacker.pos && kind !== 'starve' && !target.isSiege) {
        const dx = target.pos.x - attacker.pos.x, dz = target.pos.z - attacker.pos.z;
        const d = Math.sqrt(dx * dx + dz * dz) || 1;
        const k = kind === 'blast' ? 7 : (blocked ? 1.5 : 3.5);
        target.vel.x += dx / d * k;
        target.vel.z += dz / d * k;
        if (target.onGround) target.vel.y = Math.max(target.vel.y, kind === 'blast' ? 6 : 3);
      }
      if (attacker && attacker.isPlayer) VK.Diplomacy.onPlayerHitNPC(target);
      target.onDamaged(attacker);
      if (target.hp <= 0) {
        target.die(attacker);
        Combat.onKill(target, attacker);
      }
      return dmg;
    },

    /** Melee strike by an NPC. */
    melee(attacker, target) {
      const m = attacker.stats.melee;
      attacker.model.playAction(attacker.type === 'spearman' ? 'thrust' : 'swing', 0.45);
      VK.game.audio.play('swing', attacker.pos);
      Combat.applyDamage(target, m.damage * U.rand(0.85, 1.15), attacker, 'melee');
    },

    /** Launches a projectile from `from` toward an entity with lead and spread. */
    fireAt(from, target, speed, type, damage, spread, owner, factionId) {
      const g = VK.game;
      const tp = {
        x: target.pos.x,
        y: target.pos.y + (target.isPlayer ? 1.1 : (target.isSiege ? 1.6 : 1.0)),
        z: target.pos.z
      };
      const dist = Math.sqrt(Math.pow(tp.x - from.x, 2) + Math.pow(tp.z - from.z, 2));
      const t = dist / speed;
      if (target.vel) { tp.x += target.vel.x * t * 0.8; tp.z += target.vel.z * t * 0.8; }
      const grav = VK.ProjectileSystem.TYPES[type].gravity;
      let v = VK.ProjectileSystem.aim(from, tp, speed, grav, false);
      if (!v) {
        const dx = tp.x - from.x, dz = tp.z - from.z;
        const d = Math.sqrt(dx * dx + dz * dz) || 1;
        v = new THREE.Vector3(dx / d * speed * 0.707, speed * 0.707, dz / d * speed * 0.707);
      }
      const sp = spread * (1 + dist / 30) * (g.isNight() ? 1.6 : 1) * speed;
      v.x += gauss() * sp; v.y += gauss() * sp * 0.6; v.z += gauss() * sp;
      g.entities.projectiles.spawn(type, from.x, from.y, from.z, v.x, v.y, v.z, { owner: owner, factionId: factionId, damage: damage });
    },

    /** Archer / crossbowman shot. */
    shoot(shooter, target, r) {
      const from = { x: shooter.pos.x + Math.sin(shooter.yaw) * 0.5, y: shooter.pos.y + 1.45, z: shooter.pos.z + Math.cos(shooter.yaw) * 0.5 };
      Combat.fireAt(from, target, r.speed, r.projectile, r.damage, r.spread, shooter, shooter.faction.id);
      shooter.model.playAction('shoot', 0.4);
      VK.game.audio.play('bow', shooter.pos);
    },

    /** Arrow fired from a tower, keep or gatehouse. */
    towerShoot(p, target, faction) {
      Combat.fireAt(p, target, 36, 'arrow', 4, 0.035, null, faction.id);
      VK.game.audio.play('bow', p);
    },

    /** Trebuchet throw at a block position. */
    launchBoulder(npc, tp, s) {
      const from = { x: npc.pos.x + Math.sin(npc.yaw) * 1.5, y: npc.pos.y + 4.5, z: npc.pos.z + Math.cos(npc.yaw) * 1.5 };
      const to = { x: tp.x + 0.5 + U.rand(-1, 1), y: tp.y + 0.5, z: tp.z + 0.5 + U.rand(-1, 1) };
      const v = VK.ProjectileSystem.aim(from, to, s.speed, VK.ProjectileSystem.TYPES.boulder.gravity, true);
      if (!v) return false;
      VK.game.entities.projectiles.spawn('boulder', from.x, from.y, from.z, v.x, v.y, v.z, {
        owner: npc, factionId: npc.faction.id, damage: s.damage, blast: s.blast, power: s.power
      });
      npc.model.playAction('shoot');
      VK.game.audio.play('catapult', npc.pos);
      return true;
    },

    projectileHit(p, target) {
      Combat.applyDamage(target, p.damage, p.owner, 'arrow');
    },

    /** Loot and bookkeeping when an NPC dies. */
    onKill(victim, killer) {
      const g = VK.game;
      if (killer && !killer.isPlayer && killer.kills !== undefined) killer.kills++;
      if (killer && killer.isPlayer) VK.Diplomacy.onPlayerKillNPC(victim);
      // Only drop loot where the player can collect it.
      const p = g.player;
      if (!p || U.dist2(p.pos.x, p.pos.z, victim.pos.x, victim.pos.z) > 48) return;
      const drops = [];
      const x = victim.pos.x, y = victim.pos.y + 0.8, z = victim.pos.z;
      if (victim.isVillager) {
        const c = victim.carry;
        if (c.amount) {
          const map = { wood: 'oak_log', stone: 'cobblestone', food: 'bread', iron: 'iron_ingot', gold: 'gold_ingot' };
          drops.push([map[c.type], Math.max(1, Math.min(8, Math.floor(c.amount / 2)))]);
        }
        if (Math.random() < 0.4) drops.push(['bread', 1]);
        if (Math.random() < 0.5) drops.push(['coin', U.randInt(1, 2)]);
      } else if (victim.isSiege) {
        drops.push(['planks', U.randInt(6, 12)], ['iron_ingot', U.randInt(1, 3)]);
      } else {
        if (victim.type === 'archer') drops.push(['arrow', U.randInt(2, 6)]);
        if (victim.type === 'crossbowman' && Math.random() < 0.5) drops.push(['iron_ingot', 1]);
        if (Math.random() < 0.25) drops.push(['iron_ingot', 1]);
        if (Math.random() < 0.35) drops.push(['bread', 1]);
        if (Math.random() < 0.12) drops.push([victim.type === 'spearman' ? 'spear' : (victim.stats.shield ? 'shield' : 'bow'), 1]);
        if (victim.type === 'captain') drops.push(['gold_ingot', U.randInt(1, 2)], ['iron_sword', 1]);
        if (Math.random() < 0.6) drops.push(['coin', U.randInt(1, 3)]);
      }
      drops.forEach(function (d) {
        const st = VK.Items.stack(d[0], d[1]);
        if (st.dur) st.dur = Math.floor(st.dur * U.rand(0.3, 0.8));
        g.entities.drops.spawn(st, x, y, z);
      });
    }
  };

  VK.Combat = Combat;
})(window.VK);
