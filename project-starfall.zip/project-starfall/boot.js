// Classic (non-module) boot guard. Runs before anything else so a browser that can't start the
// game shows a reason instead of a black screen.
(function () {
  var errs = [];
  window.__bootErrors = errs;
  window.addEventListener('error', function (e) {
    var t = e.target;
    if (t && t !== window && (t.src || t.href)) { if (/fonts\.(googleapis|gstatic)/.test(t.src || t.href)) return; errs.push('Could not load ' + String(t.src || t.href).split('/').slice(-2).join('/')); }
    else if (e.message) errs.push(e.message + (e.filename ? ' (' + e.filename.split('/').pop() + ':' + e.lineno + ')' : ''));
  }, true);
  window.addEventListener('unhandledrejection', function (e) { var r = e.reason; errs.push(String(r && r.message || r)); });

  var info = { gl2: false, gl1: false, importmap: false, chrome: 0 };
  try { var c = document.createElement('canvas'); info.gl2 = !!c.getContext('webgl2'); if (!info.gl2) info.gl1 = !!(c.getContext('webgl') || c.getContext('experimental-webgl')); } catch (e) { /* */ }
  info.importmap = !!(window.HTMLScriptElement && HTMLScriptElement.supports && HTMLScriptElement.supports('importmap'));
  var m = navigator.userAgent.match(/Chrom(?:e|ium)\/(\d+)/); if (m) info.chrome = +m[1];
  window.__bootInfo = info;
  // Browsers older than Chrome 89 / Safari 16.4 lack import maps: load the polyfill
  if (!info.importmap && document.querySelector('script[type=importmap]')) {
    var s = document.createElement('script'); s.async = true;
    s.src = 'https://cdn.jsdelivr.net/npm/es-module-shims@1.10.0/dist/es-module-shims.js';
    document.head.appendChild(s);
  }

  function show(reasonHtml) {
    if (window.__starfall && window.__starfall.ui) return;
    var b = document.getElementById('boot'); if (!b) return;
    b.className = 'failed';
    var d = b.querySelector('.boot-diag');
    var lines = [];
    lines.push('<b>Project Starfall could not start.</b>');
    if (reasonHtml) lines.push(reasonHtml);
    if (!info.gl2) lines.push(info.gl1
      ? 'This browser has WebGL 1 but not WebGL 2, which the game needs. On a Chromebook, open <code>chrome://settings/system</code> and turn on <i>Use graphics acceleration when available</i>, then restart Chrome. Some older or school-managed Chromebooks block WebGL 2.'
      : 'WebGL is turned off or blocked in this browser. On a Chromebook, open <code>chrome://settings/system</code> and turn on <i>Use graphics acceleration when available</i>, then restart Chrome. On a school or work device an administrator may have disabled it.');
    if (info.chrome && info.chrome < 89) lines.push('This is Chrome ' + info.chrome + '. The game needs Chrome 89 or newer. If this Chromebook no longer gets updates, try another device.');
    if (errs.length) lines.push('Details: <code>' + errs.slice(0, 4).map(function (x) { return String(x).replace(/[<>&]/g, ''); }).join('<br>') + '</code>');
    lines.push('Browser: <code>' + navigator.userAgent.replace(/[<>&]/g, '') + '</code><br>WebGL 2: ' + (info.gl2 ? 'yes' : 'no') + ' · import maps: ' + (info.importmap ? 'yes' : 'polyfilled'));
    lines.push('<button onclick="location.reload()">Try again</button>');
    d.innerHTML = lines.join('<p>');
  }
  window.__bootFail = show;
  if (!info.gl2) window.addEventListener('DOMContentLoaded', function () { show(''); });
  // a working boot replaces #boot within a couple of seconds; after 12 s explain what went wrong
  setTimeout(function () { show(errs.length ? '' : 'The game files loaded too slowly or were blocked. Check your connection and any content blockers, then try again.'); }, 12000);
})();
