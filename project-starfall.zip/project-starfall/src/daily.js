// ============================================================================
// Daily login rewards, streaks, daily mission & daily challenge scheduling.
// Uses LOCAL calendar days (not 24h windows). Pure functions — testable.
// ============================================================================
import { DAILY_REWARDS, COSMETICS } from './data.js';

const DAY_MS = 86400000;
export const CLOCK_TOLERANCE_MS = 12 * 3600 * 1000; // allow small clock / timezone drift

// Calendar-day index in the player's local timezone.
export function dayIndex(date) {
  const d = date instanceof Date ? date : new Date(date);
  return Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / DAY_MS);
}
export function dayToDate(idx) { // returns a Date at local noon for that day index
  const u = new Date(idx * DAY_MS);
  return new Date(u.getUTCFullYear(), u.getUTCMonth(), u.getUTCDate(), 12);
}
export function msUntilNextDay(now) {
  const d = new Date(now);
  const next = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1, 0, 0, 0, 0);
  return next.getTime() - d.getTime();
}
export function formatDuration(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}

// Next streak value if the player claims today.
export function nextStreak(lastClaimDay, streak, today) {
  if (lastClaimDay == null) return 1;
  const gap = today - lastClaimDay;
  if (gap <= 0) return streak;              // already claimed (or clock moved back)
  if (gap === 1) return streak + 1;          // consecutive
  if (gap === 2) return streak + 1;          // catch-up grace: one missed day is forgiven
  return Math.max(1, Math.floor(streak / 2) + 1); // longer absence halves the streak, never wipes it
}

export function rewardForStreak(streak, ownedCosmetics = []) {
  const idx = (Math.max(1, streak) - 1) % DAILY_REWARDS.length;
  const cycle = Math.floor((Math.max(1, streak) - 1) / DAILY_REWARDS.length);
  const mult = 1 + 0.15 * Math.min(cycle, 4);
  const base = DAILY_REWARDS[idx];
  const r = {};
  for (const k of ['credits', 'alloy', 'cores']) if (base[k]) r[k] = Math.round(base[k] * (k === 'cores' ? 1 : mult));
  if (base.boost) r.boost = base.boost;
  if (base.cosmeticPool) {
    const avail = base.cosmeticPool.filter(c => COSMETICS[c] && !ownedCosmetics.includes(c));
    if (avail.length) r.cosmetic = avail[(streak * 7) % avail.length];
    else r.cores = (r.cores || 0) + 2;
  }
  r.day = idx + 1;
  r.cycle = cycle + 1;
  return r;
}

// Inspect clock state without mutating.
export function clockCheck(daily, now) {
  const today = dayIndex(now);
  const movedBack = (typeof daily.lastSeen === 'number' && now < daily.lastSeen - CLOCK_TOLERANCE_MS)
    || (Number.isInteger(daily.highestDaySeen) && today < daily.highestDaySeen);
  return { today, movedBack };
}

export function getDailyStatus(save, now = Date.now()) {
  const d = save.daily;
  const { today, movedBack } = clockCheck(d, now);
  const claimedToday = d.lastClaimDay != null && d.lastClaimDay >= today;
  const canClaim = !claimedToday && !movedBack;
  const streakIfClaimed = nextStreak(d.lastClaimDay, d.streak, today);
  const preview = rewardForStreak(canClaim ? streakIfClaimed : d.streak + 1, save.cosmetics.owned);
  const missed = d.lastClaimDay != null ? Math.max(0, today - d.lastClaimDay - 1) : 0;
  return {
    today, canClaim, claimedToday, movedBack, missed,
    streak: d.streak, streakIfClaimed, preview,
    nextInMs: msUntilNextDay(now),
    graceUsed: missed === 1,
    upcoming: Array.from({ length: 7 }, (_, i) => rewardForStreak((canClaim ? streakIfClaimed : d.streak + 1) + i, save.cosmetics.owned)),
  };
}

// Mutates save; returns reward object or null if not allowed.
export function claimDaily(save, now = Date.now()) {
  const st = getDailyStatus(save, now);
  if (!st.canClaim) return null;
  const d = save.daily;
  d.streak = st.streakIfClaimed;
  d.bestStreak = Math.max(d.bestStreak || 0, d.streak);
  d.lastClaimDay = st.today;
  touchClock(save, now);
  return rewardForStreak(d.streak, save.cosmetics.owned);
}

// Record "last seen" time. Never moves backwards.
export function touchClock(save, now = Date.now()) {
  const d = save.daily;
  const { today, movedBack } = clockCheck(d, now);
  d.clockWarning = movedBack;
  if (!movedBack) {
    d.lastSeen = Math.max(d.lastSeen || 0, now);
    d.highestDaySeen = Math.max(Number.isInteger(d.highestDaySeen) ? d.highestDaySeen : today, today);
  }
  return movedBack;
}

export function dailySeeds(today) {
  return {
    mission: `daily-mission-${today}`,
    challenge: `daily-challenge-${today}`,
    contracts: `contracts-${today}`,
  };
}
