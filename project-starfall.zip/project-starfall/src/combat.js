// ============================================================================
// Combat feel: difficulty tuning and the engagement director.
//
// The engagement director hands out a small number of "attack tokens". Only
// fighters holding a token press an attack run on the player; the rest hold
// stations spread across the player's forward view and take long-range shots.
// Tokens rotate, and a fighter that lingers behind the player loses its token
// and swings back to the front. This keeps fights readable: most enemies are
// where you can see and shoot them, and only a few are ever on your tail.
// ============================================================================
import * as THREE from 'three';

export const DIFFICULTY = {
  relaxed: {
    name: 'Relaxed', desc: 'Generous aim assist, fewer attackers at once, enemies stay in front of you.',
    assistDeg: 16, touchAssistDeg: 20, magnet: 1.15, hitPad: 3.5, dmg: 1.25, enemyDmg: 0.75,
    maxAttackers: 2, tokenTime: 5, behindMax: 1.4, turn: 0.72, accel: 0.8, jink: 0.35, breakDist: 190, holdFire: 0.22, cameraLean: 0.3,
  },
  standard: {
    name: 'Standard', desc: 'Assisted aiming and a few attackers at a time. The intended experience.',
    assistDeg: 12, touchAssistDeg: 16, magnet: 0.65, hitPad: 2.2, dmg: 1.12, enemyDmg: 0.9,
    maxAttackers: 3, tokenTime: 4, behindMax: 2.4, turn: 0.85, accel: 0.9, jink: 0.6, breakDist: 150, holdFire: 0.32, cameraLean: 0.22,
  },
  ace: {
    name: 'Ace', desc: 'Pinpoint aim assist, every enemy hunts you at once. The original tuning.',
    assistDeg: 6, touchAssistDeg: 9, magnet: 0, hitPad: 0.5, dmg: 1, enemyDmg: 1,
    maxAttackers: Infinity, tokenTime: 3, behindMax: Infinity, turn: 1, accel: 1, jink: 1, breakDist: 90, holdFire: 0.5, cameraLean: 0.12,
  },
};

export const isTouchUI = () => typeof document !== 'undefined' && document.body?.classList.contains('touch');

export function resolveDifficulty(settings) {
  const d = settings?.difficulty;
  if (d && DIFFICULTY[d]) return d;
  return isTouchUI() ? 'relaxed' : 'standard';
}

export function tuning(settings) {
  const id = resolveDifficulty(settings);
  const t = { id, ...DIFFICULTY[id] };
  const deg = isTouchUI() ? t.touchAssistDeg : t.assistDeg;
  t.assistCos = Math.cos(deg * Math.PI / 180);
  t.magnetCos = Math.cos(Math.min(40, deg * 2.2) * Math.PI / 180);
  return t;
}

// behaviours that fly attack runs at the player and therefore take part in token rotation
const FIGHTERS = new Set(['flank', 'swarm', 'stealth', 'ace']);
const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3();

export function isFighter(u) {
  return u.alive && u.team === 'enemy' && FIGHTERS.has(u.behavior) && !u.structure && !u.boss && !u.part && !(u.formation && !u.formation.broken);
}

export function updateEngagement(g, dt) {
  const P = g.player, T = g.tune;
  const fighters = [];
  for (const u of g.units) {
    if (!isFighter(u)) { u.engaged = true; continue; }
    const ai = u.ai;
    ai.tokenCd = Math.max(0, (ai.tokenCd || 0) - dt);
    if (!P.alive || (u.target && u.target !== P)) { u.engaged = true; continue; } // busy with allies or objectives
    tmp.copy(u.pos).sub(P.pos);
    const d = tmp.length();
    const dot = d > 0 ? tmp.dot(P.forward) / d : 1;
    ai.pDot = dot; ai.pDist = d;
    ai.behindT = dot < -0.15 && d < 650 ? (ai.behindT || 0) + dt : Math.max(0, (ai.behindT || 0) - dt * 2);
    fighters.push(u);
  }
  if (T.maxAttackers === Infinity) { for (const u of fighters) u.engaged = true; return; }
  let holders = 0;
  for (const u of fighters) {
    const ai = u.ai;
    if (!u.engaged) continue;
    ai.tokenT = (ai.tokenT || 0) + dt;
    // give the token back after a while, or when lingering on the player's tail
    if (ai.tokenT > T.tokenTime + (u.named ? 3 : 0) || ai.behindT > T.behindMax) { u.engaged = false; ai.tokenCd = 2 + Math.random() * 2; ai.behindT = 0; ai.state = 'hold'; }
    else holders++;
  }
  if (holders >= T.maxAttackers) {
    // too many (e.g. a new wave arrived engaged): demote the ones furthest out of view
    if (holders > T.maxAttackers) {
      const eng = fighters.filter(u => u.engaged).sort((a, b) => a.ai.pDot - b.ai.pDot);
      for (let i = 0; i < holders - T.maxAttackers; i++) { eng[i].engaged = false; eng[i].ai.state = 'hold'; eng[i].ai.tokenCd = 1; }
    }
    return;
  }
  // hand out free tokens: prefer named aces, then fighters in view and close
  const cands = fighters.filter(u => !u.engaged && !(u.ai.tokenCd > 0) && u.ai.behindT < 0.2);
  cands.sort((a, b) => score(b) - score(a));
  for (let i = 0; i < cands.length && holders < T.maxAttackers; i++) {
    const u = cands[i];
    u.engaged = true; u.ai.tokenT = 0; holders++;
    if (u.behavior === 'flank' || u.behavior === 'ace') u.ai.state = 'flank';
    if (u.behavior === 'stealth') { u.ai.state = 'cloaked'; u.ai.timer = 2 + Math.random() * 2; }
    if (u.behavior === 'swarm') u.ai.state = 'attack';
  }
}
function score(u) { return u.ai.pDot * 1.2 - u.ai.pDist / 900 + (u.named ? 3 : 0) + (u.elite ? 0.4 : 0); }

// Fighters without a token: hold a station in the player's forward view and take the occasional long shot
export function holdStation(u, g, dt, fire) {
  const P = g.player, ai = u.ai, T = g.tune;
  const right = tmp2.copy(P.right);
  const lat = Math.sin(ai.phase) * 230 + Math.sin(ai.t * 0.35 + ai.phase) * 60;
  const vert = Math.cos(ai.phase * 1.7) * 110 + Math.cos(ai.t * 0.3) * 30;
  const dist = 360 + ((u.id * 53) % 160);
  const station = tmp.copy(P.forward).multiplyScalar(dist).add(P.pos).addScaledVector(right, lat).addScaledVector(P.up, vert);
  const to = station.sub(u.pos); const d = to.length();
  const far = d > 220;
  const want = to.multiplyScalar(Math.min(far ? 1.45 : 1.15, d / 120) * u.speed / Math.max(1, d)).addScaledVector(P.vel, 0.85);
  // don't plough through the player while swinging round to the front
  tmp2.copy(u.pos).sub(P.pos); const pd = tmp2.length();
  if (pd < 140) want.addScaledVector(tmp2.normalize(), (140 - pd) * 2.5);
  // repositioning uses the craft's full agility (difficulty only softens how they attack, not how they get back in view)
  const ta = u.turn, aa = u.accel;
  if (far) { u.turn = u.baseTurn * 1.25; u.accel = u.baseAccel * 1.4; }
  u.steer(want, dt, d < 160 ? tmp2.copy(P.pos).sub(u.pos) : null);
  u.turn = ta; u.accel = aa;
  // long-range harassment, much slower than an attack run
  if (fire && u.def.weapon && d < 220) {
    u.weaponCd -= dt * T.holdFire;
    if (u.weaponCd <= 0 && pd < 750 && u.inFront(P.pos, 0.97)) { u.weaponCd = (1 / (u.def.weapon.rate * u.rateMult)) * (1.6 + Math.random()); u.fire(P, { spread: 0.06 }); }
  }
}

// A point beside and ahead of the player: where attack runs start and where breaks head back to
export function frontFlankPoint(g, side, ahead = 260, out = new THREE.Vector3()) {
  const P = g.player;
  return out.copy(P.forward).multiplyScalar(ahead).add(P.pos).addScaledVector(P.right, side * 190).addScaledVector(P.up, 40 * Math.sin(side * 3.1));
}
