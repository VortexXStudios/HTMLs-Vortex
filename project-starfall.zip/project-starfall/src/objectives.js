// ============================================================================
// Mission objectives. Each objective sets up its own set-pieces, drives its
// own encounter pacing, reports status for the HUD and decides win/lose.
// ============================================================================
import * as THREE from 'three';
import { RNG } from './rng.js';
import { composeWave, endlessWaveSpec } from './missions.js';
import { ENDLESS_PERKS, MODIFIERS, ACE_NAMES, BOSSES } from './data.js';
import { createBoss } from './bosses.js';
import { buildUnit } from './models.js';
import { ALLIES, EFFECTS, BARKS, fillCallsign } from './story.js';
import { ARENA_RADIUS } from './environment.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);

class Objective {
  constructor(game, mission) {
    this.g = game; this.m = mission; this.t = 0; this.result = null; this.failReason = ''; this.branch = {};
    this.rng = new RNG('obj-' + mission.seed);
    this.ambient = true; // director ambient waves
    this.ambientScale = 1;
    this.protect = []; // ally units enemies prefer to attack
    this.startPos = V(0, 10, -380); this.startLook = V(0, 0, 0);
    this.lastFormation = null;
  }
  setup() {}
  update(dt) { this.t += dt; }
  status() { return { title: '', lines: [] }; }
  onKill(u) {}
  onAllyLost(u) {}
  onRetreat(u, reason) {}
  anchor() { // where ambient enemies come from
    const P = this.g.player;
    const a = this.rng.range(0, Math.PI * 2);
    return V(Math.cos(a) * 850, this.rng.range(-150, 150), Math.sin(a) * 850).add(P.pos.clone().multiplyScalar(0.3));
  }
  win(text = 'MISSION COMPLETE') { if (!this.result) { this.result = 'victory'; this.g.hud.banner(text, '', 2.5); } }
  fail(reason) { if (!this.result) { this.result = 'defeat'; this.failReason = reason; } }
  spawnWave(spec, anchor, target, opts = {}) { return this.g.director.spawnWave(spec, anchor, target, opts); }
  compose(wave, budgetScale = 1, faction = null) {
    const spec = composeWave(this.rng, { wave, difficulty: this.m.difficulty, faction: faction || this.m.faction, altFaction: this.m.altFaction, lastFormation: this.lastFormation, budgetScale });
    this.lastFormation = spec.formation;
    return spec;
  }
  alive(list) { return list.filter(u => u.alive); }
  hpLine(u, label) { return { text: `${label}: ${Math.max(0, Math.round(u.hp / u.maxHp * 100))}%`, progress: Math.max(0, u.hp / u.maxHp), danger: u.hp / u.maxHp < 0.35 }; }
}

// ---------------------------------------------------------------------------
export class InterceptObjective extends Objective {
  setup() {
    const g = this.g;
    this.station = g.spawnUnit('station', { pos: V(0, -20, -260), marker: 'PROTECT', objective: true });
    this.protect = [this.station];
    this.startPos = V(0, 10, -140); this.startLook = V(0, 0, 400);
    this.ambient = false; this.wave = 0; this.waves = 3; this.waveUnits = []; this.nextT = 4;
  }
  update(dt) {
    super.update(dt);
    const g = this.g;
    if (!this.station.alive) { this.fail('The refinery was destroyed.'); return; }
    this.waveUnits = this.alive(this.waveUnits);
    if (this.wave > 0 && this.waveUnits.length === 0 && this.nextT <= 0) {
      if (this.wave >= this.waves) { this.branch.stationHp = this.station.hp / this.station.maxHp; this.win('INVASION REPELLED'); return; }
      this.nextT = 6; g.hud.toast(`WAVE ${this.wave} DESTROYED — NEXT FLEET INBOUND`, 'good', 2);
    }
    if (this.nextT > 0) {
      this.nextT -= dt;
      if (this.nextT <= 0 && (this.wave === 0 || this.waveUnits.length === 0)) {
        this.wave++;
        const spec = this.compose(this.wave + 1, 1.15);
        spec.groups[0].formation = this.wave === 1 ? 'grid' : spec.groups[0].formation;
        if (!spec.groups.some(x => x.type === 'bomber')) spec.groups.push({ type: 'bomber', count: this.wave, formation: 'loose', faction: this.m.faction });
        const dir = this.rng.range(-0.6, 0.6);
        const anchor = V(Math.sin(dir) * 950, this.rng.range(-60, 120), Math.cos(dir) * 950);
        this.waveUnits = this.spawnWave(spec, anchor, this.station, { formationTarget: this.station });
        g.hud.banner(`INVASION WAVE ${this.wave}/${this.waves}`, 'Intercept before they reach the refinery', 2);
        g.audio.play('wave');
      }
    }
  }
  status() { return { title: 'Intercept the invasion fleet', lines: [this.hpLine(this.station, 'Refinery'), { text: `Wave ${Math.max(1, this.wave)}/${this.waves} — hostiles: ${this.waveUnits.length}` }] }; }
}

// ---------------------------------------------------------------------------
export class EscortObjective extends Objective {
  setup() {
    const g = this.g;
    this.ship = g.spawnUnit('battleship', { pos: V(0, 0, 0), marker: 'PROTECT', objective: true });
    this.ship.mesh.lookAt(V(1000, 0, 0));
    this.protect = [this.ship];
    this.repair = 0; this.stage = 'repair'; this.jumpT = 15;
    this.startPos = V(-60, 40, -220); this.startLook = V(0, 0, 0);
    this.ambientScale = 1.1;
  }
  update(dt) {
    super.update(dt);
    const g = this.g, s = this.ship;
    if (!s.alive) { this.fail('The Resolute was destroyed.'); return; }
    if (this.stage === 'repair') {
      const rate = s.shield > 0 ? 1 : 0.45;
      this.repair = Math.min(100, this.repair + dt * 100 / 100 * rate);
      if (s.shield <= 0 && Math.random() < dt) g.hud.toast('RESOLUTE SHIELDS DOWN — REPAIRS SLOWED', 'warn', 1.5);
      if (this.repair >= 100) { this.stage = 'jump'; g.hud.banner('ENGINES ONLINE', 'Resolute is spooling its jump drive — hold the line!', 2.5); s.ai.moveTo = V(700, 0, 0); s.ai.speed = 25; }
    } else if (this.stage === 'jump') {
      this.jumpT -= dt;
      if (this.jumpT <= 0) {
        g.effects.flash(s.pos, 120, '#9fe8ff', 0.6); g.effects.ring(s.pos, 200, '#9fe8ff', 0.8); g.audio.play('gate');
        this.branch.allyHp = s.hp / s.maxHp;
        g.removeUnit(s, 'warp');
        this.win('RESOLUTE HAS JUMPED');
      }
    }
  }
  anchor() { const a = this.rng.range(0, Math.PI * 2); return V(Math.cos(a) * 800, this.rng.range(-120, 120), Math.sin(a) * 800); }
  status() {
    return { title: 'Escort the ISS Resolute', lines: [this.hpLine(this.ship, 'Resolute hull'),
      this.stage === 'repair' ? { text: `Engine repairs: ${Math.floor(this.repair)}%`, progress: this.repair / 100 } : { text: `Jump in ${Math.ceil(this.jumpT)}s`, progress: 1 - this.jumpT / 15 }] };
  }
}

// ---------------------------------------------------------------------------
export class ShieldGenObjective extends Objective {
  setup() {
    const g = this.g;
    this.cruiser = g.spawnUnit('cruiser', { pos: V(0, 0, 520), marker: 'TARGET', objective: true, faction: this.m.faction === 'vrell' ? 'dominion' : this.m.faction });
    this.cruiser.mesh.lookAt(V(0, 0, 0));
    this.cruiser.ai.shielded = true;
    this.bubble = new THREE.Mesh(new THREE.SphereGeometry(120, 32, 20), new THREE.MeshBasicMaterial({ color: new THREE.Color('#ff7a5a').multiplyScalar(1.2), transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
    this.cruiser.mesh.add(this.bubble);
    this.gens = [];
    for (let i = 0; i < 4; i++) {
      const a = i / 4 * Math.PI * 2 + 0.4;
      this.gens.push(g.spawnUnit('shieldgen', { pos: V(Math.cos(a) * 230, this.rng.range(-60, 60), 520 + Math.sin(a) * 230), marker: 'GEN', faction: this.cruiser.faction }));
    }
    for (let i = 0; i < 2; i++) g.spawnUnit('turret', { pos: V(i ? 150 : -150, 30, 300), faction: this.cruiser.faction });
    this.down = false;
  }
  update(dt) {
    super.update(dt);
    const g = this.g;
    const alive = this.alive(this.gens);
    for (const gen of alive) if (Math.random() < 0.2) g.effects.beam(gen.pos, this.cruiser.pos, '#ff7a5a', 0.6, 0.12);
    if (!this.down && alive.length === 0) {
      this.down = true; this.cruiser.ai.shielded = false; this.cruiser.invulnerable = false; this.bubble.visible = false;
      g.effects.ring(this.cruiser.pos, 200, '#ff7a5a', 1); g.audio.play('shieldBreak');
      g.hud.banner('SHIELD LATTICE DOWN', 'The cruiser is exposed — take it out!', 2.5);
    }
    this.bubble.material.opacity = 0.1 + 0.04 * Math.sin(this.t * 3);
    if (!this.cruiser.alive) this.win('CRUISER DESTROYED');
  }
  status() {
    const a = this.alive(this.gens).length;
    return { title: 'Break the shield lattice', lines: [{ text: `Shield generators: ${4 - a}/4 destroyed`, progress: (4 - a) / 4, done: a === 0 }, this.down ? this.hpLine(this.cruiser, 'Cruiser hull') : { text: 'Cruiser: SHIELDED' }] };
  }
}

// ---------------------------------------------------------------------------
export class SurviveObjective extends Objective {
  setup() { this.duration = 150; this.surgeT = 35; this.surge = 0; this.ambientScale = 1.25; this.g.director.preferTypes = ['interceptor', 'kamikaze', 'stealth']; }
  update(dt) {
    super.update(dt);
    const g = this.g, a = g.env.asteroids;
    this.surgeT -= dt;
    if (this.surgeT <= 0 && a) {
      this.surgeT = 40; this.surge = 10;
      g.hud.warn('STORM SURGE — ROCKS ACCELERATING', 2);
      for (let i = 0; i < a.count; i++) a.vel[i * 3 + 2] *= 1.7;
    }
    if (this.surge > 0) { this.surge -= dt; if (this.surge <= 0 && a) for (let i = 0; i < a.count; i++) a.vel[i * 3 + 2] /= 1.7; }
    if (this.t >= this.duration) this.win('STORM SURVIVED');
  }
  anchor() { const P = this.g.player; return P.pos.clone().addScaledVector(P.forward, -650).add(V(this.rng.range(-200, 200), this.rng.range(-100, 100), 0)); }
  status() { const r = Math.max(0, this.duration - this.t); return { title: 'Survive the storm', lines: [{ text: `Time remaining: ${Math.ceil(r)}s`, progress: this.t / this.duration }], timer: r }; }
}

// ---------------------------------------------------------------------------
export class CommsObjective extends Objective {
  setup() {
    const g = this.g;
    this.dishes = [];
    for (let i = 0; i < 3; i++) this.dishes.push(g.spawnUnit('comms', { pos: V((i - 1) * 220, this.rng.range(-40, 60), 520 + this.rng.range(-80, 80)), marker: 'DISH', faction: this.m.faction }));
    for (let i = 0; i < 2; i++) g.spawnUnit('turret', { pos: V((i ? 1 : -1) * 120, 0, 420), faction: this.m.faction });
    this.uplink = 0; this.called = false; this.reinf = [];
  }
  update(dt) {
    super.update(dt);
    const g = this.g;
    const alive = this.alive(this.dishes);
    if (!this.called) {
      this.uplink += dt * (alive.length / 3) * (100 / 120);
      if (alive.length === 0) { this.win('SIGNAL BLACKED OUT'); return; }
      if (this.uplink >= 100) {
        this.called = true; this.branch.reinforcementsCalled = true;
        g.hud.banner('REINFORCEMENTS CALLED', 'A heavy strike group is warping in!', 2.6); g.audio.play('alert');
        const spec = this.compose(5, 1.4);
        this.reinf = this.spawnWave(spec, V(0, 100, 900), g.player);
        const ace = g.director.spawnElite({ name: `${this.rng.pick(ACE_NAMES.first)} ${this.rng.pick(ACE_NAMES.last)}`, personality: 'tactical', variant: 'veteran', faction: this.m.faction }, V(0, 120, 900));
        this.reinf.push(ace);
      }
    } else {
      this.reinf = this.alive(this.reinf);
      if (alive.length === 0 && this.reinf.length === 0) this.win('ARRAY DESTROYED');
    }
  }
  status() {
    const a = this.alive(this.dishes).length;
    const lines = [{ text: `Relay dishes: ${3 - a}/3 destroyed`, progress: (3 - a) / 3 }];
    if (!this.called) lines.push({ text: `Reinforcement uplink: ${Math.floor(this.uplink)}%`, progress: this.uplink / 100, danger: this.uplink > 70 });
    else lines.push({ text: `Reinforcements remaining: ${this.reinf.length}`, danger: true });
    return { title: this.called ? 'Destroy the array & survive' : 'Black out the relay', lines };
  }
}

// ---------------------------------------------------------------------------
export class AceHuntObjective extends Objective {
  setup() {
    const g = this.g;
    const e = this.m.elite || { name: 'Red Talon', personality: 'aggressive', variant: 'veteran', faction: this.m.faction };
    this.aceDef = e;
    this.ace = g.director.spawnElite(e, V(0, 60, 650), { marker: 'ACE', retreatAt: 0.45 });
    this.escorts = this.spawnWave(this.compose(3, 0.7), V(0, 60, 650), g.player);
    this.stage = 'hunt'; this.returnT = 0; this.limit = 420;
    g.hud.toast(`${e.name.toUpperCase()} — ${ACE_NAMES.personalities[e.personality].desc}`, 'warn', 3.5);
  }
  onRetreat(u) {
    if (u !== this.ace) return;
    const g = this.g;
    this.stage = 'away'; this.returnT = 25;
    g.hud.banner(`${this.aceDef.name} retreats!`, 'They will regroup and come back with new tactics.', 2.6);
  }
  update(dt) {
    super.update(dt);
    const g = this.g;
    if (this.stage === 'away') {
      this.returnT -= dt;
      if (this.returnT <= 0) {
        const order = ['aggressive', 'evasive', 'tactical'];
        const next = order[(order.indexOf(this.aceDef.personality) + 1) % 3];
        this.aceDef = { ...this.aceDef, personality: next };
        const P = g.player;
        this.ace = g.director.spawnElite(this.aceDef, P.pos.clone().addScaledVector(P.forward, -500).add(V(0, 80, 0)), { marker: 'ACE', hpFrac: 0.7 });
        this.escorts = this.spawnWave(this.compose(4, 0.9), this.ace.pos.clone(), g.player);
        this.stage = 'final';
        g.hud.banner(`${this.aceDef.name} is back`, `New tactics: ${ACE_NAMES.personalities[next].desc}`, 2.8);
        g.audio.play('alert');
      }
    }
    if (this.stage !== 'away' && !this.ace.alive && this.ace.killedBy) { this.win('ACE ELIMINATED'); return; }
    if (this.t > this.limit && this.stage !== 'done') { this.branch.aceEscaped = true; this.fail(`${this.aceDef.name} escaped.`); }
  }
  status() {
    const lines = [];
    if (this.stage === 'away') lines.push({ text: `Ace regrouping… ${Math.ceil(this.returnT)}s` });
    else lines.push(this.hpLine(this.ace, this.aceDef.name));
    lines.push({ text: `Time before they escape: ${Math.max(0, Math.ceil(this.limit - this.t))}s`, danger: this.limit - this.t < 60 });
    return { title: `Hunt ${this.aceDef.name}`, lines };
  }
}

// ---------------------------------------------------------------------------
export class ColonyObjective extends Objective {
  setup() {
    const g = this.g;
    this.domes = [];
    for (let i = 0; i < 3; i++) { const a = i / 3 * Math.PI * 2; this.domes.push(g.spawnUnit('dome', { pos: V(Math.cos(a) * 150, -60, Math.sin(a) * 150), marker: 'DOME', objective: true })); }
    this.protect = this.domes;
    this.startPos = V(0, 40, -260); this.startLook = V(0, -40, 0);
    this.ambient = false; this.wave = 0; this.waves = 4; this.waveUnits = []; this.nextT = 5;
    this.dirs = this.rng.shuffle([0, 1, 2, 3, 4, 5]).map(k => k / 6 * Math.PI * 2);
  }
  update(dt) {
    super.update(dt);
    const g = this.g;
    const alive = this.alive(this.domes);
    if (!alive.length) { this.fail('The colony has fallen.'); return; }
    this.waveUnits = this.alive(this.waveUnits);
    if (this.wave > 0 && !this.waveUnits.length && this.nextT <= 0) {
      if (this.wave >= this.waves) { this.branch.domes = alive.length; this.win('COLONY SECURED'); return; }
      this.nextT = 9;
      g.hud.toast(`WAVE CLEARED — NEXT ATTACK IN 9s`, 'good', 2);
    }
    if (this.nextT > 0) {
      this.nextT -= dt;
      if (this.nextT <= 0 && (this.wave === 0 || !this.waveUnits.length)) {
        this.wave++;
        const spec = this.compose(this.wave + 1, 1.0);
        const vectors = this.wave >= 3 ? 2 : 1;
        this.waveUnits = [];
        for (let k = 0; k < vectors; k++) {
          const a = this.dirs[(this.wave * 2 + k) % this.dirs.length];
          const anchor = V(Math.cos(a) * 900, this.rng.range(-50, 150), Math.sin(a) * 900);
          const target = alive[Math.floor(this.rng.next() * alive.length)];
          this.waveUnits.push(...this.spawnWave(k === 0 ? spec : this.compose(this.wave, 0.6), anchor, target, { formationTarget: target }));
          g.hud.incoming(anchor);
        }
        g.hud.banner(`ATTACK WAVE ${this.wave}/${this.waves}`, vectors > 1 ? 'Multiple attack vectors!' : 'Watch the incoming bearing', 2);
        g.audio.play('wave');
      }
    }
  }
  status() {
    const alive = this.alive(this.domes);
    return { title: 'Defend the mining colony', lines: [{ text: `Domes standing: ${alive.length}/3`, progress: alive.length / 3, danger: alive.length < 2 }, ...alive.map((d, i) => this.hpLine(d, `Dome ${i + 1}`)), { text: `Wave ${Math.max(1, this.wave)}/${this.waves}` }] };
  }
}

// ---------------------------------------------------------------------------
export class ConvoyObjective extends Objective {
  setup() {
    const g = this.g;
    this.freighters = []; this.need = 6; this.cores = 0; this.done = 0;
    const path = [V(-900, 0, 350), V(-300, 80, 500), V(300, -40, 450), V(900, 30, 300)];
    for (let i = 0; i < 4; i++) {
      const f = g.spawnUnit('freighter', { pos: V(-900 - i * 70, i * 10, 350 + (i % 2) * 40), marker: 'FREIGHTER', faction: this.m.faction, hp: 700, shield: 220, onDeath: (u) => this._drop(u) });
      f.speed = 12; f.ai.path = path.map(p => p.clone().add(V(-i * 70, i * 10, (i % 2) * 40))); f.ai.wp = 0;
      this.freighters.push(f);
    }
    this.spawnWave(this.compose(3, 0.9), V(-850, 40, 380), g.player);
    g.spawnUnit('shieldcarrier', { pos: V(-850, 30, 360), faction: this.m.faction });
    this.startPos = V(0, 40, -150); this.startLook = V(-500, 0, 400);
    g.director.preferTypes = ['interceptor', 'shieldcarrier', 'sniper'];
  }
  _drop(u) { for (let k = 0; k < 3; k++) this.g.addPickup('core', u.pos.clone().add(V(Math.random() * 20 - 10, Math.random() * 20 - 10, Math.random() * 20 - 10)), 1); this.done++; }
  onRetreat(u, reason) { if (this.freighters.includes(u)) { this.done++; this.g.hud.toast('A FREIGHTER JUMPED AWAY', 'warn', 2); } }
  onPickup(type) { if (type === 'core') { this.cores++; if (this.cores === this.need) this.g.hud.toast('CORE QUOTA MET — GRAB WHAT YOU CAN', 'good', 2); } }
  update(dt) {
    super.update(dt);
    const left = this.alive(this.freighters).length;
    const loose = this.g.pickups.filter(p => p.type === 'core').length;
    if (left === 0 && loose === 0) {
      this.branch.cores = this.cores;
      if (this.cores >= this.need) this.win('CONVOY RAIDED'); else this.fail(`Only ${this.cores}/${this.need} cores recovered.`);
    }
  }
  status() { const left = this.alive(this.freighters).length; return { title: 'Raid the convoy', lines: [{ text: `Energy cores: ${this.cores}/${this.need}`, progress: Math.min(1, this.cores / this.need), done: this.cores >= this.need }, { text: `Freighters remaining: ${left}` }] }; }
}

// ---------------------------------------------------------------------------
export class DerelictObjective extends Objective {
  setup() {
    const g = this.g;
    this.wreck = g.spawnUnit('derelict', { pos: V(0, 0, 480), marker: 'SIGNAL' });
    this.wreck.mesh.rotation.set(0.3, 1.2, 0.5);
    this.stage = 'approach'; this.scan = 0; this.ambush = []; this.ambientScale = 0.4;
    this.extract = V(0, 40, -520);
  }
  update(dt) {
    super.update(dt);
    const g = this.g, P = g.player;
    if (this.stage === 'approach' && P.pos.distanceTo(this.wreck.pos) < 170) { this.stage = 'scan'; g.hud.toast('SCANNING — STAY CLOSE', 'info', 1.5); }
    if (this.stage === 'scan') {
      if (P.pos.distanceTo(this.wreck.pos) < 190) { this.scan += dt / 7; if (Math.random() < dt * 3) g.audio.play('scan'); }
      if (this.scan >= 1) {
        this.stage = 'ambush';
        g.hud.banner('IT\'S A TRAP!', 'The derelict was bait. Hostiles decloaking!', 2.4); g.audio.play('alert');
        const spec = this.compose(4, 1.2, 'syndicate');
        spec.groups.push({ type: 'stealth', count: 3, formation: 'loose', faction: 'syndicate' });
        this.ambush = this.spawnWave(spec, this.wreck.pos.clone().add(V(0, 150, 0)), P);
        for (let k = 0; k < 3; k++) { const t = g.spawnUnit('turret', { pos: this.wreck.pos.clone().add(V((k - 1) * 70, 50, 0)), faction: 'syndicate' }); this.ambush.push(t); }
        this.ambientScale = 1;
        if (this.rng.chance(0.4)) { g.addPickup('relic', this.wreck.pos.clone().add(V(0, 70, -60)), 1); g.hud.toast('UNKNOWN ARTIFACT DETECTED', 'info', 2); }
      }
    }
    if (this.stage === 'ambush') {
      this.ambush = this.alive(this.ambush);
      if (!this.ambush.length) { this.stage = 'extract'; g.hud.banner('AMBUSH SURVIVED', 'Reach the extraction point', 2); g.setWaypoint(this.extract, 'EXTRACT'); }
    }
    if (this.stage === 'extract') {
      if (P.pos.distanceTo(this.extract) < 70) { g.setWaypoint(null); this.win('EXTRACTED'); }
    }
  }
  status() {
    const s = this.stage;
    const lines = [];
    if (s === 'approach') lines.push({ text: 'Approach the derelict warship' });
    if (s === 'scan') lines.push({ text: `Scanning: ${Math.floor(this.scan * 100)}%`, progress: this.scan });
    if (s === 'ambush') lines.push({ text: `Ambushers remaining: ${this.ambush.length}`, danger: true });
    if (s === 'extract') lines.push({ text: `Extraction: ${Math.round(this.g.player.pos.distanceTo(this.extract))}m` });
    return { title: 'Investigate the distress signal', lines };
  }
}

// ---------------------------------------------------------------------------
export class EscapeObjective extends Objective {
  setup() {
    const g = this.g;
    this.gates = [];
    for (let i = 0; i < 8; i++) {
      const z = -700 + i * 200;
      const pos = V(Math.sin(i * 1.3) * 260, Math.cos(i * 0.9) * 120, z);
      const gate = g.spawnUnit('gate', { pos, marker: i === 0 ? 'GATE' : null });
      const next = V(Math.sin((i + 1) * 1.3) * 260, Math.cos((i + 1) * 0.9) * 120, z + 200);
      gate.mesh.lookAt(next);
      this.gates.push(gate);
    }
    this.idx = 0; this.timer = 16; this.startPos = V(0, 0, -950); this.startLook = this.gates[0].pos.clone();
    this.debrisT = 1; this.ambientScale = 0.8;
    g.director.preferTypes = ['interceptor', 'kamikaze'];
  }
  anchor() { const gt = this.gates[Math.min(this.idx + 2, 7)]; return gt.pos.clone().add(V(this.rng.range(-300, 300), this.rng.range(-150, 150), 200)); }
  update(dt) {
    super.update(dt);
    const g = this.g, P = g.player;
    this.timer -= dt;
    const gate = this.gates[this.idx];
    if (gate) {
      const local = P.pos.clone().sub(gate.pos);
      const n = V(0, 0, 1).applyQuaternion(gate.quat);
      const side = local.dot(n);
      const radial = local.clone().addScaledVector(n, -side).length();
      const crossed = this.lastSide != null && Math.sign(side) !== Math.sign(this.lastSide) && Math.abs(side - this.lastSide) < 60;
      this.lastSide = side;
      if ((crossed || Math.abs(side) < 10) && radial < 42) {
        this.lastSide = null;
        g.audio.play('gate'); g.effects.ring(gate.pos, 40, '#4fdcff', 0.5, n);
        gate.marker = null; this.idx++; this.timer += 5;
        g.hud.toast(`GATE ${this.idx}/8 — +5s`, 'good', 1.2);
        if (this.gates[this.idx]) this.gates[this.idx].marker = 'GATE';
        else { this.win('ESCAPED THE COLLAPSE'); return; }
      }
    }
    // the station tears itself apart around you
    this.debrisT -= dt;
    if (this.debrisT <= 0) {
      this.debrisT = 0.7;
      const ahead = (this.gates[this.idx] || this.gates[7]).pos;
      const p = ahead.clone().add(V(this.rng.range(-160, 160), this.rng.range(-100, 100), this.rng.range(-120, 120)));
      g.effects.marker(p, 40, 1.4, '#ff8a3a');
      setTimeout(() => { if (!g.active) return; g.effects.explosion(p, 3, '#ff8a3a'); g.damageArea(p, 45, 30, 'enemy', { environmental: true }); g.audio.play('explosionL', { pos: p }); }, 1400);
    }
    if (this.timer <= 0) this.fail('The station detonated.');
  }
  status() { return { title: 'Escape the collapsing station', lines: [{ text: `Gates: ${this.idx}/8`, progress: this.idx / 8 }, { text: `Core detonation: ${Math.max(0, this.timer).toFixed(1)}s`, danger: this.timer < 10 }], timer: this.timer }; }
}

// ---------------------------------------------------------------------------
export class CarrierObjective extends Objective {
  setup() {
    const g = this.g;
    const fac = this.m.faction === 'vrell' ? 'dominion' : this.m.faction;
    this.carrier = g.spawnUnit('carrier', { pos: V(0, -20, 560), marker: 'CARRIER', faction: fac, invulnerable: true });
    this.carrier.mesh.lookAt(V(0, -20, 0));
    this.carrier.radius = 28; // core hull; components sit outside it
    this.carrier.ai.moveTo = V(0, -20, 250); this.carrier.ai.face = V(0, 0, -1);
    this.engines = []; this.turrets = [];
    for (const x of [-9, 9]) {
      const anchor = new THREE.Object3D(); anchor.position.set(x, 0, -95);
      const glow = new THREE.Mesh(new THREE.SphereGeometry(7, 12, 10), new THREE.MeshBasicMaterial({ color: new THREE.Color('#ff7a3a').multiplyScalar(3), toneMapped: false }));
      anchor.add(glow); this.carrier.mesh.add(anchor);
      this.engines.push(g.spawnUnit('part', { mesh: anchor, part: true, name: 'Carrier Engine', hp: 1100 * this.m.difficulty, radius: 12, marker: 'ENGINE', faction: fac }));
    }
    for (let i = 0; i < 4; i++) {
      const t = buildUnit('turret', fac, { noFlames: true });
      t.position.set(i % 2 ? 30 : -30, 20, -50 + Math.floor(i / 2) * 70); t.scale.setScalar(0.8);
      this.carrier.mesh.add(t);
      const u = g.spawnUnit('part', { mesh: t, part: true, name: 'Flak Turret', hp: 450 * this.m.difficulty, shield: 120, radius: 10, behavior: 'turret', faction: fac });
      u.def = { ...u.def, weapon: { dmg: 7, speed: 420, spread: 0.03 } };
      this.turrets.push(u);
    }
    this.stage = 'parts';
  }
  update(dt) {
    super.update(dt);
    const g = this.g, c = this.carrier;
    const e = this.alive(this.engines).length, t = this.alive(this.turrets).length;
    if (e === 0 && c.ai.moveTo) { c.ai.moveTo = null; g.hud.toast('ENGINES DOWN — CARRIER DEAD IN SPACE', 'good', 2); c.ai.disabledHangar = true; }
    if (this.stage === 'parts' && e === 0 && t === 0) {
      this.stage = 'reactor'; c.invulnerable = false; c.marker = 'REACTOR';
      g.hud.banner('REACTOR BREACH', 'All defenses down — destroy the carrier!', 2.5);
    }
    if (!c.alive) this.win('CARRIER DESTROYED');
  }
  status() {
    const e = this.alive(this.engines).length, t = this.alive(this.turrets).length;
    const lines = [{ text: `Engines: ${2 - e}/2 destroyed`, progress: (2 - e) / 2, done: e === 0 }, { text: `Turrets: ${4 - t}/4 destroyed`, progress: (4 - t) / 4, done: t === 0 }];
    if (this.stage === 'reactor') lines.push(this.hpLine(this.carrier, 'Carrier reactor'));
    return { title: 'Strike the carrier', lines };
  }
}

// ---------------------------------------------------------------------------
export class AnomalyObjective extends Objective {
  setup() {
    const g = this.g;
    this.pylons = [];
    for (let i = 0; i < 5; i++) { const a = i / 5 * Math.PI * 2; this.pylons.push(g.spawnUnit('pylon', { pos: V(Math.cos(a) * 330, this.rng.range(-80, 80), 300 + Math.sin(a) * 330), marker: 'PYLON', faction: 'choir', onDeath: (u) => this._surge(u) })); }
    this.core = new THREE.Mesh(new THREE.SphereGeometry(40, 32, 20), new THREE.MeshBasicMaterial({ color: 0x000000 }));
    this.core.position.set(0, 0, 300);
    this.halo = new THREE.Mesh(new THREE.TorusGeometry(70, 3, 6, 64), new THREE.MeshBasicMaterial({ color: new THREE.Color('#b26bff').multiplyScalar(2.5), toneMapped: false }));
    this.core.add(this.halo);
    g.scene.add(this.core); g.missionObjects.push(this.core);
    this.wells = [{ pos: V(0, 0, 300), radius: 420, strength: 0.7 }, { pos: V(0, 0, 0), radius: 250, strength: 0.5, a: 0 }];
    g.gravityWells.push(...this.wells);
    this.m.faction = 'choir';
  }
  _surge(u) {
    const g = this.g;
    g.effects.ring(u.pos, 160, '#4ff0ff', 0.8); g.effects.addShake(0.6);
    g.hud.toast('PYLON DESTROYED — THE ANOMALY SURGES', 'warn', 1.6);
    for (let k = 0; k < 3; k++) g.spawnUnit(['shieldcarrier', 'sniper', 'swarm'][k], { pos: this.core.position.clone().add(V(k * 30 - 30, 50, -60)), faction: 'choir' });
    this.wells[0].strength += 0.15;
  }
  update(dt) {
    super.update(dt);
    const g = this.g;
    this.halo.rotation.x += dt * 0.7; this.halo.rotation.y += dt * 0.4;
    const w = this.wells[1]; w.a += dt * 0.3; w.pos.set(Math.cos(w.a) * 380, Math.sin(w.a * 2) * 60, 300 + Math.sin(w.a) * 380);
    if (Math.random() < 0.5) g.effects.trailPuff(this.core.position.clone().add(V(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(220)), '#b26bff', 4, 1, this.core.position.clone().sub(g.player.pos).multiplyScalar(0));
    const alive = this.alive(this.pylons);
    for (const p of alive) if (Math.random() < 0.15) g.effects.beam(p.pos, this.core.position, '#4ff0ff', 0.8, 0.12);
    if (!alive.length) {
      g.effects.explosion(this.core.position, 6, '#b26bff', { debris: false }); g.effects.ring(this.core.position, 500, '#b26bff', 1.2);
      this.core.visible = false; for (const x of this.wells) { const i = g.gravityWells.indexOf(x); if (i >= 0) g.gravityWells.splice(i, 1); }
      this.win('ANOMALY COLLAPSED');
    }
  }
  status() { const a = this.alive(this.pylons).length; return { title: 'Collapse the anomaly', lines: [{ text: `Crystal pylons: ${5 - a}/5 destroyed`, progress: (5 - a) / 5 }, { text: 'Warning: gravity distorts projectiles', danger: false }] }; }
}

// ---------------------------------------------------------------------------
export class BossObjective extends Objective {
  setup() {
    const g = this.g;
    this.ambientScale = 0.35;
    this.startPos = V(0, 20, -300); this.startLook = V(0, 0, 400);
    this.spawnBoss(this.m.boss);
  }
  spawnBoss(id) {
    const g = this.g;
    const phantomReturn = id === 'phantom' && (this.m.phantomReturn || this.m.followUp);
    this.boss = createBoss(g, id, { difficulty: this.m.difficulty, variant: this.m.bossVariant, event: this.m.event, retreat: this.m.phantomRetreat, returning: phantomReturn });
    g.boss = this.boss;
    g.encountered.bosses.add(id);
    const center = this.boss.group.position;
    g.startCinematic({ focus: center, radius: (this.boss.extent?.z || 60) * 1.6 + 60, duration: 5, title: BOSSES[id].name, subtitle: BOSSES[id].title });
  }
  update(dt) {
    super.update(dt);
    if (this.boss) this.boss.update(dt);
    if (this.boss && (this.boss.defeated || this.boss.retreated)) this.onBossEnd();
  }
  onBossEnd() { this.win(this.boss.retreated ? 'THE PHANTOM RETREATS' : 'BOSS DEFEATED'); }
  status() { return { title: `Defeat ${this.boss?.name || 'the boss'}`, lines: [{ text: this.boss ? `Phase: ${this.boss.phaseName()}` : '' }] }; }
}

export class BossRushObjective extends BossObjective {
  setup() {
    this.list = this.m.bossList.slice(); this.idx = 0; this.breakT = 0; this.ambientScale = 0.25; this.results = [];
    this.startPos = V(0, 20, -300); this.startLook = V(0, 0, 400);
    this.bossStart = 0; this.hull0 = 0;
    this.spawnBoss(this.list[0]); this.bossStart = this.t;
  }
  onBossEnd() {
    const g = this.g;
    if (this.breakT > 0) return;
    const time = this.t - this.bossStart;
    const dmg = g.player.hullDamageTaken - this.hull0;
    const score = Math.max(0, 1 - time / 240) * 0.6 + Math.max(0, 1 - dmg / g.player.maxHull) * 0.4;
    const rating = score > 0.75 ? 'S' : score > 0.55 ? 'A' : score > 0.35 ? 'B' : 'C';
    this.results.push({ boss: this.boss.id, time, rating });
    g.hud.banner(`${this.boss.name} — RANK ${rating}`, `Time ${time.toFixed(1)}s`, 2.5);
    this.boss.dispose();
    this.idx++;
    if (this.idx >= this.list.length) { this.branch.ratings = this.results; this.win('GAUNTLET COMPLETE'); return; }
    this.breakT = 6; this.boss = null;
  }
  update(dt) {
    this.t += dt;
    const g = this.g;
    if (this.breakT > 0) {
      this.breakT -= dt;
      if (this.breakT <= 0) {
        const P = g.player; P.shield = P.maxShield; P.weapons.refill(); P.heal(P.maxHull * 0.3);
        this.spawnBoss(this.list[this.idx]); this.bossStart = this.t; this.hull0 = g.player.hullDamageTaken;
      }
      return;
    }
    if (this.boss) { this.boss.update(dt); if (this.boss.defeated || this.boss.retreated) this.onBossEnd(); }
  }
  status() { return { title: `Boss Rush ${this.idx + 1}/${this.list.length}`, lines: [{ text: this.boss ? `${this.boss.name}: ${this.boss.phaseName()}` : `Next boss in ${Math.ceil(this.breakT)}s` }, ...this.results.map(r => ({ text: `${BOSSES[r.boss].name}: ${r.rating}`, done: true }))] }; }
}

// ---------------------------------------------------------------------------
// Wave assault: Endless Frontier, Daily Challenge, Experimental Zone
// ---------------------------------------------------------------------------
export class WavesObjective extends Objective {
  setup() {
    this.ambient = false; this.wave = 0; this.waveUnits = []; this.nextT = 3; this.choosing = false;
    this.total = this.m.waves; this.extraMods = [];
    this.startPos = V(0, 0, -200); this.startLook = V(0, 0, 400);
    this.modPool = this.rng.shuffle(['drones', 'regen', 'hunters', 'overheat', 'gravity', 'radarjam', 'ironclad', 'glass', 'densefield']);
  }
  update(dt) {
    super.update(dt);
    const g = this.g;
    if (this.bossCtl) {
      this.bossCtl.update(dt);
      if (this.bossCtl.defeated) { this.bossCtl.dispose(); this.bossCtl = null; g.boss = null; }
    }
    if (this.choosing) return;
    this.waveUnits = this.alive(this.waveUnits);
    if (this.wave > 0 && !this.waveUnits.length && !this.bossCtl && this.nextT <= 0) {
      g.stats.wave = this.wave;
      if (this.wave >= this.total) { this.win(this.m.mode === 'daily' ? 'CHALLENGE COMPLETE' : 'ZONE CLEARED'); return; }
      const bonus = Math.round(500 * this.wave * g.scoreMult());
      g.addScore(bonus, `WAVE ${this.wave} CLEAR`);
      if (this.m.mode === 'endless') { this._offerPerks(); return; }
      this.nextT = 4;
    }
    if (this.nextT > 0) {
      this.nextT -= dt;
      if (this.nextT <= 0) this._spawnNext();
    }
  }
  _spawnNext() {
    const g = this.g;
    this.wave++;
    g.stats.waveReached = this.wave;
    const spec = endlessWaveSpec(this.rng, this.wave, this.m.faction, this.m.altFaction, this.lastFormation);
    this.lastFormation = spec.formation;
    if (this.m.mode === 'endless' && spec.newModifier && this.modPool.length) {
      const mod = this.modPool.shift(); this.m.modifiers.push(mod); g.applyModifier(mod);
      g.hud.toast(`NEW MODIFIER: ${MODIFIERS[mod].name.toUpperCase()} — ${MODIFIERS[mod].desc}`, 'warn', 3);
    }
    const a = this.rng.range(0, Math.PI * 2);
    const anchor = V(Math.cos(a) * 800, this.rng.range(-120, 160), Math.sin(a) * 800);
    this.waveUnits = this.spawnWave(spec, anchor, g.player);
    if (spec.elite) this.waveUnits.push(g.director.spawnElite(null, anchor.clone().add(V(0, 60, 0))));
    if (spec.miniboss) { const mb = g.spawnUnit(spec.miniboss, { pos: anchor.clone(), faction: this.m.faction, marker: 'MINI-BOSS' }); this.waveUnits.push(mb); g.hud.toast(`${mb.name.toUpperCase()} INBOUND`, 'warn', 2); }
    if (this.wave % 10 === 0 && this.m.mode === 'endless') {
      const bosses = ['dreadnought', 'swarmqueen', 'phantom', 'anomaly'];
      const b = createBoss(g, bosses[(this.wave / 10 - 1) % 4], { difficulty: 0.6 + this.wave * 0.04 });
      g.boss = b; this.bossCtl = b; g.encountered.bosses.add(b.id);
      g.hud.banner(b.name, 'Frontier boss', 2.4);
    }
    g.hud.banner(`WAVE ${this.wave}${this.total < Infinity ? '/' + this.total : ''}`, this.m.mode === 'endless' ? `Score multiplier x${g.scoreMult().toFixed(1)}` : '', 1.8);
    g.audio.play('wave');
    g.hud.incoming(anchor);
  }
  _offerPerks() {
    const g = this.g;
    this.choosing = true;
    const ids = this.rng.shuffle(Object.keys(ENDLESS_PERKS)).slice(0, 3);
    g.offerChoice({
      title: `WAVE ${this.wave} SURVIVED`, subtitle: 'Choose a perk for this run',
      options: ids.map(id => ({ id, title: ENDLESS_PERKS[id].name, desc: ENDLESS_PERKS[id].desc, icon: ENDLESS_PERKS[id].icon })),
      onPick: id => { g.applyPerk(id); this.choosing = false; this.nextT = 3; },
    });
  }
  status() {
    const lines = [{ text: `Wave ${Math.max(1, this.wave)}${this.total < Infinity ? '/' + this.total : ''} — hostiles: ${this.waveUnits.length}` }];
    if (this.m.mode === 'endless') lines.push({ text: `Score multiplier: x${this.g.scoreMult().toFixed(1)}` });
    if (this.m.mutators?.length) lines.push({ text: 'Mutators active', danger: false });
    return { title: this.m.mode === 'endless' ? 'Endless Frontier' : this.m.mode === 'daily' ? 'Daily Challenge' : 'Experimental Zone', lines };
  }
}

// ---------------------------------------------------------------------------
// Flight School — guided onboarding
// ---------------------------------------------------------------------------
export class TutorialObjective extends Objective {
  setup() {
    this.ambient = false; this.step = -1; this.stepT = 0; this.items = [];
    this.startPos = V(0, 0, -300); this.startLook = V(0, 0, 0);
    this.steps = [
      { title: 'Steering', text: 'Move the mouse to steer toward the glowing ring. W throttles up, S slows down.', init: () => this._gates([V(0, 20, -120)]), done: () => this._gatesDone() },
      { title: 'Boost & strafe', text: 'Hold SHIFT to boost through the next two rings. A / D strafe sideways.', init: () => this._gates([V(120, 40, 120), V(-60, -20, 360)]), done: () => this._gatesDone() },
      { title: 'Weapons', text: 'Hold LEFT MOUSE to fire. Destroy the 5 training drones. Press X to swap weapons.', init: () => this._drones(5, false), done: () => this.alive(this.items).length === 0 },
      { title: 'Lock-on ordnance', text: 'Keep a target under your crosshair until the bracket turns red, then press RIGHT MOUSE (or R).', init: () => { this.secStart = this.g.stats.secondaryKills; this._drones(2, true); }, done: () => this.g.stats.secondaryKills > this.secStart || this.alive(this.items).length === 0 },
      { title: 'Evasion', text: 'Tap SPACE to perform an evasive dash. Dashing makes you briefly untouchable.', init: () => { this.dashStart = this.g.player.dashCd; }, done: () => this.g.player.dashT > 0 || this.g.player.invuln > 0 },
      { title: 'Ability', text: 'Press F to activate your ship ability.', init: () => {}, done: () => this.g.player.ability.cd > 0 },
      { title: 'Live fire', text: 'Hostiles inbound! Use everything you learned. Shields recharge when you avoid damage.', init: () => { this.items = this.spawnWave({ groups: [{ type: 'swarm', count: 6, formation: 'grid', faction: 'dominion' }, { type: 'interceptor', count: 2, formation: 'loose', faction: 'dominion' }] }, V(0, 0, 700), this.g.player); }, done: () => this.alive(this.items).length === 0 },
    ];
    this.g.settings.tutorialSeen = true;
  }
  _gates(list) {
    const g = this.g;
    this.gates = list.map((p, i) => { const u = g.spawnUnit('gate', { pos: p, marker: i === 0 ? 'RING' : null }); u.mesh.scale.setScalar(0.7); u.mesh.lookAt(g.player.pos); return u; });
    this.gi = 0;
  }
  _gatesDone() {
    const g = this.g, gate = this.gates[this.gi];
    if (!gate) return true;
    if (g.player.pos.distanceTo(gate.pos) < 34) {
      g.audio.play('gate'); g.effects.ring(gate.pos, 30, '#4fdcff', 0.5);
      g.removeUnit(gate); this.gi++;
      if (this.gates[this.gi]) { this.gates[this.gi].marker = 'RING'; g.hud.trackUnit(this.gates[this.gi]); }
    }
    return this.gi >= this.gates.length;
  }
  _drones(n, far) {
    const g = this.g, P = g.player;
    this.items = [];
    for (let i = 0; i < n; i++) {
      const pos = P.pos.clone().addScaledVector(P.forward, far ? 420 : 220).add(V((i - (n - 1) / 2) * 40, Math.sin(i) * 20, 0));
      const u = g.spawnUnit('swarm', { pos, faction: 'dominion', behavior: 'drift', marker: 'TARGET', hpMult: far ? 1.6 : 0.8 });
      u.def = { ...u.def, weapon: null };
      this.items.push(u);
    }
  }
  update(dt) {
    super.update(dt);
    const g = this.g;
    if (this.step < 0 || (this.stepT > 1 && this.steps[this.step].done())) {
      if (this.step >= 0) { g.audio.play('claim', { volume: 0.5 }); g.addScore(250, 'LESSON'); }
      this.step++; this.stepT = 0;
      if (this.step >= this.steps.length) { this.win('FLIGHT SCHOOL COMPLETE'); g.hud.prompt(null); return; }
      const st = this.steps[this.step];
      st.init();
      g.hud.banner(st.title, `Lesson ${this.step + 1} of ${this.steps.length}`, 2);
    }
    this.stepT += dt;
    g.hud.prompt(this.steps[this.step].text);
  }
  status() { const st = this.steps[Math.max(0, this.step)]; return { title: 'Flight School', lines: this.steps.map((x, i) => ({ text: x.title, done: i < this.step, danger: false })) }; }
}


// ---------------------------------------------------------------------------
// Story chapters: a chain of the objectives above. The commander briefs each
// stage over comms; between stages the ship jumps to the next nav point.
// ---------------------------------------------------------------------------
const ROMAN = ['', 'I', 'II', 'III'];
let STAGE_TYPES = {};
export class StoryObjective extends Objective {
  // fields the game and director read from the objective follow the current stage
  get protect() { return this.cur ? this.cur.protect : (this._protect || []); } set protect(v) { this._protect = v; }
  get ambient() { return this.cur ? this.cur.ambient && this.phase === 'play' : false; } set ambient(v) { this._ambient = v; }
  get ambientScale() { return (this.cur ? this.cur.ambientScale ?? 1 : 1) * (this.effectScale || 1); } set ambientScale(v) { this._ambientScale = v; }
  get startPos() { return this.cur ? this.cur.startPos : this._startPos; } set startPos(v) { this._startPos = v; }
  get startLook() { return this.cur ? this.cur.startLook : this._startLook; } set startLook(v) { this._startLook = v; }
  get boss() { return this.cur?.boss; } set boss(v) { /* owned by stages */ }
  get bossCtl() { return this.cur?.bossCtl; } set bossCtl(v) { /* owned by stages */ }
  get wave() { return this.cur?.wave; } set wave(v) { /* owned by stages */ }
  get current() { return this.cur; }

  setup() {
    const g = this.g;
    this.ch = this.m.story;
    this.choices = this.m.storyChoices || {};
    this.cs = g.save.profile.callsign;
    this.comms = g.hud.comms;
    this.comms.reset();
    this.stages = this.ch.stages || [];
    this.si = -1; this.phase = 'intro'; this.waitT = 0;
    this.persist = [];
    this.flags = { lowHullT: 0, shieldT: 0, comboT: 0, allyT: 0, lastCombo: 0, lastShield: 1 };
    // choice consequences for this chapter
    this.effectScale = 1;
    const fx = [];
    for (const e of Object.values(EFFECTS)) if (e.when(this.choices) && e.chapters.includes(this.ch.id)) { fx.push(e); if (e.ambientScale) this.effectScale *= e.ambientScale; if (e.bossHp) g.bossHpMult *= e.bossHp; }
    this.fxLines = fx.flatMap(e => e.lines);
    this.allyDefs = Object.entries(ALLIES).filter(([, a]) => a.when(this.choices) && a.chapters.includes(this.ch.id));
    this._startStage(0);
  }

  say(lines, opts) { for (const [who, text] of lines || []) this.comms.say(who, fillCallsign(text, this.cs), opts); }
  bark(pool) { const l = pool[Math.floor(Math.random() * pool.length)]; if (l) this.comms.say(l[0], fillCallsign(l[1], this.cs), { bark: true, cooldown: 12 }); }

  _stageMission(st) {
    const m = { ...this.m, objective: st.obj, elite: null, boss: null, phantomRetreat: false, ...(st.m || {}) };
    if (st.obj === 'waves' && !m.waves) m.waves = 2;
    return m;
  }

  _startStage(i) {
    const g = this.g;
    this.si = i;
    const st = this.stages[i];
    this.stage = st;
    this.stageStartObjects = g.missionObjects.length;
    g.director.preferTypes = null;
    const C = STAGE_TYPES[st.obj] || InterceptObjective;
    const inner = new C(g, this._stageMission(st));
    inner.rng = new RNG(`obj-${this.m.seed}-${i}`);
    this.cur = inner;
    inner.setup();
    for (const [k, v] of Object.entries(st.set || {})) inner[k] = v;
    this.phaseLinesSaid = new Set(); this.lastBossPhase = -1;
    this.timed = (st.at || []).map(a => ({ t: a[0], who: a[1], text: a[2] }));
    if (i > 0) { this.phase = 'play'; this._sayStageStart(); }
  }
  _sayStageStart() {
    const st = this.stage;
    this.say(st.say);
    if (this.si === 0) {
      this.say(this.fxLines);
      for (const [, a] of this.allyDefs) this.say(a.lines);
    }
  }

  _spawnAllies() {
    const g = this.g, P = g.player;
    for (const [id, a] of this.allyDefs) {
      for (let k = 0; k < a.count; k++) {
        const w = g.spawnUnit('wingman', { pos: P.pos.clone().add(V((k - 0.5) * 40 + (id === 'vant' ? 25 : -25), 12, -40)), team: 'ally', faction: 'ally', name: id === 'vant' ? 'Kaeso Vant' : 'Ashkar Militia', marker: id === 'vant' ? 'VANT' : null, hp: id === 'vant' ? 600 : 260, shield: id === 'vant' ? 200 : 80, tint: id === 'vant' ? '#ffcc33' : '#ff8a5a' });
        w.ai.side = k === 0 ? -1 : 1.5; w.persist = true; w.allyKind = id;
        this.persist.push(w);
      }
    }
  }

  // move to the next nav point: everything but the player and story wingmen is left behind
  _jump() {
    const g = this.g, P = g.player;
    this.branch = { ...this.branch, ...this.cur.branch };
    if (this.cur.boss?.dispose) this.cur.boss.dispose();
    if (this.cur.bossCtl?.dispose) this.cur.bossCtl.dispose();
    g.boss = null;
    for (const u of g.units) if (u.alive && !u.persist) g.removeUnit(u, 'warp');
    g.units = g.units.filter(u => u.alive);
    g.hazards.length = 0; g.gravityWells.length = 0;
    g.projectiles.clearTeam?.('enemy');
    while (g.missionObjects.length > this.stageStartObjects) { const o = g.missionObjects.pop(); g.scene.remove(o); o.traverse?.(x => { x.geometry?.dispose?.(); x.material?.dispose?.(); }); }
    g.arenaRadius = ARENA_RADIUS; if (g.boundary) g.boundary = null;
    g.setWaypoint(null); g.flags.drift = false;
    this._startStage(this.si + 1);
    g._clearSetPieces?.();
    P.pos.copy(this.cur.startPos); P.vel.multiplyScalar(0.3);
    P.mesh.lookAt(this.cur.startLook); P.forward.set(0, 0, 1).applyQuaternion(P.quat);
    if (P.aimDir) P.aimDir.copy(P.forward);
    for (const t of P.trails) t.t.reset(P.pos);
    for (const p of g.pickups) p.pos.copy(P.pos);
    this.persist.forEach((w, k) => { if (w.alive) { w.pos.copy(P.pos).add(V((k - 0.5) * 50, 12, 0).applyQuaternion(P.quat)); w.vel.copy(P.vel); } });
    g.camPos.copy(P.pos).add(V(0, 6, -24).applyQuaternion(P.quat)); g.camLook.copy(P.pos);
    g.effects.flash(P.pos, 40, '#9fe8ff', 0.6); g.audio.play('gate');
    g.hud.banner(`NAV POINT ${this.si + 1}/${this.stages.length}`, '', 1.8);
  }

  update(dt) {
    super.update(dt);
    const g = this.g, P = g.player;
    if (this.phase === 'intro') {
      // opening scene: title card and the intro conversation over a slow orbit of your ship
      const lines = this.ch.intro || [];
      this.phase = 'play';
      this._spawnAllies();
      if (lines.length && !g.headless) {
        const dur = lines.reduce((a, l) => a + 2.4 + fillCallsign(l[1], this.cs).length / 16, 1);
        this.say(lines, {});
        g.startCinematic({ story: true, focus: P.pos.clone(), radius: 70, duration: dur, title: `ACT ${ROMAN[this.ch.act]} · CHAPTER ${this.m.storyIndex + 1}`, subtitle: this.ch.title,
          onEnd: () => { this.comms.skipAll(); this._sayStageStart(); } });
        if (!g.cinematic) { this.comms.skipAll(); this._sayStageStart(); } // intros skipped in settings
      } else this._sayStageStart();
      return;
    }
    if (this.phase === 'play') {
      this.cur.update(dt);
      this._chatter(dt);
      if (this.cur.result === 'defeat') { this.fail(this.cur.failReason); return; }
      if (this.cur.result === 'victory') {
        this.cur.result = null; this.cur.update = () => {}; // stage done: freeze its logic, keep its world until the jump
        this.say(this.stage.done);
        const last = this.si >= this.stages.length - 1;
        this.phase = last ? 'finale' : 'between'; this.waitT = 0;
        g.hud.toast(last ? 'FINAL OBJECTIVE COMPLETE' : 'OBJECTIVE COMPLETE — STAND BY TO JUMP', 'good', 2.5);
      }
      return;
    }
    if (this.phase === 'between') {
      this.waitT += dt;
      if ((!this.comms.busy && this.waitT > 2.5) || this.waitT > 14) this._jump();
      return;
    }
    if (this.phase === 'finale') {
      this.waitT += dt;
      if (this.comms.busy && this.waitT < 20) return;
      if (this.ch.finalLines && !this._finalSaid) { this._finalSaid = true; this.say(this.ch.finalLines); this.waitT = 0; return; }
      const ch = this.ch.choice;
      if (ch && ch.when === 'after' && !this._picked) {
        this._picked = true;
        g.offerChoice({ title: ch.title, subtitle: ch.subtitle, options: ch.options.map(o => ({ ...o })),
          onPick: id => { this.branch.storyChoice = { id: ch.id, value: id }; this.choices = { ...this.choices, [ch.id]: id }; this._outro(); } });
        return;
      }
      if (!ch || ch.when !== 'after') { if (!this._outroStarted) this._outro(); }
      if (this._outroStarted && (!this.comms.busy || this.waitT > 25)) {
        this.branch = { ...this.branch, ...this.cur.branch, storyChoice: this.branch.storyChoice };
        if (this.ch.id === 'c30') this.branch.ending = this.choices.lattice || 'silence';
        this.win(this.ch.id === 'c30' ? 'THE SONG ENDS' : 'CHAPTER COMPLETE');
      }
    }
  }
  _outro() {
    this._outroStarted = true; this.waitT = 0;
    // a choice made at the end of the chapter selects that chapter's matching outro
    let outro = this.ch.outro || [];
    const ch = this.ch.choice;
    if (ch && this.ch.variant) { const v = this.ch.variant[`${ch.id}=${this.choices[ch.id]}`]; if (v?.outro) outro = v.outro; }
    this.say(outro);
  }

  _chatter(dt) {
    const g = this.g, P = g.player, f = this.flags;
    const t = this.cur.t;
    for (const a of this.timed) if (!a.done && t >= a.t) { a.done = true; this.comms.say(a.who, fillCallsign(a.text, this.cs)); }
    // boss phase lines
    const b = g.boss;
    if (b && b.phase !== this.lastBossPhase) { this.lastBossPhase = b.phase; const pl = this.stage.phase?.[b.phase]; if (pl && !this.phaseLinesSaid.has(b.phase)) { this.phaseLinesSaid.add(b.phase); this.say(pl); } }
    for (const k of ['lowHullT', 'shieldT', 'comboT', 'allyT']) f[k] = Math.max(0, f[k] - dt);
    if (!P.alive) return;
    if (P.hull / P.maxHull < 0.3 && f.lowHullT <= 0) { f.lowHullT = 35; this.bark(BARKS.lowHull); }
    if (f.lastShield > 0 && P.shield <= 0 && P.maxShield > 0 && f.shieldT <= 0) { f.shieldT = 30; this.bark(BARKS.shieldDown); }
    f.lastShield = P.shield;
    if (g.combo >= 6 && f.lastCombo < 6 && f.comboT <= 0) { f.comboT = 40; this.bark(BARKS.combo); }
    f.lastCombo = g.combo;
    if (f.allyT <= 0) for (const w of this.persist) if (w.alive && w.allyKind === 'militia' && g.time - w.lastHit < 0.5 && w.hp < w.maxHp * 0.5) { f.allyT = 45; this.bark(BARKS.ally); break; }
  }

  onKill(u) { this.cur?.onKill?.(u); }
  onAllyLost(u) { this.cur?.onAllyLost?.(u); }
  onRetreat(u, r) { this.cur?.onRetreat?.(u, r); }
  onPickup(k) { this.cur?.onPickup?.(k); }
  anchor() { return this.cur ? this.cur.anchor() : super.anchor(); }
  status() {
    const s = this.cur ? this.cur.status() : { title: '', lines: [] };
    const n = this.stages.length;
    if (this.phase === 'between') return { title: 'Stand by to jump', lines: [{ text: `Next: objective ${this.si + 2}/${n}`, progress: Math.min(1, this.waitT / 4) }] };
    if (this.phase === 'finale') return { title: this.ch.title, lines: [{ text: 'All objectives complete' }] };
    return { ...s, title: `${n > 1 ? `${this.si + 1}/${n} · ` : ''}${s.title}` };
  }
}

export function createObjective(game, mission) {
  const map = {
    intercept: InterceptObjective, escort: EscortObjective, shieldgen: ShieldGenObjective, survive: SurviveObjective,
    comms: CommsObjective, acehunt: AceHuntObjective, colony: ColonyObjective, convoy: ConvoyObjective,
    derelict: DerelictObjective, escape: EscapeObjective, carrier: CarrierObjective, anomaly: AnomalyObjective,
    boss: BossObjective, bossrush: BossRushObjective, waves: WavesObjective, tutorial: TutorialObjective, story: StoryObjective,
  };
  STAGE_TYPES = map;
  const C = map[mission.objective] || InterceptObjective;
  return new C(game, mission);
}
