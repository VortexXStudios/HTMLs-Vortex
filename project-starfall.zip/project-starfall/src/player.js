// ============================================================================
// Player ship: flight model, health/shields/boost, abilities, damage intake.
// ============================================================================
import * as THREE from 'three';
import { SHIPS, ABILITIES } from './data.js';
import { buildPlayerShip } from './models.js';
import { PlayerWeapons } from './weapons.js';
import { RibbonTrail } from './effects.js';
import { ARENA_RADIUS } from './environment.js';
import { hexTexture } from './textures.js';
import { COSMETICS } from './data.js';

const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3(), tmpQ = new THREE.Quaternion();
const X = new THREE.Vector3(1, 0, 0), Y = new THREE.Vector3(0, 1, 0), Z = new THREE.Vector3(0, 0, 1);
const FLIP_TIME = 0.5;

export class Player {
  constructor(game, shipId, stats, cosmetics) {
    this.game = game;
    this.shipId = shipId;
    this.def = SHIPS[shipId];
    this.stats = stats;
    this.cosmetics = cosmetics;
    this.mesh = buildPlayerShip(shipId, cosmetics);
    this.mesh.userData.materials.hull.envMapIntensity = 1.2;
    game.scene.add(this.mesh);
    this.pos = this.mesh.position;
    this.quat = this.mesh.quaternion;
    this.vel = new THREE.Vector3();
    this.forward = new THREE.Vector3(0, 0, 1);
    this.up = new THREE.Vector3(0, 1, 0);
    this.right = new THREE.Vector3(-1, 0, 0);
    this.radius = this.mesh.userData.radius;
    const perks = game.runPerks || {};
    this.maxHull = stats.hull * (perks.hullMult || 1);
    this.hull = this.maxHull;
    this.maxShield = game.mutators.has('vampire') ? 0 : stats.shield;
    this.shield = this.maxShield;
    this.shieldDelay = 0;
    this.boost = stats.boostMax; this.boosting = false;
    this.alive = true;
    this.throttle = 0.6;
    this.rollVel = 0; this.pitchVel = 0; this.yawVel = 0;
    this.dashT = 0; this.dashCd = 0; this.invuln = 0; this.dashRoll = 0;
    this.kickT = 0;
    this.aegis = 0; this.overdrive = 0; this.cloak = 0; this.repairing = 0; this.chill = 0;
    this.ability = { id: stats.loadout.ability, def: ABILITIES[stats.loadout.ability], cd: 0 };
    this.weapons = new PlayerWeapons(game, this, stats.loadout, stats);
    const wt = COSMETICS[cosmetics.weapon]?.tint; if (wt) this.weapons.tint = wt;
    this.softTarget = null;
    this.hullDamageTaken = 0;
    this.reactiveCd = 0;
    this.lastDamageDir = new THREE.Vector3();
    this.disabled = false;
    this.bulwarkCollision = stats.trait === 'reinforced';
    this.outOfBounds = 0;
    this.trailStyle = COSMETICS[cosmetics.trail]?.trail || 'standard';
    // Trails
    const mats = this.mesh.userData.materials;
    this.trails = [];
    const len = this.trailStyle === 'long' ? 44 : 20;
    for (const e of this.mesh.userData.engines) {
      const t = new RibbonTrail(len, 0.32 * (this.def.size || 1), mats.engineColor, this.trailStyle);
      game.effects.addTrail(t); this.trails.push({ t, local: e });
    }
    // Aegis bubble
    this.bubble = new THREE.Mesh(new THREE.SphereGeometry(20, 32, 20), new THREE.MeshBasicMaterial({ color: new THREE.Color('#6ad8ff').multiplyScalar(1.5), map: hexTexture(), transparent: true, opacity: 0.25, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
    this.bubble.visible = false; this.mesh.add(this.bubble);
    // Shield hit shell (brief flash on impact)
    this.shell = new THREE.Mesh(new THREE.SphereGeometry(this.radius * 1.35, 24, 16), new THREE.MeshBasicMaterial({ color: new THREE.Color('#5ab8ff').multiplyScalar(1.6), map: hexTexture(), transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
    this.mesh.add(this.shell);
    this.engineLight = new THREE.PointLight(mats.engineColor, 0, 30, 2);
    this.engineLight.position.set(0, 0, -this.mesh.userData.length * 0.6);
    this.mesh.add(this.engineLight);
  }

  inCone(u, cos) { tmp.copy(u.pos).sub(this.pos).normalize(); return tmp.dot(this.forward) > cos; }

  kick(a) { this.kickT = Math.min(1, this.kickT + a * 0.2); }

  update(dt, input) {
    const g = this.game, st = this.stats;
    if (!this.alive) return;
    // --- orientation from virtual stick
    const sens = 1;
    const ag = st.agility * (this.chill > 0 ? 0.7 : 1);
    let sx = deadzone(input.stick.x), sy = deadzone(input.stick.y);
    // mouse aim: the cursor marks a direction and the ship turns to face it, settling when it gets there
    const aiming = input.mode === 'aim' && input.mouseAim && !input.usingGamepad && !input.touchSteer && g.camera;
    if (aiming) {
      const cam = g.camera, sens = input.sensitivity || 1;
      if (!this.aimDir) this.aimDir = this.forward.clone();
      if (input.locked) {
        const k = 0.0021 * sens;
        tmp.set(0, 1, 0).applyQuaternion(cam.quaternion); this.aimDir.applyAxisAngle(tmp, -input.aimDX * k);
        tmp.set(1, 0, 0).applyQuaternion(cam.quaternion); this.aimDir.applyAxisAngle(tmp, -input.aimDY * k * (input.invertY ? -1 : 1));
        this.aimDir.normalize();
      } else {
        // the point under the cursor at crosshair distance (320 m): putting the cursor on the crosshair means "hold course"
        const d = tmp.set(input.cursor.nx, -input.cursor.ny * (input.invertY ? -1 : 1), 0.5).unproject(cam).sub(cam.position).normalize();
        const oc = tmp2.copy(cam.position).sub(this.pos);
        const b = oc.dot(d), cc = oc.lengthSq() - 320 * 320;
        const r = -b + Math.sqrt(Math.max(0, b * b - cc));
        this.aimDir.copy(cam.position).addScaledVector(d, r).sub(this.pos).normalize();
      }
      input.aimDX = 0; input.aimDY = 0;
      // keep the aim point within reach so it never ends up behind the ship
      const c = this.aimDir.dot(this.forward);
      if (c < 0.42) this.aimDir.lerp(this.forward, (0.42 - c) / 1.42).normalize();
      const z = this.aimDir.dot(this.forward);
      const ex = Math.atan2(this.aimDir.dot(this.right), z), ey = Math.atan2(this.aimDir.dot(this.up), z);
      // sensitivity also sets how hard the ship chases the cursor (and its top turn rate)
      const gain = 3.2 * (0.6 + 0.4 * sens);
      sx = THREE.MathUtils.clamp(ex * gain, -1, 1) * (0.9 + 0.35 * Math.min(2, sens));
      sy = THREE.MathUtils.clamp(-ey * gain, -1, 1) * (0.9 + 0.35 * Math.min(2, sens));
    } else if (this.aimDir) this.aimDir.copy(this.forward);
    this.aiming = aiming;
    // aim magnetism: a gentle pull toward the soft target's lead point when it is near the crosshair
    let ax = 0, ay = 0;
    const T = g.tune, tg = this.softTarget;
    if (T && T.magnet > 0 && g.settings.aimAssist && tg && tg.alive && !(this.flipT > 0)) {
      const dist = tg.pos.distanceTo(this.pos);
      tmp.copy(tg.pos).addScaledVector(tg.vel || tmp2.set(0, 0, 0), Math.min(1.5, dist / 600)).sub(this.pos);
      const z = tmp.dot(this.forward);
      if (z > 0 && dist < 950) {
        const ex = Math.atan2(tmp.dot(this.right), z), ey = Math.atan2(tmp.dot(this.up), z);
        if (Math.hypot(ex, ey) < Math.acos(T.magnetCos)) {
          const w = T.magnet * (1 - Math.min(1, Math.hypot(sx, sy)) * 0.5) * (input.isDown('fire') ? 1.25 : 1);
          ax = THREE.MathUtils.clamp(ex * 3, -0.6, 0.6) * w; ay = THREE.MathUtils.clamp(-ey * 3, -0.6, 0.6) * w;
        }
      }
    }
    const flipping = this.flipT > 0;
    const yawRate = flipping ? 0 : -(sx + ax) * 1.9 * ag * sens, pitchRate = flipping ? 0 : (sy + ay) * 1.6 * ag * sens;
    let roll = 0;
    if (input.isDown('rollL')) roll -= 1;
    if (input.isDown('rollR')) roll += 1;
    const resp = aiming ? 18 : 8; // mouse aim responds almost instantly
    this.yawVel += (yawRate - this.yawVel) * Math.min(1, dt * resp);
    this.pitchVel += (pitchRate - this.pitchVel) * Math.min(1, dt * resp);
    this.rollVel += (roll * 2.6 * ag - this.rollVel) * Math.min(1, dt * 6);
    tmpQ.setFromAxisAngle(Y, this.yawVel * dt); this.quat.multiply(tmpQ);
    tmpQ.setFromAxisAngle(X, this.pitchVel * dt); this.quat.multiply(tmpQ);
    tmpQ.setFromAxisAngle(Z, this.rollVel * dt); this.quat.multiply(tmpQ);
    // quick turn: a half-second 180° swing that carries your momentum round with you
    if (flipping) {
      const step = Math.min(this.flipT, dt), ang = Math.PI * step / FLIP_TIME;
      this.flipT -= dt;
      tmpQ.setFromAxisAngle(Y, ang); this.quat.multiply(tmpQ);
      this.vel.applyAxisAngle(tmp.copy(Y).applyQuaternion(this.quat), ang);
    }
    // auto-level gently when not rolling (keeps horizon readable)
    if (!roll) {
      const upNow = tmp.copy(Y).applyQuaternion(this.quat);
      const fwd = tmp2.copy(Z).applyQuaternion(this.quat);
      const rightNow = new THREE.Vector3().crossVectors(upNow, fwd);
      const bankErr = rightNow.y; // >0 means banked
      const targetBank = -this.yawVel * 0.28; // bank into turns
      tmpQ.setFromAxisAngle(Z, -(bankErr - targetBank) * Math.min(1, dt * 2.2));
      this.quat.multiply(tmpQ);
    }
    this.quat.normalize();
    this.forward.copy(Z).applyQuaternion(this.quat);
    this.up.copy(Y).applyQuaternion(this.quat);
    this.right.copy(X).applyQuaternion(this.quat).negate(); // screen-right

    // --- throttle & boost
    let target = 0.55;
    if (input.isDown('thrust')) target = 1;
    if (input.isDown('brake')) target = 0.12;
    this.throttle += (target - this.throttle) * Math.min(1, dt * 3);
    const wantBoost = input.isDown('boost') && this.boost > 4 && !this.disabled;
    this.boosting = wantBoost;
    if (this.boosting) this.boost = Math.max(0, this.boost - 30 * dt);
    else this.boost = Math.min(st.boostMax, this.boost + st.boostRegen * dt);
    const od = this.overdrive > 0 ? 1.6 : 1;
    const chillMul = this.chill > 0 ? 0.65 : 1;
    let speed = (this.boosting ? st.boostSpeed : st.speed * (0.35 + this.throttle * 0.65)) * od * chillMul;
    const desired = tmp.copy(this.forward).multiplyScalar(speed);
    let strafe = 0;
    if (input.isDown('left')) strafe -= 1;
    if (input.isDown('right')) strafe += 1;
    desired.addScaledVector(this.right, strafe * st.speed * 0.55 * od);
    const lowg = g.mutators.has('lowgrav');
    const response = lowg ? 0.6 : 3.2;
    this.vel.lerp(desired, Math.min(1, dt * response * (this.boosting ? 1.3 : 1)));

    // --- evasive dash
    this.dashCd -= dt; this.flipCd = (this.flipCd || 0) - dt;
    const dashTap = input.pressed('dash');
    const doubleTap = dashTap && g.time - (this.lastDashTap ?? -9) < 0.32;
    if (dashTap) this.lastDashTap = g.time;
    if ((input.pressed('flip') || doubleTap) && this.flipCd <= 0 && !flipping) {
      if (this.boost >= 15) {
        this.boost -= 15; this.flipT = FLIP_TIME; if (this.aimDir) this.aimDir.applyAxisAngle(this.up, Math.PI); this.flipCd = 2.2; this.invuln = Math.max(this.invuln, 0.3);
        this.dashT = 0; this.lastDashTap = -9;
        g.audio.play('dash'); g.effects.sparks(this.pos, this.mesh.userData.materials.engineColor, 14, 90, 1.6, 0.45);
        g.hud.toast?.('QUICK TURN', 'info', 0.6);
      } else g.audio.play('error');
    } else if (dashTap && this.dashCd <= 0) {
      const cost = st.trait === 'slipstream' ? 18 : 30;
      if (this.boost >= cost) {
        this.boost -= cost; this.dashCd = 0.9; this.dashT = 0.35;
        const dir = strafe !== 0 ? strafe : (Math.random() < 0.5 ? -1 : 1);
        this.vel.addScaledVector(this.right, dir * 220);
        this.dashRoll = dir;
        this.invuln = st.mods.has('phasedash') ? 0.8 : 0.3;
        if (st.mods.has('phasedash')) this.weapons.ventHeat();
        g.audio.play('dash');
        g.effects.sparks(this.pos, this.mesh.userData.materials.engineColor, 10, 80, 1.6, 0.4);
      } else g.audio.play('error');
    }
    if (this.dashT > 0) {
      this.dashT -= dt;
      tmpQ.setFromAxisAngle(Z, this.dashRoll * Math.PI * 2 / 0.35 * dt);
      this.mesh.quaternion.multiply(tmpQ);
    }
    this.invuln = Math.max(0, this.invuln - dt);

    // --- move
    this.pos.addScaledVector(this.vel, dt);
    // arena boundary: warn then push back and damage
    const d = this.pos.length();
    const AR = g.arenaRadius || ARENA_RADIUS;
    if (d > AR) {
      this.outOfBounds += dt;
      const over = d - AR;
      this.vel.addScaledVector(tmp.copy(this.pos).normalize(), -over * 4 * dt);
      if (over > 160) { this.vel.addScaledVector(tmp.copy(this.pos).normalize(), -over * 3 * dt); if (Math.random() < dt * 2) g.damagePlayer(6, { pos: this.pos, environmental: true }); }
    } else this.outOfBounds = 0;

    // --- shields
    this.shieldDelay -= dt;
    if (this.shieldDelay <= 0 && this.shield < this.maxShield) this.shield = Math.min(this.maxShield, this.shield + st.shieldRegen * (g.runPerks?.shieldRegen || 1) * dt);
    this.shell.material.opacity = Math.max(0, this.shell.material.opacity - dt * 3);
    this.chill = Math.max(0, this.chill - dt);
    this.reactiveCd -= dt;

    // --- abilities
    this.ability.cd = Math.max(0, this.ability.cd - dt);
    if (input.pressed('ability') && !this.disabled) this.useAbility();
    this._tickAbilities(dt);

    // --- weapons
    if (input.pressed('swap')) this.weapons.swap();
    this.weapons.update(dt, input.isDown('fire'), input.pressed('secondary') || (input.isDown('secondary') && this.weapons.secondary.id !== 'torpedo'));

    // --- visuals
    this.kickT = Math.max(0, this.kickT - dt * 4);
    const pw = this.boosting ? 1.6 : 0.5 + this.throttle * 0.6;
    for (const f of this.mesh.userData.flames) { f.material.uniforms.uTime.value = g.time; f.material.uniforms.uPower.value = pw; f.scale.z = (this.boosting ? 9 : 5) * f.scale.x / 0.9 * (0.9 + Math.random() * 0.1); }
    const mats = this.mesh.userData.materials;
    if (mats.engineCycle) { const c = new THREE.Color().setHSL((g.time * 0.15) % 1, 1, 0.6); mats.glow.color.copy(c).multiplyScalar(1.8); for (const f of this.mesh.userData.flames) f.material.uniforms.uColor.value.copy(c); for (const t of this.trails) t.t.color.copy(c); }
    this.engineLight.intensity = pw * 25;
    this.mesh.updateMatrixWorld();
    for (const tr of this.trails) {
      tmp.copy(tr.local).applyMatrix4(this.mesh.matrixWorld);
      tr.t.update(tmp, g.camera, dt, this.boosting ? 1.4 : 0.5 + this.throttle * 0.5);
      this._trailExtras(tmp, dt);
    }
    // afterburner wake damages pursuers
    if (this.boosting && st.mods.has('afterburner')) {
      this._wakeT = (this._wakeT || 0) - dt;
      if (this._wakeT <= 0) { this._wakeT = 0.12; g.addHazard({ pos: this.pos.clone().addScaledVector(this.forward, -12), radius: 14, dps: 40, life: 1.6, team: 'player', color: '#ff7a2a' }); }
    }
  }

  _trailExtras(p, dt) {
    const g = this.game, s = this.trailStyle;
    const r = Math.random();
    if (s === 'ion' && r < 0.4) g.effects.sparks(p, '#bff6ff', 1, 15, 1.2, 0.6);
    else if (s === 'ember' && r < 0.5) g.effects.trailPuff(p, '#ff7a2a', 1.6, 0.8, tmp2.set((Math.random() - 0.5) * 10, (Math.random() - 0.5) * 10, (Math.random() - 0.5) * 10));
    else if (s === 'spectral' && r < 0.35) g.effects.trailPuff(p, '#7dff6a', 3, 1.2);
    else if (s === 'snow' && r < 0.4) g.effects.trailPuff(p, '#ffffff', 1.4, 1.2, tmp2.set(0, -6, 0));
    else if (s === 'petal' && r < 0.3) g.effects.trailPuff(p, '#ff9fd2', 1.8, 1.4, tmp2.set((Math.random() - 0.5) * 8, -4, 0));
    else if (s === 'confetti' && r < 0.5) g.effects.trailPuff(p, ['#ff5ce1', '#ffd04a', '#4ff0ff', '#7dff6a'][Math.floor(Math.random() * 4)], 1.5, 1.1, tmp2.set((Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20));
  }

  useAbility() {
    const g = this.game, st = this.stats, ab = this.ability, def = ab.def;
    if (ab.cd > 0) { g.audio.play('error'); return; }
    ab.cd = def.cooldown * st.abilityCd * (g.runPerks?.abilityCd || 1);
    const dur = def.duration * st.abilityPower;
    g.audio.play('ability');
    g.stats.abilityUses = (g.stats.abilityUses || 0) + 1;
    switch (ab.id) {
      case 'aegis': this.aegis = dur; this.bubble.visible = true; break;
      case 'overdrive': this.overdrive = dur; g.effects.ring(this.pos, 30, '#ffd04a', 0.5); break;
      case 'repair': this.repairing = dur; this._repairRate = def.amount * st.abilityPower / def.duration; g.audio.play('heal'); break;
      case 'emp': {
        const r = def.radius * st.abilityRadius;
        g.effects.ring(this.pos, r, '#7ab8ff', 0.7); g.effects.flash(this.pos, 30, '#9fd8ff', 0.3);
        g.audio.play('emp');
        for (const u of g.units) if (u.alive && u.team === 'enemy' && u.pos.distanceTo(this.pos) < r) { u.stunned = Math.max(u.stunned, dur); u.shield = 0; g.effects.sparks(u.pos, '#9fd8ff', 6, 50, 1.6, 0.5); }
        g.projectiles.clearTeam('enemy', this.pos, r);
        break;
      }
      case 'decoy': g.spawnDecoy(dur); break;
      case 'nova': {
        const r = def.radius * st.abilityRadius;
        g.effects.explosion(this.pos, 3, '#ffd06a', { debris: false });
        g.effects.ring(this.pos, r, '#ffe0a0', 0.8);
        g.audio.play('nova');
        g.damageArea(this.pos, r, def.damage * st.abilityPower * this.weapons.damageMult(), 'player', { weapon: 'nova', ability: true, falloff: 0.4 });
        g.projectiles.clearTeam('enemy', this.pos, r);
        break;
      }
      case 'timedilation': g.timeDilation = dur; g.audio.play('phase'); break;
      case 'cloak': this.cloak = dur; this._setCloakVisual(true); g.audio.play('cloak'); break;
    }
    g.hud.abilityUsed();
  }

  _tickAbilities(dt) {
    const g = this.game;
    if (this.aegis > 0) { this.aegis -= dt; this.bubble.rotation.y += dt; this.bubble.material.opacity = 0.18 + 0.08 * Math.sin(g.time * 8); if (this.aegis <= 0) this.bubble.visible = false; }
    if (this.overdrive > 0) { this.overdrive -= dt; if (Math.random() < 0.5) g.effects.sparks(this.pos, '#ffd04a', 1, 30, 1.2, 0.3); }
    if (this.repairing > 0) { this.repairing -= dt; this.hull = Math.min(this.maxHull, this.hull + this._repairRate * dt); if (Math.random() < 0.3) g.effects.sparks(this.pos, '#43ff8e', 1, 20, 1.5, 0.6); }
    if (this.cloak > 0) { this.cloak -= dt; if (this.cloak <= 0) this.breakCloak(); }
  }

  breakCloak() {
    if (this.cloak <= 0 && !this._cloakVisual) return;
    this.cloak = 0; this._setCloakVisual(false);
  }
  _setCloakVisual(on) {
    this._cloakVisual = on;
    const m = this.mesh.userData.materials;
    for (const k of ['hull', 'accent', 'dark', 'glass']) { m[k].transparent = on; m[k].opacity = on ? 0.18 : 1; m[k].needsUpdate = true; }
  }

  // Returns actual damage applied to hull
  takeDamage(amount, info = {}) {
    const g = this.game;
    if (!this.alive) return 0;
    if (this.invuln > 0 || this.aegis > 0 || g.cinematic) { if (this.aegis > 0) g.effects.sparks(info.pos || this.pos, '#6ad8ff', 4, 50, 1.5, 0.3); return 0; }
    if (info.dir) this.lastDamageDir.copy(info.dir).negate().normalize();
    else if (info.pos) this.lastDamageDir.copy(info.pos).sub(this.pos).normalize();
    g.hud.damageIndicator(this.lastDamageDir);
    if (info.chill) this.chill = 2.5;
    this.shieldDelay = 3;
    let rem = amount;
    if (this.shield > 0) {
      const absorbed = Math.min(this.shield, rem);
      this.shield -= absorbed; rem -= absorbed;
      this.shell.material.opacity = 0.6;
      g.audio.play('playerShieldHit', { volume: 0.7 });
      if (this.stats.mods.has('static') && info.source && info.source.alive && info.source.team === 'enemy') {
        g.effects.arc(this.pos, info.source.pos, '#9fd8ff', 8, 0.15);
        g.damageUnit(info.source, 22 * this.stats.damage, { source: 'player', weapon: 'static', pos: info.source.pos });
      }
      if (this.shield <= 0) {
        g.audio.play('shieldBreak'); g.effects.ring(this.pos, 20, '#5ab8ff', 0.4);
        g.hud.toast('SHIELDS DOWN', 'warn', 1);
        if (this.stats.mods.has('reactive') && this.reactiveCd <= 0) {
          this.reactiveCd = 8;
          g.effects.ring(this.pos, 120, '#7ab8ff', 0.6); g.audio.play('emp');
          for (const u of g.units) if (u.alive && u.team === 'enemy' && u.pos.distanceTo(this.pos) < 120) { u.stunned = 2; u.shield = 0; }
        }
      }
    }
    if (rem > 0) {
      if (this.bulwarkCollision && info.collision) rem *= 0.4;
      this.hull -= rem;
      this.hullDamageTaken += rem;
      g.audio.play('playerHullHit', { volume: 0.8 });
      g.effects.sparks(info.pos || this.pos, '#ffb070', 8, 70, 1.6, 0.4);
      g.effects.addShake(Math.min(0.8, rem / 25));
      g.hud.hullHit(rem / this.maxHull);
      if (this.hull <= 0) { this.hull = 0; g.playerDestroyed(); }
    }
    return rem;
  }

  heal(amount) { this.hull = Math.min(this.maxHull, this.hull + amount); }

  dispose() {
    this.weapons.dispose();
    for (const t of this.trails) this.game.effects.removeTrail(t.t);
    this.game.scene.remove(this.mesh);
    const m = this.mesh.userData.materials;
    for (const k of ['hull', 'accent', 'dark', 'glass', 'glow']) m[k].dispose();
    this.mesh.traverse(o => { if (o.material && o.material.isShaderMaterial) o.material.dispose(); });
    this.bubble.geometry.dispose(); this.bubble.material.dispose(); this.shell.geometry.dispose(); this.shell.material.dispose();
  }
}

function deadzone(v) { const a = Math.abs(v); if (a < 0.04) return 0; return Math.sign(v) * Math.pow((a - 0.04) / 0.96, 1.3); }
