// ============================================================================
// PROJECT STARFALL — application bootstrap & state machine
// ============================================================================
import { Renderer } from './render.js';
import { AudioSystem } from './audio.js';
import { Input } from './input.js';
import { TouchControls } from './touch.js';
import { HUD } from './hud.js';
import { Game } from './game.js';
import { MenuScene } from './menu3d.js';
import { UI } from './ui.js';
import { SaveManager, memoryStorage } from './save.js';
import { applyMissionResult, checkAchievements } from './progression.js';
import { getActiveEvents, readDevOverrides, eventInstanceKey } from './events.js';
import { touchClock, dayIndex } from './daily.js';
import { REGION_ORDER } from './data.js';

class App {
  constructor() {
    this.dev = readDevOverrides();
    // Storage (falls back to memory if localStorage is blocked)
    let storage;
    try { storage = window.localStorage; const k = '__starfall_test'; storage.setItem(k, '1'); storage.removeItem(k); this.storageOk = true; }
    catch (e) { storage = memoryStorage(); this.storageOk = false; }
    this.saveManager = new SaveManager(storage, () => this.now());
    this.saveManager.load();
    const save = this.saveManager.data;
    this.clockIssue = touchClock(save, this.now());
    this.saveManager.save();

    const canvas = document.getElementById('game');
    try { this.renderer = new Renderer(canvas); }
    catch (e) { document.getElementById('fatal').style.display = 'flex'; window.__bootFail?.('The 3D renderer could not start: ' + e.message); throw e; }
    this.renderer.applySettings(save.settings);
    this.audio = new AudioSystem();
    this.audio.setVolumes(save.settings);
    this.input = new Input(canvas);
    this.input.sensitivity = save.settings.mouseSensitivity; this.input.invertY = save.settings.invertY; this.input.mode = save.settings.mouseMode;
    this.hud = new HUD(document.getElementById('hud'));
    this.game = new Game(this);
    this.menu = new MenuScene(this);
    this.ui = new UI(this);
    this.touch = new TouchControls(this);
    this.state = 'splash';
    this.paused = false;
    this.last = performance.now();
    this.acc = 0;
    window.addEventListener('resize', () => this.renderer.resize());
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.onFocusLost(); else this.audio.resume(); });
    window.addEventListener('blur', () => this.onFocusLost());
    window.addEventListener('keydown', e => this.onKey(e));
    const gesture = () => { this.audio.init(); if (this.audio.music && !this.audio.music.playing) this.audio.music.start(this.state === 'mission' ? 'combat' : 'menu'); };
    window.addEventListener('pointerdown', gesture); window.addEventListener('keydown', gesture);
    this.ui.boot();
    document.getElementById('boot')?.remove();
    requestAnimationFrame(t => this.frame(t));
    window.__starfall = this; // handy for debugging & automated tests
  }

  now() { return this.dev.date ? this.dev.date.getTime() + (performance.now() - (this._t0 = this._t0 ?? performance.now())) : Date.now(); }
  nowDate() { return new Date(this.now()); }
  today() { return dayIndex(this.now()); }
  activeEvents() { return getActiveEvents(this.nowDate(), this.dev.dev ? this.dev.event : null); }
  eventKey(id) { return eventInstanceKey(id, this.nowDate()); }

  persist() {
    const ok = this.saveManager.save();
    if (!ok) this.ui.toast('Could not write save data — progress may not persist', 'warn');
    return ok;
  }

  onFocusLost() {
    if (this.state === 'mission' && !this.paused && this.game.active) this.pause(true);
    this.audio.suspend();
  }

  onKey(e) {
    if (e.code === 'Escape' || e.code === 'KeyP') {
      if (this.state === 'mission' && this.game.active && !this.game.choice) { this.pause(!this.paused); e.preventDefault(); }
      else if (this.state !== 'mission') this.ui.back();
    }
  }

  pause(on) {
    if (this.state !== 'mission') return;
    this.paused = on;
    document.body.classList.toggle('paused', on);
    if (on) { this.input.exitLock(); this.ui.showPause(); this.audio.stopAllLoops(); }
    else { this.ui.hidePause(); this.audio.resume(); this.input.requestLock(); this.last = performance.now(); if (this.game.active) this.audio.loop('engine', true, { volume: 0.05 }); }
  }

  // ------------------------------------------------------------------ flow
  launchMission(mission) {
    this.ui.hideAll();
    this.state = 'mission'; this.paused = false; document.body.classList.remove('paused');
    this.menu.active = false;
    this.currentMission = mission;
    if (!mission._original) mission._original = mission.modifiers.slice();
    this.audio.init();
    try { this.game.start(mission); }
    catch (e) { console.error(e); this.ui.toast('Mission failed to start: ' + e.message, 'warn'); this.toHangar(); return; }
    this.input.enabled = true;
    this.input.requestLock();
    this.saveManager.data.stats.lastMission = Date.now();
  }

  restartMission() {
    const m = this.currentMission;
    if (!m) return;
    this.game.cleanup();
    // regenerate a fresh copy (modifiers may have been mutated by Endless)
    const fresh = JSON.parse(JSON.stringify(m));
    if (m._original) fresh.modifiers = m._original.slice();
    this.launchMission(fresh);
  }

  abandonMission() {
    this.game.cleanup();
    this.paused = false; document.body.classList.remove('paused');
    this.input.exitLock();
    this.toHangar();
  }

  onMissionEnd(mission, result) {
    const save = this.saveManager.data;
    result.today = this.today();
    if (mission.mode === 'event' && mission.event) result.eventKey = this.eventKey(mission.event);
    if (result.cosmeticFind && !save.cosmetics.owned.includes(result.cosmeticFind)) save.cosmetics.owned.push(result.cosmeticFind);
    const before = { level: save.profile.level, currencies: { ...save.currencies } };
    const summary = applyMissionResult(save, mission, result, this.now());
    this.lastResult = { mission, result, summary };
    if (mission.mode === 'contract' && result.outcome === 'victory') save.universe.contracts.list = save.universe.contracts.list.filter(c => c.id !== mission.id);
    this.persist();
    this.input.exitLock();
    this.game.cleanup();
    this.state = 'results';
    this.ui.showResults(mission, result, summary, before);
  }

  toHangar(tab) {
    this.state = 'hangar';
    this.menu.active = true;
    this.menu.setMode('hangar');
    this.menu.setRegion(this._menuRegion(), this.activeEvents()[0] || null);
    this.renderer.setScene(this.menu.scene);
    this.audio.music?.setMode('menu');
    this.ui.showHangar(tab);
  }

  toTitle() {
    this.state = 'title';
    this.menu.active = true;
    this.menu.setMode('title');
    this.menu.setRegion(this._menuRegion(), this.activeEvents()[0] || null);
    this.renderer.setScene(this.menu.scene);
    const save = this.saveManager.data;
    this.menu.showShip(save.ships.selected, save.cosmetics.equipped[save.ships.selected]);
    this.audio.music?.setMode('menu');
    this.ui.showTitle();
  }

  _menuRegion() {
    const ev = this.activeEvents()[0];
    if (ev === 'halloween') return 'graveyard';
    if (ev === 'winter') return 'belt';
    if (ev === 'spring') return 'nebula';
    if (ev === 'summer') return 'volcanic';
    if (ev === 'anomaly') return 'megastructure';
    return REGION_ORDER[(this.today() % REGION_ORDER.length)];
  }

  // ------------------------------------------------------------------ loop
  frame(t) {
    requestAnimationFrame(tt => this.frame(tt));
    const cap = this.saveManager.data.settings.fpsCap;
    const elapsed = (t - this.last) / 1000;
    if (cap && elapsed < 1 / cap - 0.002) return;
    this.last = t;
    const dt = Math.min(0.1, Math.max(0, elapsed));
    this.renderer.resize();
    try {
      if (this.state === 'mission') {
        if (!this.paused && this.game.active) this.game.update(dt);
        else if (this.game.scene) { this.input.sample(dt); if (this.paused && this.input.gp?.pressed?.pause) this.pause(false); this.renderer.render(this.game.scene, this.renderer.camera); this.input.endFrame(); }
      } else if (this.state !== 'splash') {
        this.menu.update(dt);
        this.menu.render();
        this.input.endFrame();
      } else {
        this.input.endFrame();
      }
      this.ui.tick(dt);
      this.touch.update();
    } catch (e) {
      console.error('[Starfall] frame error', e);
      this._errors = (this._errors || 0) + 1;
      if (this._errors > 30 && this.state === 'mission') { this.ui.toast('A critical error occurred — returning to hangar', 'warn'); this.abandonMission(); this._errors = 0; }
    }
  }
}

function start() {
  try { new App(); }
  catch (e) { console.error(e); const f = document.getElementById('fatal'); if (f) { f.style.display = 'flex'; f.querySelector('p').textContent = 'Starfall could not start: ' + e.message; } window.__bootFail?.('Starfall could not start: ' + e.message); }
}
// (the import-map polyfill on old browsers can run this module after DOMContentLoaded)
if (document.readyState === 'loading') window.addEventListener('DOMContentLoaded', start); else start();
