// ============================================================================
// Progression: XP/levels, currencies, purchases, upgrades, achievements,
// mission reward resolution and universe evolution. Pure save mutation.
// ============================================================================
import {
  SHIPS, WEAPONS, SECONDARIES, ABILITIES, UPGRADE_BRANCHES, UPGRADE_MAX_TIER, upgradeCost,
  MODS, MOD_UNLOCK_TIER, MOD_COST, COSMETICS, ACHIEVEMENTS, xpForLevel, MAX_LEVEL, LEVEL_REWARDS,
  BOSSES, OPTIONAL_OBJECTIVES, REGION_ORDER, CAMPAIGN, RARITY,
} from './data.js';
import { recordHistory } from './missions.js';
import { EVENTS } from './events.js';
import { RNG } from './rng.js';

export const CURRENCY_KEYS = ['credits', 'alloy', 'cores', 'tokens'];

export function canAfford(save, cost) {
  if (!cost) return true;
  return CURRENCY_KEYS.every(k => (save.currencies[k] || 0) >= (cost[k] || 0));
}
export function spend(save, cost) {
  if (!canAfford(save, cost)) return false;
  for (const k of CURRENCY_KEYS) if (cost[k]) save.currencies[k] -= cost[k];
  return true;
}
export function formatCost(cost) {
  if (!cost) return 'Free';
  return CURRENCY_KEYS.filter(k => cost[k]).map(k => `${cost[k]} ${k === 'cores' ? 'cores' : k}`).join(' · ');
}

// Apply a reward bundle. Returns a list of human-readable lines.
export function grant(save, reward, lines = []) {
  if (!reward) return lines;
  for (const k of CURRENCY_KEYS) if (reward[k]) { save.currencies[k] += Math.round(reward[k]); lines.push({ kind: k, amount: Math.round(reward[k]) }); }
  if (reward.cosmetic && COSMETICS[reward.cosmetic]) {
    if (!save.cosmetics.owned.includes(reward.cosmetic)) {
      save.cosmetics.owned.push(reward.cosmetic);
      lines.push({ kind: 'cosmetic', id: reward.cosmetic });
    } else {
      save.currencies.credits += 300; lines.push({ kind: 'credits', amount: 300, note: 'duplicate cosmetic' });
    }
  }
  if (reward.boost === 'xp2') { save.daily.boosts.xp2 = (save.daily.boosts.xp2 || 0) + 2; lines.push({ kind: 'boost', id: 'xp2', text: 'Double XP for 2 missions' }); }
  if (reward.xp) addXp(save, reward.xp, lines);
  return lines;
}

export function addXp(save, amount, lines = []) {
  const p = save.profile;
  p.xp += amount; p.totalXp += amount;
  while (p.level < MAX_LEVEL && p.xp >= xpForLevel(p.level)) {
    p.xp -= xpForLevel(p.level);
    p.level += 1;
    lines.push({ kind: 'level', level: p.level });
    const lr = LEVEL_REWARDS[p.level];
    if (lr) grant(save, lr, lines);
  }
  if (p.level >= MAX_LEVEL) p.xp = Math.min(p.xp, xpForLevel(p.level));
  return lines;
}

// ---------------------------------------------------------------------------
// Purchases
// ---------------------------------------------------------------------------
export function unlockStatus(save, item) {
  const lvl = item.unlock?.level || 1;
  if (save.profile.level < lvl) return { ok: false, reason: `Requires pilot level ${lvl}` };
  if (item.cost && !canAfford(save, item.cost)) return { ok: false, reason: 'Insufficient funds', affordable: false, levelOk: true };
  return { ok: true };
}

export function buyShip(save, id) {
  const s = SHIPS[id];
  if (!s || save.ships.owned.includes(id)) return { ok: false, reason: 'Already owned' };
  const st = unlockStatus(save, s);
  if (!st.ok) return st;
  spend(save, s.cost);
  save.ships.owned.push(id);
  for (const w of s.loadout.primary) if (!save.arsenal.weapons.includes(w)) save.arsenal.weapons.push(w);
  if (!save.arsenal.secondaries.includes(s.loadout.secondary)) save.arsenal.secondaries.push(s.loadout.secondary);
  if (!save.arsenal.abilities.includes(s.loadout.ability)) save.arsenal.abilities.push(s.loadout.ability);
  return { ok: true };
}

export function buyItem(save, kind, id) {
  const table = { weapons: WEAPONS, secondaries: SECONDARIES, abilities: ABILITIES }[kind];
  const item = table && table[id];
  if (!item) return { ok: false, reason: 'Unknown item' };
  if (save.arsenal[kind].includes(id)) return { ok: false, reason: 'Already owned' };
  const st = unlockStatus(save, item);
  if (!st.ok) return st;
  spend(save, item.cost);
  save.arsenal[kind].push(id);
  return { ok: true };
}

export function buyUpgrade(save, branch) {
  if (!UPGRADE_BRANCHES[branch]) return { ok: false, reason: 'Unknown upgrade' };
  const tier = save.upgrades[branch];
  if (tier >= UPGRADE_MAX_TIER) return { ok: false, reason: 'Maxed' };
  const cost = upgradeCost(branch, tier + 1);
  if (!canAfford(save, cost)) return { ok: false, reason: 'Insufficient funds' };
  spend(save, cost);
  save.upgrades[branch] = tier + 1;
  return { ok: true, tier: tier + 1 };
}

export function buyMod(save, modId) {
  const m = MODS[modId];
  if (!m) return { ok: false, reason: 'Unknown mod' };
  if (save.mods.owned.includes(modId)) return { ok: false, reason: 'Already owned' };
  if (save.upgrades[m.branch] < MOD_UNLOCK_TIER) return { ok: false, reason: `Requires ${UPGRADE_BRANCHES[m.branch].name} tier ${MOD_UNLOCK_TIER}` };
  if (!canAfford(save, MOD_COST)) return { ok: false, reason: 'Insufficient funds' };
  spend(save, MOD_COST);
  save.mods.owned.push(modId);
  save.mods.equipped[m.branch] = modId;
  return { ok: true };
}
export function equipMod(save, modId) {
  const m = MODS[modId];
  if (!m || !save.mods.owned.includes(modId)) return false;
  if (save.mods.equipped[m.branch] === modId) delete save.mods.equipped[m.branch];
  else save.mods.equipped[m.branch] = modId;
  return true;
}
export function activeMods(save) { return new Set(Object.values(save.mods.equipped)); }

export function buyCosmetic(save, id) {
  const c = COSMETICS[id];
  if (!c || !c.price) return { ok: false, reason: 'Not for sale' };
  if (save.cosmetics.owned.includes(id)) return { ok: false, reason: 'Already owned' };
  if (!canAfford(save, c.price)) return { ok: false, reason: 'Insufficient funds' };
  spend(save, c.price);
  save.cosmetics.owned.push(id);
  return { ok: true };
}
export function equipCosmetic(save, shipId, id) {
  const c = COSMETICS[id];
  if (!c || !save.cosmetics.owned.includes(id) || !save.cosmetics.equipped[shipId]) return false;
  save.cosmetics.equipped[shipId][c.type] = id;
  return true;
}
export function setLoadout(save, shipId, slot, value, index = 0) {
  const lo = save.ships.loadouts[shipId];
  if (!lo) return false;
  if (slot === 'primary') {
    if (!save.arsenal.weapons.includes(value)) return false;
    const other = lo.primary.indexOf(value);
    if (other >= 0 && other !== index) lo.primary[other] = lo.primary[index]; // swap
    lo.primary[index] = value;
  } else if (slot === 'secondary') {
    if (!save.arsenal.secondaries.includes(value)) return false;
    lo.secondary = value;
  } else if (slot === 'ability') {
    if (!save.arsenal.abilities.includes(value)) return false;
    lo.ability = value;
  } else return false;
  return true;
}

// ---------------------------------------------------------------------------
// Derived combat stats (used by gameplay + upgrade comparison UI)
// ---------------------------------------------------------------------------
export function computeShipStats(save, shipId, upgradesOverride = null) {
  const s = SHIPS[shipId];
  const u = upgradesOverride || save.upgrades;
  const B = UPGRADE_BRANCHES;
  const t = k => (u[k] || 0) * B[k].per;
  const mods = activeMods(save);
  const lo = save.ships.loadouts[shipId];
  return {
    hull: Math.round(s.hull * (1 + t('hull'))),
    shield: Math.round(s.shield * (1 + t('shield'))),
    shieldRegen: 14 * (1 + t('shield') * 1.5),
    speed: 120 * s.speed * (1 + t('engine')),
    boostSpeed: 240 * s.speed * (1 + t('engine')),
    boostMax: 100 * s.boost * (1 + t('engine') * 1.5),
    boostRegen: 22 * (1 + t('energy')),
    agility: s.agility,
    damage: 1 + t('damage'),
    fireRate: 1 + t('firerate'),
    crit: 0.05 + t('crit'),
    ammo: 1 + t('missiles'),
    cooling: 38 * (1 + t('energy')) * (s.traitId === 'steady' ? 1.1 : 1),
    heatMult: s.traitId === 'steady' ? 0.9 : 1,
    abilityCd: (1 - t('ability')) * (s.traitId === 'resonance' ? 0.75 : 1),
    abilityPower: (1 + t('ability')) * (mods.has('amplify') ? 1.5 : 1),
    abilityRadius: mods.has('amplify') ? 1.3 : 1,
    lootRadius: 40 * (1 + t('loot')),
    trait: s.traitId,
    mods,
    loadout: lo,
    size: s.size,
  };
}

// ---------------------------------------------------------------------------
// Achievements
// ---------------------------------------------------------------------------
export function derivedStats(save) {
  const st = save.stats;
  return {
    ...st,
    level: save.profile.level,
    shipsOwned: save.ships.owned.length,
    cosmeticsOwned: save.cosmetics.owned.length,
    maxBranch: Math.max(...Object.values(save.upgrades)),
    uniqueBosses: ['dreadnought', 'swarmqueen', 'phantom', 'anomaly'].filter(b => (st.bossesDefeated[b] || 0) > 0).length,
    bestStreak: save.daily.bestStreak,
  };
}

export function achievementProgress(save, a) {
  const d = derivedStats(save);
  return Math.min(1, (d[a.stat] || 0) / a.goal);
}

export function checkAchievements(save, now = Date.now()) {
  const d = derivedStats(save);
  const unlocked = [];
  for (const a of ACHIEVEMENTS) {
    if (save.achievements[a.id]) continue;
    if ((d[a.stat] || 0) >= a.goal) {
      save.achievements[a.id] = now;
      const lines = grant(save, a.reward);
      unlocked.push({ achievement: a, lines });
    }
  }
  // Achievements can unlock other achievements (e.g., cosmetics count) — one extra pass
  if (unlocked.length) {
    const more = checkAchievements(save, now);
    unlocked.push(...more);
  }
  return unlocked;
}

// ---------------------------------------------------------------------------
// Mission results -> rewards, stats, universe evolution
// ---------------------------------------------------------------------------
/**
 * result = {
 *  outcome: 'victory'|'defeat'|'retreat', score, time, kills, killsByType:{}, bossesKilled:[], aceKills,
 *  secondaryKills, bestCombo, wave, loot:{credits,alloy,cores,tokens}, optionalDone:[], hullDamage,
 *  discoveries:[], branch:{...}, weaponsUsed:[], encountered:{enemies:[], bosses:[]}, ratings:[]
 * }
 */
export function applyMissionResult(save, mission, result, now = Date.now()) {
  const st = save.stats;
  const lines = [];
  const breakdown = [];
  const won = result.outcome === 'victory';
  const retreated = result.outcome === 'retreat';

  st.missionsPlayed++;
  st.kills += result.kills || 0;
  st.secondaryKills += result.secondaryKills || 0;
  st.aceKills += result.aceKills || 0;
  st.bestCombo = Math.max(st.bestCombo, result.bestCombo || 0);
  st.playTime += result.time || 0;
  st.damageDealt += result.damageDealt || 0;
  st.highScore = Math.max(st.highScore, result.score || 0);
  for (const [k, v] of Object.entries(result.killsByType || {})) st.enemyKills[k] = (st.enemyKills[k] || 0) + v;
  for (const b of result.bossesKilled || []) { st.bossKills++; st.bossesDefeated[b] = (st.bossesDefeated[b] || 0) + 1; }
  for (const e of result.encountered?.enemies || []) save.universe.encountered.enemies[e] = (save.universe.encountered.enemies[e] || 0) + 1;
  for (const b of result.encountered?.bosses || []) save.universe.encountered.bosses[b] = (save.universe.encountered.bosses[b] || 0) + 1;
  if (won) st.missionsWon++; else if (retreated) st.retreats++; else { st.missionsLost++; st.deaths++; }
  if (won && (result.hullDamage || 0) <= 0.01) st.flawless++;

  // ---- reward computation
  const base = mission.rewards || { credits: 0, alloy: 0, xp: 0, cores: 0 };
  let factor = won ? 1 : retreated ? 0.4 : 0.25;
  const reward = { credits: 0, alloy: 0, cores: 0, tokens: 0, xp: 0 };

  if (mission.mode === 'endless' || mission.mode === 'daily' || mission.mode === 'experimental') {
    const w = result.wave || 0;
    reward.credits = Math.round((80 * w + (result.score || 0) * 0.02) * (mission.mode === 'experimental' ? 1.3 : 1));
    reward.alloy = Math.round(w * 2.2);
    reward.xp = Math.round(90 * w + (result.score || 0) * 0.015);
    reward.cores = Math.floor(w / 8);
    factor = 1;
    breakdown.push({ label: `Waves cleared: ${w}`, credits: reward.credits });
  } else {
    reward.credits = Math.round(base.credits * factor);
    reward.alloy = Math.round(base.alloy * factor);
    reward.xp = Math.round(base.xp * (won ? 1 : 0.5));
    reward.cores = won ? (base.cores || 0) : 0;
    reward.tokens = Math.round((base.tokens || 0) * factor);
    breakdown.push({ label: won ? 'Mission complete' : retreated ? 'Tactical retreat (40%)' : 'Mission failed (25%)', credits: reward.credits });
  }
  // Optional objectives (risk/reward)
  for (const o of result.optionalDone || []) {
    const r = OPTIONAL_OBJECTIVES[o]?.reward;
    if (!r || !won) continue;
    for (const k of Object.keys(r)) reward[k] = (reward[k] || 0) + r[k];
    breakdown.push({ label: `Optional: ${OPTIONAL_OBJECTIVES[o].name}`, credits: r.credits || 0 });
  }
  // Battlefield loot (always kept)
  const loot = result.loot || {};
  for (const k of ['credits', 'alloy', 'cores', 'tokens']) if (loot[k]) reward[k] += loot[k];
  if (loot.credits || loot.alloy) breakdown.push({ label: 'Battlefield salvage', credits: loot.credits || 0, alloy: loot.alloy || 0 });
  // Boss rewards
  for (const b of result.bossesKilled || []) {
    const br = BOSSES[b]?.rewards;
    if (!br) continue;
    const firstKill = (st.bossesDefeated[b] || 0) === 1;
    const m = firstKill ? 1 : 0.5;
    reward.credits += br.credits * m; reward.alloy += br.alloy * m; reward.cores += Math.ceil(br.cores * m);
    reward.xp += br.xp * m; if (br.tokens) reward.tokens += br.tokens;
    breakdown.push({ label: `${BOSSES[b].name} destroyed${firstKill ? ' (first kill!)' : ''}`, credits: br.credits * m });
    // Cosmetic drop from boss reward table
    const rng = new RNG(`${b}-${st.bossKills}-${now}`);
    const pool = br.cosmeticPool.filter(c => !save.cosmetics.owned.includes(c));
    if (pool.length && (firstKill || rng.chance(0.35))) {
      reward.cosmetic = rng.pick(pool);
    }
  }
  // Event bonuses
  if (mission.event && EVENTS[mission.event]) {
    const ev = EVENTS[mission.event];
    if (ev.bonusRewards) { reward.credits *= ev.bonusRewards; reward.xp *= ev.bonusRewards; }
    if (won) reward.tokens += Math.round(4 * (ev.tokenRate || 1));
  }
  // Double XP boost from daily streak
  if (save.daily.boosts.xp2 > 0 && reward.xp > 0) {
    reward.xp *= 2; save.daily.boosts.xp2--; breakdown.push({ label: 'Double XP boost', xp: reward.xp / 2 });
  }
  // Daily mission bonus (once per day)
  if (mission.daily && won) {
    const today = result.today;
    if (save.daily.missionDay !== today) {
      save.daily.missionDay = today;
      reward.cores += 1; reward.alloy += 10;
      breakdown.push({ label: 'Daily Op bonus', alloy: 10 });
    }
  }
  for (const k of Object.keys(reward)) if (typeof reward[k] === 'number') reward[k] = Math.round(reward[k]);
  grant(save, reward, lines);

  // ---- Mode-specific bookkeeping
  if (mission.mode === 'campaign' && won && mission.campaignId) {
    if (!save.campaign.completed.includes(mission.campaignId)) save.campaign.completed.push(mission.campaignId);
    if (mission.campaignId === 'c4') save.campaign.phantomEscaped = true;
    if (save.campaign.completed.length >= CAMPAIGN.length) st.campaignDone = 1;
  }
  if (mission.mode === 'endless') {
    st.bestWave = Math.max(st.bestWave, result.wave || 0);
    pushRecord(save.records.endless, { score: result.score, wave: result.wave, date: now, ship: save.ships.selected });
  }
  if (mission.mode === 'daily') {
    const today = result.today;
    const prev = save.daily.challengeBest[today] || 0;
    if ((result.score || 0) > prev) save.daily.challengeBest[today] = result.score || 0;
    if (save.daily.challengeDay !== today && (result.wave || 0) >= (mission.waves || 6)) { st.dailyChallenges++; save.daily.challengeDay = today; }
    pushRecord(save.records.daily, { score: result.score, wave: result.wave, date: now, day: today });
    // keep only the 14 most recent day bests
    const keys = Object.keys(save.daily.challengeBest).map(Number).sort((a, b) => b - a);
    for (const k of keys.slice(14)) delete save.daily.challengeBest[k];
  }
  if (mission.mode === 'experimental') {
    if (won) st.experimentalWins++;
    pushRecord(save.records.experimental, { score: result.score, wave: result.wave, date: now });
  }
  if (mission.mode === 'bossrush') {
    if (won) st.bossRushWins++;
    pushRecord(save.records.bossrush, { score: result.score, time: result.time, date: now, rating: result.rating, difficulty: mission.difficultyName });
  }
  if (mission.mode === 'contract') {
    pushRecord(save.records.contracts, { score: result.score, date: now, title: mission.title });
    // a completed contract rotates out
    if (won) {
      save.universe.contracts.list = save.universe.contracts.list.filter(c => c.id !== mission.id);
    }
  }
  if (mission.mode === 'event' && won && mission.event) {
    st.eventMissions++;
    const key = result.eventKey || mission.event;
    const prog = save.events.progress[key] || { completed: [] };
    if (!prog.completed.includes(mission.eventMissionId)) prog.completed.push(mission.eventMissionId);
    save.events.progress[key] = prog;
  }
  for (const disc of result.discoveries || []) {
    if (!save.universe.discoveries.includes(disc)) { save.universe.discoveries.push(disc); st.discoveries++; }
  }

  // ---- Universe evolution
  const followUps = evolveUniverse(save, mission, result);

  // ---- Mission history (director memory)
  if (mission.objective) save.universe.history = recordHistory(save.universe.history, mission.objective);
  save.universe.missionCounter++;

  const achievements = checkAchievements(save, now);
  return { reward, lines, breakdown, achievements, followUps };
}

function pushRecord(list, entry) {
  list.push(entry);
  list.sort((a, b) => (b.score || 0) - (a.score || 0));
  if (list.length > 10) list.length = 10;
}

let followSeq = 0;
export function evolveUniverse(save, mission, result) {
  const u = save.universe;
  const created = [];
  const won = result.outcome === 'victory';
  const region = mission.region;
  if (!REGION_ORDER.includes(region)) return created;
  // Factions react where you intervene; quiet regions settle down.
  for (const r of REGION_ORDER) {
    if (r === region) u.threat[r] = Math.min(3, u.threat[r] + (won ? 0.12 : 0.05));
    else u.threat[r] = Math.max(0.6, u.threat[r] + (1 - u.threat[r]) * 0.08);
  }
  if (mission.followUp) u.followUps = u.followUps.filter(f => f.id !== mission.followUp);
  const add = f => {
    if (u.followUps.length >= 4 || u.followUps.some(x => x.kind === f.kind && x.region === f.region)) return;
    f.id = `${f.kind}-${region}-${u.missionCounter}-${followSeq++}`;
    u.followUps.push(f); created.push(f);
  };
  const b = result.branch || {};
  if (u.threat[region] >= 1.6 && won && mission.objective !== 'carrier') {
    add({ kind: 'retaliation', region, objective: 'carrier', difficulty: 1.4 + (u.threat[region] - 1) * 0.5, title: 'Retaliation Strike',
      brief: `Your raids in ${region === 'belt' ? 'the belt' : 'this region'} have drawn heavy attention. A carrier group is moving in to make an example of you.`, rewardMult: 1.5 });
  }
  if (mission.objective === 'intercept' && won && b.stationHp != null && b.stationHp < 0.5) {
    add({ kind: 'rescue', region, objective: 'escort', difficulty: 1.3, title: 'Evacuation Run', brief: 'The station you saved is venting atmosphere. Escort the evacuation ship clear of the debris field.', rewardMult: 1.3 });
  }
  if (mission.objective === 'escort' && won && b.allyHp != null && b.allyHp > 0.6) {
    add({ kind: 'favor', region, objective: 'shieldgen', difficulty: 1.4, title: 'Fleet Gratitude', brief: 'The Resolute\'s crew owes you. They will fly with you against a cruiser group — allied wing attached.', modifiers: ['allies'], rewardMult: 1.4 });
  }
  if (mission.objective === 'comms' && b.reinforcementsCalled) {
    add({ kind: 'reinforced', region, objective: 'intercept', difficulty: 1.6, title: 'The Call Was Answered', brief: 'The reinforcement call went through. A second Dominion fleet is en route. Stop it.', rewardMult: 1.4 });
  }
  if (mission.objective === 'acehunt' && b.aceEscaped && mission.elite) {
    add({ kind: 'rival', region, objective: 'acehunt', difficulty: 1.7, title: `${mission.elite.name} Returns`, brief: `${mission.elite.name} survived your last encounter and has been spotted again. They have adapted.`, rewardMult: 1.6 });
  }
  if (result.discoveries?.length) {
    add({ kind: 'discovery', region, objective: 'anomaly', difficulty: 1.5, title: 'Echoes of the Lattice', brief: 'The artifact you recovered points to a hidden rift. Something waits there.', rewardMult: 1.6 });
  }
  return created;
}

// Rarity display helper
export function rarityOf(id) { return RARITY[COSMETICS[id]?.rarity] || RARITY.common; }
