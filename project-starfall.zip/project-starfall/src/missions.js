// ============================================================================
// Procedural mission generation & encounter composition (pure / testable).
// ============================================================================
import { resolveChapter } from './story.js';
import { RNG, hashString } from './rng.js';
import {
  OBJECTIVES, MODIFIERS, REGIONS, REGION_ORDER, FACTIONS, ENEMIES, VARIANTS, OPTIONAL_OBJECTIVES,
  BOSSES, ACE_NAMES, CAMPAIGN, MUTATORS,
} from './data.js';
import { EVENTS } from './events.js';

const OP_A = ['Iron', 'Silent', 'Crimson', 'Hollow', 'Broken', 'Distant', 'Burning', 'Frozen', 'Shattered', 'Black', 'Pale', 'Last', 'Sudden', 'Falling', 'Rising'];
const OP_B = ['Lance', 'Horizon', 'Anvil', 'Tide', 'Veil', 'Spear', 'Lantern', 'Comet', 'Vigil', 'Harbor', 'Echo', 'Gauntlet', 'Ember', 'Crown', 'Meridian'];

const BRIEFS = {
  intercept: f => `${f} invasion group inbound on a civilian refinery. Engage before they reach weapons range of the station.`,
  escort: f => `The battleship ISS Resolute is dead in space with ${f} hunters closing. Keep her alive while engineers restart the drives.`,
  shieldgen: f => `A ${f} cruiser is hiding behind a shield lattice. Knock out the generators and finish it.`,
  survive: f => `A rogue asteroid storm is crossing the sector and a ${f} pursuit wing wants you dead inside it. Stay alive.`,
  comms: f => `${f} forces are coordinating through a relay array. Destroy the dishes before the reinforcement call completes.`,
  acehunt: f => `Intel reports a named ${f} ace in the area. Expect them to retreat, regroup, and change tactics.`,
  colony: f => `${f} raiders are hitting the mining colony from multiple vectors. Protect the habitat domes.`,
  convoy: f => `A ${f} convoy is moving energy cores. Crack the freighters, grab the cores, get out before they jump.`,
  derelict: f => `An abandoned warship is broadcasting an old distress code. Scan it. Expect company — ${f} activity nearby.`,
  escape: f => `Halcyon platform is collapsing. Race through the escape gates — ${f} fighters will try to box you in.`,
  carrier: f => `A ${f} carrier is launching fighters non-stop. Kill its engines and turrets, then breach the reactor.`,
  anomaly: f => `An unstable rift is being fed by crystal pylons. Enter, destroy the pylons, and survive whatever ${f} forces guard it.`,
  boss: f => `A major ${f} threat has entered the sector. All wings, engage.`,
};

export function missionTitle(rng) { return `Operation ${rng.pick(OP_A)} ${rng.pick(OP_B)}`; }

export function tierFromDifficulty(d) { return Math.max(1, Math.min(5, Math.round((d - 0.8) * 3) + 1)); }

export function pickObjective(rng, region, history = [], exclude = []) {
  const last = history.slice(-3);
  const lastTags = history.length ? (OBJECTIVES[history[history.length - 1]]?.tags || []) : [];
  const entries = [];
  for (const [id, o] of Object.entries(OBJECTIVES)) {
    if (id === 'boss' || exclude.includes(id)) continue;
    let w = o.regions.includes(region) ? 3 : 0.4;
    if (last.includes(id)) w *= 0.08;              // strongly avoid recent repeats
    if (o.tags.some(t => lastTags.includes(t))) w *= 0.5; // vary the *structure*, not just the name
    entries.push([id, w]);
  }
  return rng.weighted(entries);
}

export function pickModifiers(rng, count, region, objective, extra = []) {
  const pool = Object.keys(MODIFIERS).filter(m => !(MODIFIERS[m].excludes || []).includes(region));
  const out = extra.slice();
  const conflicts = { glass: ['ironclad'], ironclad: ['glass'], allies: ['hunters'], hunters: ['allies'] };
  let guard = 0;
  while (out.length < count + extra.length && guard++ < 50) {
    const m = rng.pick(pool);
    if (out.includes(m)) continue;
    if ((conflicts[m] || []).some(c => out.includes(c))) continue;
    if (objective === 'escape' && m === 'allies') continue;
    out.push(m);
  }
  return out;
}

export function makeAce(rng, faction) {
  const personality = rng.pick(Object.keys(ACE_NAMES.personalities));
  return {
    name: `${rng.pick(ACE_NAMES.first)} ${rng.pick(ACE_NAMES.last)}`,
    personality, faction,
    variant: rng.pick(['veteran', 'overcharged', 'shielded', 'swift']),
  };
}

export function rewardPreview(m) {
  const modSum = m.modifiers.reduce((a, id) => a + (MODIFIERS[id]?.reward || 0), 0);
  const regionMult = REGIONS[m.region]?.rewardMult || 1;
  const mult = Math.max(0.6, (1 + modSum) * regionMult * (m.rewardMult || 1));
  const d = m.difficulty;
  const r = {
    credits: Math.round(260 * d * mult / 10) * 10,
    alloy: Math.round(5 * d * mult),
    xp: Math.round(240 * d * mult),
    cores: d >= 1.8 || m.boss ? 1 : 0,
  };
  if (m.boss && BOSSES[m.boss]) { r.credits += BOSSES[m.boss].rewards.credits * 0.5; r.cores += 1; }
  if (m.event) r.tokens = Math.round(6 * d * (EVENTS[m.event]?.tokenRate || 1));
  return r;
}

/**
 * Generate a mission.
 * opts: { seed, mode, region, objective, difficulty, faction, history, threat, activeEvents, boss, optional, title, brief }
 */
export function generateMission(opts = {}) {
  const seed = opts.seed ?? `m-${Date.now()}`;
  const rng = new RNG(typeof seed === 'number' ? seed : hashString(String(seed)));
  const history = opts.history || [];
  const events = opts.activeEvents || [];
  const region = opts.region || rng.pick(REGION_ORDER);
  const R = REGIONS[region];
  const threat = (opts.threat && opts.threat[region]) || 1;
  let difficulty = (opts.difficulty ?? rng.range(1, 1.6)) * (opts.mode === 'campaign' ? 1 : (0.85 + 0.15 * threat));
  difficulty = Math.round(difficulty * 100) / 100;

  const objective = opts.objective || (opts.boss ? 'boss' : pickObjective(rng, region, history, opts.excludeObjectives || []));
  const faction = opts.faction || rng.pick(R.factions);
  const altFaction = rng.chance(0.3) ? rng.pick(Object.keys(FACTIONS).filter(f => f !== faction)) : null;

  // Modifier count scales with difficulty; boss & campaign missions get fewer.
  let modCount = opts.modCount ?? (difficulty < 1.2 ? rng.int(0, 1) : difficulty < 1.7 ? rng.int(1, 2) : rng.int(2, 3));
  if (objective === 'boss' || opts.mode === 'campaign') modCount = Math.min(modCount, opts.mode === 'campaign' ? 0 : 1);
  const modifiers = opts.modifiers || pickModifiers(rng, modCount, region, objective);

  // Optional objectives
  const optPool = Object.keys(OPTIONAL_OBJECTIVES).filter(o => o !== 'elite');
  let optional = opts.optional || rng.shuffle(optPool).slice(0, objective === 'boss' ? 1 : 2);

  // Elite ace (named) — from objective or random encounter roll
  let elite = null;
  if (objective === 'acehunt' || (objective !== 'boss' && (modifiers.includes('hunters') || rng.chance(0.18 + 0.1 * (difficulty - 1))))) {
    elite = makeAce(rng, faction);
    if (objective !== 'acehunt' && !optional.includes('elite')) optional = optional.concat('elite');
  }

  // Event flavour
  let event = null, variantPool = [];
  for (const e of events) {
    const ev = EVENTS[e];
    if (!ev) continue;
    event = event || e;
    if (ev.enemyVariant) variantPool.push([ev.enemyVariant, ev.variantChance]);
  }
  for (const v of ['armored', 'overcharged', 'veteran', 'swift', 'shielded']) variantPool.push([v, 0.04 * difficulty]);
  if (modifiers.includes('ironclad')) variantPool.push(['armored', 0.7]);

  // Surprise encounter roll: neutral trader, hidden cache, or ambush
  let surprise = null;
  if (objective !== 'boss' && objective !== 'escape') {
    surprise = rng.weighted([[null, 6], ['neutral', 2], ['cache', 1.2], ['ambush', 1.2], ['discovery', 0.4]]) ?? null;
  }

  const boss = opts.boss || (objective === 'boss' ? rng.pick(['dreadnought', 'swarmqueen', 'phantom', 'anomaly']) : null);
  const bossFaction = boss ? BOSSES[boss].faction : faction;

  const m = {
    id: `${opts.mode || 'contract'}-${hashString(String(seed)).toString(36)}`,
    seed: String(seed),
    mode: opts.mode || 'contract',
    title: opts.title || (boss ? BOSSES[boss].name : missionTitle(rng)),
    brief: opts.brief || BRIEFS[objective](FACTIONS[boss ? bossFaction : faction].name),
    region, objective, faction: boss ? bossFaction : faction, altFaction,
    difficulty, tier: tierFromDifficulty(difficulty),
    modifiers, optional, elite, event, variantPool, surprise,
    boss, bossVariant: opts.bossVariant || null,
    phantomRetreat: !!opts.phantomRetreat,
    parTime: objective === 'boss' ? 300 : objective === 'escape' ? 150 : 240,
    rewardMult: opts.rewardMult || 1,
    campaignId: opts.campaignId || null,
    eventMissionId: opts.eventMissionId || null,
    followUp: opts.followUp || null,
    mutators: opts.mutators || [],
  };
  m.rewards = rewardPreview(m);
  return m;
}

// ---------------------------------------------------------------------------
// Campaign, contracts, daily, event, experimental, boss rush builders
// ---------------------------------------------------------------------------
export function campaignMission(index, save, activeEvents = []) {
  const base = CAMPAIGN[index];
  if (!base) return null;
  let choices = save?.campaign?.choices || {};
  // a 'before' choice not made yet (the hangar asks first): fall back to the first option so the chapter is playable
  if (base.choice?.when === 'before' && !choices[base.choice.id]) choices = { ...choices, [base.choice.id]: base.choice.options[0].id };
  const c = resolveChapter(base, choices);
  const stages = c.stages || [];
  const bossStage = stages.find(s => s.obj === 'boss');
  const m = generateMission({
    seed: `campaign-${c.id}`, mode: 'campaign', region: c.region, objective: 'story', faction: c.faction,
    difficulty: c.difficulty, boss: bossStage?.m?.boss || null, optional: c.optional || (bossStage ? ['nohull'] : ['combo', 'variety']),
    title: `${index + 1}. ${c.title}`, brief: c.brief, activeEvents, campaignId: c.id, modifiers: [],
    history: save?.universe?.history || [], rewardMult: 1 + 0.35 * Math.max(0, stages.length - 1),
  });
  // the story drives encounters itself: no random aces, surprises or top-level boss
  m.elite = null; m.surprise = null; m.boss = null;
  m.story = c; m.storyIndex = index; m.storyChoices = { ...choices };
  m.parTime = 170 * Math.max(1, stages.length);
  m.act = c.act;
  return m;
}
export function needsStoryChoice(save, index) {
  const c = CAMPAIGN[index];
  return c?.choice?.when === 'before' && !save.campaign.choices?.[c.choice.id] ? c.choice : null;
}

export function isCampaignUnlocked(save, index) {
  if (index === 0) return true;
  return save.campaign.completed.includes(CAMPAIGN[index - 1].id);
}

export function generateContracts(save, today, activeEvents = []) {
  const refresh = save.universe.contracts.refreshes || 0;
  const rng = new RNG(`contracts-${today}-${refresh}-${save.universe.missionCounter}`);
  const list = [];
  const usedObjectives = [];
  const regions = rng.shuffle(REGION_ORDER);
  const diffs = [1.0, 1.15, 1.35, 1.55, 1.85];
  const baseDiff = 1 + Math.min(1.2, (save.profile.level - 1) * 0.04);
  for (let i = 0; i < 5; i++) {
    const region = regions[i % regions.length];
    const m = generateMission({
      seed: `contract-${today}-${refresh}-${i}-${save.universe.missionCounter}`,
      mode: 'contract', region, difficulty: diffs[i] * baseDiff,
      history: save.universe.history.concat(usedObjectives),
      threat: save.universe.threat, activeEvents,
      excludeObjectives: usedObjectives,
    });
    usedObjectives.push(m.objective);
    list.push(m);
  }
  // Follow-up contracts emerge from previous outcomes
  for (const f of (save.universe.followUps || []).slice(0, 2)) {
    const m = generateMission({
      seed: `follow-${f.id}`, mode: 'contract', region: f.region, objective: f.objective,
      difficulty: f.difficulty || 1.5 * baseDiff, title: f.title, brief: f.brief,
      threat: save.universe.threat, activeEvents, modifiers: f.modifiers || undefined,
      boss: f.boss || null, rewardMult: f.rewardMult || 1.4, followUp: f.id,
    });
    m.special = f.kind;
    list.unshift(m);
  }
  return list;
}

export function dailyMission(today, save, activeEvents = []) {
  const rng = new RNG(`daily-mission-${today}`);
  const m = generateMission({
    seed: `daily-mission-${today}`, mode: 'contract', region: rng.pick(REGION_ORDER),
    difficulty: 1.2 + Math.min(1, (save.profile.level - 1) * 0.04), activeEvents, rewardMult: 1.6,
    history: [],
  });
  m.daily = true;
  m.title = 'Daily Op: ' + m.title.replace('Operation ', '');
  return m;
}

export function dailyChallenge(today, activeEvents = []) {
  const rng = new RNG(`daily-challenge-${today}`);
  const region = rng.pick(REGION_ORDER);
  const mods = pickModifiers(rng, 2, region, 'survive');
  return {
    id: `daily-challenge-${today}`, seed: `daily-challenge-${today}`, mode: 'daily',
    title: 'Daily Challenge', brief: `Score attack: 6 escalating waves in ${REGIONS[region].name}. Fixed seed — same fight for every attempt today. Beat your own best.`,
    region, objective: 'waves', faction: rng.pick(REGIONS[region].factions), altFaction: null,
    difficulty: 1.4, tier: 3, modifiers: mods, optional: [], elite: null, event: activeEvents[0] || null,
    variantPool: [['veteran', 0.08], ['overcharged', 0.08]], surprise: null, boss: null,
    waves: 6, parTime: 300, rewardMult: 1, mutators: [],
    rewards: { credits: 400, alloy: 10, xp: 400, cores: 0 },
  };
}

export function eventMission(eventId, idx, save, activeEvents) {
  const ev = EVENTS[eventId];
  const c = ev?.chain?.[idx];
  if (!c) return null;
  const m = generateMission({
    seed: `event-${c.id}`, mode: 'event', region: c.region, objective: c.objective, difficulty: c.difficulty,
    boss: c.boss || null, bossVariant: c.bossVariant || null, title: c.title, brief: c.brief,
    activeEvents: [eventId], rewardMult: 1.3, eventMissionId: c.id,
    history: save?.universe?.history || [],
  });
  m.event = eventId;
  m.rewards = rewardPreview(m);
  return m;
}

export function experimentalMission(seed) {
  const rng = new RNG(`exp-${seed}`);
  const mutators = rng.shuffle(Object.keys(MUTATORS)).slice(0, 3);
  // keep it fair: never combine glass with vampire, or giants with tiny
  const fixed = [];
  for (const mu of mutators) {
    if (mu === 'tiny' && fixed.includes('giants')) continue;
    if (mu === 'giants' && fixed.includes('tiny')) continue;
    if (mu === 'vampire' && fixed.includes('glass')) continue;
    if (mu === 'glass' && fixed.includes('vampire')) continue;
    fixed.push(mu);
  }
  const region = rng.pick(REGION_ORDER);
  return {
    id: `exp-${seed}`, seed: `exp-${seed}`, mode: 'experimental', title: 'Experimental Zone',
    brief: 'Unstable test range. Survive 5 waves under these mutators: ' + fixed.map(m => MUTATORS[m].name).join(', ') + '.',
    region, objective: 'waves', faction: rng.pick(REGIONS[region].factions), altFaction: rng.pick(Object.keys(FACTIONS)),
    difficulty: 1.4, tier: 3, modifiers: [], optional: ['variety'], elite: null, event: null,
    variantPool: [], surprise: null, boss: null, waves: 5, parTime: 300, rewardMult: 1.3, mutators: fixed,
    rewards: { credits: 600, alloy: 18, xp: 500, cores: 1 },
  };
}

export function bossRushMission(save, difficultyName = 'normal') {
  const encountered = Object.keys(save.universe.encountered.bosses || {}).filter(b => BOSSES[b] && !BOSSES[b].event);
  const list = encountered.length ? encountered : ['dreadnought'];
  const mult = { normal: 1.3, hard: 1.8, nightmare: 2.4 }[difficultyName] || 1.3;
  return {
    id: `bossrush-${difficultyName}`, seed: `bossrush-${Date.now()}`, mode: 'bossrush',
    title: `Boss Rush — ${difficultyName[0].toUpperCase() + difficultyName.slice(1)}`,
    brief: `Fight every boss you have encountered back to back: ${list.map(b => BOSSES[b].name).join(', ')}. Hull carries over; shields refill between fights.`,
    region: 'megastructure', objective: 'bossrush', bossList: list, faction: 'dominion', altFaction: null,
    difficulty: mult, tier: 5, modifiers: [], optional: [], elite: null, event: null, variantPool: [],
    surprise: null, boss: list[0], parTime: 240 * list.length, rewardMult: 1, mutators: [], difficultyName,
    rewards: { credits: 900 * list.length * mult, alloy: 20 * list.length, xp: 450 * list.length, cores: list.length },
  };
}

export function endlessMission(seed) {
  const rng = new RNG(`endless-${seed}`);
  const region = rng.pick(REGION_ORDER);
  return {
    id: `endless-${seed}`, seed: `endless-${seed}`, mode: 'endless', title: 'Endless Frontier',
    brief: 'Survive as long as you can. Every 3 waves adds a new modifier. Choose a perk between waves. Score multiplier grows every wave.',
    region, objective: 'waves', faction: rng.pick(REGIONS[region].factions), altFaction: rng.pick(Object.keys(FACTIONS)),
    difficulty: 1, tier: 1, modifiers: [], optional: [], elite: null, event: null, variantPool: [],
    surprise: null, boss: null, waves: Infinity, parTime: 9999, rewardMult: 1, mutators: [],
    rewards: { credits: 0, alloy: 0, xp: 0, cores: 0 },
  };
}

// ---------------------------------------------------------------------------
// Wave composition — budget-based, faction-aware, avoids repeating structure.
// ---------------------------------------------------------------------------
export const FORMATIONS = ['grid', 'vee', 'ring', 'column', 'pincer', 'scatter'];

export function composeWave(rng, { wave = 1, difficulty = 1, faction = 'dominion', altFaction = null, lastFormation = null, budgetScale = 1 }) {
  const budget = Math.round((6 + wave * 3.2) * difficulty * budgetScale);
  const roster = FACTIONS[faction].roster;
  const alt = altFaction ? FACTIONS[altFaction].roster : [];
  const groups = [];
  let spent = 0;
  // Primary group: always a recognisable formation (the Space-Invaders DNA)
  const formation = rng.pick(FORMATIONS.filter(f => f !== lastFormation));
  const leadType = wave < 3 ? 'swarm' : rng.pick(['swarm', 'swarm', 'interceptor', 'kamikaze'].filter(t => roster.includes(t) || t === 'swarm'));
  const leadCount = Math.max(4, Math.min(16, Math.round(budget * 0.4 / ENEMIES[leadType].cost)));
  groups.push({ type: leadType, count: leadCount, formation, faction });
  spent += leadCount * ENEMIES[leadType].cost;
  // Support & specialists — weighted by wave so later waves introduce new mechanics
  const unlockByWave = { swarm: 1, interceptor: 1, kamikaze: 2, bomber: 3, sniper: 3, repair: 4, shieldcarrier: 4, stealth: 5, artillery: 5 };
  let guard = 0;
  while (spent < budget && guard++ < 20) {
    const fromAlt = alt.length && rng.chance(0.25);
    const pool = (fromAlt ? alt : roster).filter(t => (unlockByWave[t] || 1) <= wave + Math.floor(difficulty));
    if (!pool.length) break;
    const type = rng.pick(pool);
    const cost = ENEMIES[type].cost;
    const count = Math.max(1, Math.min(type === 'swarm' ? 8 : 4, Math.floor((budget - spent) / cost)));
    if (count < 1 || cost > budget - spent + 2) break;
    const existing = groups.find(g => g.type === type && g.faction === (fromAlt ? altFaction : faction) && g.formation === 'loose');
    if (existing) existing.count += count;
    else groups.push({ type, count, formation: 'loose', faction: fromAlt ? altFaction : faction });
    spent += cost * count;
  }
  return { groups, budget, spent, formation };
}

export function endlessWaveSpec(rng, wave, faction, altFaction, lastFormation) {
  const spec = composeWave(rng, { wave, difficulty: 1 + wave * 0.05, faction, altFaction: wave > 4 ? altFaction : null, lastFormation });
  spec.elite = wave % 5 === 0 && wave % 10 !== 0;
  spec.miniboss = wave % 10 === 0 ? rng.pick(['sentinel', 'broodmother']) : null;
  spec.newModifier = wave > 1 && wave % 3 === 1;
  return spec;
}

// Mission director memory: record a played objective (bounded history)
export function recordHistory(history, objective) {
  const h = history.concat(objective);
  return h.slice(-12);
}

export function stageName(st) {
  if (st.obj === 'boss') return BOSSES[st.m?.boss]?.name || 'Boss';
  if (st.obj === 'waves') return 'Clear the area';
  if (st.obj === 'acehunt') return `Hunt ${st.m?.elite?.name || 'the ace'}`;
  return OBJECTIVES[st.obj]?.name || st.obj;
}
export function describeMission(m) {
  return {
    objective: m.objective === 'story' ? (m.story?.stages || []).map(stageName).join(' → ') : OBJECTIVES[m.objective]?.name || (m.objective === 'waves' ? 'Wave Assault' : m.objective === 'bossrush' ? 'Boss Gauntlet' : m.objective),
    region: REGIONS[m.region]?.name,
    faction: FACTIONS[m.faction]?.name,
    modifiers: m.modifiers.map(x => MODIFIERS[x]?.name),
    mutators: (m.mutators || []).map(x => MUTATORS[x]?.name),
  };
}

export { VARIANTS };
