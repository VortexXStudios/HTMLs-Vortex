// ============================================================================
// Mission Director: paces ambient encounters (build-up / peak / relief),
// applies mission modifiers at runtime and stages surprise encounters.
// Remembers what it spawned recently so it doesn't repeat itself.
// ============================================================================
import * as THREE from 'three';
import { RNG } from './rng.js';
import { composeWave, makeAce } from './missions.js';
import { ENEMIES, ACE_NAMES } from './data.js';
import { Formation } from './units.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);

export class Director {
  constructor(game, mission) {
    this.g = game; this.m = mission;
    this.rng = new RNG('director-' + mission.seed);
    this.t = 0; this.waveCd = 10; this.waveNum = 0; this.intensity = 0;
    this.recent = []; // recent wave compositions (types)
    this.formations = [];
    this.preferTypes = null;
    this.lastFormation = null;
    this.relief = 0;
    // modifiers
    const mods = new Set(mission.modifiers);
    this.mods = mods;
    this.droneT = 20; this.hunterT = 60; this.cargoT = 0;
    // surprise encounter
    this.surprise = mission.surprise;
    this.surpriseAt = mission.parTime * this.rng.range(0.25, 0.5);
    this.surpriseDone = false;
    this.eliteAt = mission.elite && mission.objective !== 'acehunt' ? this.rng.range(40, 90) : Infinity;
    this.trader = null; this.challenge = null;
    this.roamingWell = null;
  }

  start() {
    const g = this.g;
    if (this.mods.has('allies')) for (let i = 0; i < 3; i++) { const w = g.spawnUnit('wingman', { pos: g.player.pos.clone().add(V((i - 1) * 30, 10, -30)), team: 'ally', faction: 'ally' }); w.ai.side = i - 1 || 1.5; }
    if (this.mods.has('cargo')) for (let i = 0; i < 8; i++) this._spawnCargo();
    if (this.mods.has('gravity')) this.addRoamingWell();
    if (this.m.region === 'graveyard' || this.m.event === 'halloween') for (let i = 0; i < 10; i++) g.spawnUnit('mine', { pos: V(this.rng.range(-800, 800), this.rng.range(-200, 200), this.rng.range(-600, 800)), faction: 'neutral' });
    if (this.m.region === 'frontier' && this.m.objective !== 'boss') for (let i = 0; i < 3; i++) g.spawnUnit('turret', { pos: V(this.rng.range(-600, 600), this.rng.range(-150, 150), this.rng.range(100, 800)), faction: 'dominion' });
  }

  addRoamingWell() {
    const g = this.g;
    if (this.roamingWell) return;
    this.roamingWell = { pos: V(0, 0, 300), radius: 260, strength: 0.6, a: 0 };
    g.gravityWells.push(this.roamingWell);
    this.wellVis = new THREE.Mesh(new THREE.SphereGeometry(10, 16, 12), new THREE.MeshBasicMaterial({ color: 0 }));
    const halo = new THREE.Mesh(new THREE.TorusGeometry(18, 1.5, 6, 32), new THREE.MeshBasicMaterial({ color: new THREE.Color('#b26bff').multiplyScalar(2.2), toneMapped: false }));
    this.wellVis.add(halo); g.scene.add(this.wellVis); g.missionObjects.push(this.wellVis);
  }

  // Desired threat budget alive at time t (build-up -> peaks -> relief)
  targetBudget() {
    const obj = this.g.objective;
    const t = this.t;
    const base = 8 + Math.min(18, t * 0.12);
    const wave = 0.65 + 0.35 * Math.sin(t / 22);
    return base * wave * this.m.difficulty * (obj.ambientScale ?? 1);
  }

  aliveBudget() {
    let b = 0;
    for (const u of this.g.units) if (u.alive && u.team === 'enemy' && !u.structure && !u.passive && !u.part) b += (ENEMIES[u.type]?.cost || 2);
    return b;
  }

  update(dt) {
    const g = this.g;
    this.t += dt;
    for (const f of this.formations) f.update(dt);
    this.formations = this.formations.filter(f => !f.broken);
    const obj = g.objective;
    // --- ambient pacing
    if (obj.ambient) {
      this.waveCd -= dt;
      const alive = this.aliveBudget();
      const want = this.targetBudget();
      if (this.waveCd <= 0 && alive < want * 0.55) {
        this.waveNum++;
        const spec = composeWave(this.rng, { wave: 1 + Math.floor(this.t / 40), difficulty: this.m.difficulty, faction: this.m.faction, altFaction: this.m.altFaction, lastFormation: this.lastFormation, budgetScale: Math.max(0.4, (want - alive) / Math.max(6, want)) * (obj.ambientScale ?? 1) });
        if (this.preferTypes) for (const grp of spec.groups) if (grp.formation === 'loose' && this.rng.chance(0.5)) grp.type = this.rng.pick(this.preferTypes);
        // avoid repeating the exact same composition twice
        const sig = spec.groups.map(x => x.type).sort().join(',');
        if (this.recent.includes(sig) && spec.groups.length > 1) spec.groups.reverse().pop();
        this.recent.push(sig); if (this.recent.length > 4) this.recent.shift();
        this.lastFormation = spec.formation;
        const anchor = obj.anchor();
        const target = obj.protect.length && this.rng.chance(0.55) ? this.rng.pick(obj.protect.filter(u => u.alive)) || g.player : g.player;
        this.spawnWave(spec, anchor, target, { formationTarget: target });
        g.hud.incoming(anchor);
        this.waveCd = this.rng.range(14, 22);
      }
    }
    // --- modifiers
    if (this.mods.has('drones')) { this.droneT -= dt; if (this.droneT <= 0) { this.droneT = 28; const a = g.objective.anchor(); this.spawnWave({ groups: [{ type: 'swarm', count: 6, formation: this.rng.pick(['vee', 'ring', 'column']), faction: this.m.faction }] }, a, g.player); g.hud.toast('DRONE CARRIER DEPLOYMENT', 'warn', 1.2); } }
    if (this.mods.has('hunters')) { this.hunterT -= dt; if (this.hunterT <= 0) { this.hunterT = 75; const P = g.player; this.spawnElite(null, P.pos.clone().addScaledVector(P.forward, -600)); g.hud.warn('HUNTER ON YOUR SIX', 2); } }
    if (this.mods.has('cargo')) { this.cargoT -= dt; if (this.cargoT <= 0) { this.cargoT = 30; this._spawnCargo(); } }
    if (this.roamingWell) {
      const w = this.roamingWell; w.a += dt * 0.15;
      w.pos.set(Math.cos(w.a) * 450, Math.sin(w.a * 1.7) * 120, Math.sin(w.a) * 450 + 150);
      this.wellVis.position.copy(w.pos); this.wellVis.children[0].rotation.x += dt; this.wellVis.children[0].rotation.y += dt * 1.3;
      const P = g.player; const d = P.pos.distanceTo(w.pos);
      if (d < w.radius) P.vel.addScaledVector(w.pos.clone().sub(P.pos).normalize(), 110 * dt * (1 - d / w.radius));
      if (Math.random() < 0.5) g.effects.trailPuff(w.pos.clone().add(V(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(90)), '#b26bff', 2.5, 0.8);
    }
    // --- named elite appears mid-mission
    if (this.t > this.eliteAt) {
      this.eliteAt = Infinity;
      const e = this.spawnElite(this.m.elite, obj.anchor(), { marker: 'BOUNTY' });
      e.bounty = true;
      g.hud.banner(`${this.m.elite.name} has entered the sector`, 'Optional: destroy the marked elite', 2.4);
    }
    // --- surprise encounters
    if (!this.surpriseDone && this.surprise && this.t > this.surpriseAt) { this.surpriseDone = true; this._surprise(this.surprise); }
    if (this.trader) this._updateTrader(dt);
    if (this.challenge) this._updateChallenge(dt);
  }

  spawnWave(spec, anchor, target, opts = {}) {
    const g = this.g;
    const out = [];
    for (const grp of spec.groups) {
      const count = Math.round(grp.count * (g.mutators.has('tiny') ? 1.6 : 1));
      const variant = () => this._variant();
      if (grp.formation && grp.formation !== 'loose' && count >= 3) {
        const ftarget = opts.formationTarget || target;
        const f = new Formation(g, grp.formation, count, anchor, ftarget);
        for (let i = 0; i < count; i++) {
          const u = g.spawnUnit(grp.type, { pos: f.slotPos(i, new THREE.Vector3()), faction: grp.faction || this.m.faction, variant: variant() });
          if (grp.type === 'swarm' || grp.type === 'kamikaze' || grp.type === 'interceptor') { f.add(u, i); if (u.behavior !== 'swarm') u.ai.formationLeader = f; }
          out.push(u);
        }
        // only drones hold the block; others break immediately but arrive together
        if (grp.type !== 'swarm') f.break(); else this.formations.push(f);
      } else {
        for (let i = 0; i < count; i++) {
          const pos = anchor.clone().add(V(this.rng.range(-90, 90), this.rng.range(-50, 50), this.rng.range(-90, 90)));
          const u = g.spawnUnit(grp.type, { pos, faction: grp.faction || this.m.faction, variant: variant() });
          u.vel.copy(target.pos).sub(pos).normalize().multiplyScalar(u.speed * 0.5);
          out.push(u);
        }
      }
    }
    for (const u of out) g.effects.ring(u.pos, u.radius * 3, '#9fd8ff', 0.4);
    if (out.length) g.audio.play('phase', { pos: anchor, volume: 0.6 });
    return out;
  }

  _variant() {
    let pool = this.m.variantPool || [];
    if (this.mods.has('ironclad')) pool = pool.concat([['armored', 0.6]]);
    for (const [v, p] of pool) if (this.rng.chance(p)) return v;
    return null;
  }

  spawnElite(def, pos, opts = {}) {
    const g = this.g;
    const e = def || makeAce(this.rng, this.m.faction);
    const u = g.spawnUnit('ace', { pos, faction: e.faction || this.m.faction, variant: e.variant, name: e.name, marker: opts.marker || 'ELITE', elite: true });
    u.ai.personality = e.personality;
    u.retreatAt = opts.retreatAt || 0;
    if (opts.hpFrac) u.hp = u.maxHp * opts.hpFrac;
    u.named = true;
    return u;
  }

  _spawnCargo() {
    const g = this.g;
    const pos = V(this.rng.range(-700, 700), this.rng.range(-200, 200), this.rng.range(-500, 800));
    const c = g.spawnUnit('cargo', { pos, faction: 'neutral', marker: null });
    c.vel.set(this.rng.range(-5, 5), this.rng.range(-3, 3), this.rng.range(-5, 5));
  }

  _surprise(kind) {
    const g = this.g, P = g.player;
    if (kind === 'neutral') {
      const pos = P.pos.clone().addScaledVector(P.forward, 350).add(V(0, 40, 0));
      this.trader = g.spawnUnit('trader', { pos, marker: 'UNKNOWN VESSEL', team: 'neutral' });
      this.trader.trap = this.rng.chance(0.25);
      this.traderState = 'waiting';
      g.hud.banner('UNKNOWN VESSEL DETECTED', 'A neutral ship is hailing on an open channel', 2.6);
      g.audio.play('scan');
    } else if (kind === 'cache') {
      const pos = V(this.rng.range(-700, 700), this.rng.range(-150, 150), this.rng.range(-600, 700));
      const c = g.spawnUnit('cargo', { pos, faction: 'neutral', marker: 'SIGNAL', hp: 80, scale: 2.2 });
      c.loot = 'cache';
      g.hud.toast('FAINT SIGNAL — HIDDEN SUPPLY CACHE NEARBY', 'info', 2.5);
    } else if (kind === 'ambush') {
      g.hud.warn('AMBUSH — HOSTILES DECLOAKING BEHIND YOU', 2.2);
      g.audio.play('alert');
      const anchor = P.pos.clone().addScaledVector(P.forward, -260);
      this.spawnWave({ groups: [{ type: 'stealth', count: 3, formation: 'loose', faction: 'syndicate' }, { type: 'kamikaze', count: 4, formation: 'loose', faction: this.m.faction }] }, anchor, P);
    } else if (kind === 'discovery') {
      const pos = V(this.rng.range(-800, 800), this.rng.range(-250, 250), this.rng.range(-700, 800));
      g.addPickup('relic', pos, 1);
      g.hud.toast('ANOMALOUS READING — SOMETHING ANCIENT IS OUT THERE', 'info', 3);
    }
  }

  _updateTrader(dt) {
    const g = this.g, P = g.player, tr = this.trader;
    if (!tr.alive) { this.trader = null; return; }
    if (this.traderState === 'waiting') {
      const d = P.pos.distanceTo(tr.pos);
      if (d < 140) {
        g.hud.prompt('Press G to answer the hail');
        if (g.input.pressed('interact')) {
          g.hud.prompt(null);
          if (tr.trap) { this._springTrap(); return; }
          this.traderState = 'talking';
          const canPay = g.save.currencies.credits >= 150;
          g.offerChoice({
            title: '"Greetings, pilot. Business or pleasure?"', subtitle: 'The Wanderer — a neutral trader',
            options: [
              { id: 'trade', title: 'Trade (150 credits)', desc: canPay ? 'Full repair, shield and ordnance refill — plus a rare quantum core.' : 'You cannot afford this.', disabled: !canPay, icon: 'credits' },
              { id: 'challenge', title: 'Accept a wager', desc: 'Destroy 12 hostiles in 45s for 400 credits and 12 alloy. Fail and pay nothing.', icon: 'rank_skull' },
              { id: 'leave', title: 'Decline', desc: 'Move along.', icon: 'cancel' },
            ],
            onPick: id => {
              if (id === 'trade') { g.save.currencies.credits -= 150; P.heal(P.maxHull); P.shield = P.maxShield; P.weapons.refill(); g.loot.cores += 1; g.hud.toast('TRADE COMPLETE — SYSTEMS RESTORED', 'good', 2); g.audio.play('buy'); }
              if (id === 'challenge') { this.challenge = { t: 45, kills: 0, need: 12 }; this.spawnWave(composeWave(this.rng, { wave: 4, difficulty: this.m.difficulty, faction: this.m.faction }), P.pos.clone().addScaledVector(P.forward, 500), P); g.hud.banner('WAGER ACCEPTED', 'Destroy 12 hostiles in 45 seconds', 2); }
              this.traderState = 'done';
              setTimeout(() => { if (tr.alive) { g.effects.flash(tr.pos, 40, '#ffcc55', 0.4); g.removeUnit(tr, 'warp'); } }, 3000);
            },
          });
        }
      } else g.hud.prompt(null);
    }
  }

  _springTrap() {
    const g = this.g, tr = this.trader;
    g.hud.banner('IT\'S A TRAP!', 'The "trader" is a pirate decoy', 2.4); g.audio.play('alert');
    tr.team = 'enemy'; tr.hostile = true; tr.behavior = 'sentinel'; tr.def = { ...tr.def, weapon: { dmg: 8, rate: 3, speed: 400, spread: 0.03 } }; tr.marker = 'PIRATE';
    tr.maxHp = 900; tr.hp = 900;
    this.spawnWave({ groups: [{ type: 'interceptor', count: 4, formation: 'loose', faction: 'syndicate' }, { type: 'stealth', count: 2, formation: 'loose', faction: 'syndicate' }] }, tr.pos.clone().add(V(0, 60, 0)), g.player);
    this.traderState = 'done';
  }

  _updateChallenge(dt) {
    const g = this.g, c = this.challenge;
    c.t -= dt;
    g.hud.challenge(`WAGER: ${c.kills}/${c.need} kills — ${Math.ceil(c.t)}s`);
    if (c.kills >= c.need) { g.loot.credits += 400; g.loot.alloy += 12; g.hud.toast('WAGER WON: +400 CREDITS, +12 ALLOY', 'good', 2.5); g.audio.play('claim'); this.challenge = null; g.hud.challenge(null); }
    else if (c.t <= 0) { g.hud.toast('WAGER LOST', 'warn', 2); this.challenge = null; g.hud.challenge(null); }
  }

  onKill(u) { if (this.challenge && u.team === 'enemy') this.challenge.kills++; }

  dispose() {
    for (const f of this.formations) f.break();
    if (this.roamingWell) { const i = this.g.gravityWells.indexOf(this.roamingWell); if (i >= 0) this.g.gravityWells.splice(i, 1); }
    this.g.hud.challenge(null); this.g.hud.prompt(null);
  }
}
