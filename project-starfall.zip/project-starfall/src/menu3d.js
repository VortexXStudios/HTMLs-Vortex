// ============================================================================
// 3D backdrop for title screen, hangar display and collection inspector.
// ============================================================================
import * as THREE from 'three';
import { Environment } from './environment.js';
import { buildPlayerShip, buildUnit, buildDreadnought, buildSwarmQueen, buildPhantom, buildAnomaly, buildHollowWarden } from './models.js';

export class MenuScene {
  constructor(app) {
    this.app = app;
    this.scene = new THREE.Scene();
    this.camera = app.renderer.camera;
    this.env = new Environment(this.scene, app.renderer.renderer);
    this.region = null;
    this.pivot = new THREE.Group(); this.scene.add(this.pivot);
    this.model = null; this.modelKind = null;
    this.time = 0; this.mode = 'title';
    this.yaw = 0.6; this.pitch = 0.15; this.dist = 30; this.autoRotate = true;
    this.dragging = false;
    // studio lighting for the hangar: key, rim, under-glow
    this.key = new THREE.SpotLight(0xffffff, 700, 260, 0.6, 0.6, 1.6); this.key.position.set(20, 40, 25); this.scene.add(this.key); this.scene.add(this.key.target);
    this.rimA = new THREE.PointLight(0x4fdcff, 380, 140, 2); this.rimA.position.set(-30, 8, -20); this.scene.add(this.rimA);
    this.rimB = new THREE.PointLight(0xff7a3a, 200, 140, 2); this.rimB.position.set(30, -10, -25); this.scene.add(this.rimB);
    // pedestal ring
    const ring = new THREE.Mesh(new THREE.TorusGeometry(14, 0.25, 6, 96), new THREE.MeshBasicMaterial({ color: new THREE.Color('#4fdcff').multiplyScalar(2), toneMapped: false }));
    ring.rotation.x = Math.PI / 2; ring.position.y = -6; this.ring = ring; this.scene.add(ring);
    const disc = new THREE.Mesh(new THREE.CircleGeometry(14, 64), new THREE.MeshStandardMaterial({ color: '#0b1220', metalness: 0.9, roughness: 0.35, transparent: true, opacity: 0.85 }));
    disc.rotation.x = -Math.PI / 2; disc.position.y = -6.1; disc.receiveShadow = true; this.disc = disc; this.scene.add(disc);
    this.trails = [];
    const el = app.renderer.canvas;
    el.addEventListener('pointerdown', e => { if (!this.active || this.mode === 'title') return; this.dragging = true; this.lx = e.clientX; this.ly = e.clientY; this.autoRotate = false; });
    window.addEventListener('pointerup', () => { this.dragging = false; this.resumeT = 4; });
    window.addEventListener('pointermove', e => { if (!this.dragging) return; this.yaw -= (e.clientX - this.lx) * 0.008; this.pitch = Math.max(-0.6, Math.min(0.9, this.pitch + (e.clientY - this.ly) * 0.006)); this.lx = e.clientX; this.ly = e.clientY; });
    el.addEventListener('wheel', e => { if (!this.active || this.mode === 'title') return; this.dist = Math.max(this.minDist || 12, Math.min(this.maxDist || 80, this.dist * (1 + Math.sign(e.deltaY) * 0.1))); }, { passive: true });
    this.active = false;
  }

  setRegion(id, event) {
    const key = id + ':' + event;
    if (this.region === key) return;
    this.region = key;
    this.env.build(id, { settings: this.app.saveManager.data.settings, seed: 7, event, noAsteroids: false, asteroidMult: 0.35 });
  }

  clearModel() {
    if (this.model) {
      this.pivot.remove(this.model);
      this.model.traverse(o => { if (o.material && (o.material.isShaderMaterial || o.userData.own)) o.material.dispose(); });
    }
    for (const t of this.trails) { this.scene.remove(t.mesh); t.dispose(); }
    this.trails = [];
    this.model = null;
  }

  showShip(shipId, cosmetics) {
    this.clearModel();
    const m = buildPlayerShip(shipId, cosmetics);
    this.model = m; this.modelKind = 'ship';
    this.pivot.add(m);
    this._fit(m.userData.length * 0.5, 1);
  }

  showUnit(type, faction) {
    this.clearModel();
    const m = buildUnit(type, faction);
    this.model = m; this.modelKind = 'unit';
    this.pivot.add(m);
    this._fit(m.userData.radius, 1);
  }

  showBoss(id) {
    this.clearModel();
    const b = id === 'dreadnought' ? buildDreadnought() : id === 'swarmqueen' ? buildSwarmQueen() : id === 'phantom' ? buildPhantom() : id === 'anomaly' ? buildAnomaly() : buildHollowWarden();
    this.model = b.group; this.modelKind = 'boss';
    this.pivot.add(b.group);
    this._fit((b.length || 100) * 0.5, 1);
  }

  _fit(radius, k) {
    // scale model to fit display radius ~10 units
    const s = 10 / Math.max(1, radius) * k;
    this.pivot.scale.setScalar(s);
    this.dist = this.mode === 'title' ? 78 : 62; this.minDist = 26; this.maxDist = 120;
  }

  setMode(mode) {
    this.mode = mode;
    const title = mode === 'title';
    this.ring.visible = !title; this.disc.visible = !title;
    if (title) { this.yaw = 0.9; this.pitch = 0.1; this.dist = 78; this.autoRotate = true; }
    else { this.pitch = 0.22; this.dist = 62; }
  }

  update(dt) {
    this.time += dt;
    if (this.autoRotate) this.yaw += dt * (this.mode === 'title' ? 0.06 : 0.25);
    if (!this.autoRotate && !this.dragging) { this.resumeT = (this.resumeT || 0) - dt; if (this.resumeT <= 0) this.autoRotate = true; }
    const cam = this.camera;
    const target = this._target || (this._target = new THREE.Vector3());
    target.set(0, this.mode === 'title' ? 0 : 1, 0);
    cam.position.set(Math.sin(this.yaw) * Math.cos(this.pitch) * this.dist, Math.sin(this.pitch) * this.dist + 2, Math.cos(this.yaw) * Math.cos(this.pitch) * this.dist).add(target);
    cam.up.set(0, 1, 0);
    cam.lookAt(target);
    // shift the subject on screen with a view offset so menus never cover the ship
    const w = window.innerWidth, h = window.innerHeight;
    const shift = this.mode === 'title' ? -0.2 : this.mode === 'hangar' ? 0.17 : 0;
    const shiftY = this.mode === 'hangar' ? 0.08 : 0;
    cam.setViewOffset(w, h, shift * w, shiftY * h, w, h);
    { const a = cam.aspect, f = a < 1.25 ? Math.min(90, 2 * Math.atan(Math.tan(22.5 * Math.PI / 180) * 1.25 / a) * 180 / Math.PI) : 45; if (cam.fov !== f) { cam.fov = f; cam.updateProjectionMatrix(); } }
    if (this.model) {
      // idle hover bob
      this.model.position.y = Math.sin(this.time * 1.2) * 0.4;
      this.model.rotation.z = Math.sin(this.time * 0.7) * 0.05;
      if (this.modelKind === 'ship') {
        this.model.updateMatrixWorld(true);
        for (const f of this.model.userData.flames) { f.material.uniforms.uTime.value = this.time; f.material.uniforms.uPower.value = 0.45; }
        const mats = this.model.userData.materials;
        if (mats.engineCycle) { const c = new THREE.Color().setHSL((this.time * 0.15) % 1, 1, 0.6); mats.glow.color.copy(c).multiplyScalar(1.8); for (const f of this.model.userData.flames) f.material.uniforms.uColor.value.copy(c); }
      }
      if (this.modelKind === 'unit') for (const f of this.model.userData.flames || []) { f.material.uniforms.uTime.value = this.time; f.material.uniforms.uPower.value = 0.7; }
    }
    this.key.target.position.set(0, 0, 0);
    this.ring.material.color.setRGB(0.3, 1.4 + Math.sin(this.time * 2) * 0.3, 2);
    this.env.update(dt, cam, new THREE.Vector3());
  }

  render() { this.app.renderer.render(this.scene, this.camera); }
}
