// ============================================================================
// Projectiles (pooled + instanced) and the player's weapon systems.
// ============================================================================
import * as THREE from 'three';
import { WEAPONS, SECONDARIES } from './data.js';
import { ARENA_RADIUS } from './environment.js';

const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3(), tmp3 = new THREE.Vector3(), tmpQ = new THREE.Quaternion();
const Z = new THREE.Vector3(0, 0, 1);
const m4 = new THREE.Matrix4(), scl = new THREE.Vector3();

// Closest-approach test between segment AB and sphere (C, r)
export function segSphere(ax, ay, az, bx, by, bz, cx, cy, cz, r) {
  const abx = bx - ax, aby = by - ay, abz = bz - az;
  const acx = cx - ax, acy = cy - ay, acz = cz - az;
  const ab2 = abx * abx + aby * aby + abz * abz;
  let t = ab2 > 0 ? (acx * abx + acy * aby + acz * abz) / ab2 : 0;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  const dx = ax + abx * t - cx, dy = ay + aby * t - cy, dz = az + abz * t - cz;
  return dx * dx + dy * dy + dz * dz <= r * r ? t : -1;
}
// Ray vs sphere: returns distance or -1
export function raySphere(o, d, c, r, maxDist) {
  const ox = c.x - o.x, oy = c.y - o.y, oz = c.z - o.z;
  const t = ox * d.x + oy * d.y + oz * d.z;
  if (t < 0 || t > maxDist + r) return -1;
  const d2 = ox * ox + oy * oy + oz * oz - t * t;
  if (d2 > r * r) return -1;
  return Math.max(0, t - Math.sqrt(r * r - d2));
}

class Projectile {
  constructor() {
    this.active = false; this.pos = new THREE.Vector3(); this.prev = new THREE.Vector3(); this.vel = new THREE.Vector3();
    this.color = new THREE.Color(); this.hit = new Set(); this.target = null; this.aim = new THREE.Vector3();
  }
}

export class Projectiles {
  constructor(game) {
    this.game = game;
    this.group = new THREE.Group();
    game.scene.add(this.group);
    const caps = { bolt: 1600, orb: 500, missile: 160 };
    this.pools = {}; this.meshes = {};
    const boltGeo = new THREE.CapsuleGeometry(0.5, 1, 2, 6); boltGeo.rotateX(Math.PI / 2);
    const orbGeo = new THREE.IcosahedronGeometry(1, 2);
    const misGeo = new THREE.ConeGeometry(0.5, 2.6, 6); misGeo.rotateX(Math.PI / 2);
    const geos = { bolt: boltGeo, orb: orbGeo, missile: misGeo };
    for (const k of Object.keys(caps)) {
      const mat = k === 'missile'
        ? new THREE.MeshStandardMaterial({ color: '#d8dde4', metalness: 0.7, roughness: 0.3, emissive: '#ff8a3a', emissiveIntensity: 0.6 })
        : new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
      const im = new THREE.InstancedMesh(geos[k], mat, caps[k]);
      im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      im.setColorAt(0, new THREE.Color(1, 1, 1));
      im.frustumCulled = false; im.count = 0;
      this.group.add(im);
      this.meshes[k] = im;
      this.pools[k] = Array.from({ length: caps[k] }, () => new Projectile());
    }
  }

  spawn(o) {
    const kind = o.kind || 'bolt';
    const pool = this.pools[kind];
    let p = null;
    for (let i = 0; i < pool.length; i++) if (!pool[i].active) { p = pool[i]; break; }
    if (!p) return null;
    p.active = true; p.kind = kind; p.team = o.team || 'player';
    p.pos.copy(o.pos); p.prev.copy(o.pos); p.vel.copy(o.vel);
    p.life = o.life ?? 2; p.maxLife = p.life;
    p.dmg = o.dmg ?? 5; p.radius = o.radius ?? 1; p.size = o.size ?? 1; p.len = o.len ?? 1;
    p.color.set(o.color || '#ffffff');
    p.splash = o.splash || 0; p.splashDmg = o.splashDmg ?? p.dmg * 0.6;
    p.pierce = o.pierce || 0; p.hit.clear();
    p.target = o.target || null; p.turn = o.turn || 0;
    p.weapon = o.weapon || null; p.crit = !!o.crit; p.source = o.source || null;
    p.gravity = !!o.gravity; p.pull = o.pull || 0;
    p.shell = !!o.shell; if (o.aim) p.aim.copy(o.aim);
    p.shieldBonus = o.shieldBonus || 1; p.secondary = !!o.secondary; p.split = !!o.split;
    p.chill = !!o.chill; p.trail = o.trail || null; p.spore = !!o.spore; p.bounce = o.bounce || 0;
    p.ricochet = o.ricochet || 0; p.reflected = false; p.firstCloak = !!o.firstCloak;
    return p;
  }

  update(dt) {
    const g = this.game;
    const eScale = g.enemyTimeScale;
    const wells = g.gravityWells;
    const units = g.units;
    const player = g.player;
    const ast = g.env.asteroids;
    const obstacles = g.obstacles;
    for (const kind of ['bolt', 'orb', 'missile']) {
      const pool = this.pools[kind];
      const im = this.meshes[kind];
      let n = 0;
      for (let i = 0; i < pool.length; i++) {
        const p = pool[i];
        if (!p.active) continue;
        const pdt = p.team === 'enemy' ? dt * eScale : dt;
        p.life -= pdt;
        if (p.life <= 0) { this._expire(p); continue; }
        // homing
        if (p.target && p.turn > 0) {
          if (!p.target.alive) p.target = null;
          else {
            tmp.copy(p.target.pos).sub(p.pos).normalize();
            const sp = p.vel.length();
            tmp2.copy(p.vel).divideScalar(sp || 1);
            tmp2.lerp(tmp, Math.min(1, p.turn * pdt)).normalize();
            p.vel.copy(tmp2).multiplyScalar(sp + (kind === 'missile' ? 60 * pdt : 0));
          }
        }
        // gravity bending (anomaly wells / bent-space mutator)
        if (wells.length) {
          for (const w of wells) {
            tmp.copy(w.pos).sub(p.pos); const d2 = Math.max(400, tmp.lengthSq());
            if (d2 < w.radius * w.radius) p.vel.addScaledVector(tmp.normalize(), w.strength * 9000 / d2 * pdt * 60);
          }
        }
        // gravity orb pulls enemies
        if (p.gravity) {
          for (const u of units) {
            if (!u.alive || u.team !== 'enemy' || u.structure || u.boss || u.part) continue;
            tmp.copy(p.pos).sub(u.pos); const d = tmp.length();
            if (d < p.pull && d > 1) u.vel.addScaledVector(tmp.divideScalar(d), 420 * pdt * (1 - d / p.pull));
          }
          if (Math.random() < 0.6) g.effects.sparks(p.pos, '#a07bff', 1, 40, 2.5, 0.4);
        }
        if (p.trail) {
          if (Math.random() < (kind === 'missile' ? 1 : 0.5)) g.effects.trailPuff(p.pos, p.trail, kind === 'missile' ? 2.2 : 1.4, kind === 'missile' ? 0.5 : 0.3);
          if (kind === 'missile' && Math.random() < 0.35) g.effects.smokePuff(p.pos, 1.6, 0.9, 0.18);
        }
        p.prev.copy(p.pos);
        p.pos.addScaledVector(p.vel, pdt);
        if (!Number.isFinite(p.pos.x + p.pos.y + p.pos.z)) { p.active = false; continue; }
        // arena boundary
        if (p.pos.lengthSq() > (ARENA_RADIUS * 1.6) ** 2) {
          if (p.bounce > 0) { p.bounce--; tmp.copy(p.pos).normalize(); p.vel.reflect(tmp); p.pos.copy(p.prev); }
          else { p.active = false; continue; }
        }
        // artillery shells detonate at aim point
        if (p.shell && p.pos.distanceToSquared(p.aim) < 64) { this._explode(p); continue; }
        // ---- collisions
        let consumed = false;
        if (p.team === 'player' || p.team === 'ally') {
          for (let k = 0; k < units.length; k++) {
            const u = units[k];
            if (!u.alive || u.untargetable || u.team === 'ally' || u.team === 'neutral' && !u.hostile) continue;
            if (p.hit.size && p.hit.has(u)) continue;
            const r = u.radius + p.radius + (p.team === 'player' && !u.structure && g.tune ? g.tune.hitPad : 0); // forgiving hitboxes for small craft
            // quick reject
            const dx = u.pos.x - p.pos.x, dy = u.pos.y - p.pos.y, dz = u.pos.z - p.pos.z;
            const reach = r + p.vel.length() * pdt;
            if (dx * dx + dy * dy + dz * dz > reach * reach) continue;
            if (segSphere(p.prev.x, p.prev.y, p.prev.z, p.pos.x, p.pos.y, p.pos.z, u.pos.x, u.pos.y, u.pos.z, r) < 0) continue;
            if (u.phased && Math.random() < 0.85) continue; // ghostly variants
            g.damageUnit(u, p.dmg, { source: p.team, weapon: p.weapon, crit: p.crit, pos: p.pos, shieldBonus: p.shieldBonus, secondary: p.secondary, projectile: p });
            if (p.splash) { this._explode(p, u); consumed = true; break; }
            if (p.ricochet > 0) {
              p.ricochet--; p.hit.add(u);
              const nxt = g.nearestEnemy(p.pos, 200, u);
              if (nxt) { const sp = p.vel.length(); p.vel.copy(nxt.pos).sub(p.pos).normalize().multiplyScalar(sp); continue; }
            }
            if (p.pierce > 0) { p.pierce--; p.hit.add(u); continue; }
            g.effects.sparks(p.pos, p.color, 5, 60, 1.2, 0.3);
            consumed = true; break;
          }
        } else if (p.team === 'enemy') {
          // Aegis reflection
          if (player.alive && player.aegis > 0 && p.pos.distanceToSquared(player.pos) < 22 * 22) {
            p.team = 'player'; p.vel.multiplyScalar(-1.2); p.dmg *= 2; p.reflected = true; p.life = 2; p.color.set('#9fe8ff');
            g.effects.sparks(p.pos, '#9fe8ff', 6, 60, 1.5, 0.3); g.audio.play('reflect', { pos: p.pos });
            continue;
          }
          if (g.mutators.has('chaos') && p.source && p.source.faction) {
            let hitRival = null;
            for (let k = 0; k < units.length; k++) { const u = units[k]; if (!u.alive || u.team !== 'enemy' || u.faction === p.source.faction || u === p.source) continue; if (segSphere(p.prev.x, p.prev.y, p.prev.z, p.pos.x, p.pos.y, p.pos.z, u.pos.x, u.pos.y, u.pos.z, u.radius + p.radius) >= 0) { hitRival = u; break; } }
            if (hitRival) { g.damageUnit(hitRival, p.dmg, { source: 'chaos', pos: p.pos }); g.effects.sparks(p.pos, p.color, 4, 50, 1.2, 0.3); p.active = false; continue; }
          }
          if (player.alive && segSphere(p.prev.x, p.prev.y, p.prev.z, p.pos.x, p.pos.y, p.pos.z, player.pos.x, player.pos.y, player.pos.z, player.radius + p.radius) >= 0) {
            g.damagePlayer(p.dmg, { pos: p.pos, source: p.source, chill: p.chill, dir: p.vel });
            if (p.splash) this._explode(p); else g.effects.sparks(p.pos, p.color, 6, 70, 1.4, 0.3);
            consumed = true;
          } else {
            for (let k = 0; k < units.length; k++) {
              const u = units[k];
              if (!u.alive || u.team !== 'ally' || u.intangible) continue;
              const r = u.radius + p.radius;
              if (segSphere(p.prev.x, p.prev.y, p.prev.z, p.pos.x, p.pos.y, p.pos.z, u.pos.x, u.pos.y, u.pos.z, r) < 0) continue;
              g.damageUnit(u, p.dmg, { source: 'enemy', pos: p.pos });
              if (p.splash) this._explode(p); else g.effects.sparks(p.pos, p.color, 5, 60, 1.2, 0.3);
              consumed = true; break;
            }
          }
        }
        if (consumed) { p.active = false; continue; }
        // obstacles: asteroids & set pieces absorb shots
        if (ast) {
          const cell = g.asteroidGrid.query(p.pos.x, p.pos.y, p.pos.z);
          let hitA = -1;
          if (cell) for (let c = 0; c < cell.length; c++) {
            const a = cell[c];
            if (!ast.alive[a]) continue;
            if (segSphere(p.prev.x, p.prev.y, p.prev.z, p.pos.x, p.pos.y, p.pos.z, ast.pos[a * 3], ast.pos[a * 3 + 1], ast.pos[a * 3 + 2], ast.radius[a]) >= 0) { hitA = a; break; }
          }
          if (hitA >= 0) {
            g.effects.sparks(p.pos, '#d8c0a0', 5, 50, 1.6, 0.4);
            g.effects.smokePuff(p.pos, 2.5, 0.8, 0.3);
            if (p.team === 'player' && Number.isFinite(ast.hp[hitA])) { ast.hp[hitA] -= p.dmg; if (ast.hp[hitA] <= 0) g.breakAsteroid(hitA); }
            if (p.splash) this._explode(p);
            p.active = false; continue;
          }
        }
        if (obstacles.length) {
          let blocked = false;
          for (const o of obstacles) { if (p.pos.distanceToSquared(o.pos) < o.radius * o.radius) { blocked = true; break; } }
          if (blocked) { g.effects.sparks(p.pos, '#ffd0a0', 4, 50, 1.4, 0.3); if (p.splash) this._explode(p); p.active = false; continue; }
        }
        // ---- render instance
        if (n < im.instanceMatrix.count) {
          const sp = p.vel.length();
          if (kind === 'bolt') {
            tmpQ.setFromUnitVectors(Z, tmp.copy(p.vel).divideScalar(sp || 1));
            scl.set(p.size, p.size, p.size * p.len);
          } else if (kind === 'missile') {
            tmpQ.setFromUnitVectors(Z, tmp.copy(p.vel).divideScalar(sp || 1));
            scl.setScalar(p.size);
          } else {
            tmpQ.identity();
            const pulse = p.gravity ? 1 + Math.sin(g.time * 30) * 0.2 : 1;
            scl.setScalar(p.size * pulse);
          }
          m4.compose(p.pos, tmpQ, scl);
          im.setMatrixAt(n, m4);
          if (kind !== 'missile') { const k = p.team === 'player' ? 1.9 : 1.5; im.setColorAt(n, tmp3.set(p.color.r * k, p.color.g * k, p.color.b * k)); }
          n++;
        }
      }
      im.count = n;
      im.instanceMatrix.needsUpdate = true;
      if (im.instanceColor) im.instanceColor.needsUpdate = true;
    }
  }

  _expire(p) {
    if (p.gravity || p.shell || (p.kind === 'missile' && p.splash) || p.spore) this._explode(p);
    p.active = false;
  }

  _explode(p, directHit = null) {
    const g = this.game;
    p.active = false;
    const r = p.splash || 20;
    if (p.gravity) {
      g.effects.explosion(p.pos, 1.6, '#a07bff', { debris: false });
      g.effects.ring(p.pos, r * 1.4, '#c0a0ff', 0.6);
      g.audio.play('explosionM', { pos: p.pos });
    } else if (p.shell) {
      g.effects.explosion(p.pos, r / 28, p.color.getStyle(), { debris: false });
      g.audio.play('explosionM', { pos: p.pos });
    } else {
      g.effects.explosion(p.pos, Math.max(0.5, r / 30), p.kind === 'missile' ? '#ffaa44' : p.color.getStyle(), { debris: false, noRing: r < 20 });
      g.audio.play(r > 40 ? 'explosionL' : 'explosionS', { pos: p.pos });
    }
    if (p.team === 'player' || p.team === 'ally') {
      g.damageArea(p.pos, r, p.splashDmg, 'player', { weapon: p.weapon, secondary: p.secondary, exclude: directHit, shieldBonus: p.shieldBonus });
      if (p.split) {
        for (let k = 0; k < 3; k++) {
          tmp.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize().multiplyScalar(14).add(p.pos);
          g.effects.explosion(tmp, 0.5, '#ffcc66', { debris: false, noRing: true });
          g.damageArea(tmp, 14, p.dmg * 0.35, 'player', { weapon: p.weapon, secondary: true });
        }
      }
    } else {
      g.damageArea(p.pos, r, p.splashDmg, 'enemy', { source: p.source, chill: p.chill });
    }
  }

  clear() { for (const pool of Object.values(this.pools)) for (const p of pool) { p.active = false; p.target = null; p.source = null; } for (const im of Object.values(this.meshes)) im.count = 0; }
  clearTeam(team, pos = null, radius = Infinity) {
    for (const pool of Object.values(this.pools)) for (const p of pool) {
      if (!p.active || p.team !== team) continue;
      if (pos && p.pos.distanceTo(pos) > radius) continue;
      p.active = false; this.game.effects.sparks(p.pos, p.color, 2, 30, 1, 0.2);
    }
  }
  dispose() { this.game.scene.remove(this.group); for (const im of Object.values(this.meshes)) { im.geometry.dispose(); im.material.dispose(); im.dispose(); } }
}

// ---------------------------------------------------------------------------
// Player weapon systems
// ---------------------------------------------------------------------------
export class PlayerWeapons {
  constructor(game, player, loadout, stats) {
    this.game = game; this.player = player; this.stats = stats;
    this.slots = loadout.primary.map(id => ({ id, def: WEAPONS[id], heat: 0, overheated: false, cd: 0, gun: 0 }));
    this.active = 0;
    this.secondary = { id: loadout.secondary, def: SECONDARIES[loadout.secondary], ammo: 0, max: 0, cd: 0, regen: 0 };
    this.secondary.max = Math.round(this.secondary.def.ammo * stats.ammo + (game.runPerks?.ammo || 0));
    this.secondary.ammo = this.secondary.max;
    this.beam = null; this.beamTarget = null; this.beamTime = 0;
    this.lockTarget = null; this.lockProgress = 0; this.locked = false;
    this.tint = null;
  }

  get current() { return this.slots[this.active]; }

  swap() {
    if (this.slots.length < 2) return;
    this.active = (this.active + 1) % this.slots.length;
    this._stopBeam();
    this.game.audio.play('equip');
    this.game.hud.flashWeapon();
  }
  setWeapon(slotIdx, id) { this.slots[slotIdx] = { id, def: WEAPONS[id], heat: 0, overheated: false, cd: 0, gun: 0 }; this._stopBeam(); }

  update(dt, firing, secondaryPressed) {
    const g = this.game, P = this.player, st = this.stats;
    const coolMult = (g.runPerks?.cooling || 1);
    for (const s of this.slots) {
      s.cd = Math.max(0, s.cd - dt);
      const cool = st.cooling * coolMult * (s.overheated ? 0.8 : 1);
      if (!(firing && s === this.current && s.def.kind === 'beam')) s.heat = Math.max(0, s.heat - cool * dt);
      if (s.overheated && s.heat <= 30) s.overheated = false;
    }
    // secondary regen & cooldown
    const sec = this.secondary;
    sec.cd = Math.max(0, sec.cd - dt);
    if (sec.ammo < sec.max) { sec.regen += dt; if (sec.regen >= sec.def.regen) { sec.regen = 0; sec.ammo++; } } else sec.regen = 0;

    // lock-on tracking (needs soft target held under crosshair)
    const soft = P.softTarget;
    if (soft && soft === this.lockTarget && soft.alive) {
      if (!this.locked) {
        this.lockProgress += dt * 2.2;
        if (Math.floor(this.lockProgress * 6) !== Math.floor((this.lockProgress - dt * 2.2) * 6)) g.audio.play('locking');
        if (this.lockProgress >= 1) { this.locked = true; g.audio.play('lock'); }
      }
    } else if (soft && soft.alive) { this.lockTarget = soft; this.lockProgress = 0; this.locked = false; }
    else if (this.lockTarget && (!this.lockTarget.alive || !P.inCone(this.lockTarget, 0.88))) { this.lockTarget = null; this.locked = false; this.lockProgress = 0; }

    const s = this.current;
    if (firing && !P.disabled) this._firePrimary(s, dt);
    else this._stopBeam();
    if (secondaryPressed && !P.disabled) this._fireSecondary();
  }

  _heat(s, amount) {
    const g = this.game, P = this.player;
    if (P.overdrive > 0) return;
    const mult = this.stats.heatMult * (g.mission.modifiers.includes('overheat') ? 1.5 : 1);
    s.heat += amount * mult;
    if (s.heat >= 100) { s.heat = 100; s.overheated = true; g.audio.play('overheat'); g.hud.toast('WEAPON OVERHEATED', 'warn', 1.2); this._stopBeam(); }
  }

  damageMult(targetDist = 0) {
    const g = this.game, P = this.player, st = this.stats;
    let m = st.damage * (g.runPerks?.dmg || 1) * g.playerDamageMult;
    if (st.mods.has('laststand') && P.hull / P.maxHull < 0.3) m *= 1.45;
    if (st.trait === 'marksman' && targetDist > 350) m *= 1.25;
    if (P.cloak > 0) m *= 3;
    return m;
  }
  rateMult() {
    const P = this.player, st = this.stats;
    let r = st.fireRate * (this.game.runPerks?.rate || 1);
    if (P.overdrive > 0) r *= 1.5;
    if (st.mods.has('laststand') && P.hull / P.maxHull < 0.3) r *= 1.2;
    return r;
  }
  _critRoll(extra = 0) { return Math.random() < this.stats.crit + extra + (this.game.runPerks?.crit || 0); }

  _muzzle(s) {
    const P = this.player;
    const guns = P.mesh.userData.guns;
    const gun = guns[s.gun % guns.length]; s.gun++;
    return tmp.copy(gun).applyMatrix4(P.mesh.matrixWorld);
  }

  _aimDir(from, speed) {
    // Converge on crosshair point; aim assist snaps to lead position of a soft target.
    const P = this.player, g = this.game;
    const out = new THREE.Vector3();
    const tgt = P.softTarget;
    if (tgt && tgt.alive && g.settings.aimAssist && P.inCone(tgt, g.tune ? g.tune.assistCos : 0.994)) {
      const d = tgt.pos.distanceTo(from);
      const t = speed > 0 ? d / speed : 0;
      out.copy(tgt.pos).addScaledVector(tgt.vel, t).sub(from).normalize();
      return out;
    }
    out.copy(P.forward).multiplyScalar(320).add(P.pos).sub(from).normalize();
    return out;
  }

  _color(def) { return this.tint || def.color; }

  _firePrimary(s, dt) {
    const g = this.game, P = this.player, def = s.def;
    if (s.overheated) return;
    if (def.kind === 'beam') { this._updateBeam(s, dt); return; }
    if (s.cd > 0) return;
    s.cd = 1 / (def.rate * this.rateMult());
    const wasCloaked = P.cloak > 0;
    const dm = this.damageMult();
    const col = this._color(def);
    const pierceMod = this.stats.mods.has('piercing');
    const ric = g.runPerks?.ricochet || 0;
    if (def.kind === 'projectile' || def.kind === 'gravity') {
      const from = this._muzzle(s).clone();
      const dir = this._aimDir(from, def.speed);
      dir.x += (Math.random() - 0.5) * def.spread; dir.y += (Math.random() - 0.5) * def.spread; dir.normalize();
      const crit = this._critRoll();
      const vel = dir.multiplyScalar(def.speed).addScaledVector(P.vel, 0.6);
      g.projectiles.spawn({
        kind: def.kind === 'gravity' ? 'orb' : (def.splash ? 'orb' : 'bolt'), team: 'player', pos: from, vel, life: def.life,
        dmg: def.damage * dm * (crit ? 2 : 1), crit, radius: def.splash ? 2.2 : 1.2, size: def.size * (crit ? 1.3 : 1), len: 6,
        color: col, splash: def.kind === 'gravity' ? def.splash : (def.splash ? def.splash * (pierceMod ? 1.3 : 1) : 0), splashDmg: def.damage * dm * 0.6,
        weapon: s.id, gravity: def.kind === 'gravity', pull: def.pull, pierce: s.id === 'pulse' && pierceMod ? 1 : 0,
        shieldBonus: def.shieldBonus || 1, trail: def.kind === 'gravity' ? '#a07bff' : (def.splash ? col : null), ricochet: def.kind === 'projectile' && !def.splash ? ric : 0,
        bounce: g.mutators.has('bounce') ? 2 : 0,
      });
      if (s.id === 'pulse') { const f2 = this._muzzle(s).clone(); const d2 = this._aimDir(f2, def.speed).multiplyScalar(def.speed).addScaledVector(P.vel, 0.6); g.projectiles.spawn({ kind: 'bolt', team: 'player', pos: f2, vel: d2, life: def.life, dmg: def.damage * dm, radius: 1.2, size: def.size, len: 6, color: col, weapon: s.id, pierce: pierceMod ? 1 : 0, ricochet: ric, bounce: g.mutators.has('bounce') ? 2 : 0 }); }
      g.effects.glowPuff(from, col, def.splash ? 4 : 2.2, 0.06);
      g.audio.play(s.id === 'gravity' ? 'gravity' : s.id === 'plasma' ? 'plasma' : 'pulse', { volume: 0.7 });
    } else if (def.kind === 'pellets') {
      const from = this._muzzle(s).clone();
      const base = this._aimDir(from, def.speed);
      for (let k = 0; k < def.pellets; k++) {
        const d = base.clone(); d.x += (Math.random() - 0.5) * def.spread * 2; d.y += (Math.random() - 0.5) * def.spread * 2; d.z += (Math.random() - 0.5) * def.spread * 2; d.normalize();
        const crit = this._critRoll();
        g.projectiles.spawn({ kind: 'bolt', team: 'player', pos: from, vel: d.multiplyScalar(def.speed * (0.9 + Math.random() * 0.2)).addScaledVector(P.vel, 0.7), life: def.life * (0.85 + Math.random() * 0.3), dmg: def.damage * dm * (crit ? 2 : 1), crit, radius: 1.4, size: def.size, len: 3, color: col, weapon: s.id, pierce: pierceMod ? 1 : 0, bounce: g.mutators.has('bounce') ? 1 : 0 });
      }
      g.effects.glowPuff(from, col, 5, 0.08);
      g.effects.sparks(from, col, 6, 120, 1.2, 0.15, base);
      g.audio.play('scatter', { volume: 0.8 });
      P.kick(0.6);
    } else if (def.kind === 'hitscan') {
      const from = this._muzzle(s).clone();
      const dir = this._aimDir(from, 0);
      const hits = g.raycastUnits(from, dir, def.range, 'player');
      const pierce = pierceMod;
      let end = from.clone().addScaledVector(dir, def.range);
      const crit = this._critRoll(def.crit);
      for (const h of hits) {
        const dmgv = def.damage * this.damageMult(h.dist) * (crit ? 2.2 : 1);
        g.damageUnit(h.unit, dmgv, { source: 'player', weapon: s.id, crit, pos: h.point });
        g.effects.sparks(h.point, col, 12, 140, 1.8, 0.4);
        end = h.point;
        if (!pierce) break;
        end = from.clone().addScaledVector(dir, def.range);
      }
      const blocked = g.raycastObstacles(from, dir, end.distanceTo(from));
      if (blocked) end = blocked;
      g.effects.beam(from, end, col, crit ? 1.3 : 0.9, 0.35);
      g.effects.beam(from, end, '#ffffff', 0.3, 0.18);
      g.effects.glowPuff(from, col, 6, 0.12);
      g.effects.ring(from, 6, col, 0.25, P.forward);
      g.audio.play('rail');
      P.kick(1.4);
    } else if (def.kind === 'chain') {
      const from = this._muzzle(s).clone();
      const first = g.findTarget(P.pos, P.forward, Math.cos(def.cone), def.range, 'player');
      if (!first) {
        const end = from.clone().addScaledVector(P.forward, def.range * 0.6);
        end.x += (Math.random() - 0.5) * 30; end.y += (Math.random() - 0.5) * 30;
        g.effects.arc(from, end, col, 8, 0.08);
      } else {
        let cur = first, prevPos = from, dmgv = def.damage * dm;
        const hitSet = new Set();
        for (let c = 0; c <= def.chains && cur; c++) {
          hitSet.add(cur);
          const crit = this._critRoll();
          const armorPenalty = cur.def && cur.def.hp > 500 ? 0.6 : 1;
          g.effects.arc(prevPos, cur.pos, col, 6 + c * 2, 0.12);
          g.damageUnit(cur, dmgv * armorPenalty * (crit ? 2 : 1), { source: 'player', weapon: s.id, crit, pos: cur.pos });
          prevPos = cur.pos; dmgv *= 0.82;
          cur = g.nearestEnemy(cur.pos, def.chainRange, null, hitSet);
        }
      }
      g.audio.play('arc', { volume: 0.7 });
    }
    if (wasCloaked) P.breakCloak();
    this._heat(s, def.heat);
  }

  _updateBeam(s, dt) {
    const g = this.game, P = this.player, def = s.def;
    const from = tmp2.copy(P.mesh.userData.guns[0]).applyMatrix4(P.mesh.matrixWorld);
    const dir = this._aimDir(from, 0);
    const hits = g.raycastUnits(from, dir, def.range, 'player');
    let end = from.clone().addScaledVector(dir, def.range);
    const h = hits[0];
    if (h) {
      end = h.point;
      if (this.beamTarget === h.unit) this.beamTime += dt; else { this.beamTarget = h.unit; this.beamTime = 0; }
      const ramp = 1 + Math.min(1, this.beamTime / 2) * (def.ramp - 1);
      g.damageUnit(h.unit, def.damage * this.damageMult(h.dist) * ramp * dt, { source: 'player', weapon: s.id, pos: h.point, dot: true });
      if (Math.random() < 0.5) g.effects.sparks(h.point, this._color(def), 3, 90, 1.6, 0.25);
    } else { this.beamTarget = null; this.beamTime = 0; }
    const blocked = g.raycastObstacles(from, dir, end.distanceTo(from));
    if (blocked) end = blocked;
    const w = 0.7 + Math.sin(g.time * 50) * 0.15 + Math.min(1, this.beamTime / 2) * 0.5;
    g.effects.beam(from, end, this._color(def), w, dt * 1.6);
    g.effects.beam(from, end, '#ffffff', w * 0.35, dt * 1.6);
    g.audio.loop('beam', true, { volume: 0.12 });
    this.beam = true;
    if (P.cloak > 0) P.breakCloak();
    s.heat += def.heat * dt * this.stats.heatMult * (g.mission.modifiers.includes('overheat') ? 1.5 : 1) * (P.overdrive > 0 ? 0 : 1);
    if (s.heat >= 100) { s.heat = 100; s.overheated = true; g.audio.play('overheat'); g.hud.toast('WEAPON OVERHEATED', 'warn', 1.2); this._stopBeam(); }
  }
  _stopBeam() { if (this.beam) { this.beam = null; this.game.audio.loop('beam', false); } this.beamTarget = null; this.beamTime = 0; }

  _fireSecondary() {
    const g = this.game, P = this.player, sec = this.secondary, def = sec.def;
    if (sec.cd > 0) return;
    if (sec.ammo <= 0) { g.audio.play('error'); g.hud.toast('NO ORDNANCE', 'warn', 0.8); sec.cd = 0.4; return; }
    sec.ammo--; sec.cd = def.cooldown;
    const dm = this.damageMult();
    if (sec.id === 'drones') {
      for (let k = 0; k < def.salvo; k++) g.spawnPlayerDrone(def.life, def.damage * dm);
      g.audio.play('drone');
      return;
    }
    const target = this.locked && this.lockTarget?.alive ? this.lockTarget : (P.softTarget || null);
    const guns = P.mesh.userData.guns;
    for (let k = 0; k < def.salvo; k++) {
      const from = tmp.copy(guns[k % guns.length]).applyMatrix4(P.mesh.matrixWorld).clone();
      const side = new THREE.Vector3(k % 2 ? 1 : -1, 0.3, 0).applyQuaternion(P.quat).multiplyScalar(40);
      const vel = P.forward.clone().multiplyScalar(def.speed * 0.6).add(side).addScaledVector(P.vel, 0.8);
      g.projectiles.spawn({
        kind: 'missile', team: 'player', pos: from, vel, life: def.life, dmg: def.damage * dm, radius: 2, size: sec.id === 'torpedo' ? 2.4 : 1.1,
        splash: def.splash, splashDmg: def.damage * dm * 0.7, target: sec.id === 'torpedo' ? (target || null) : target, turn: target ? def.turn : 0,
        weapon: sec.id, secondary: true, trail: sec.id === 'torpedo' ? '#ff7a4d' : '#ffd27a', split: this.stats.mods.has('split') && sec.id === 'missiles',
      });
    }
    if (this.stats.mods.has('swarm') && sec.id === 'missiles') {
      const others = g.enemiesNear(P.pos, 600).filter(u => u !== target).slice(0, 2);
      for (const o of others) {
        const from = P.pos.clone().add(new THREE.Vector3(0, -2, 0).applyQuaternion(P.quat));
        g.projectiles.spawn({ kind: 'missile', team: 'player', pos: from, vel: P.forward.clone().multiplyScalar(160).addScaledVector(P.vel, 0.8), life: 4, dmg: def.damage * dm * 0.45, radius: 1.5, size: 0.7, splash: 8, splashDmg: def.damage * dm * 0.3, target: o, turn: 4, weapon: sec.id, secondary: true, trail: '#ffe0a0' });
      }
    }
    g.audio.play(sec.id === 'torpedo' ? 'torpedo' : 'missile');
    if (P.cloak > 0) P.breakCloak();
  }

  refill(amount = Infinity) { this.secondary.ammo = Math.min(this.secondary.max, this.secondary.ammo + amount); }
  ventHeat() { for (const s of this.slots) { s.heat = 0; s.overheated = false; } }
  dispose() { this._stopBeam(); }
}
