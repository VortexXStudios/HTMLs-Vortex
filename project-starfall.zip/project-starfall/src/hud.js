// ============================================================================
// In-mission HUD (DOM overlay + radar canvas). Pooled elements, no per-frame
// allocation of DOM nodes.
// ============================================================================
import * as THREE from 'three';
import { WEAPONS, SECONDARIES, ABILITIES, COSMETICS } from './data.js';
import { Comms } from './comms.js';

const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3();
const el = (tag, cls, parent, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; if (parent) parent.appendChild(e); return e; };
const icon = n => `assets/icons/${n}.png`;

export class HUD {
  constructor(root) {
    this.root = root;
    this.root.innerHTML = '';
    this.root.classList.add('hud');
    const r = this.root;
    // objective
    this.obj = el('div', 'hud-obj panel', r);
    this.objTitle = el('div', 'hud-obj-title', this.obj);
    this.objLines = el('div', 'hud-obj-lines', this.obj);
    this.modsEl = el('div', 'hud-mods', this.obj);
    // score
    this.scoreBox = el('div', 'hud-score panel', r);
    this.scoreEl = el('div', 'hud-score-val', this.scoreBox, '0');
    this.comboEl = el('div', 'hud-combo', this.scoreBox);
    this.lootEl = el('div', 'hud-loot', this.scoreBox);
    this.scoreFloat = el('div', 'hud-score-float', this.scoreBox);
    // target panel
    this.target = el('div', 'hud-target panel', r);
    this.targetName = el('div', 'hud-target-name', this.target);
    this.targetShield = el('div', 'bar shield', this.target, '<i></i>');
    this.targetHull = el('div', 'bar hull', this.target, '<i></i>');
    this.targetInfo = el('div', 'hud-target-info', this.target);
    // boss bar
    this.boss = el('div', 'hud-boss', r);
    this.bossName = el('div', 'hud-boss-name', this.boss);
    this.bossBar = el('div', 'bar boss', this.boss, '<i></i><b></b>');
    this.bossPhase = el('div', 'hud-boss-phase', this.boss);
    // ship status
    this.status = el('div', 'hud-status panel', r);
    this.shieldBar = this._statBar(this.status, 'SHIELD', 'shield');
    this.hullBar = this._statBar(this.status, 'HULL', 'hull');
    this.boostBar = this._statBar(this.status, 'BOOST', 'boost');
    this.ability = el('div', 'hud-ability', this.status);
    this.abilityIcon = el('img', '', this.ability);
    this.abilityCd = el('div', 'hud-ability-cd', this.ability);
    this.abilityKey = el('span', 'key', this.ability, 'F');
    // weapons
    this.weapons = el('div', 'hud-weapons panel', r);
    this.wSlots = [0, 1].map(i => { const s = el('div', 'hud-wslot', this.weapons); const img = el('img', '', s); const n = el('div', 'hud-wname', s); const h = el('div', 'bar heat', s, '<i></i>'); return { s, img, n, h }; });
    this.secEl = el('div', 'hud-wslot sec', this.weapons);
    this.secImg = el('img', '', this.secEl); this.secName = el('div', 'hud-wname', this.secEl); this.secAmmo = el('div', 'hud-ammo', this.secEl);
    el('div', 'hud-keys', this.weapons, '<span class="key">LMB</span> fire <span class="key">RMB</span> ordnance <span class="key">X</span> swap');
    // radar
    this.radarWrap = el('div', 'hud-radar', r);
    this.radar = el('canvas', '', this.radarWrap); this.radar.width = 200; this.radar.height = 200;
    this.rctx = this.radar.getContext('2d');
    // crosshair
    this.cross = el('div', 'hud-cross', r, `<svg viewBox="-50 -50 100 100"><circle r="14" class="c1"/><path d="M-26 0H-18M18 0H26M0 -26V-18M0 18V26" class="c2"/><circle r="1.6" class="c3"/></svg>`);
    this.hitMark = el('div', 'hud-hitmark', r, `<svg viewBox="-50 -50 100 100"><path d="M-14 -14L-7 -7M14 -14L7 -7M-14 14L-7 7M14 14L7 7"/></svg>`);
    this.cursor = el('div', 'hud-cursor', r);
    this.lock = el('div', 'hud-lock', r, `<svg viewBox="-50 -50 100 100"><path class="lk" d="M-30 -18V-30H-18M18 -30H30V-18M30 18V30H18M-18 30H-30V18"/></svg>`);
    this.lead = el('div', 'hud-lead', r);
    // markers & damage numbers
    this.markerLayer = el('div', 'hud-markers', r);
    this.markers = new Map();
    this.dmgPool = []; for (let i = 0; i < 40; i++) { const d = el('div', 'hud-dmg', r); d.style.display = 'none'; this.dmgPool.push({ e: d, t: 0, pos: new THREE.Vector3(), v: 0 }); }
    this.dmgIdx = 0;
    // damage direction
    // edge arrows for off-screen attackers
    this.threats = [0, 1, 2, 3, 4].map(() => { const e = el('div', 'hud-threat', r, '<i></i>'); e.style.display = 'none'; return e; });
    this.dmgDirs = [0, 1, 2, 3].map(() => { const d = el('div', 'hud-dmgdir', r); d.style.opacity = 0; return { e: d, t: 0, a: 0 }; });
    this.dmgDirIdx = 0;
    // text layers
    this.toasts = el('div', 'hud-toasts', r);
    this.warnEl = el('div', 'hud-warn', r);
    this.bannerEl = el('div', 'hud-banner', r, '<h2></h2><p></p>');
    this.promptEl = el('div', 'hud-prompt', r);
    this.challengeEl = el('div', 'hud-challenge', r);
    this.retreatEl = el('div', 'hud-retreat', r, '<span>JUMP DRIVE CHARGING — hold J</span><div class="bar"><i></i></div>');
    this.pickupFeed = el('div', 'hud-feed', r);
    this.letterbox = el('div', 'hud-letterbox', r, '<div class="lb top"></div><div class="lb bot"></div><div class="lb-title"><h1></h1><p></p><small>Press SPACE / click to skip</small></div>');
    this.choiceEl = el('div', 'hud-choice', r);
    this.fpsEl = el('div', 'hud-fps', r);
    this.boundsEl = el('div', 'hud-bounds', r, 'LEAVING COMBAT ZONE — TURN BACK');
    this.vignette = el('div', 'hud-hurt', r);
    this.helpEl = el('div', 'hud-help panel', r, `<b>CONTROLS</b><br><span class="key">Mouse</span> steer · <span class="key">W/S</span> throttle · <span class="key">A/D</span> strafe · <span class="key">Q/E</span> roll<br><span class="key">Shift</span> boost · <span class="key">Space</span> evasive dash · <span class="key">F</span> ability · <span class="key">T</span> cycle target<br><span class="key">LMB</span> primary · <span class="key">RMB</span>/<span class="key">R</span> ordnance (hold aim to lock) · <span class="key">X</span> swap weapon · <span class="key">G</span> interact · <span class="key">J</span> retreat · <span class="key">Esc</span> pause`);
    this.root.style.display = 'none';
    this.toastList = []; this.warnT = 0; this.bannerT = 0; this.flashT = 0; this.hurtPulse = 0;
    this.fpsAcc = 0; this.fpsN = 0;
    this.incomingList = [];
    this.waypoint = null;
    this.lastLoot = '';
    this.comms = new Comms(r, null);
  }

  _statBar(parent, label, cls) {
    const w = el('div', 'hud-stat ' + cls, parent);
    el('span', 'lbl', w, label);
    const b = el('div', 'bar ' + cls, w, '<i></i><em></em>');
    const v = el('span', 'val', w);
    return { w, fill: b.firstChild, ghost: b.children[1], v, last: 1 };
  }

  startMission(game) {
    this.game = game;
    this.root.style.display = '';
    for (const m of this.markers.values()) m.e.remove();
    this.markers.clear();
    this.toasts.innerHTML = ''; this.toastList = [];
    this.choiceEl.style.display = 'none'; this.letterbox.classList.remove('on');
    this.boss.style.display = 'none'; this.target.style.display = 'none';
    const P = game.player;
    this.abilityIcon.src = icon(ABILITIES[P.ability.id].icon);
    this.secImg.src = icon(SECONDARIES[P.weapons.secondary.id].icon);
    this.secName.textContent = SECONDARIES[P.weapons.secondary.id].name;
    const s = game.settings;
    this.helpEl.style.display = s.tutorialSeen ? 'none' : '';
    this.helpT = s.tutorialSeen ? 0 : 14;
    this.modsEl.innerHTML = (game.mission.modifiers || []).map(m => `<img title="${m}" src="${icon(modIcon(m))}">`).join('') + (game.mission.mutators || []).map(m => `<span class="mut">${m}</span>`).join('');
    this.radarJam = game.mission.modifiers.includes('radarjam');
    this.fpsEl.style.display = s.showFps ? '' : 'none';
    this.scoreEl.textContent = '0'; this.comboEl.textContent = '';
    this.prompt(null); this.challenge(null); this.retreat(0);
    this.setWaypoint(null);
  }
  endMission() { this.comms.reset(); this.root.classList.remove('cine'); this.root.style.display = 'none'; for (const m of this.markers.values()) m.e.remove(); this.markers.clear(); this.game = null; this.choiceEl.style.display = 'none'; }

  // ------------------------------------------------------------------ events
  toast(text, kind = 'info', dur = 2) {
    if (this.toastList.some(t => t.text === text)) return;
    const e = el('div', 'toast ' + kind, this.toasts, text);
    this.toastList.push({ e, t: dur, text });
    if (this.toastList.length > 4) { const o = this.toastList.shift(); o.e.remove(); }
  }
  warn(text, dur = 1.5) { this.warnEl.textContent = text; this.warnEl.classList.add('on'); this.warnT = dur; this.game?.audio.play('warning'); }
  banner(title, sub = '', dur = 2) { this.bannerEl.querySelector('h2').textContent = title; this.bannerEl.querySelector('p').textContent = sub; this.bannerEl.classList.remove('on'); void this.bannerEl.offsetWidth; this.bannerEl.classList.add('on'); this.bannerT = dur; }
  flashWeapon() { this.weapons.classList.remove('pulse'); void this.weapons.offsetWidth; this.weapons.classList.add('pulse'); }
  abilityUsed() { this.ability.classList.remove('pulse'); void this.ability.offsetWidth; this.ability.classList.add('pulse'); }
  hullHit(frac) { this.hurtPulse = Math.min(1, this.hurtPulse + frac * 4 + 0.1); if (this.game?.settings.reduceFlashing) this.hurtPulse *= 0.5; }
  damageIndicator(dir) {
    const g = this.game; if (!g) return;
    const cam = g.camera;
    tmp.copy(dir).applyQuaternion(tmp2.set(0, 0, 0) && cam.quaternion.clone().invert());
    const a = Math.atan2(tmp.x, tmp.y);
    const d = this.dmgDirs[this.dmgDirIdx++ % 4];
    d.t = 1; d.e.style.transform = `translate(-50%,-50%) rotate(${a}rad)`;
  }
  hitMarker(crit = false, shield = false) { this.hitMark.className = 'hud-hitmark on' + (crit ? ' crit' : '') + (shield ? ' shield' : ''); this.hitT = 0.12; }
  damageNumber(pos, amount, crit, shield) {
    if (!this.game?.settings.damageNumbers || amount < 1) return;
    const d = this.dmgPool[this.dmgIdx++ % this.dmgPool.length];
    d.pos.copy(pos); d.t = 0.8; d.v = 0;
    d.e.textContent = Math.round(amount);
    d.e.className = 'hud-dmg' + (crit ? ' crit' : '') + (shield ? ' shield' : '');
    d.e.style.display = '';
  }
  combo(n) {
    if (n < 2) { this.comboEl.textContent = ''; return; }
    this.comboEl.innerHTML = `COMBO <b>x${n}</b>`;
    this.comboEl.classList.remove('bump'); void this.comboEl.offsetWidth; this.comboEl.classList.add('bump');
  }
  score(total, add, label) {
    this.scoreEl.textContent = total.toLocaleString();
    if (add > 0) { const f = el('div', 'sf', this.scoreFloat, `+${add}${label ? ' <em>' + label + '</em>' : ''}`); setTimeout(() => f.remove(), 900); if (this.scoreFloat.children.length > 5) this.scoreFloat.firstChild.remove(); }
  }
  pickup(type, amount) {
    if (type === 'credits' || type === 'salvage') return;
    const names = { alloy: `+${amount} Alloy`, cores: `+${amount} Quantum Core`, repair: 'Hull repaired', ammo: 'Ordnance resupplied', core: 'Energy core secured', tokens: `+${amount} Event Token`, relic: 'Relic recovered' };
    if (this.pickupFeed.children.length > 4) this.pickupFeed.firstChild.remove();
    const f = el('div', 'feed-item', this.pickupFeed, names[type] || type);
    setTimeout(() => f.remove(), 1800);
  }
  trackUnit(u) {
    if (this.markers.has(u)) return;
    const e = el('div', 'hud-marker', this.markerLayer, `<div class="br"></div><span></span>`);
    this.markers.set(u, { e, label: e.querySelector('span') });
  }
  untrackUnit(u) { const m = this.markers.get(u); if (m) { m.e.remove(); this.markers.delete(u); } }
  incoming(pos) { this.incomingList.push({ pos: pos.clone(), t: 3 }); }
  prompt(text) { this.promptEl.textContent = text || ''; this.promptEl.style.display = text ? '' : 'none'; }
  challenge(text) { this.challengeEl.textContent = text || ''; this.challengeEl.style.display = text ? '' : 'none'; }
  retreat(f) { this.retreatEl.style.display = f > 0 ? '' : 'none'; this.retreatEl.querySelector('i').style.width = `${Math.min(1, f) * 100}%`; }
  setWaypoint(wp) { this.waypoint = wp; if (!wp && this.wpEl) { this.wpEl.remove(); this.wpEl = null; } if (wp && !this.wpEl) { this.wpEl = el('div', 'hud-marker waypoint', this.markerLayer, `<div class="br"></div><span></span>`); } }
  cinematic(title, sub, story = false) {
    this.root.classList.toggle('cine', !!title);
    if (title) this.letterbox.classList.toggle('story', !!story); // keep the style while the bars slide away
    if (!title) { this.letterbox.classList.remove('on'); return; }
    this.letterbox.querySelector('h1').textContent = title; this.letterbox.querySelector('p').textContent = sub || '';
    this.letterbox.classList.add('on');
  }
  showChoice(c) {
    if (!c) { this.choiceEl.style.display = 'none'; this.choiceEl.innerHTML = ''; return; }
    this.game?.input.exitLock();
    this.choiceEl.style.display = '';
    this.choiceEl.innerHTML = `<div class="choice-box"><h2>${c.title}</h2><p>${c.subtitle || ''}</p><div class="choice-opts"></div></div>`;
    const wrap = this.choiceEl.querySelector('.choice-opts');
    c.options.forEach((o, i) => {
      const b = el('button', 'choice-card' + (o.disabled ? ' disabled' : ''), wrap, `<span class="key">${i + 1}</span>${o.icon ? `<img src="${icon(o.icon)}">` : ''}<h3>${o.title}</h3><p>${o.desc || ''}</p>`);
      b.addEventListener('click', () => this.game?.pickChoice(o.id));
    });
  }

  // ------------------------------------------------------------------ frame
  update(dt, g) {
    const P = g.player; const cam = g.camera;
    this.comms.update(dt);
    const W = window.innerWidth, H = window.innerHeight;
    // fps
    if (g.settings.showFps) { this.fpsAcc += dt; this.fpsN++; if (this.fpsAcc > 0.5) { this.fpsEl.textContent = `${Math.round(this.fpsN / this.fpsAcc)} FPS · ${g.units.filter(u => u.alive).length} units`; this.fpsAcc = 0; this.fpsN = 0; } }
    if (this.helpT > 0) { this.helpT -= dt; if (this.helpT <= 0) { this.helpEl.style.display = 'none'; g.settings.tutorialSeen = true; } }
    // objective
    this.objT = (this.objT || 0) - dt;
    if (this.objT <= 0) {
      this.objT = 0.2; // objective panel refreshes at 5 Hz
      const st = g.objective.status();
      if (st.title !== this._lastTitle) { this.objTitle.textContent = st.title; this._lastTitle = st.title; }
      const html = st.lines.map(l => `<div class="ol${l.done ? ' done' : ''}${l.danger ? ' danger' : ''}">${l.text}${l.progress != null ? `<div class="bar thin"><i style="width:${Math.round(Math.max(0, Math.min(1, l.progress)) * 100)}%"></i></div>` : ''}</div>`).join('');
      if (html !== this._lastLines) { this.objLines.innerHTML = html; this._lastLines = html; }
    }
    // loot
    const L = g.loot;
    const lt = `<span><img src="${icon('credits')}">${L.credits}</span><span><img src="${icon('crystal_blue')}">${L.alloy}</span>${L.cores ? `<span><img src="${icon('crystal_purple')}">${L.cores}</span>` : ''}${L.tokens ? `<span><img src="${icon('crystal_red')}">${L.tokens}</span>` : ''}`;
    if (lt !== this.lastLoot) { this.lootEl.innerHTML = lt; this.lastLoot = lt; }
    // ship bars
    this._setBar(this.shieldBar, P.maxShield ? P.shield / P.maxShield : 0, `${Math.ceil(P.shield)}`);
    this._setBar(this.hullBar, P.hull / P.maxHull, `${Math.ceil(P.hull)}`);
    this._setBar(this.boostBar, P.boost / P.stats.boostMax, '');
    this.hullBar.w.classList.toggle('critical', P.hull / P.maxHull < 0.3);
    const ab = P.ability;
    const cdFrac = ab.cd > 0 ? ab.cd / (ab.def.cooldown * P.stats.abilityCd) : 0;
    this.abilityCd.style.height = `${cdFrac * 100}%`;
    const cdTxt = ab.cd > 0 ? String(Math.ceil(ab.cd)) : '';
    if (cdTxt !== this._cdTxt) { this.abilityCd.textContent = cdTxt; this._cdTxt = cdTxt; }
    this.ability.classList.toggle('ready', ab.cd <= 0);
    // weapons
    const Wp = P.weapons;
    Wp.slots.forEach((s, i) => {
      const ui = this.wSlots[i]; if (!ui) return;
      if (ui.id !== s.id) { ui.id = s.id; ui.img.src = icon(WEAPONS[s.id].icon); ui.n.textContent = WEAPONS[s.id].name; }
      ui.s.classList.toggle('active', i === Wp.active);
      ui.s.classList.toggle('over', s.overheated);
      ui.h.firstChild.style.width = `${s.heat}%`;
    });
    const sec = Wp.secondary;
    const am = `${sec.ammo}<small>/${sec.max}</small>`;
    if (am !== this._ammo) { this.secAmmo.innerHTML = am; this._ammo = am; }
    this.secEl.classList.toggle('empty', sec.ammo === 0);
    // crosshair placement: project a point ahead of the ship
    const aimPt = tmp.copy(P.forward).multiplyScalar(320).add(P.pos);
    const s = this._toScreen(aimPt, cam, W, H);
    if (s) { this.cross.style.transform = `translate(${s.x}px, ${s.y}px)`; this.hitMark.style.transform = this.cross.style.transform; }
    this.cross.style.opacity = P.alive && !g.cinematic ? 1 : 0;
    // virtual stick cursor
    const inp = g.input;
    let cx, cy;
    const as = P.aiming && P.aimDir ? this._toScreen(tmp.copy(P.aimDir).multiplyScalar(320).add(P.pos), cam, W, H) : null;
    if (as) { cx = as.x; cy = as.y; } // mouse aim: the ring marks where the ship is turning to
    else {
      const R = Math.min(W, H) * 0.42 / (g.settings.mouseSensitivity || 1);
      cx = W / 2 + inp.stick.x * R; cy = H / 2 + inp.stick.y * R * (g.settings.invertY ? -1 : 1);
    }
    this.cursor.classList.toggle('aim', !!as);
    this.cursor.style.transform = `translate(${cx}px, ${cy}px)`;
    this.cursor.style.opacity = P.alive && !g.cinematic ? 0.9 : 0;
    if (this.hitT > 0) { this.hitT -= dt; if (this.hitT <= 0) this.hitMark.className = 'hud-hitmark'; }
    // target panel + lock bracket + lead indicator
    const t = P.softTarget;
    if (t && t.alive && !g.cinematic) {
      this.target.style.display = '';
      const nm = t.name + (t.variant ? ` <em>${t.variant.name}</em>` : '');
      if (this._tn !== nm) { this.targetName.innerHTML = nm; this._tn = nm; }
      this.targetShield.firstChild.style.width = `${t.maxShield ? Math.max(0, t.shield / t.maxShield) * 100 : 0}%`;
      this.targetShield.style.display = t.maxShield ? '' : 'none';
      this.targetHull.firstChild.style.width = `${Math.max(0, t.hp / t.maxHp) * 100}%`;
      const dist = Math.round(t.pos.distanceTo(P.pos));
      const ti = `${Math.round(dist / 5) * 5}m${t.protector && t.protector.alive ? ' · SHIELDED BY BASTION' : ''}${t.def.role ? ' · ' + t.def.role : ''}`;
      if (ti !== this._ti) { this.targetInfo.textContent = ti; this._ti = ti; }
      const ts = this._toScreen(t.pos, cam, W, H);
      if (ts) {
        const sz = Math.max(36, Math.min(200, t.radius * 2 * H / (dist * 1.2 + 1)));
        this.lock.style.display = '';
        this.lock.style.transform = `translate(${ts.x}px, ${ts.y}px) scale(${sz / 60})`;
        this.lock.classList.toggle('locked', Wp.locked && Wp.lockTarget === t);
        this.lock.classList.toggle('hard', P.hardTarget === t);
        this.lock.style.setProperty('--p', Wp.lockTarget === t ? Wp.lockProgress : 0);
        // lead indicator for projectile weapons
        const wd = Wp.current.def;
        if (wd.speed) {
          const lt = dist / wd.speed;
          const lp = tmp2.copy(t.pos).addScaledVector(t.vel, lt).addScaledVector(P.vel, -lt * 0.6);
          const ls = this._toScreen(lp, cam, W, H);
          if (ls) { this.lead.style.display = ''; this.lead.style.transform = `translate(${ls.x}px, ${ls.y}px)`; } else this.lead.style.display = 'none';
        } else this.lead.style.display = 'none';
      } else { this.lock.style.display = 'none'; this.lead.style.display = 'none'; }
    } else { this.target.style.display = 'none'; this.lock.style.display = 'none'; this.lead.style.display = 'none'; }
    // boss bar
    const b = g.boss;
    if (b && b.dying < 0 && !b.retreated && !b.defeated) {
      this.boss.style.display = '';
      if (this.bossName.textContent !== b.name) this.bossName.textContent = b.name;
      const f = b.hpFrac();
      this.bossBar.firstChild.style.width = `${f * 100}%`;
      this.bossBar.children[1].style.width = `${f * 100}%`;
      const ph = b.phaseName();
      if (this.bossPhase.textContent !== ph) this.bossPhase.textContent = ph;
    } else this.boss.style.display = 'none';
    // markers for tracked units
    for (const [u, m] of this.markers) {
      if (!u.alive) { m.e.remove(); this.markers.delete(u); continue; }
      const label = u.marker || (u.bounty ? 'BOUNTY' : '');
      const d = Math.round(u.pos.distanceTo(P.pos) / 10) * 10;
      const txt = `${label} ${d}m`;
      if (m.label.textContent !== txt) m.label.textContent = txt;
      this._placeMarker(m.e, u.pos, cam, W, H, u.team === 'ally' ? 'ally' : u.team === 'neutral' ? 'neutral' : 'enemy');
      m.e.classList.toggle('hurt', u.team === 'ally' && g.time - u.lastHit < 0.4);
    }
    if (this.wpEl && this.waypoint) { this.wpEl.querySelector('span').textContent = `${this.waypoint.label} ${Math.round(this.waypoint.pos.distanceTo(P.pos))}m`; this._placeMarker(this.wpEl, this.waypoint.pos, cam, W, H, 'ally'); }
    this._threatArrows(g, cam, W, H);
    // damage numbers
    for (const d of this.dmgPool) {
      if (d.t <= 0) continue;
      d.t -= dt; d.v += dt * 40;
      const ds = this._toScreen(d.pos, cam, W, H);
      if (!ds || d.t <= 0) { d.e.style.display = 'none'; d.t = 0; continue; }
      d.e.style.transform = `translate(${ds.x}px, ${ds.y - d.v}px)`;
      d.e.style.opacity = Math.min(1, d.t * 2.5);
    }
    for (const d of this.dmgDirs) { if (d.t > 0) { d.t -= dt * 1.4; d.e.style.opacity = Math.max(0, d.t); } }
    // texts
    for (const t2 of this.toastList) { t2.t -= dt; if (t2.t <= 0) t2.e.classList.add('out'); }
    this.toastList = this.toastList.filter(t2 => { if (t2.t < -0.4) { t2.e.remove(); return false; } return true; });
    if (this.warnT > 0) { this.warnT -= dt; if (this.warnT <= 0) this.warnEl.classList.remove('on'); }
    if (this.bannerT > 0) { this.bannerT -= dt; if (this.bannerT <= 0) this.bannerEl.classList.remove('on'); }
    this.hurtPulse = Math.max(0, this.hurtPulse - dt * 1.8);
    this.vignette.style.opacity = Math.min(1, this.hurtPulse * 0.9 + (P.hull / P.maxHull < 0.25 ? 0.35 + Math.sin(g.realTime * 6) * 0.15 : 0));
    this.boundsEl.classList.toggle('on', P.outOfBounds > 0);
    // radar (throttled to ~30 Hz; skipped during headless simulation)
    this.radarT = (this.radarT || 0) - dt;
    if (!g.headless && this.radarT <= 0) { this.radarT = 1 / 30; this._radar(g, 1 / 30); }
  }

  _setBar(b, f, txt) {
    f = Math.max(0, Math.min(1, f));
    b.fill.style.width = `${f * 100}%`;
    b.last += (f - b.last) * 0.05; if (b.last < f) b.last = f;
    b.ghost.style.width = `${b.last * 100}%`;
    if (txt !== b._t) { b.v.textContent = txt; b._t = txt; }
  }

  // Off-screen enemies close enough to matter get an arrow on the screen edge. Attackers pressing a run pulse red.
  _threatArrows(g, cam, W, H) {
    const P = g.player;
    const list = [];
    if (P.alive && !g.cinematic) for (const u of g.units) {
      if (!u.alive || u.team !== 'enemy' || u.passive || u.structure || u.part || u.untargetable) continue;
      const d = u.pos.distanceTo(P.pos); if (d > 750) continue;
      tmp2.copy(u.pos).project(cam);
      const behind = tmp2.z > 1;
      if (!behind && Math.abs(tmp2.x) < 0.98 && Math.abs(tmp2.y) < 0.98) continue;
      const attacking = u.engaged !== false && (u.ai.state === 'attack' || u.behavior === 'kamikaze' || u.ai.charge > 0);
      list.push({ u, d, attacking, x: behind ? -tmp2.x : tmp2.x, y: behind ? -tmp2.y : tmp2.y });
    }
    list.sort((a, b) => (b.attacking - a.attacking) || a.d - b.d);
    for (let i = 0; i < this.threats.length; i++) {
      const e = this.threats[i], t = list[i];
      if (!t) { if (e.style.display !== 'none') e.style.display = 'none'; continue; }
      const a = Math.atan2(t.y, t.x);
      const rx = W * 0.5 - 34, ry = H * 0.5 - 34;
      const m = Math.max(Math.abs(Math.cos(a)) * W * 0.5 / rx, Math.abs(Math.sin(a)) * H * 0.5 / ry);
      const x = W / 2 + Math.cos(a) / m * W * 0.5, y = H / 2 - Math.sin(a) / m * H * 0.5;
      e.style.display = '';
      e.style.transform = `translate(${x}px, ${y}px) rotate(${-a}rad) scale(${t.d < 300 ? 1.25 : t.d < 600 ? 1 : 0.8})`;
      e.classList.toggle('atk', t.attacking);
      e.style.opacity = t.attacking ? 1 : 0.55;
    }
  }

  _toScreen(pos, cam, W, H) {
    tmp2.copy(pos).project(cam);
    if (tmp2.z > 1) return null;
    return { x: (tmp2.x * 0.5 + 0.5) * W, y: (-tmp2.y * 0.5 + 0.5) * H };
  }

  _placeMarker(e, pos, cam, W, H, kind) {
    tmp2.copy(pos).project(cam);
    const behind = tmp2.z > 1;
    let x = tmp2.x, y = tmp2.y;
    if (behind) { x = -x; y = -y; }
    const off = behind || Math.abs(x) > 0.95 || Math.abs(y) > 0.92;
    if (off) {
      const a = Math.atan2(y, x);
      const m = Math.max(Math.abs(Math.cos(a)) / 0.92, Math.abs(Math.sin(a)) / 0.85);
      x = Math.cos(a) / m; y = Math.sin(a) / m;
      e.style.setProperty('--rot', `${-a}rad`);
    }
    e.classList.toggle('off', off);
    e.dataset.kind = kind;
    e.style.transform = `translate(${(x * 0.5 + 0.5) * W}px, ${(-y * 0.5 + 0.5) * H}px)`;
  }

  _radar(g, dt) {
    const c = this.rctx, P = g.player, S = 200, R = 92, range = 1300;
    c.clearRect(0, 0, S, S);
    c.save(); c.translate(S / 2, S / 2);
    c.fillStyle = 'rgba(6,14,26,0.7)'; c.beginPath(); c.arc(0, 0, R + 4, 0, Math.PI * 2); c.fill();
    c.strokeStyle = 'rgba(90,180,255,0.35)'; c.lineWidth = 1;
    for (const k of [0.33, 0.66, 1]) { c.beginPath(); c.arc(0, 0, R * k, 0, Math.PI * 2); c.stroke(); }
    c.beginPath(); c.moveTo(-R, 0); c.lineTo(R, 0); c.moveTo(0, -R); c.lineTo(0, R); c.stroke();
    // sweep
    const sw = (g.realTime * 2) % (Math.PI * 2);
    if (this.sweepGrad === undefined) {
      this.sweepGrad = c.createConicGradient ? c.createConicGradient(-0.6, 0, 0) : null;
      if (this.sweepGrad) { this.sweepGrad.addColorStop(0, 'rgba(80,200,255,0)'); this.sweepGrad.addColorStop(0.09, 'rgba(80,200,255,0.18)'); this.sweepGrad.addColorStop(0.1, 'rgba(80,200,255,0)'); }
    }
    if (this.sweepGrad) { c.save(); c.rotate(sw); c.fillStyle = this.sweepGrad; c.beginPath(); c.arc(0, 0, R, 0, Math.PI * 2); c.fill(); c.restore(); }
    const jam = this.radarJam && (Math.sin(g.realTime * 3.3) > 0.2 || Math.random() < 0.15);
    if (jam) {
      for (let i = 0; i < 60; i++) { c.fillStyle = `rgba(120,200,255,${Math.random() * 0.4})`; c.fillRect((Math.random() - 0.5) * R * 2, (Math.random() - 0.5) * R * 2, 2, 2); }
      c.fillStyle = '#ff9a5a'; c.font = 'bold 11px Orbitron, sans-serif'; c.textAlign = 'center'; c.fillText('JAMMED', 0, 4);
    } else {
      const right = P.right, fwd = P.forward, up = P.up;
      const plot = (pos, color, size, shape = 'dot') => {
        tmp.copy(pos).sub(P.pos);
        let x = tmp.dot(right) / range * R, y = -tmp.dot(fwd) / range * R;
        const h = tmp.dot(up);
        const d = Math.hypot(x, y);
        let clipped = false;
        if (d > R) { x *= R / d; y *= R / d; clipped = true; }
        c.fillStyle = color; c.globalAlpha = clipped ? 0.5 : 1;
        if (shape === 'diamond') { c.beginPath(); c.moveTo(x, y - size); c.lineTo(x + size, y); c.lineTo(x, y + size); c.lineTo(x - size, y); c.fill(); }
        else if (shape === 'square') c.fillRect(x - size, y - size, size * 2, size * 2);
        else { c.beginPath(); c.arc(x, y, size, 0, Math.PI * 2); c.fill(); }
        if (!clipped && Math.abs(h) > 40) { c.strokeStyle = color; c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + (h > 0 ? -5 : 5)); c.stroke(); }
        c.globalAlpha = 1;
      };
      for (const u of g.units) {
        if (!u.alive || u.untargetable || u.part && !u.marker) continue;
        if (u.team === 'enemy') plot(u.pos, u.elite || u.named ? '#ffcc33' : u.structure ? '#ff8a5a' : u.passive ? '#a08070' : '#ff4a3a', u.radius > 30 ? 5 : u.elite ? 3.5 : 2.4, u.structure ? 'square' : u.elite ? 'diamond' : 'dot');
        else if (u.team === 'ally') plot(u.pos, '#4fdcff', u.structure ? 4 : 2.4, u.structure ? 'square' : 'dot');
        else if (u.team === 'neutral') plot(u.pos, '#ffe066', 3.5, 'diamond');
      }
      for (const p of g.pickups) if (p.type === 'core' || p.type === 'relic') plot(p.pos, '#ffe066', 2.5, 'diamond');
      if (this.waypoint) plot(this.waypoint.pos, '#43ff8e', 4, 'diamond');
      for (const inc of this.incomingList) { inc.t -= dt; if (inc.t > 0 && Math.sin(g.realTime * 12) > 0) plot(inc.pos, '#ff2a2a', 6, 'diamond'); }
      this.incomingList = this.incomingList.filter(i => i.t > 0);
    }
    // player
    c.fillStyle = '#e8f4ff'; c.beginPath(); c.moveTo(0, -6); c.lineTo(4, 4); c.lineTo(-4, 4); c.fill();
    c.restore();
  }
}

function modIcon(m) {
  return { drones: 'drone', radarjam: 'crosshair', densefield: 'asteroid', regen: 'shield', overheat: 'fuel', allies: 'ship_white', cargo: 'crate_blue', hunters: 'rank_skull', gravity: 'blackhole', glass: 'crystal_red', ironclad: 'crate_metal' }[m] || 'help';
}
