// ============================================================================
// Game: the in-mission runtime. Owns the scene, units, projectiles, player,
// objective and director. Pure mission state — permanent progression is only
// touched through the result object handed back to the app at the end.
// ============================================================================
import * as THREE from 'three';
import { Environment, ARENA_RADIUS, AsteroidGrid } from './environment.js';
import { Effects } from './effects.js';
import { Projectiles, raySphere } from './weapons.js';
import { Player } from './player.js';
import { Unit } from './units.js';
import { tuning, updateEngagement } from './combat.js';
import { Director } from './director.js';
import { createObjective } from './objectives.js';
import { computeShipStats } from './progression.js';
import { WEAPONS, ENEMIES, REGIONS, OPTIONAL_OBJECTIVES, MODIFIERS, COSMETICS } from './data.js';
import { EVENTS } from './events.js';
import { buildPlayerShip } from './models.js';
import { iconDecalTexture, glowSprite } from './textures.js';
import { RNG } from './rng.js';

const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3(), tmp3 = new THREE.Vector3();
const UP = new THREE.Vector3(0, 1, 0);

const FACTION_BOLT = { dominion: '#ff5a3c', vrell: '#a6ff3c', syndicate: '#d05cff', choir: '#4ff0ff', ally: '#4fdcff', neutral: '#ffcc55', ghost: '#7dff6a' };
const PICKUPS = {
  credits: { icon: 'credits', color: '#ffcc33', size: 6 },
  alloy: { icon: 'crystal_blue', color: '#4fa8ff', size: 6 },
  cores: { icon: 'crystal_purple', color: '#c05cff', size: 7 },
  repair: { icon: 'repair', color: '#43ff8e', size: 7 },
  ammo: { icon: 'torpedo', color: '#ffb347', size: 6 },
  salvage: { icon: 'wrench', color: '#c0c8d0', size: 5 },
  core: { icon: 'energy', color: '#ffe066', size: 8 },
  tokens: { icon: 'crystal_red', color: '#ff5a5a', size: 7 },
  relic: { icon: 'emblem_prism', color: '#ff5ce1', size: 10 },
};

export class Game {
  constructor(app) {
    this.app = app;
    this.renderer = app.renderer; this.audio = app.audio; this.input = app.input; this.hud = app.hud;
    this.camera = app.renderer.camera;
    this.active = false;
  }

  get save() { return this.app.saveManager.data; }
  get settings() { return this.save.settings; }

  // -------------------------------------------------------------------------
  start(mission, opts = {}) {
    this.cleanup();
    this.mission = mission;
    const save = this.save;
    this.scene = new THREE.Scene();
    this.time = 0; this.realTime = 0; this.active = true; this.ending = null; this.endT = 0;
    this.units = []; this.pickups = []; this.hazards = []; this.gravityWells = []; this.missionObjects = [];
    this.obstacles = []; this.dynamicObstacles = [];
    this.flags = { drift: false };
    this.mutators = new Set(mission.mutators || []);
    this.runPerks = { dmg: 1, rate: 1, cooling: 1, shieldRegen: 1, abilityCd: 1, crit: 0, ricochet: 0, ammo: 0, hullMult: 1, greed: 1, leech: 0, magnet: 1 };
    this.perksTaken = [];
    this.timeDilation = 0; this.enemyTimeScale = 1;
    this.cinematic = null; this.choice = null;
    this.boss = null;
    this.score = 0; this.combo = 0; this.comboT = 0; this.lastKillWeapon = null;
    this.retreatCharge = 0;
    this.loot = { credits: 0, alloy: 0, cores: 0, tokens: 0 };
    this.stats = { kills: 0, killsByType: {}, secondaryKills: 0, aceKills: 0, bestCombo: 0, salvage: 0, weaponsKill: new Set(), damageDealt: 0, damageByKind: {}, avgRange: 300, rangeN: 0, wave: 0, waveReached: 0, discoveries: [], bossesKilled: [], eliteBounty: false, abilityUses: 0 };
    this.encountered = { enemies: new Set(), bosses: new Set() };
    this.arenaRadius = ARENA_RADIUS;
    this.waypoint = null;
    // difficulty knobs (smarter composition does most of the scaling — HP scales gently)
    const d = mission.difficulty || 1;
    this.enemyHpMult = 0.85 + (d - 1) * 0.45;
    this.enemyDamageMult = 0.8 + (d - 1) * 0.35;
    this.bossHpMult = 1;
    this.playerDamageMult = 1;
    // player-facing difficulty (aim assist, attacker limits, enemy agility) — see combat.js
    this.tune = tuning(this.settings);
    this.playerDamageMult *= this.tune.dmg; this.enemyDamageMult *= this.tune.enemyDmg;
    const ev = mission.event ? EVENTS[mission.event] : null;
    if (ev?.globalDamage) { this.playerDamageMult *= ev.globalDamage; this.enemyDamageMult *= ev.globalDamage; }
    if (mission.modifiers.includes('glass') || this.mutators.has('glass')) { this.playerDamageMult *= 2; this.enemyDamageMult *= 2; }
    if (mission.mode === 'bossrush') { this.bossHpMult = mission.difficulty / 1.3; this.enemyDamageMult *= mission.difficulty / 1.3; }

    // World
    this.env = new Environment(this.scene, this.renderer.renderer);
    this.env.build(mission.region, { settings: this.settings, seed: hashSeed(mission.seed), event: mission.event, denseField: mission.modifiers.includes('densefield'), storm: mission.objective === 'survive', asteroidMult: mission.objective === 'survive' ? 1.5 : 1 });
    this.asteroidGrid = new AsteroidGrid();
    this.effects = new Effects(this.scene, this.settings);
    this.projectiles = new Projectiles(this);

    // Player
    const shipId = save.ships.selected;
    const stats = computeShipStats(save, shipId);
    this.shipStats = stats;
    this.player = new Player(this, shipId, stats, save.cosmetics.equipped[shipId]);
    if (this.mutators.has('vampire')) this.player.maxShield = 0;

    this.hud.startMission(this);
    this.objective = createObjective(this, mission);
    this.director = new Director(this, mission);
    if (mission.event === 'anomaly') this.director.mods.add('gravity');
    if (REGIONS[mission.region]?.hazards?.includes('gravity') && mission.objective !== 'boss') this.director.mods.add('gravity');
    this.objective.setup();
    this._clearSetPieces();
    this.player.pos.copy(this.objective.startPos);
    this.player.mesh.lookAt(this.objective.startLook);
    this.player.forward.set(0, 0, 1).applyQuaternion(this.player.quat);
    for (const t of this.player.trails) t.t.reset(this.player.pos);
    this.director.start();
    if (this.mutators.has('curve')) this.gravityWells.push({ pos: new THREE.Vector3(0, 0, 200), radius: 900, strength: 0.35, projectilesOnly: true });
    this.rouletteT = 20;
    this.hazardT = 12; this.rng = new RNG('game-' + mission.seed);

    this.camPos = this.player.pos.clone().add(new THREE.Vector3(0, 5, -20).applyQuaternion(this.player.quat));
    this.camLook = this.player.pos.clone();
    this.camera.position.copy(this.camPos);
    this.camera.clearViewOffset();
    this.camera.fov = portraitFov(68, this.camera.aspect); this.camera.updateProjectionMatrix();
    this.renderer.setScene(this.scene);
    this.hud.refreshMission?.(this);
    this.audio.music?.setMode(mission.boss || mission.objective === 'bossrush' ? 'combat' : mission.event ? 'event' : 'combat');
    this.audio.music?.setIntensity(1);
    this.audio.loop('engine', true, { volume: 0.05 });
    this.introT = 2.2; // brief warp-in
    this.effects.flash(this.player.pos, 30, '#9fe8ff', 0.5);
    this.audio.play('gate');
  }

  // Push region set-pieces (wrecks, ruins) away from objective structures so they never hide or block them
  _clearSetPieces() {
    const obs = this.env.obstacles;
    for (const u of this.units) {
      if (!u.alive || u.part) continue;
      for (const o of obs) {
        const need = o.radius + u.radius + 50;
        const d = o.pos.distanceTo(u.pos);
        if (d < need) o.pos.add(tmp.copy(o.pos).sub(u.pos).normalize().multiplyScalar(need - d + 1));
      }
    }
    const P = this.objective.startPos;
    for (const o of obs) { const d = o.pos.distanceTo(P); if (d < o.radius + 60) o.pos.add(tmp.copy(o.pos).sub(P).normalize().multiplyScalar(o.radius + 60 - d)); }
  }

  // -------------------------------------------------------------------------
  // Unit management
  // -------------------------------------------------------------------------
  spawnUnit(type, opts = {}) {
    if (this.mutators.has('mirror') && ENEMIES[type] && !ENEMIES[type].miniboss && type !== 'ace' && (opts.team || 'enemy') === 'enemy' && !opts.mesh) {
      const m = buildPlayerShip(this.save.ships.selected, { ...this.save.cosmetics.equipped[this.save.ships.selected], paint: 'paint_crimson', engine: 'engine_crimson', emblem: 'emblem_none', pattern: 'pattern_none' });
      m.userData.hullMat = m.userData.materials.hull; m.userData.meshes = []; m.userData.hullMat.emissive = new THREE.Color(0);
      opts = { ...opts, mesh: m, radius: Math.max(ENEMIES[type].radius, 6) };
    }
    const u = new Unit(this, type, opts);
    if (!u.mesh.parent) this.scene.add(u.mesh);
    this.units.push(u);
    if (u.team === 'enemy' && ENEMIES[type]) this.encountered.enemies.add(type);
    if (u.marker || u.bounty) this.hud.trackUnit(u);
    return u;
  }

  removeUnit(u, reason = 'remove') {
    if (!u.alive && u._removed) return;
    u.alive = false; u._removed = true;
    if (u.part) u.mesh.visible = false;
    else if (u.mesh.parent) u.mesh.parent.remove(u.mesh);
    u.dispose();
    if (this.decoy === u) this.decoy = null;
    this.hud.untrackUnit(u);
  }

  unitRetreat(u, reason = 'warp') {
    this.effects.flash(u.pos, u.radius * 3, '#9fe8ff', 0.4);
    this.effects.ring(u.pos, u.radius * 4, '#9fe8ff', 0.5);
    this.audio.play('gate', { pos: u.pos, volume: 0.6 });
    this.removeUnit(u, reason);
    this.objective.onRetreat(u, reason);
  }

  factionColor(faction, variant) {
    if (variant === 'ghost') return '#7dff6a';
    if (variant === 'frost') return '#9fe6ff';
    if (variant === 'solar') return '#ffb02e';
    if (variant === 'bloom') return '#ff8fd0';
    return FACTION_BOLT[faction] || '#ff5a3c';
  }

  // -------------------------------------------------------------------------
  // Targeting helpers
  // -------------------------------------------------------------------------
  enemyTarget(u) {
    const P = this.player;
    if (this.decoy && this.decoy.alive && u.pos.distanceToSquared(this.decoy.pos) < 900 * 900) return this.decoy;
    if (this.mutators.has('chaos') && u.ai.chaosT === undefined) u.ai.chaosT = 0;
    if (this.mutators.has('chaos')) {
      u.ai.chaosT -= 1 / 60;
      if (u.ai.chaosT <= 0) { u.ai.chaosT = 4; u.ai.rival = null; for (const o of this.units) if (o.alive && o.team === 'enemy' && o.faction !== u.faction && !o.structure && !o.passive && o.pos.distanceToSquared(u.pos) < 400 * 400) { u.ai.rival = o; break; } }
      if (u.ai.rival && u.ai.rival.alive && Math.random() < 0.6) return u.ai.rival;
    }
    if (P.cloak > 0 || !P.alive) {
      let best = null, bd = 1e12;
      for (const a of this.units) if (a.alive && a.team === 'ally' && !a.intangible) { const d = a.pos.distanceToSquared(u.pos); if (d < bd) { bd = d; best = a; } }
      return best;
    }
    // wingmen and drones draw some attention
    if (u.ai.allyT === undefined || (u.ai.allyT -= 1 / 60) <= 0) {
      u.ai.allyT = 3; u.ai.ally = null;
      for (const a of this.units) if (a.alive && a.team === 'ally' && !a.structure && a.pos.distanceToSquared(u.pos) < P.pos.distanceToSquared(u.pos) * 0.3) { u.ai.ally = a; break; }
    }
    if (u.ai.ally && u.ai.ally.alive) return u.ai.ally;
    return P;
  }

  objectiveTarget(u, prob = 0.85) {
    const list = this.objective.protect;
    if (!list.length) return null;
    if (u.ai.objTarget === undefined) {
      const alive = list.filter(x => x.alive);
      u.ai.objTarget = alive.length && Math.random() < prob ? alive[Math.floor(Math.random() * alive.length)] : null;
    }
    if (u.ai.objTarget && !u.ai.objTarget.alive) { const alive = list.filter(x => x.alive); u.ai.objTarget = alive[0] || null; }
    // peel off to fight the player if they get close
    if (u.ai.objTarget && this.player.alive && this.player.pos.distanceToSquared(u.pos) < 140 * 140) return this.player;
    return u.ai.objTarget;
  }

  isTargetable(u) { return u.alive && !u.untargetable && u.team !== 'ally' && (u.team !== 'neutral' || u.hostile) && !u.intangible; }

  nearestEnemy(pos, range, exclude = null, excludeSet = null, forAlly = false) {
    let best = null, bd = range * range;
    for (const u of this.units) {
      if (!this.isTargetable(u) || u === exclude || (excludeSet && excludeSet.has(u))) continue;
      if (u.team !== 'enemy' && !u.hostile) continue;
      if (forAlly && (u.passive || u.armored || u.invulnerable)) continue;
      const d = u.pos.distanceToSquared(pos);
      if (d < bd) { bd = d; best = u; }
    }
    return best;
  }
  enemiesNear(pos, r, filter = null) {
    const out = [];
    for (const u of this.units) if (u.alive && u.team === 'enemy' && !u.passive && u.pos.distanceToSquared(pos) < r * r && (!filter || filter(u))) out.push(u);
    out.sort((a, b) => a.pos.distanceToSquared(pos) - b.pos.distanceToSquared(pos));
    return out;
  }
  findTarget(origin, dir, cos, range, team = 'player') {
    let best = null, bestDot = cos;
    for (const u of this.units) {
      if (!this.isTargetable(u) || u.armored) continue;
      tmp.copy(u.pos).sub(origin); const d = tmp.length();
      if (d > range + u.radius) continue;
      const dot = tmp.divideScalar(d || 1).dot(dir);
      if (dot > bestDot) { bestDot = dot; best = u; }
    }
    return best;
  }
  raycastUnits(from, dir, range, team = 'player') {
    const hits = [];
    for (const u of this.units) {
      if (!this.isTargetable(u)) continue;
      if (u.phased && Math.random() < 0.85) continue;
      const t = raySphere(from, dir, u.pos, u.radius, range);
      if (t >= 0 && t <= range) hits.push({ unit: u, dist: t, point: from.clone().addScaledVector(dir, t) });
    }
    hits.sort((a, b) => a.dist - b.dist);
    return hits;
  }
  raycastObstacles(from, dir, maxDist) {
    let best = maxDist, hit = null;
    const a = this.env.asteroids;
    if (a) for (let i = 0; i < a.count; i++) {
      if (!a.alive[i]) continue;
      tmp.set(a.pos[i * 3], a.pos[i * 3 + 1], a.pos[i * 3 + 2]);
      const t = raySphere(from, dir, tmp, a.radius[i], best);
      if (t >= 0 && t < best) { best = t; hit = true; }
    }
    for (const o of this.obstacles) { const t = raySphere(from, dir, o.pos, o.radius, best); if (t >= 0 && t < best) { best = t; hit = true; } }
    return hit ? from.clone().addScaledVector(dir, best) : null;
  }
  hasLOS(a, b) { tmp2.copy(b).sub(a); const d = tmp2.length(); return !this.raycastObstacles(a, tmp2.divideScalar(d), d - 10); }

  // -------------------------------------------------------------------------
  // Damage
  // -------------------------------------------------------------------------
  damageUnit(u, amount, info = {}) {
    if (!u.alive || amount <= 0) return;
    if (u.proxy) {
      if (!u.proxyMult) { this._deflect(u, info); return; }
      return this.damageUnit(u.proxy, amount * u.proxyMult, info);
    }
    if (u.armored) { this._deflect(u, info, 'ARMORED — HIT THE WEAK POINTS'); return; }
    if (u.invulnerable) { this._deflect(u, info, u.boss || u.bossMain ? 'SHIELDED' : 'INVULNERABLE'); return; }
    if (u.team === 'ally' && info.source !== 'enemy') return;
    if (u.team === 'neutral' && !u.hostile) return;
    if (u.isDecoy && info.source === 'player') { this.effects.explosion(u.pos, 1, '#ff2a4a', { debris: false }); this.removeUnit(u); this.audio.play('phase', { pos: u.pos }); return; }
    amount *= u.damageTakenMult ?? 1;
    // shield carriers absorb damage for protected allies
    if (u.protector && u.protector.alive && u.protector !== u && u.protector.shield > 0 && u.protector.pos.distanceToSquared(u.pos) < (u.protector.def.aura || 140) ** 2) {
      u.protector.shield -= amount * 0.7; u.protector.shieldDelay = 3;
      this.effects.sparks(info.pos || u.pos, '#5ab8ff', 4, 40, 1.6, 0.3);
      if (u.protector.aura) u.protector.aura.material.opacity = 0.35;
      this.audio.play('hitShield', { pos: info.pos || u.pos, volume: 0.6 });
      if (info.source === 'player') this.hud.hitMarker(false, true);
      return;
    }
    const isPlayer = info.source === 'player';
    let shieldHit = false;
    if (u.shield > 0) {
      const sdmg = amount * (info.shieldBonus || 1);
      const absorbed = Math.min(u.shield, sdmg);
      u.shield -= absorbed; amount -= absorbed / (info.shieldBonus || 1);
      u.shieldDelay = 3.5; shieldHit = true;
      if (u.shield <= 0) { this.effects.ring(u.pos, u.radius * 2, '#5ab8ff', 0.3); this.audio.play('shieldBreak', { pos: u.pos, volume: 0.4 }); }
    }
    if (amount > 0) u.hp -= amount;
    u.flash = Math.min(1, u.flash + (info.dot ? 0.15 : 0.7));
    u.lastHit = this.time; u.lastAttacker = info.source;
    if (isPlayer) {
      const total = amount + (shieldHit ? 1 : 0);
      this.stats.damageDealt += total;
      const kind = info.weapon && WEAPONS[info.weapon] ? WEAPONS[info.weapon].kind : info.secondary ? 'missile' : 'other';
      this.stats.damageByKind[kind] = (this.stats.damageByKind[kind] || 0) + total;
      const r = u.pos.distanceTo(this.player.pos); this.stats.rangeN++; this.stats.avgRange += (r - this.stats.avgRange) / Math.min(60, this.stats.rangeN);
      if (!info.dot || Math.random() < 0.08) this.hud.damageNumber(info.pos || u.pos, info.dot ? amount * 12 : amount + (shieldHit && amount <= 0 ? 0 : 0), info.crit, shieldHit && amount <= 0);
      if (!info.dot) this.hud.hitMarker(info.crit);
      if (!info.dot) this.audio.play(shieldHit ? 'hitShield' : 'hitHull', { pos: info.pos || u.pos, volume: 0.6 });
      u.lastPlayerWeapon = info.weapon; u.lastSecondary = !!info.secondary; u.lastCrit = !!info.crit;
    }
    if (u.hp <= 0) this.killUnit(u, info);
  }

  _deflect(u, info, hint) {
    this.effects.sparks(info.pos || u.pos, '#ffffff', 3, 60, 1.2, 0.2);
    if (info.source === 'player' && !info.dot) {
      this.audio.play('deflect', { pos: info.pos || u.pos, volume: 0.5 });
      if (hint && (!this._hintT || this.time - this._hintT > 6)) { this._hintT = this.time; this.hud.toast(hint, 'info', 1.6); }
    }
  }

  killUnit(u, info = {}) {
    if (!u.alive) return;
    u.alive = false; u.killedBy = info.source || 'unknown';
    const big = u.radius > 30;
    const color = u.variant?.tint || (u.faction === 'vrell' ? '#b6ff6a' : u.faction === 'choir' ? '#8af6ff' : '#ffaa44');
    this.effects.explosion(u.pos, Math.max(0.6, Math.min(6, u.radius / 7)), color);
    this.audio.play(big ? 'explosionL' : u.radius > 9 ? 'explosionM' : 'explosionS', { pos: u.pos });
    if (u.onDeath) u.onDeath(u);
    const byPlayer = info.source === 'player' || info.source === 'ally';
    if (u.team === 'enemy' && byPlayer && !u.passive) {
      this.stats.kills++;
      this.stats.killsByType[u.type] = (this.stats.killsByType[u.type] || 0) + 1;
      if (u.lastSecondary || info.secondary) this.stats.secondaryKills++;
      if (u.named) this.stats.aceKills++;
      if (u.bounty) this.stats.eliteBounty = true;
      const w = info.weapon || u.lastPlayerWeapon;
      if (w) this.stats.weaponsKill.add(w);
      // combo & score
      this.combo++; this.comboT = 4;
      this.stats.bestCombo = Math.max(this.stats.bestCombo, this.combo);
      let mult = 1 + Math.min(40, this.combo) * 0.05;
      let label = '';
      if (w && this.lastKillWeapon && w !== this.lastKillWeapon) { mult *= 1.25; label = 'VARIETY'; }
      if (info.crit || u.lastCrit) { mult *= 1.2; label = label || 'PRECISION'; }
      if (u.elite) { mult *= 1.5; label = 'ELITE'; }
      this.lastKillWeapon = w;
      this.addScore(Math.round(u.score * mult), label);
      this.hud.combo(this.combo);
      // mods & perks
      const mods = this.shipStats.mods;
      if (mods.has('leech')) this.player.heal(u.elite ? 20 : 3);
      if (this.runPerks.leech) this.player.heal(this.runPerks.leech);
      if (this.mutators.has('vampire')) this.player.heal(8);
      if (mods.has('echo') && (u.elite || u.def.miniboss)) { this.player.ability.cd = 0; this.hud.toast('ECHO: ABILITY RECHARGED', 'good', 1); }
      if (mods.has('volatile') && !u.structure) { this.effects.ring(u.pos, 45, '#ff9a3a', 0.4); this.damageArea(u.pos, 45, u.maxHp * 0.35, 'player', { exclude: u, weapon: 'volatile' }); }
      // loot
      this._dropLoot(u);
    }
    if (u.loot === 'cargo' && byPlayer) { this.addPickup('credits', u.pos, 30); this.addPickup('alloy', u.pos, 3); this.addPickup('salvage', u.pos, 1); }
    if (u.loot === 'cache' && byPlayer) {
      this.addPickup('credits', u.pos, 200); this.addPickup('alloy', u.pos, 15); this.addPickup('cores', u.pos, 1);
      this.hud.toast('SUPPLY CACHE CRACKED OPEN', 'good', 2);
      if (this.rng.chance(0.12)) { const pool = Object.keys(COSMETICS).filter(k => COSMETICS[k].source === 'drop' && !this.save.cosmetics.owned.includes(k)); if (pool.length) { this.loot.cosmetic = this.rng.pick(pool); this.hud.toast(`RARE FIND: ${COSMETICS[this.loot.cosmetic].name}`, 'good', 3); } }
    }
    // seasonal variant death effects
    if (u.variant?.spores && !u.structure) for (let k = 0; k < 2; k++) this.spawnUnit('swarm', { pos: u.pos.clone().add(new THREE.Vector3(Math.random() * 10 - 5, 3, Math.random() * 10 - 5)), faction: u.faction, hpMult: 0.4, tint: '#ff8fd0' });
    if (u.variant?.deathBlast) { this.effects.ring(u.pos, 40, '#ffb02e', 0.4); this.damageArea(u.pos, 38, 14, 'enemy', {}); }
    this.objective.onKill(u);
    this.director.onKill(u);
    if (u.part) { u.mesh.visible = false; u._removed = true; u.dispose(); this.hud.untrackUnit(u); }
    else this.removeUnit(u, 'killed');
    u.alive = false;
  }

  _dropLoot(u) {
    const greed = this.runPerks.greed * (REGIONS[this.mission.region]?.rewardMult || 1);
    const c = (u.def.credits || 5) * greed;
    this.addPickup('credits', u.pos, Math.round(c));
    if (Math.random() < 0.25 + (u.elite ? 0.5 : 0)) this.addPickup('alloy', u.pos, u.elite ? 6 : 1 + Math.floor(Math.random() * 2));
    if (Math.random() < 0.28) this.addPickup('salvage', u.pos, 1);
    if (u.elite && Math.random() < 0.5) this.addPickup('cores', u.pos, 1);
    const P = this.player;
    if (Math.random() < 0.07 + (P.hull / P.maxHull < 0.4 ? 0.08 : 0)) this.addPickup('repair', u.pos, 20);
    if (Math.random() < 0.06 + (P.weapons.secondary.ammo === 0 ? 0.1 : 0)) this.addPickup('ammo', u.pos, 4);
    if (this.mission.event && Math.random() < 0.12) this.addPickup('tokens', u.pos, 1);
  }

  damageArea(pos, radius, dmg, team, info = {}) {
    const fall = info.falloff ?? 0.5;
    if (team === 'player' || team === 'ally') {
      for (const u of this.units) {
        if (!u.alive || u === info.exclude || u.team === 'ally' || (u.team === 'neutral' && !u.hostile) || u.untargetable) continue;
        const d = u.pos.distanceTo(pos) - u.radius;
        if (d > radius) continue;
        const k = 1 - Math.max(0, d) / radius * fall;
        this.damageUnit(u, dmg * k, { source: 'player', weapon: info.weapon, secondary: info.secondary, pos: u.pos, shieldBonus: info.shieldBonus });
      }
    } else {
      const P = this.player;
      if (P.alive) { const d = P.pos.distanceTo(pos) - P.radius; if (d < radius) this.damagePlayer(dmg * (1 - Math.max(0, d) / radius * fall), { pos, source: info.source, chill: info.chill }); }
      for (const u of this.units) {
        if (!u.alive || u.team !== 'ally' || u.intangible) continue;
        const d = u.pos.distanceTo(pos) - u.radius;
        if (d < radius) this.damageUnit(u, dmg * (1 - Math.max(0, d) / radius * fall), { source: 'enemy', pos: u.pos });
      }
      if (this.mutators.has('chaos')) for (const u of this.units) if (u.alive && u.team === 'enemy' && info.source && u.faction !== info.source.faction && u.pos.distanceTo(pos) < radius) this.damageUnit(u, dmg * 0.5, { source: 'chaos', pos: u.pos });
    }
  }

  detonate(u, radius, dmg) {
    if (!u.alive) return;
    this.effects.explosion(u.pos, Math.max(1, radius / 25), u.variant?.tint || '#ff7a3a');
    this.audio.play('explosionM', { pos: u.pos });
    const pos = u.pos.clone();
    this.removeUnit(u, 'detonate');
    this.damageArea(pos, radius, dmg, 'enemy', { source: u });
  }

  damagePlayer(amount, info = {}) {
    if (!this.player.alive || this.ending) return;
    this.player.takeDamage(amount, info);
  }

  playerDestroyed() {
    const P = this.player;
    if (!P.alive) return;
    P.alive = false;
    this.effects.explosion(P.pos, 4, '#ffaa44');
    this.effects.ring(P.pos, 80, '#ffd8a0', 0.8);
    this.effects.addShake(1.5);
    this.audio.play('explosionL');
    P.mesh.visible = false;
    for (const t of P.trails) t.t.mesh.visible = false;
    this.deathPos = P.pos.clone();
    this.hud.banner('SHIP DESTROYED', this.objective.result === 'victory' ? '' : 'Mission failed', 2.5);
    if (!this.objective.result) { this.objective.result = 'defeat'; this.objective.failReason = 'Your ship was destroyed.'; }
    this.audio.loop('engine', false);
  }

  // -------------------------------------------------------------------------
  // Pickups, hazards, misc spawns
  // -------------------------------------------------------------------------
  addPickup(type, pos, amount = 1) {
    const def = PICKUPS[type];
    if (!def) return;
    const mat = new THREE.SpriteMaterial({ map: iconDecalTexture(def.icon), transparent: true, depthWrite: false, toneMapped: false });
    mat.color.setScalar(1.6);
    const s = new THREE.Sprite(mat);
    s.scale.setScalar(def.size);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowSprite(def.color, 'pk'), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
    glow.scale.setScalar(2.2); s.add(glow);
    s.position.copy(pos).add(tmp.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(8));
    this.scene.add(s);
    const vel = new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(30);
    this.pickups.push({ type, amount, sprite: s, vel, life: type === 'core' || type === 'relic' ? 120 : 30, pos: s.position });
  }

  _collect(p) {
    const P = this.player;
    switch (p.type) {
      case 'credits': this.loot.credits += p.amount; this.audio.play('coin', { volume: 0.5 }); break;
      case 'alloy': this.loot.alloy += p.amount; this.audio.play('pickup', { volume: 0.6 }); break;
      case 'cores': this.loot.cores += p.amount; this.audio.play('claim', { volume: 0.6 }); this.hud.toast('+1 QUANTUM CORE', 'good', 1.4); break;
      case 'tokens': this.loot.tokens += p.amount; this.audio.play('pickup'); break;
      case 'repair': P.heal(p.amount); this.audio.play('heal'); break;
      case 'ammo': P.weapons.refill(p.amount); this.audio.play('equip'); break;
      case 'salvage': this.stats.salvage++; this.loot.alloy += 1; this.audio.play('pickup', { volume: 0.4 }); break;
      case 'core': this.audio.play('claim', { volume: 0.7 }); this.objective.onPickup?.('core'); break;
      case 'relic': {
        const id = `relic-${this.mission.region}-${Math.floor(this.time)}-${this.save.universe.discoveries.length}`;
        this.stats.discoveries.push(id); this.loot.cores += 2;
        this.hud.banner('RARE DISCOVERY', 'An ancient Lattice relic — logged to your collection', 2.6); this.audio.play('achievement');
        break;
      }
    }
    this.hud.pickup(p.type, p.amount);
  }

  addHazard(h) { this.hazards.push(h); }

  spawnDecoy(dur) {
    const P = this.player;
    const m = buildPlayerShip(this.save.ships.selected, this.save.cosmetics.equipped[this.save.ships.selected]);
    const holo = new THREE.MeshBasicMaterial({ color: new THREE.Color('#6ad8ff').multiplyScalar(1.4), transparent: true, opacity: 0.45, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
    m.traverse(o => { if (o.isMesh && !o.material.isShaderMaterial) o.material = holo; });
    m.userData.hullMat = null; m.userData.meshes = [];
    const u = this.spawnUnit('part', { mesh: m, team: 'ally', behavior: 'decoy', hp: 200, radius: 7, name: 'Holo Decoy', faction: 'ally' });
    u.pos.copy(P.pos).addScaledVector(P.right, 25); u.quat.copy(P.quat); u.vel.copy(P.vel).multiplyScalar(0.6);
    u.ai.life = dur;
    this.decoy = u;
    this.effects.ring(u.pos, 20, '#6ad8ff', 0.4);
  }

  spawnPlayerDrone(life, dmg) {
    const P = this.player;
    const u = this.spawnUnit('pdrone', { pos: P.pos.clone().addScaledVector(P.up, -4).addScaledVector(P.right, (Math.random() - 0.5) * 10), team: 'ally', faction: 'ally' });
    u.ai.life = life; u.ai.dmg = dmg; u.ai.cd = 0.5;
    u.vel.copy(P.vel);
  }

  breakAsteroid(i) {
    const a = this.env.asteroids;
    const pos = new THREE.Vector3(a.pos[i * 3], a.pos[i * 3 + 1], a.pos[i * 3 + 2]);
    this.effects.explosion(pos, a.scale[i] / 8, '#c8a080', { noRing: true });
    for (let k = 0; k < 6; k++) this.effects.smokePuff(pos, a.scale[i] * 0.6, 2, 0.25);
    this.env.destroyAsteroid(i);
    if (Math.random() < 0.4) this.addPickup('salvage', pos, 1);
    if (Math.random() < 0.15) this.addPickup('alloy', pos, 2);
    this.audio.play('explosionS', { pos });
  }

  setArenaShrink(r) { this.arenaRadius = r; this.hud.toast(`ARENA COLLAPSING TO ${r}m`, 'warn', 2); if (!this.boundary) { this.boundary = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 32), new THREE.MeshBasicMaterial({ color: new THREE.Color('#b26bff').multiplyScalar(1.4), wireframe: true, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false })); this.scene.add(this.boundary); this.missionObjects.push(this.boundary); } this.boundary.scale.setScalar(r); }
  setWaypoint(pos, label) { this.waypoint = pos ? { pos, label } : null; this.hud.setWaypoint(this.waypoint); }

  startCinematic(c) {
    if (this.settings.skipIntros && !c.story) return; // story intros have their own skip
    this.cinematic = { ...c, t: 0 };
    this.hud.cinematic(c.title, c.subtitle, !!c.story);
    if (!c.story) { this.audio.play('bossIntro'); this.audio.music?.setMode('boss'); }
  }
  endCinematic() { const c = this.cinematic; if (!c) return; this.cinematic = null; this.hud.cinematic(null); c.onEnd?.(); }

  offerChoice(c) { this.choice = c; this.hud.showChoice(c); }
  pickChoice(id) {
    const c = this.choice; if (!c) return;
    const opt = c.options.find(o => o.id === id); if (!opt || opt.disabled) { this.audio.play('error'); return; }
    this.choice = null; this.hud.showChoice(null); this.audio.play('click');
    c.onPick(id);
  }

  applyPerk(id) {
    const p = this.runPerks, P = this.player;
    this.perksTaken.push(id);
    switch (id) {
      case 'dmg': p.dmg *= 1.15; break;
      case 'rate': p.rate *= 1.12; break;
      case 'hull': P.maxHull *= 1.15; P.heal(P.maxHull * 0.5); break;
      case 'shieldr': p.shieldRegen *= 1.4; break;
      case 'ammo': P.weapons.secondary.max += 3; P.weapons.refill(); break;
      case 'magnet': p.magnet *= 2; break;
      case 'crit': p.crit += 0.08; break;
      case 'cooling': p.cooling *= 1.3; break;
      case 'ability': p.abilityCd *= 0.75; break;
      case 'leech': p.leech += 2; break;
      case 'ricochet': p.ricochet += 1; break;
      case 'greed': p.greed *= 1.3; this.enemyHpMult *= 1.1; break;
    }
    this.hud.toast(`PERK ACQUIRED`, 'good', 1.2);
  }

  applyModifier(mod) {
    this.director.mods.add(mod);
    if (mod === 'glass') { this.playerDamageMult *= 2; this.enemyDamageMult *= 2; }
    if (mod === 'gravity') this.director.addRoamingWell();
    if (mod === 'densefield') this.env.setFogMultiplier(1.6);
  }

  scoreMult() { return this.mission.mode === 'endless' ? 1 + Math.max(0, this.objective.wave - 1) * 0.15 : 1; }
  addScore(n, label = '') { const v = Math.round(n * this.scoreMult()); this.score += v; this.hud.score(this.score, v, label); }

  onBossDefeated(boss) {
    this.stats.bossesKilled.push(boss.id);
    this.addScore(10000 * (boss.diff || 1), 'BOSS');
    this.audio.music?.setMode('combat');
    this.combo += 5; this.hud.combo(this.combo);
    if (this.shipStats.mods.has('echo')) this.player.ability.cd = 0;
  }
  onBossRetreat(boss) { this.audio.music?.setMode('combat'); }

  // -------------------------------------------------------------------------
  // Main update
  // -------------------------------------------------------------------------
  update(rawDt) {
    if (!this.active) return;
    const dt = Math.min(rawDt, 1 / 20);
    this.realTime += dt;
    const input = this.input;
    input.sample(dt);
    // choice overlay (perks, trader) freezes the action
    if (this.choice) {
      for (const [i, k] of ['choice1', 'choice2', 'choice3'].entries()) if (input.pressed(k) && this.choice.options[i]) this.pickChoice(this.choice.options[i].id);
      this._render(dt * 0.05);
      input.endFrame();
      return;
    }
    // boss intro cinematic
    if (this.cinematic) {
      this.cinematic.t += dt;
      if (this.cinematic.t > this.cinematic.duration || input.pressed('skip') || input.mouse.leftPressed) this.endCinematic();
      this.effects.update(dt, this.camera); this.env.update(dt, this.camera, this.player.pos);
      this._cinematicCamera(dt);
      if (this.boss) this.boss.group.updateMatrixWorld(true);
      if (!this.headless) this.renderer.render(this.scene, this.camera);
      input.endFrame();
      return;
    }
    // slow-motion on victory
    let simDt = dt;
    if (this.objective.result === 'victory' && !this.ending) { this.ending = 'victory'; this.endT = 2.8; this.audio.play('complete'); this.audio.music?.setIntensity(0); }
    if (this.objective.result === 'defeat' && !this.ending) { this.ending = 'defeat'; this.endT = 3; this.audio.play('fail'); this.audio.music?.setIntensity(0); }
    if (this.ending) { this.endT -= dt; simDt = dt * (this.ending === 'victory' ? 0.35 : 0.6); if (this.endT <= 0) { this.finish(this.ending); input.endFrame(); return; } }
    this.time += simDt;
    // time dilation ability
    if (this.timeDilation > 0) { this.timeDilation -= simDt; this.enemyTimeScale = 0.3; } else this.enemyTimeScale = 1;
    const eDt = simDt * this.enemyTimeScale;

    // dynamic obstacles (static env + boss hull spheres)
    this.obstacles = this.env.obstacles;
    this.asteroidGrid.rebuild(this.env.asteroids);

    const P = this.player;
    if (this.introT > 0) this.introT -= dt;
    if (P.alive && !this.ending) P.update(simDt, input);
    else if (P.alive) { P.update(simDt, { stick: { x: 0, y: 0 }, isDown: () => false, pressed: () => false }); }
    if (this.flags.drift && P.alive) P.vel.multiplyScalar(1 + 0.6 * simDt); // folded space: momentum carries

    if (input.gp && input.gp.pressed && input.gp.pressed.pause) { this.app.pause(true); input.endFrame(); return; }
    if (input.pressedCode('Enter') || input.pressedCode('KeyN')) this.hud.comms.skip(); // skip the current radio line
    // targeting
    this._updateTargeting();
    if (input.pressed('target')) this._cycleTarget();

    // retreat
    if (input.isDown('retreat') && P.alive && !this.ending && this.mission.mode !== 'bossrush') {
      this.retreatCharge += dt;
      this.hud.retreat(this.retreatCharge / 3);
      if (this.retreatCharge >= 3) { this.objective.result = 'retreat'; this.ending = 'retreat'; this.endT = 0.8; this.effects.flash(P.pos, 40, '#9fe8ff', 0.5); this.audio.play('gate'); P.mesh.visible = false; }
    } else if (this.retreatCharge > 0) { this.retreatCharge = 0; this.hud.retreat(0); }

    // weapon roulette mutator
    if (this.mutators.has('roulette')) { this.rouletteT -= simDt; if (this.rouletteT <= 0) { this.rouletteT = 20; const ids = Object.keys(WEAPONS); const id = ids[Math.floor(Math.random() * ids.length)]; P.weapons.setWeapon(P.weapons.active, id); this.hud.toast(`ROULETTE: ${WEAPONS[id].name.toUpperCase()}`, 'info', 1.6); } }

    // units (the engagement director decides who may press an attack right now)
    updateEngagement(this, eDt);
    for (let i = 0; i < this.units.length; i++) {
      const u = this.units[i];
      if (!u.alive) continue;
      u.update(u.team === 'enemy' ? eDt : simDt);
    }
    this._collisions(simDt);
    this.projectiles.update(simDt);
    this._updateHazards(simDt);
    this._updatePickups(simDt);
    this._regionHazards(simDt);
    if (!this.ending) { this.director.update(simDt); this.objective.update(simDt); }
    else if (this.boss) this.boss.update(simDt);
    // combo decay
    if (this.comboT > 0) { this.comboT -= simDt; if (this.comboT <= 0) { this.combo = 0; this.hud.combo(0); } }
    // prune dead units
    if (this.units.length > 40 && Math.random() < 0.1) this.units = this.units.filter(u => u.alive);
    // music intensity follows threat
    const threat = this.director.aliveBudget();
    this.audio.music?.setIntensity(this.boss && this.boss.dying < 0 && !this.boss.retreated ? 3 : threat > 24 ? 2 : threat > 0 ? 1 : 1);

    this._render(dt);
    input.endFrame();
  }

  _render(dt) {
    const P = this.player;
    this.effects.update(dt, this.camera);
    this._camera(dt);
    this.env.update(dt, this.camera, P.pos);
    this.audio.setListener(this.camera.position, tmp.set(1, 0, 0).applyQuaternion(this.camera.quaternion));
    this.audio.engineParams(Math.min(1, P.vel.length() / 250), P.boosting);
    this.audio.loop('boost', P.boosting && P.alive, { volume: 0.06 });
    const hullFrac = P.hull / P.maxHull;
    this.renderer.setGrade({ damage: Math.max(0, 0.6 - hullFrac) * 1.4 + (this.hud.hurtPulse || 0), slow: this.timeDilation > 0 ? 1 : 0, time: this.realTime });
    this._hudAcc = (this._hudAcc || 0) + dt;
    if (!this.headless || this._hudAcc > 0.5) { this.hud.update(this.headless ? this._hudAcc : dt, this); this._hudAcc = 0; }
    if (!this.headless) this.renderer.render(this.scene, this.camera);
  }

  _camera(dt) {
    const P = this.player, cam = this.camera;
    if (!P.alive || (this.ending === 'retreat')) {
      const c = this.deathPos || P.pos;
      const a = this.realTime * 0.3;
      tmp.set(Math.cos(a) * 60, 25, Math.sin(a) * 60).add(c);
      cam.position.lerp(tmp, Math.min(1, dt * 2)); cam.lookAt(c);
      return;
    }
    const boost = P.boosting ? 1 : 0;
    const back = 23 + boost * 5 + (P.def.size - 1) * 10;
    const desired = tmp.set(0, 6.2 + (P.def.size - 1) * 2, -back).applyQuaternion(P.quat).add(P.pos);
    const k = 1 - Math.exp(-dt * (this.introT > 0 ? 3 : 9));
    this.camPos.lerp(desired, k);
    const look = tmp2.copy(P.forward).multiplyScalar(60).add(P.pos).addScaledVector(P.up, 3.5);
    // optional camera lean toward the locked target (only while it's roughly ahead, so the view never whips round)
    const lt = P.hardTarget;
    if (lt && lt.alive && this.settings.cameraLean !== false && this.tune.cameraLean > 0) {
      tmp3.copy(lt.pos).sub(P.pos); const ld = tmp3.length();
      const ldot = tmp3.dot(P.forward) / Math.max(1, ld);
      if (ldot > 0.2) { const w = this.tune.cameraLean * Math.min(1, (ldot - 0.2) * 2); tmp3.multiplyScalar(60 / Math.max(1, ld)).add(P.pos); look.lerp(tmp3, w); }
    }
    this.camLook.lerp(look, 1 - Math.exp(-dt * 14));
    cam.position.copy(this.camPos).add(this.effects.shakeOffset);
    cam.up.lerp(P.up, 1 - Math.exp(-dt * 6)).normalize();
    cam.lookAt(this.camLook);
    const fov = portraitFov(68 + boost * 10 + (P.overdrive > 0 ? 4 : 0) - P.kickT * 2, cam.aspect);
    if (Math.abs(cam.fov - fov) > 0.05) { cam.fov += (fov - cam.fov) * Math.min(1, dt * 4); cam.updateProjectionMatrix(); }
  }

  _cinematicCamera(dt) {
    const c = this.cinematic, cam = this.camera;
    const t = c.t / c.duration;
    const a = -0.8 + t * 1.6;
    const r = c.radius * (1.4 - t * 0.5);
    tmp.set(Math.sin(a) * r, r * 0.25 + 20, -Math.cos(a) * r).add(c.focus);
    cam.position.lerp(tmp, Math.min(1, dt * 3 + (c.t < 0.05 ? 1 : 0)));
    cam.up.set(0, 1, 0);
    cam.lookAt(c.focus);
    { const cf = portraitFov(55, cam.aspect); if (cam.fov !== cf) { cam.fov = cf; cam.updateProjectionMatrix(); } }
    this.hud.update(dt, this);
  }

  _updateTargeting() {
    const P = this.player;
    if (!P.alive) { P.softTarget = null; return; }
    const fog = this.mission.region === 'nebula' || this.mission.modifiers.includes('densefield') ? 0.65 : 1;
    const range = 1100 * fog;
    if (P.hardTarget && (!P.hardTarget.alive || P.hardTarget.untargetable || !P.inCone(P.hardTarget, 0.2))) P.hardTarget = null;
    P.softTarget = P.hardTarget || this.findTarget(P.pos, P.forward, Math.min(0.965, this.tune.magnetCos), range, 'player');
    if (P.softTarget && P.softTarget.passive && !P.hardTarget) {
      // prefer real threats over cargo/mines
      const alt = this.findTarget(P.pos, P.forward, 0.94, range, 'player');
      if (alt && !alt.passive) P.softTarget = alt;
    }
  }
  _cycleTarget() {
    const P = this.player;
    const cands = this.units.filter(u => this.isTargetable(u) && !u.passive && !u.armored && u.pos.distanceTo(P.pos) < 1400 && P.inCone(u, 0.3));
    if (!cands.length) { P.hardTarget = null; return; }
    cands.sort((a, b) => tmp.copy(b.pos).sub(P.pos).normalize().dot(P.forward) - tmp2.copy(a.pos).sub(P.pos).normalize().dot(P.forward));
    const idx = P.hardTarget ? (cands.indexOf(P.hardTarget) + 1) % cands.length : 0;
    P.hardTarget = cands[idx];
    this.audio.play('lock');
  }

  _collisions(dt) {
    const P = this.player;
    if (!P.alive) return;
    const a = this.env.asteroids;
    // player vs asteroids
    if (a) {
      const cell = this.asteroidGrid.query(P.pos.x, P.pos.y, P.pos.z);
      if (cell) for (const i of cell) {
        if (!a.alive[i]) continue;
        tmp.set(a.pos[i * 3], a.pos[i * 3 + 1], a.pos[i * 3 + 2]);
        const r = a.radius[i] + P.radius * 0.7;
        const d = P.pos.distanceTo(tmp);
        if (d < r) {
          const n = tmp2.copy(P.pos).sub(tmp).normalize();
          P.pos.copy(tmp).addScaledVector(n, r);
          const rel = tmp3.set(a.vel[i * 3], a.vel[i * 3 + 1], a.vel[i * 3 + 2]).sub(P.vel);
          const impact = Math.abs(rel.dot(n));
          P.vel.reflect(n).multiplyScalar(0.45);
          if (impact > 30) { this.damagePlayer(impact * 0.18, { pos: P.pos, collision: true, environmental: true }); this.effects.sparks(P.pos, '#ffd0a0', 12, 80, 1.6, 0.5); this.audio.play('hitArmor'); }
        }
      }
    }
    // player vs set pieces & big units
    for (const o of this.obstacles) {
      const r = o.radius + P.radius * 0.6; const d = P.pos.distanceTo(o.pos);
      if (d < r) { const n = tmp.copy(P.pos).sub(o.pos).normalize(); P.pos.copy(o.pos).addScaledVector(n, r); const imp = Math.abs(P.vel.dot(n)); P.vel.reflect(n).multiplyScalar(0.4); if (imp > 40) this.damagePlayer(imp * 0.15, { pos: P.pos, collision: true }); }
    }
    for (const u of this.units) {
      if (!u.alive || u.intangible || u === this.decoy || u.team === 'ally' && !u.structure) continue;
      const r = u.radius + P.radius * 0.7;
      const dsq = P.pos.distanceToSquared(u.pos);
      if (dsq > r * r) continue;
      if (u.behavior === 'kamikaze' || u.behavior === 'etorpedo' || u.behavior === 'mine') continue; // they handle their own detonation
      const d = Math.sqrt(dsq);
      const n = tmp.copy(P.pos).sub(u.pos).divideScalar(d || 1);
      // push out gently (multiple overlapping hull spheres must never trap the player)
      P.pos.addScaledVector(n, Math.min(r - d, 40 * dt + 2));
      const rel = tmp2.copy(P.vel).sub(u.vel).dot(n);
      const imp = Math.max(0, -rel);
      if (rel < 0) P.vel.addScaledVector(n, -rel * 1.3);
      if (imp > 40 && !u.part && !u.structure && u.radius < 20) { this.damageUnit(u, imp * 0.6, { source: 'player', pos: u.pos, weapon: 'ram' }); }
      if (imp > 40) this.damagePlayer(imp * (u.radius > 20 ? 0.2 : 0.1), { pos: P.pos, collision: true });
    }
    // enemies steer around asteroids (cheap push-out)
    if (a) for (const u of this.units) {
      if (!u.alive || u.structure || u.part || u.boss) continue;
      const cell = this.asteroidGrid.query(u.pos.x, u.pos.y, u.pos.z);
      if (!cell) continue;
      for (const i of cell) {
        if (!a.alive[i]) continue;
        tmp.set(a.pos[i * 3], a.pos[i * 3 + 1], a.pos[i * 3 + 2]);
        const r = a.radius[i] + u.radius; const d = u.pos.distanceTo(tmp);
        if (d < r) { const n = tmp2.copy(u.pos).sub(tmp).normalize(); u.pos.copy(tmp).addScaledVector(n, r); u.vel.addScaledVector(n, 40); }
      }
    }
  }

  _updateHazards(dt) {
    const P = this.player;
    for (const h of this.hazards) {
      h.life -= dt;
      if (Math.random() < 0.5) this.effects.trailPuff(tmp.copy(h.pos).add(tmp2.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(h.radius)), h.color || '#ff7a2a', 3, 0.5);
      if (h.team === 'player') { for (const u of this.units) if (u.alive && u.team === 'enemy' && u.pos.distanceTo(h.pos) < h.radius + u.radius) this.damageUnit(u, h.dps * dt, { source: 'player', weapon: 'afterburner', dot: true, pos: u.pos }); }
      else if (P.alive && P.pos.distanceTo(h.pos) < h.radius) this.damagePlayer(h.dps * dt, { pos: h.pos, environmental: true });
    }
    this.hazards = this.hazards.filter(h => h.life > 0);
  }

  _updatePickups(dt) {
    const P = this.player;
    const rad = this.shipStats.lootRadius * this.runPerks.magnet;
    for (const p of this.pickups) {
      p.life -= dt;
      const d = P.alive ? p.pos.distanceTo(P.pos) : 1e9;
      if (d < rad) { tmp.copy(P.pos).sub(p.pos).normalize(); p.vel.addScaledVector(tmp, (300 + (rad - d) * 8) * dt); p.vel.multiplyScalar(0.92); }
      else p.vel.multiplyScalar(1 - 1.2 * dt);
      p.pos.addScaledVector(p.vel, dt);
      p.sprite.material.opacity = p.life < 5 ? (Math.sin(this.time * 20) > 0 ? 1 : 0.3) : 1;
      p.sprite.material.rotation += dt;
      if (d < P.radius + 5) { this._collect(p); p.life = -1; }
    }
    const dead = this.pickups.filter(p => p.life <= 0);
    for (const p of dead) { this.scene.remove(p.sprite); p.sprite.material.dispose(); p.sprite.children[0].material.dispose(); }
    if (dead.length) this.pickups = this.pickups.filter(p => p.life > 0);
  }

  _regionHazards(dt) {
    const hz = REGIONS[this.mission.region]?.hazards || [];
    const P = this.player;
    if (!P.alive || this.ending) return;
    this.hazardT -= dt;
    if (this.hazardT > 0) return;
    if (hz.includes('flares') || (this.mission.event === 'summer')) {
      this.hazardT = this.rng.range(14, 22);
      const pos = P.pos.clone().addScaledVector(P.forward, this.rng.range(60, 220)).add(new THREE.Vector3(this.rng.range(-80, 80), this.rng.range(-60, 60), this.rng.range(-80, 80)));
      this.effects.marker(pos, 110, 3, '#ff7a1a');
      this.hud.warn('MAGMA FLARE ERUPTING', 2);
      setTimeout(() => { if (!this.active) return; this.addHazard({ pos, radius: 110, dps: 28, life: 5, team: 'enemy', color: '#ff7a1a' }); this.effects.explosion(pos, 3, '#ff7a1a', { debris: false }); this.audio.play('explosionL', { pos }); }, 3000);
    } else if (hz.includes('ionstorm')) {
      this.hazardT = this.rng.range(6, 11);
      const pos = P.pos.clone().add(new THREE.Vector3(this.rng.range(-150, 150), this.rng.range(-80, 80), this.rng.range(-150, 150)));
      this.effects.marker(pos, 45, 1.3, '#9fd8ff');
      setTimeout(() => {
        if (!this.active) return;
        const sky = pos.clone().add(new THREE.Vector3(0, 400, 0));
        this.effects.arc(sky, pos, '#bfe6ff', 40, 0.3); this.effects.arc(sky, pos, '#ffffff', 25, 0.2);
        this.effects.flash(pos, 30, '#bfe6ff', 0.3); this.audio.play('arc', { pos, volume: 1 });
        if (P.pos.distanceTo(pos) < 50) { P.shield = Math.max(0, P.shield - 45); P.shieldDelay = 4; this.hud.toast('ION STRIKE — SHIELDS DRAINED', 'warn', 1.4); }
        for (const u of this.units) if (u.alive && u.pos.distanceTo(pos) < 50) { u.shield = 0; u.stunned = 1.5; }
      }, 1300);
    } else this.hazardT = 999;
  }

  // -------------------------------------------------------------------------
  finish(outcome) {
    if (!this.active) return;
    const m = this.mission, P = this.player, st = this.stats;
    const optionalDone = [];
    if (outcome === 'victory') {
      for (const o of m.optional || []) {
        const ok = o === 'nohull' ? P.hullDamageTaken <= 0.01
          : o === 'speed' ? this.time <= m.parTime
          : o === 'secondary' ? st.secondaryKills >= 8
          : o === 'elite' ? st.eliteBounty
          : o === 'salvage' ? st.salvage >= 25
          : o === 'combo' ? st.bestCombo >= 8
          : o === 'variety' ? st.weaponsKill.size >= 3 : false;
        if (ok) optionalDone.push(o);
      }
    }
    const result = {
      outcome: outcome === 'retreat' ? 'retreat' : outcome, score: this.score, time: this.time,
      kills: st.kills, killsByType: st.killsByType, bossesKilled: st.bossesKilled, aceKills: st.aceKills,
      secondaryKills: st.secondaryKills, bestCombo: st.bestCombo, wave: m.mode === 'daily' || m.mode === 'experimental' || m.mode === 'endless' ? (outcome === 'victory' ? (this.objective.wave || 0) : Math.max(0, (this.objective.wave || 1) - 1)) : 0,
      loot: { ...this.loot }, optionalDone, hullDamage: P.hullDamageTaken, damageDealt: st.damageDealt,
      discoveries: st.discoveries, branch: this.objective.branch, weaponsUsed: [...st.weaponsKill],
      encountered: { enemies: [...this.encountered.enemies], bosses: [...this.encountered.bosses] },
      failReason: this.objective.failReason, perks: this.perksTaken.slice(),
      rating: this.objective.branch?.ratings ? this.objective.branch.ratings.map(r => r.rating).join('') : null,
    };
    if (this.loot.cosmetic) result.cosmeticFind = this.loot.cosmetic;
    this.active = false;
    this.audio.stopAllLoops();
    this.app.onMissionEnd(m, result);
  }

  cleanup() {
    if (!this.scene) return;
    this.audio.stopAllLoops();
    if (this.objective?.boss?.dispose) this.objective.boss.dispose();
    if (this.objective?.bossCtl?.dispose) this.objective.bossCtl.dispose();
    this.director?.dispose();
    for (const u of this.units) if (!u._removed) { u.dispose(); }
    this.player?.dispose();
    this.projectiles?.dispose();
    this.effects?.dispose();
    for (const p of this.pickups) { p.sprite.material.dispose(); p.sprite.children[0]?.material.dispose(); }
    for (const o of this.missionObjects) { this.scene.remove(o); o.traverse(x => { if (x.geometry) x.geometry.dispose(); if (x.material) x.material.dispose(); }); }
    this.env?.dispose();
    this.scene.traverse(o => { if (o.geometry && o.userData?.own) o.geometry.dispose(); });
    this.units = []; this.pickups = []; this.hazards = []; this.gravityWells = []; this.missionObjects = [];
    this.scene = null; this.player = null; this.boss = null; this.objective = null; this.director = null;
    this.active = false;
    this.hud.endMission();
  }
}

function hashSeed(s) { let h = 0; for (let i = 0; i < String(s).length; i++) h = (h * 31 + String(s).charCodeAt(i)) | 0; return Math.abs(h); }

// Tall (portrait) screens keep roughly the horizontal view of a landscape screen so the ship doesn't fill the display
function portraitFov(v, aspect) {
  if (!aspect || aspect >= 1.25) return v;
  const r = Math.PI / 180;
  return Math.min(108, 2 * Math.atan(Math.tan(v * r / 2) * 1.25 / aspect) / r);
}
