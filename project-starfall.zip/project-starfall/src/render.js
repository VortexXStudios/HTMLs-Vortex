// ============================================================================
// Renderer, post-processing (bloom) with safe fallback, quality settings.
// ============================================================================
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';

// Final colour-grade pass: vignette, subtle chromatic aberration on damage, grade tint.
const GradeShader = {
  uniforms: {
    tDiffuse: { value: null },
    uVignette: { value: 0.35 },
    uDamage: { value: 0.0 },
    uTint: { value: new THREE.Color(1, 1, 1) },
    uSlow: { value: 0.0 },
    uTime: { value: 0 },
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
  fragmentShader: `
    uniform sampler2D tDiffuse; uniform float uVignette; uniform float uDamage; uniform vec3 uTint; uniform float uSlow; uniform float uTime;
    varying vec2 vUv;
    void main(){
      vec2 c = vUv - 0.5;
      float d = length(c);
      float ab = 0.0025 * uDamage + 0.0015 * uSlow;
      vec3 col;
      col.r = texture2D(tDiffuse, vUv + c * ab).r;
      col.g = texture2D(tDiffuse, vUv).g;
      col.b = texture2D(tDiffuse, vUv - c * ab).b;
      col *= uTint;
      // time-dilation desaturate + blue shift
      float l = dot(col, vec3(0.299,0.587,0.114));
      col = mix(col, vec3(l*0.8, l*0.95, l*1.25), uSlow*0.55);
      // damage red edge
      col = mix(col, col + vec3(0.6,0.0,0.0)*smoothstep(0.3,0.75,d), uDamage*0.6);
      // vignette
      col *= 1.0 - smoothstep(0.35, 0.85, d) * uVignette;
      // film grain (very light)
      float n = fract(sin(dot(vUv*vec2(1233.1,733.7) + uTime, vec2(12.9898,78.233))) * 43758.5453);
      col += (n - 0.5) * 0.015;
      gl_FragColor = vec4(col, 1.0);
    }`,
};

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.webglOk = true;
    try {
      this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance', stencil: false });
    } catch (e) {
      this.webglOk = false;
      throw e;
    }
    const r = this.renderer;
    // Bloom renders into half-float targets. GPUs that can't render to them (some Chromebooks) would show a black
    // screen without any error, so only enable post-processing when the extension is present.
    const ext = r.extensions;
    this.floatTargetsOk = !!(ext.has('EXT_color_buffer_float') || ext.has('EXT_color_buffer_half_float'));
    this.bloomOk = this.floatTargetsOk;
    if (!this.floatTargetsOk) console.warn('[Starfall] float render targets unsupported: bloom disabled');
    canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); this.contextLost = true; window.__starfall?.ui?.toast?.('The graphics driver reset. Reload the page if the screen stays black.', 'warn', 8); });
    canvas.addEventListener('webglcontextrestored', () => { this.contextLost = false; });
    r.outputColorSpace = THREE.SRGBColorSpace;
    r.toneMapping = THREE.ACESFilmicToneMapping;
    r.toneMappingExposure = 1.0;
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFSoftShadowMap;
    this.camera = new THREE.PerspectiveCamera(68, window.innerWidth / window.innerHeight, 0.5, 12000);
    this.settings = null;
    this.composer = null;
    this.scene = null;
    this.grade = null;
    this.pixelRatio = 1;
    this._lastW = 0; this._lastH = 0;
    this.resize();
  }

  _buildComposer(scene) {
    if (this.composer) {
      for (const pass of this.composer.passes) if (pass.dispose) pass.dispose();
      this.composer.dispose?.();
    }
    this.composer = null;
    if (!this.settings || this.settings.effects === 'low' || !this.bloomOk) return;
    try {
      const size = this.renderer.getSize(new THREE.Vector2());
      const composer = new EffectComposer(this.renderer);
      composer.setPixelRatio(this.pixelRatio);
      composer.setSize(size.x, size.y);
      this.renderPass = new RenderPass(scene, this.camera);
      composer.addPass(this.renderPass);
      const half = this.settings.effects === 'medium';
      const bloom = new UnrealBloomPass(new THREE.Vector2(size.x * (half ? 0.5 : 1), size.y * (half ? 0.5 : 1)), 0.85, 0.55, 0.82);
      composer.addPass(bloom);
      this.grade = new ShaderPass(GradeShader);
      composer.addPass(this.grade);
      composer.addPass(new OutputPass());
      // verify the offscreen target is actually renderable on this GPU
      const gl = this.renderer.getContext();
      this.renderer.setRenderTarget(composer.renderTarget1);
      const ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      this.renderer.setRenderTarget(null);
      if (!ok) throw new Error('offscreen render target incomplete');
      this.bloom = bloom;
      this.composer = composer;
    } catch (e) {
      console.warn('[Starfall] Post-processing unavailable, falling back to direct rendering:', e);
      this.bloomOk = false;
      this.composer = null;
    }
  }

  applySettings(settings) {
    this.settings = settings;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.pixelRatio = dpr * settings.resolutionScale;
    this.renderer.setPixelRatio(this.pixelRatio);
    this.renderer.shadowMap.enabled = settings.shadows !== 'off';
    const far = { low: 5000, medium: 8000, high: 12000 }[settings.renderDistance] || 12000;
    this.camera.far = far; this.camera.updateProjectionMatrix();
    this.resize(true);
    if (this.scene) this._buildComposer(this.scene);
  }

  setScene(scene) {
    if (this.scene === scene && (this.composer || !this.bloomOk || this.settings?.effects === 'low')) return;
    this.scene = scene;
    if (this.composer && this.renderPass) { this.renderPass.scene = scene; return; }
    this._buildComposer(scene);
  }

  resize(force = false) {
    const w = window.innerWidth, h = window.innerHeight;
    if (!force && w === this._lastW && h === this._lastH) return;
    this._lastW = w; this._lastH = h;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    if (this.composer) { this.composer.setPixelRatio(this.pixelRatio); this.composer.setSize(w, h); }
  }

  setGrade({ damage = 0, slow = 0, tint = null, time = 0 } = {}) {
    if (!this.grade) return;
    const u = this.grade.uniforms;
    u.uDamage.value = damage; u.uSlow.value = slow; u.uTime.value = time % 100;
    if (tint) u.uTint.value.copy(tint); else u.uTint.value.setRGB(1, 1, 1);
  }

  render(scene, camera = this.camera) {
    if (this.scene !== scene) this.setScene(scene);
    if (this.composer) {
      try { this.composer.render(); return; }
      catch (e) { console.warn('[Starfall] composer failed, disabling bloom', e); this.bloomOk = false; this.composer = null; }
    }
    this.renderer.render(scene, camera);
  }

  info() { return this.renderer.info; }
}
