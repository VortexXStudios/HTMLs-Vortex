// ============================================================================
// Visual effects: pooled GPU particles, explosions, shockwaves, debris,
// beams, lightning arcs, telegraph markers, ribbon trails and camera shake.
// No per-frame allocations in update loops.
// ============================================================================
import * as THREE from 'three';

const tmpV = new THREE.Vector3(), tmpV2 = new THREE.Vector3(), tmpV3 = new THREE.Vector3();
const tmpC = new THREE.Color();

// ---------------------------------------------------------------------------
// GPU point-sprite particle system (CPU simulated, typed arrays)
// ---------------------------------------------------------------------------
class ParticleSystem {
  constructor(capacity, blending, softness = 1) {
    this.cap = capacity;
    this.pos = new Float32Array(capacity * 3);
    this.vel = new Float32Array(capacity * 3);
    this.col = new Float32Array(capacity * 3);
    this.size = new Float32Array(capacity);
    this.alpha = new Float32Array(capacity);
    this.life = new Float32Array(capacity);
    this.maxLife = new Float32Array(capacity);
    this.s0 = new Float32Array(capacity); this.s1 = new Float32Array(capacity);
    this.drag = new Float32Array(capacity);
    this.baseCol = new Float32Array(capacity * 3);
    this.fade = new Uint8Array(capacity);
    this.cursor = 0; this.alive = 0;
    const g = new THREE.BufferGeometry();
    this.aPos = new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage);
    this.aCol = new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage);
    this.aSize = new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage);
    this.aAlpha = new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage);
    g.setAttribute('position', this.aPos); g.setAttribute('color', this.aCol); g.setAttribute('size', this.aSize); g.setAttribute('alpha', this.aAlpha);
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    this.material = new THREE.ShaderMaterial({
      uniforms: { uPixel: { value: window.innerHeight / 2 }, uSoft: { value: softness } },
      vertexShader: `attribute float size; attribute float alpha; attribute vec3 color; varying vec3 vC; varying float vA; uniform float uPixel;
        void main(){ vC = color; vA = alpha; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_PointSize = clamp(size * uPixel / max(0.1, -mv.z), 0.0, 400.0); gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `varying vec3 vC; varying float vA; uniform float uSoft;
        void main(){ vec2 c = gl_PointCoord - 0.5; float d = length(c); if (d > 0.5) discard; float a = pow(1.0 - d*2.0, 1.0 + uSoft); gl_FragColor = vec4(vC, a * vA); }`,
      transparent: true, depthWrite: false, blending, toneMapped: false,
    });
    this.points = new THREE.Points(g, this.material);
    this.points.frustumCulled = false;
    this.points.renderOrder = 5;
  }
  emit(x, y, z, vx, vy, vz, life, s0, s1, r, g, b, drag = 1.5, fade = 1) {
    const i = this.cursor; this.cursor = (this.cursor + 1) % this.cap;
    const i3 = i * 3;
    this.pos[i3] = x; this.pos[i3 + 1] = y; this.pos[i3 + 2] = z;
    this.vel[i3] = vx; this.vel[i3 + 1] = vy; this.vel[i3 + 2] = vz;
    this.baseCol[i3] = r; this.baseCol[i3 + 1] = g; this.baseCol[i3 + 2] = b;
    this.life[i] = life; this.maxLife[i] = life; this.s0[i] = s0; this.s1[i] = s1; this.drag[i] = drag; this.fade[i] = fade;
    this.alpha[i] = 1; this.size[i] = s0;
  }
  update(dt) {
    let alive = 0;
    for (let i = 0; i < this.cap; i++) {
      if (this.life[i] <= 0) { if (this.alpha[i] !== 0) { this.alpha[i] = 0; this.size[i] = 0; } continue; }
      alive++;
      this.life[i] -= dt;
      const t = 1 - Math.max(0, this.life[i]) / this.maxLife[i];
      const i3 = i * 3;
      const d = Math.max(0, 1 - this.drag[i] * dt);
      this.vel[i3] *= d; this.vel[i3 + 1] *= d; this.vel[i3 + 2] *= d;
      this.pos[i3] += this.vel[i3] * dt; this.pos[i3 + 1] += this.vel[i3 + 1] * dt; this.pos[i3 + 2] += this.vel[i3 + 2] * dt;
      this.size[i] = this.s0[i] + (this.s1[i] - this.s0[i]) * t;
      const a = this.fade[i] ? (1 - t) * (1 - t) : 1 - t * t;
      this.alpha[i] = a;
      // hot -> cool colour shift for fire
      const k = this.fade[i] === 2 ? Math.max(0.15, 1 - t * 1.4) : 1;
      this.col[i3] = this.baseCol[i3] * k; this.col[i3 + 1] = this.baseCol[i3 + 1] * k * k; this.col[i3 + 2] = this.baseCol[i3 + 2] * k * k * k;
      if (this.life[i] <= 0) { this.alpha[i] = 0; this.size[i] = 0; }
    }
    this.alive = alive;
    this.aPos.needsUpdate = true; this.aCol.needsUpdate = true; this.aSize.needsUpdate = true; this.aAlpha.needsUpdate = true;
    this.material.uniforms.uPixel.value = window.innerHeight / 2;
  }
  clear() { this.life.fill(0); this.alpha.fill(0); this.size.fill(0); }
}

// ---------------------------------------------------------------------------
// Ribbon trail (camera-facing strip)
// ---------------------------------------------------------------------------
export class RibbonTrail {
  constructor(length = 32, width = 1, color = new THREE.Color(1, 1, 1), style = 'standard') {
    this.n = length; this.width = width; this.color = color.clone(); this.style = style;
    this.points = []; for (let i = 0; i < length; i++) this.points.push(new THREE.Vector3());
    this.inited = false; this.timer = 0;
    const g = new THREE.BufferGeometry();
    this.posArr = new Float32Array(length * 2 * 3);
    this.alphaArr = new Float32Array(length * 2);
    const idx = [];
    for (let i = 0; i < length - 1; i++) { const a = i * 2, b = a + 1, c = a + 2, d = a + 3; idx.push(a, b, c, b, d, c); }
    g.setIndex(idx);
    this.aPos = new THREE.BufferAttribute(this.posArr, 3).setUsage(THREE.DynamicDrawUsage);
    this.aA = new THREE.BufferAttribute(this.alphaArr, 1).setUsage(THREE.DynamicDrawUsage);
    g.setAttribute('position', this.aPos); g.setAttribute('alpha', this.aA);
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    this.mat = new THREE.ShaderMaterial({
      uniforms: { uColor: { value: this.color }, uOpacity: { value: 1 } },
      vertexShader: `attribute float alpha; varying float vA; void main(){ vec4 mv = modelViewMatrix * vec4(position,1.0); vA = alpha * smoothstep(10.0, 34.0, -mv.z); gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `uniform vec3 uColor; uniform float uOpacity; varying float vA; void main(){ gl_FragColor = vec4(uColor * 1.3, vA * uOpacity * 0.55); }`,
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, toneMapped: false,
    });
    this.mesh = new THREE.Mesh(g, this.mat);
    this.mesh.frustumCulled = false;
  }
  reset(p) { for (const q of this.points) q.copy(p); this.inited = true; }
  update(head, camera, dt, power = 1) {
    if (!this.inited) this.reset(head);
    this.timer += dt;
    const step = 1 / 60;
    while (this.timer >= step) {
      this.timer -= step;
      for (let i = this.n - 1; i > 0; i--) this.points[i].copy(this.points[i - 1]);
    }
    this.points[0].copy(head);
    const camPos = camera.position;
    for (let i = 0; i < this.n; i++) {
      const p = this.points[i];
      const nx = this.points[Math.min(this.n - 1, i + 1)];
      const pv = this.points[Math.max(0, i - 1)];
      tmpV.subVectors(pv, nx); // segment dir
      if (tmpV.lengthSq() < 1e-6) tmpV.set(0, 0, 1);
      tmpV2.subVectors(camPos, p);
      tmpV3.crossVectors(tmpV, tmpV2).normalize();
      const t = i / (this.n - 1);
      const w = this.width * (1 - t) * power;
      this.posArr[i * 6] = p.x + tmpV3.x * w; this.posArr[i * 6 + 1] = p.y + tmpV3.y * w; this.posArr[i * 6 + 2] = p.z + tmpV3.z * w;
      this.posArr[i * 6 + 3] = p.x - tmpV3.x * w; this.posArr[i * 6 + 4] = p.y - tmpV3.y * w; this.posArr[i * 6 + 5] = p.z - tmpV3.z * w;
      const a = (1 - t) * (1 - t) * 0.8 * Math.min(1, power);
      this.alphaArr[i * 2] = a; this.alphaArr[i * 2 + 1] = a;
    }
    this.aPos.needsUpdate = true; this.aA.needsUpdate = true;
  }
  dispose() { this.mesh.geometry.dispose(); this.mat.dispose(); }
}

// ---------------------------------------------------------------------------
// Effects manager
// ---------------------------------------------------------------------------
export class Effects {
  constructor(scene, settings) {
    this.scene = scene;
    this.group = new THREE.Group();
    scene.add(this.group);
    this.setQuality(settings);
    this.add = new ParticleSystem(this.capacity, THREE.AdditiveBlending, 0.6);
    this.smoke = new ParticleSystem(Math.round(this.capacity / 3), THREE.NormalBlending, 0.2);
    this.group.add(this.smoke.points); this.group.add(this.add.points);
    // Shockwave rings
    this.rings = [];
    const ringGeo = new THREE.RingGeometry(0.85, 1, 48);
    for (let i = 0; i < 16; i++) {
      const m = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
      m.visible = false; m.userData = { life: 0, max: 1, size: 10, color: new THREE.Color() };
      this.group.add(m); this.rings.push(m);
    }
    // Flash spheres
    this.flashes = [];
    const fg = new THREE.SphereGeometry(1, 16, 12);
    for (let i = 0; i < 16; i++) {
      const m = new THREE.Mesh(fg, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
      m.visible = false; m.userData = { life: 0, max: 1, size: 1 };
      this.group.add(m); this.flashes.push(m);
    }
    // Dynamic lights pool
    this.lights = [];
    for (let i = 0; i < 6; i++) { const l = new THREE.PointLight(0xffaa66, 0, 220, 2); l.userData = { life: 0, max: 1, power: 0 }; this.group.add(l); this.lights.push(l); }
    // Debris (instanced)
    this.debrisCap = 260;
    const dg = new THREE.TetrahedronGeometry(1, 0);
    this.debrisMesh = new THREE.InstancedMesh(dg, new THREE.MeshStandardMaterial({ color: '#555a62', metalness: 0.8, roughness: 0.5, emissive: '#ff5a1a', emissiveIntensity: 0.4 }), this.debrisCap);
    this.debrisMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.debrisMesh.frustumCulled = false;
    this.debris = [];
    for (let i = 0; i < this.debrisCap; i++) this.debris.push({ life: 0, pos: new THREE.Vector3(), vel: new THREE.Vector3(), rot: new THREE.Quaternion(), spin: new THREE.Quaternion(), size: 1 });
    this.debrisCursor = 0;
    this.group.add(this.debrisMesh);
    this._hideAllDebris();
    // Beams (cylinders)
    this.beams = [];
    const bg = new THREE.CylinderGeometry(1, 1, 1, 8, 1, true); bg.translate(0, 0.5, 0); bg.rotateX(Math.PI / 2);
    for (let i = 0; i < 24; i++) {
      const m = new THREE.Mesh(bg, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
      m.visible = false; m.userData = { life: 0, max: 1, width: 1 };
      this.group.add(m); this.beams.push(m);
    }
    // Lightning arcs (line segments)
    this.arcs = [];
    for (let i = 0; i < 16; i++) {
      const g = new THREE.BufferGeometry(); const arr = new Float32Array(14 * 3);
      g.setAttribute('position', new THREE.BufferAttribute(arr, 3).setUsage(THREE.DynamicDrawUsage));
      g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
      const l = new THREE.Line(g, new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
      l.visible = false; l.frustumCulled = false; l.userData = { life: 0, max: 0.15 };
      this.group.add(l); this.arcs.push(l);
    }
    // Telegraph markers (warning spheres / rings)
    this.markers = [];
    const mg = new THREE.SphereGeometry(1, 24, 16);
    for (let i = 0; i < 20; i++) {
      const m = new THREE.Mesh(mg, new THREE.MeshBasicMaterial({ color: 0xff3a2a, transparent: true, opacity: 0.2, blending: THREE.AdditiveBlending, depthWrite: false, wireframe: true, toneMapped: false }));
      m.visible = false; m.userData = { life: 0, max: 1 };
      this.group.add(m); this.markers.push(m);
    }
    // Sniper / laser sight lines
    this.sights = [];
    for (let i = 0; i < 12; i++) {
      const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3).setUsage(THREE.DynamicDrawUsage));
      const l = new THREE.Line(g, new THREE.LineBasicMaterial({ color: 0xff2a2a, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
      l.visible = false; l.frustumCulled = false; this.group.add(l); this.sights.push(l);
    }
    this.shake = 0; this.shakeOffset = new THREE.Vector3();
    this.time = 0;
    this.trails = [];
  }

  setQuality(settings) {
    this.settings = settings;
    this.density = { low: 0.35, medium: 0.65, high: 1 }[settings.particles] || 1;
    this.capacity = { low: 2500, medium: 4500, high: 7000 }[settings.particles] || 7000;
    this.lightsOn = settings.effects !== 'low';
  }

  _hideAllDebris() { const m = new THREE.Matrix4().makeScale(0, 0, 0); for (let i = 0; i < this.debrisCap; i++) this.debrisMesh.setMatrixAt(i, m); this.debrisMesh.instanceMatrix.needsUpdate = true; }

  // ---------------- emitters
  sparks(pos, color, count = 10, speed = 80, size = 1.6, life = 0.5, dir = null) {
    const n = Math.max(1, Math.round(count * this.density));
    tmpC.set(color);
    for (let i = 0; i < n; i++) {
      let vx = (Math.random() - 0.5) * 2, vy = (Math.random() - 0.5) * 2, vz = (Math.random() - 0.5) * 2;
      if (dir) { vx = vx * 0.5 + dir.x; vy = vy * 0.5 + dir.y; vz = vz * 0.5 + dir.z; }
      const s = speed * (0.4 + Math.random() * 0.8);
      this.add.emit(pos.x, pos.y, pos.z, vx * s, vy * s, vz * s, life * (0.6 + Math.random() * 0.6), size, size * 0.2, tmpC.r * 2, tmpC.g * 2, tmpC.b * 2, 2.5);
    }
  }
  glowPuff(pos, color, size = 6, life = 0.3) {
    tmpC.set(color);
    this.add.emit(pos.x, pos.y, pos.z, 0, 0, 0, life, size, size * 1.6, tmpC.r * 2.5, tmpC.g * 2.5, tmpC.b * 2.5, 0);
  }
  trailPuff(pos, color, size = 2, life = 0.4, vel = null) {
    tmpC.set(color);
    this.add.emit(pos.x, pos.y, pos.z, vel ? vel.x : 0, vel ? vel.y : 0, vel ? vel.z : 0, life, size, size * 0.2, tmpC.r * 1.8, tmpC.g * 1.8, tmpC.b * 1.8, 1);
  }
  smokePuff(pos, size = 6, life = 1.6, dark = 0.12) {
    this.smoke.emit(pos.x, pos.y, pos.z, (Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8, life, size, size * 3, dark, dark, dark * 1.1, 0.8, 1);
  }

  explosion(pos, scale = 1, color = '#ffaa44', opts = {}) {
    const n = Math.round(40 * scale * this.density + 6);
    tmpC.set(color);
    // fireball core
    for (let i = 0; i < n; i++) {
      const u = Math.random() * 2 - 1, t = Math.random() * Math.PI * 2, r = Math.sqrt(1 - u * u);
      const s = (20 + Math.random() * 70) * scale;
      this.add.emit(pos.x, pos.y, pos.z, r * Math.cos(t) * s, u * s, r * Math.sin(t) * s, 0.5 + Math.random() * 0.7 * Math.sqrt(scale), (4 + Math.random() * 6) * scale, 1 * scale, tmpC.r * 3, tmpC.g * 2.6, tmpC.b * 2.2, 3, 2);
    }
    // sparks
    this.sparks(pos, '#ffe6b0', Math.round(26 * scale), 160 * Math.sqrt(scale), 1.4 * Math.sqrt(scale), 0.9);
    // smoke
    const sm = Math.round(10 * scale * this.density);
    for (let i = 0; i < sm; i++) { tmpV.set(pos.x + (Math.random() - 0.5) * 6 * scale, pos.y + (Math.random() - 0.5) * 6 * scale, pos.z + (Math.random() - 0.5) * 6 * scale); this.smokePuff(tmpV, 5 * scale, 1.5 + Math.random(), 0.08 + Math.random() * 0.06); }
    this.flash(pos, 8 * scale, color, 0.25);
    if (!opts.noRing) this.ring(pos, 26 * scale, color, 0.55, opts.normal);
    if (opts.debris !== false) this.debrisBurst(pos, Math.round(6 * scale), scale);
    this.light(pos, color, 2400 * scale, 0.35 + 0.1 * scale);
    if (scale > 1.5) this.addShake(Math.min(1.5, scale * 0.25));
  }

  flash(pos, size, color, life = 0.2) {
    const f = this.flashes.find(x => !x.visible) || this.flashes[0];
    f.visible = true; f.position.copy(pos); f.userData.life = life; f.userData.max = life; f.userData.size = size;
    f.material.color.set(color).multiplyScalar(this.settings.reduceFlashing ? 1.2 : 3);
    f.scale.setScalar(size * 0.3);
  }

  ring(pos, size, color, life = 0.5, normal = null) {
    const r = this.rings.find(x => !x.visible) || this.rings[0];
    r.visible = true; r.position.copy(pos); r.userData.life = life; r.userData.max = life; r.userData.size = size;
    r.material.color.set(color).multiplyScalar(2);
    if (normal) r.lookAt(tmpV.copy(pos).add(normal)); else r.userData.billboard = true;
    r.scale.setScalar(0.1);
  }

  light(pos, color, intensity, life) {
    if (!this.lightsOn) return;
    let l = this.lights.find(x => x.userData.life <= 0);
    if (!l) l = this.lights.reduce((a, b) => (a.userData.life < b.userData.life ? a : b));
    l.position.copy(pos); l.color.set(color); l.userData.life = life; l.userData.max = life; l.userData.power = intensity;
  }

  debrisBurst(pos, n, scale = 1) {
    for (let i = 0; i < n; i++) {
      const d = this.debris[this.debrisCursor]; this.debrisCursor = (this.debrisCursor + 1) % this.debrisCap;
      d.life = 1.5 + Math.random() * 1.5; d.pos.copy(pos);
      d.vel.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize().multiplyScalar((30 + Math.random() * 70) * Math.sqrt(scale));
      d.size = (0.5 + Math.random() * 1.6) * Math.sqrt(scale);
      d.rot.setFromEuler(new THREE.Euler(Math.random() * 6, Math.random() * 6, 0));
      d.spin.setFromAxisAngle(tmpV.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize(), (Math.random() - 0.5) * 0.3);
    }
  }

  beam(from, to, color, width = 0.6, life = 0.12) {
    const b = this.beams.find(x => !x.visible) || this.beams[0];
    b.visible = true; b.position.copy(from);
    const len = from.distanceTo(to);
    b.lookAt(to);
    b.userData.life = life; b.userData.max = life; b.userData.width = width; b.userData.len = len;
    b.scale.set(width, width, len);
    b.material.color.set(color).multiplyScalar(3);
    b.material.opacity = 1;
    return b;
  }

  arc(from, to, color = '#9fd8ff', jag = 6, life = 0.12) {
    const l = this.arcs.find(x => !x.visible) || this.arcs[0];
    const arr = l.geometry.attributes.position.array;
    const n = 14;
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1);
      tmpV.lerpVectors(from, to, t);
      if (i > 0 && i < n - 1) { tmpV.x += (Math.random() - 0.5) * jag; tmpV.y += (Math.random() - 0.5) * jag; tmpV.z += (Math.random() - 0.5) * jag; }
      arr[i * 3] = tmpV.x; arr[i * 3 + 1] = tmpV.y; arr[i * 3 + 2] = tmpV.z;
    }
    l.geometry.attributes.position.needsUpdate = true;
    l.material.color.set(color).multiplyScalar(3);
    l.visible = true; l.userData.life = life; l.userData.max = life;
    this.glowPuff(to, color, 5, 0.15);
  }

  marker(pos, radius, life, color = '#ff3a2a') {
    const m = this.markers.find(x => !x.visible) || this.markers[0];
    m.visible = true; m.position.copy(pos); m.scale.setScalar(radius); m.userData.life = life; m.userData.max = life; m.userData.radius = radius;
    m.material.color.set(color);
    return m;
  }

  sight(from, to, color = '#ff2a2a', alpha = 0.6) {
    const l = this.sights.find(x => !x.visible);
    if (!l) return;
    const a = l.geometry.attributes.position.array;
    a[0] = from.x; a[1] = from.y; a[2] = from.z; a[3] = to.x; a[4] = to.y; a[5] = to.z;
    l.geometry.attributes.position.needsUpdate = true;
    l.material.color.set(color).multiplyScalar(2); l.material.opacity = alpha; l.visible = true;
  }

  addShake(amount) { if (this.settings.reduceShake) amount *= 0.25; this.shake = Math.min(2.2, this.shake + amount); }

  addTrail(trail) { this.trails.push(trail); this.group.add(trail.mesh); return trail; }
  removeTrail(trail) { const i = this.trails.indexOf(trail); if (i >= 0) this.trails.splice(i, 1); this.group.remove(trail.mesh); trail.dispose(); }

  update(dt, camera) {
    this.time += dt;
    this.add.update(dt); this.smoke.update(dt);
    for (const r of this.rings) {
      if (!r.visible) continue;
      r.userData.life -= dt;
      const t = 1 - r.userData.life / r.userData.max;
      r.scale.setScalar(Math.max(0.01, r.userData.size * (0.2 + t * 0.9)));
      r.material.opacity = (1 - t) * 0.9;
      if (r.userData.billboard) r.quaternion.copy(camera.quaternion);
      if (r.userData.life <= 0) { r.visible = false; r.userData.billboard = false; }
    }
    for (const f of this.flashes) {
      if (!f.visible) continue;
      f.userData.life -= dt;
      const t = 1 - f.userData.life / f.userData.max;
      f.scale.setScalar(f.userData.size * (0.4 + t * 0.8)); f.material.opacity = 1 - t;
      if (f.userData.life <= 0) f.visible = false;
    }
    for (const l of this.lights) {
      if (l.userData.life <= 0) { l.intensity = 0; continue; }
      l.userData.life -= dt;
      l.intensity = Math.max(0, l.userData.life / l.userData.max) * l.userData.power;
    }
    const m4 = this._m4 || (this._m4 = new THREE.Matrix4()); const sc = this._sc || (this._sc = new THREE.Vector3());
    let anyDebris = false;
    for (let i = 0; i < this.debrisCap; i++) {
      const d = this.debris[i];
      if (d.life <= 0) continue;
      anyDebris = true;
      d.life -= dt;
      d.pos.addScaledVector(d.vel, dt); d.vel.multiplyScalar(1 - 0.4 * dt); d.rot.multiply(d.spin);
      const s = d.life > 0 ? d.size * Math.min(1, d.life) : 0;
      if (Math.random() < 0.08 * this.density && d.life > 0.6) this.smokePuff(d.pos, 1.5, 0.8, 0.1);
      m4.compose(d.pos, d.rot, sc.setScalar(s)); this.debrisMesh.setMatrixAt(i, m4);
    }
    if (anyDebris) this.debrisMesh.instanceMatrix.needsUpdate = true;
    for (const b of this.beams) {
      if (!b.visible) continue;
      b.userData.life -= dt;
      const t = Math.max(0, b.userData.life / b.userData.max);
      b.material.opacity = t; b.scale.x = b.scale.y = b.userData.width * (0.4 + 0.6 * t);
      if (b.userData.life <= 0) b.visible = false;
    }
    for (const a of this.arcs) {
      if (!a.visible) continue;
      a.userData.life -= dt; a.material.opacity = Math.max(0, a.userData.life / a.userData.max);
      if (a.userData.life <= 0) a.visible = false;
    }
    for (const m of this.markers) {
      if (!m.visible) continue;
      m.userData.life -= dt;
      const t = 1 - m.userData.life / m.userData.max;
      m.material.opacity = 0.12 + 0.3 * t * (0.6 + 0.4 * Math.sin(this.time * 20));
      m.rotation.y += dt * 0.6;
      if (m.userData.life <= 0) m.visible = false;
    }
    for (const s of this.sights) s.visible = false; // re-drawn each frame by owners
    // camera shake decay
    this.shake = Math.max(0, this.shake - dt * 2.4);
    const k = this.shake * this.shake * 2.2;
    this.shakeOffset.set((Math.random() - 0.5) * k, (Math.random() - 0.5) * k, (Math.random() - 0.5) * k * 0.5);
  }

  clear() {
    this.add.clear(); this.smoke.clear();
    for (const x of [...this.rings, ...this.flashes, ...this.beams, ...this.arcs, ...this.markers, ...this.sights]) x.visible = false;
    for (const l of this.lights) { l.userData.life = 0; l.intensity = 0; }
    for (const d of this.debris) d.life = 0;
    this._hideAllDebris();
    for (const t of this.trails.slice()) this.removeTrail(t);
    this.shake = 0;
  }

  dispose() {
    this.clear();
    this.scene.remove(this.group);
    this.group.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); });
  }
}
