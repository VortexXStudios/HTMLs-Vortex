// ============================================================================
// Menus: splash, title, hangar (missions, ships, upgrades, customization,
// shop, collection, achievements, daily, events, records, settings),
// briefing, pause and results. DOM-based with event delegation.
// ============================================================================
import { DIFFICULTY, resolveDifficulty, tuning } from './combat.js';
import {
  SHIPS, SHIP_ORDER, WEAPONS, PRIMARY_ORDER, SECONDARIES, SECONDARY_ORDER, ABILITIES, ABILITY_ORDER,
  UPGRADE_BRANCHES, UPGRADE_MAX_TIER, upgradeCost, MODS, MOD_PAIRS, MOD_UNLOCK_TIER, MOD_COST,
  COSMETICS, COSMETIC_TYPES, RARITY, ACHIEVEMENTS, CAMPAIGN, BOSSES, BOSS_ORDER, ENEMIES, ENEMY_ORDER,
  FACTIONS, REGIONS, OBJECTIVES, MODIFIERS, OPTIONAL_OBJECTIVES, MUTATORS, xpForLevel, CURRENCIES, GAME_VERSION, VARIANTS, ACE_NAMES,
} from './data.js';
import {
  canAfford, buyShip, buyItem, buyUpgrade, buyMod, equipMod, buyCosmetic, equipCosmetic, setLoadout,
  computeShipStats, achievementProgress, formatCost, grant, checkAchievements, derivedStats,
} from './progression.js';
import {
  campaignMission, isCampaignUnlocked, generateContracts, dailyMission, dailyChallenge, eventMission,
  experimentalMission, bossRushMission, endlessMission, describeMission,
} from './missions.js';
import { getDailyStatus, claimDaily, formatDuration } from './daily.js';
import { EVENTS, EVENT_ORDER, upcomingEvents, eventEndsAt } from './events.js';

const icon = n => `assets/icons/${n}.png`;
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const cur = (k, v) => `<span class="cur"><img src="${icon(CURRENCIES[k].icon)}" alt="">${Math.round(v).toLocaleString()}</span>`;
const costHtml = (c, save) => { if (!c) return '<span class="free">FREE</span>'; return Object.entries(c).filter(([, v]) => v).map(([k, v]) => `<span class="cur ${save && (save.currencies[k] || 0) < v ? 'short' : ''}"><img src="${icon(CURRENCIES[k].icon)}">${v.toLocaleString()}</span>`).join(' '); };
const bar = (f, cls = '') => `<div class="bar ${cls}"><i style="width:${Math.max(0, Math.min(1, f)) * 100}%"></i></div>`;
const pct = v => `${Math.round(v * 100)}%`;

const NAV = [
  ['missions', 'missions', 'Missions'], ['ships', 'ships', 'Ships'], ['upgrades', 'upgrades', 'Upgrades'], ['customize', 'customize', 'Customize'],
  ['shop', 'shop', 'Shop'], ['collection', 'collection', 'Collection'], ['achievements', 'achievements', 'Achievements'], ['daily', 'daily', 'Daily Rewards'],
  ['events', 'events', 'Events'], ['leaderboards', 'leaderboards', 'Records'], ['settings', 'settings', 'Settings'], ['exit', 'exit', 'Exit'],
];

export class UI {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('ui');
    this.tab = 'missions'; this.sub = {};
    this.missionCache = new Map();
    this.previewShip = null;
    this.custType = 'paint';
    this.selected = {};
    this.root.addEventListener('click', e => this._click(e));
    this.root.addEventListener('mouseover', e => { const b = e.target.closest('button, .card[data-action], .navbtn'); if (b && b !== this._hover) { this._hover = b; this.app.audio.play('hover', { volume: 0.4 }); } });
    this.root.addEventListener('input', e => this._input(e));
    this.root.addEventListener('change', e => this._input(e));
    this.tickT = 0;
  }

  get save() { return this.app.saveManager.data; }

  // ------------------------------------------------------------- skeleton
  boot() {
    this.root.innerHTML = `
      <div id="splash" class="screen on">
        <div class="vortex"><svg viewBox="-100 -100 200 200">${Array.from({ length: 7 }, (_, i) => `<path d="M ${-80 + i * 10} 0 A ${80 - i * 10} ${80 - i * 10} 0 0 1 ${80 - i * 10} 0" style="--i:${i}" />`).join('')}<circle r="10"/></svg></div>
        <div class="studio">${'VORTEX STUDIOS'.split('').map((c, i) => `<span style="--d:${i * 0.06}s">${c === ' ' ? '&nbsp;' : c}</span>`).join('')}</div>
        <div class="presents">PRESENTS...</div>
        <div class="skip">click to skip</div>
      </div>
      <div id="title" class="screen"></div>
      <div id="hangar" class="screen"></div>
      <div id="briefing" class="screen overlay"></div>
      <div id="results" class="screen overlay"></div>
      <div id="pause" class="screen overlay"></div>
      <div id="modal" class="screen overlay"></div>
      <div id="ui-toasts"></div>`;
    this.splashT = 0; this.splashDone = false;
    const skip = () => this._endSplash();
    this.root.querySelector('#splash').addEventListener('click', skip);
    this._splashKey = e => { if (this.app.state === 'splash') skip(); };
    window.addEventListener('keydown', this._splashKey);
    const st = this.app.saveManager.status;
    if (st.recovered) setTimeout(() => this.toast(st.source === 'backup' ? 'Save data was damaged — restored from backup.' : 'Save data was unreadable. A copy was kept and a new profile was created.', 'warn', 6), 4500);
    if (this.app.clockIssue) setTimeout(() => this.toast('System clock moved backwards — daily rewards are paused until the date catches up.', 'warn', 6), 5000);
    if (!this.app.storageOk) setTimeout(() => this.toast('Browser storage is blocked: progress will not be saved this session.', 'warn', 6), 4800);
  }

  _endSplash() {
    if (this.splashDone) return;
    this.splashDone = true;
    window.removeEventListener('keydown', this._splashKey);
    const sp = this.root.querySelector('#splash');
    sp.classList.add('out');
    setTimeout(() => sp.classList.remove('on'), 900);
    this.app.toTitle();
  }

  tick(dt) {
    if (this.app.state === 'splash') { this.splashT += dt; if (this.splashT > 5.2) this._endSplash(); }
    this.tickT += dt;
    if (this.tickT > 1) {
      this.tickT = 0;
      for (const e of this.root.querySelectorAll('[data-countdown]')) e.textContent = formatDuration(+e.dataset.countdown - this.app.now());
    }
  }

  hideAll() { for (const s of this.root.querySelectorAll('.screen')) if (s.id !== 'splash') s.classList.remove('on'); }
  show(id) { this.root.querySelector('#' + id).classList.add('on'); }
  hide(id) { this.root.querySelector('#' + id).classList.remove('on'); }

  toast(text, kind = 'info', dur = 3) {
    const host = this.root.querySelector('#ui-toasts');
    const e = document.createElement('div'); e.className = 'uitoast ' + kind; e.textContent = text; host.appendChild(e);
    setTimeout(() => e.classList.add('out'), dur * 1000); setTimeout(() => e.remove(), dur * 1000 + 500);
  }

  confirm(title, text, onYes, yes = 'Confirm') {
    const m = this.root.querySelector('#modal');
    m.innerHTML = `<div class="modal-box panel"><h2>${title}</h2><p>${text}</p><div class="row"><button class="btn" data-action="modal-no">Cancel</button><button class="btn danger" data-action="modal-yes">${yes}</button></div></div>`;
    this._modalYes = onYes;
    m.classList.add('on');
  }

  back() {
    const m = this.root.querySelector('#modal');
    if (m.classList.contains('on')) { m.classList.remove('on'); return; }
    if (this.root.querySelector('#briefing').classList.contains('on')) { this.hide('briefing'); this._restoreHangarModel(); return; }
    if (this.app.state === 'hangar') this.app.toTitle();
  }

  // ------------------------------------------------------------- title
  showTitle() {
    this.hideAll();
    const s = this.save;
    const ev = this.app.activeEvents();
    const daily = getDailyStatus(s, this.app.now());
    const t = this.root.querySelector('#title');
    t.innerHTML = `
      <div class="title-logo"><div class="pre">VORTEX STUDIOS PRESENTS</div><h1>PROJECT <b>STARFALL</b></h1><div class="tagline2">Defend the Kepler Reach</div></div>
      <div class="title-menu">
        ${imgBtn('play', 'title-play', 'Play')}
        ${imgBtn('campaign', 'title-campaign', 'Campaign')}
        ${imgBtn('endless', 'title-endless', 'Endless')}
        ${imgBtn('bossrush', 'title-bossrush', 'Boss Rush')}
        ${imgBtn('daily', 'title-daily', 'Daily Rewards', daily.canClaim ? '<i class="dot"></i>' : '')}
        ${imgBtn('events', 'title-events', 'Events', ev.length ? '<i class="dot"></i>' : '')}
        ${imgBtn('tutorial', 'title-tutorial', 'Tutorial')}
        ${imgBtn('settings', 'title-settings', 'Settings')}
        ${imgBtn('exit', 'title-exit', 'Exit')}
      </div>
      ${ev.length ? `<div class="title-event" style="--a:${EVENTS[ev[0]].colors.a}"><img src="${icon(EVENTS[ev[0]].icon)}"><div><b>${EVENTS[ev[0]].name}</b> is live<br><small>${EVENTS[ev[0]].tagline}</small></div></div>` : ''}
      <div class="title-foot">Pilot <b>${esc(s.profile.callsign)}</b> · Level ${s.profile.level} · v${GAME_VERSION}${this.app.dev.dev ? ' · <span class="devtag">DEV MODE</span>' : ''}</div>`;
    this.show('title');
  }

  // ------------------------------------------------------------- hangar
  showHangar(tab) {
    this.hideAll();
    if (tab) this.tab = tab;
    const h = this.root.querySelector('#hangar');
    h.innerHTML = `
      <div class="topbar">
        <div class="tb-left"><div class="logo-sm">STARFALL</div><div class="pilot"><div class="lvl">${this.save.profile.level}</div><div><b>${esc(this.save.profile.callsign)}</b><div class="xp">${bar(this.save.profile.xp / xpForLevel(this.save.profile.level), 'xp')}<small>${Math.round(this.save.profile.xp)} / ${xpForLevel(this.save.profile.level)} XP</small></div></div></div></div>
        <div class="tb-right" id="tb-cur"></div>
      </div>
      <nav class="nav">${NAV.map(([id, img, label]) => `<button class="navbtn${this.tab === id ? ' active' : ''}" data-action="tab" data-tab="${id}" title="${label}"><img src="assets/buttons/${img}.png" alt="${label}"><span class="badge" id="badge-${id}"></span></button>`).join('')}</nav>
      <section class="content panel" id="content"></section>
      <div class="hangar-side" id="side"></div>
      <div class="hangar-ship-label" id="shiplabel"></div>`;
    this.show('hangar');
    this.refreshTop();
    this.renderTab();
  }

  refreshTop() {
    const s = this.save;
    const el = this.root.querySelector('#tb-cur');
    if (!el) return;
    el.innerHTML = `${cur('credits', s.currencies.credits)}${cur('alloy', s.currencies.alloy)}${cur('cores', s.currencies.cores)}${s.currencies.tokens || this.app.activeEvents().length ? cur('tokens', s.currencies.tokens) : ''}`;
    const daily = getDailyStatus(s, this.app.now());
    const setBadge = (id, on) => { const b = this.root.querySelector('#badge-' + id); if (b) b.classList.toggle('on', !!on); };
    setBadge('daily', daily.canClaim);
    setBadge('events', this.app.activeEvents().length);
    setBadge('upgrades', Object.keys(UPGRADE_BRANCHES).some(b => s.upgrades[b] < UPGRADE_MAX_TIER && canAfford(s, upgradeCost(b, s.upgrades[b] + 1))));
    this.renderSide();
  }

  renderSide() {
    const side = this.root.querySelector('#side');
    if (!side) return;
    const s = this.save, cards = [];
    const daily = getDailyStatus(s, this.app.now());
    if (daily.canClaim) cards.push(`<div class="nd good" data-action="tab" data-tab="daily"><img src="${icon('daily')}"><div><b>Daily reward ready</b><small>Streak day ${daily.streakIfClaimed}</small></div></div>`);
    const next = CAMPAIGN.findIndex(c => !s.campaign.completed.includes(c.id));
    if (next >= 0) cards.push(`<div class="nd" data-action="brief-campaign" data-idx="${next}"><img src="${icon('campaign')}"><div><b>Campaign: ${CAMPAIGN[next].title}</b><small>Chapter ${next + 1} of ${CAMPAIGN.length}</small></div></div>`);
    const up = Object.keys(UPGRADE_BRANCHES).filter(b => s.upgrades[b] < UPGRADE_MAX_TIER && canAfford(s, upgradeCost(b, s.upgrades[b] + 1)));
    if (up.length) cards.push(`<div class="nd" data-action="tab" data-tab="upgrades"><img src="${icon('upgrades')}"><div><b>${up.length} upgrade${up.length > 1 ? 's' : ''} affordable</b><small>${UPGRADE_BRANCHES[up[0]].name}…</small></div></div>`);
    const buyable = SHIP_ORDER.filter(id => !s.ships.owned.includes(id) && s.profile.level >= SHIPS[id].unlock.level && canAfford(s, SHIPS[id].cost));
    if (buyable.length) cards.push(`<div class="nd good" data-action="tab" data-tab="ships"><img src="${icon(SHIPS[buyable[0]].icon)}"><div><b>New ship available</b><small>${SHIPS[buyable[0]].name} can be built</small></div></div>`);
    for (const e of this.app.activeEvents()) cards.push(`<div class="nd event" style="--a:${EVENTS[e].colors.a}" data-action="tab" data-tab="events"><img src="${icon(EVENTS[e].icon)}"><div><b>${EVENTS[e].name}</b><small>${EVENTS[e].tagline}</small></div></div>`);
    if (s.universe.followUps.length) cards.push(`<div class="nd warn" data-action="sub" data-tab="missions" data-sub="contracts"><img src="${icon('missions')}"><div><b>${s.universe.followUps.length} special contract${s.universe.followUps.length > 1 ? 's' : ''}</b><small>Consequences of your actions</small></div></div>`);
    side.innerHTML = `<h4>NEXT DECISIONS</h4>${cards.slice(0, 5).join('') || '<div class="nd"><div><b>All caught up</b><small>Pick a contract and fly.</small></div></div>'}<button class="launch-btn" data-action="sub" data-tab="missions" data-sub="contracts"><img src="assets/buttons/play.png" alt="Play"></button>`;
  }

  renderTab() {
    for (const b of this.root.querySelectorAll('.navbtn')) b.classList.toggle('active', b.dataset.tab === this.tab);
    const c = this.root.querySelector('#content');
    if (!c) return;
    const fn = { missions: this.tabMissions, ships: this.tabShips, upgrades: this.tabUpgrades, customize: this.tabCustomize, shop: this.tabShop, collection: this.tabCollection, achievements: this.tabAchievements, daily: this.tabDaily, events: this.tabEvents, leaderboards: this.tabRecords, settings: this.tabSettings }[this.tab];
    c.className = 'content panel tab-' + this.tab;
    c.innerHTML = fn ? fn.call(this) : '';
    if (this.tab !== 'collection') this._restoreHangarModel();
  }

  _restoreHangarModel() {
    const id = this.previewShip && this.tab === 'ships' ? this.previewShip : this.save.ships.selected;
    const key = id + JSON.stringify(this.save.cosmetics.equipped[id]);
    if (this._modelKey !== key) { this._modelKey = key; this.app.menu.showShip(id, this.save.cosmetics.equipped[id]); }
    const lbl = this.root.querySelector('#shiplabel');
    if (lbl) lbl.innerHTML = `<b>${SHIPS[id].name}</b> <span>${SHIPS[id].role}</span>`;
  }

  subtabs(group, items) {
    const cur = this.sub[group] || items[0][0];
    return `<div class="subtabs">${items.map(([id, label, badge]) => `<button class="${cur === id ? 'active' : ''}" data-action="sub" data-tab="${this.tab}" data-group="${group}" data-sub="${id}">${label}${badge ? ' <i class="dot"></i>' : ''}</button>`).join('')}</div>`;
  }
  getSub(group, def) { return this.sub[group] || def; }

  // ------------------------------------------------------------- missions
  cacheMission(m) { this.missionCache.set(m.id, m); return m.id; }

  missionCard(m, extra = '') {
    const d = describeMission(m);
    const id = this.cacheMission(m);
    const r = m.rewards || {};
    return `<div class="card mission ${m.special ? 'special' : ''} ${m.daily ? 'daily' : ''}" data-action="brief" data-id="${id}">
      <div class="mc-head"><img src="${icon(OBJECTIVES[m.objective]?.icon || 'missions')}"><div><h3>${esc(m.title)}</h3><small>${d.objective} · ${d.region}</small></div><div class="tier">T${m.tier}</div></div>
      ${m.special ? `<div class="mc-special">${m.special === 'retaliation' ? 'Retaliation' : m.special === 'rival' ? 'Rival returns' : m.special === 'rescue' ? 'Rescue' : m.special === 'favor' ? 'Fleet favor' : m.special === 'discovery' ? 'Discovery' : 'Consequence'}</div>` : ''}
      <p>${esc(m.brief)}</p>
      <div class="mc-mods">${m.modifiers.map(x => `<span class="chip" title="${esc(MODIFIERS[x].desc)}"><img src="${icon(MODIFIERS[x].icon)}">${MODIFIERS[x].name}</span>`).join('')}${m.elite ? `<span class="chip elite"><img src="${icon('rank_skull')}">${esc(m.elite.name)}</span>` : ''}${m.boss ? `<span class="chip boss"><img src="${icon('bossrush')}">${BOSSES[m.boss].name}</span>` : ''}</div>
      <div class="mc-rew">${r.credits ? cur('credits', r.credits) : ''}${r.alloy ? cur('alloy', r.alloy) : ''}${r.cores ? cur('cores', r.cores) : ''}${r.tokens ? cur('tokens', r.tokens) : ''}${extra}</div>
    </div>`;
  }

  contracts() {
    const s = this.save, today = this.app.today();
    if (s.universe.contracts.day !== today || !s.universe.contracts.list.length) {
      if (s.universe.contracts.day !== today) s.universe.contracts.refreshes = 0;
      s.universe.contracts.day = today;
      s.universe.contracts.list = generateContracts(s, today, this.app.activeEvents());
      this.app.persist();
    }
    return s.universe.contracts.list;
  }

  tabMissions() {
    const s = this.save;
    const ev = this.app.activeEvents();
    const sub = this.getSub('missions', 'contracts');
    let body = '';
    if (sub === 'campaign') {
      body = `<div class="campaign">${CAMPAIGN.map((c, i) => {
        const done = s.campaign.completed.includes(c.id), open = isCampaignUnlocked(s, i);
        return `<div class="card chapter ${done ? 'done' : ''} ${open ? '' : 'locked'}" ${open ? `data-action="brief-campaign" data-idx="${i}"` : ''}>
          <div class="ch-num">${i + 1}</div><div class="ch-body"><h3>${c.title}</h3><small>${REGIONS[c.region].name} · ${c.boss ? BOSSES[c.boss].name : OBJECTIVES[c.objective].name}</small><p>${open ? esc(c.brief) : 'Complete the previous chapter to unlock.'}</p></div>
          <div class="ch-state">${done ? `<img src="${icon('confirm')}">` : open ? '<span class="go">FLY</span>' : `<img src="${icon('cancel')}">`}</div></div>`;
      }).join('')}</div>`;
    } else if (sub === 'contracts') {
      const list = this.contracts();
      const dm = dailyMission(this.app.today(), s, ev);
      const doneToday = s.daily.missionDay === this.app.today();
      body = `<div class="row between"><p class="hint">Contracts rotate daily and when completed. The director avoids repeating recent mission types. Regions where you fight often become more dangerous — and more rewarding.</p><button class="btn small" data-action="refresh-contracts" ${s.currencies.credits < 100 ? 'disabled' : ''}>Refresh board ${costHtml({ credits: 100 }, s)}</button></div>
        <h4 class="sec">DAILY OP ${doneToday ? '<span class="ok">COMPLETED TODAY</span>' : '<span class="bonus">+1 core, +10 alloy bonus</span>'}</h4>
        <div class="cards">${this.missionCard(dm, doneToday ? '<span class="done-tag">bonus claimed</span>' : '')}</div>
        <h4 class="sec">CONTRACT BOARD</h4><div class="cards">${list.map(m => this.missionCard(m)).join('')}</div>
        <h4 class="sec">REGION THREAT</h4><div class="threat">${Object.entries(s.universe.threat).map(([r, t]) => `<div><img src="${icon(REGIONS[r].icon)}"><span>${REGIONS[r].name}</span>${bar((t - 0.5) / 2.5, t > 1.6 ? 'danger' : '')}</div>`).join('')}</div>`;
    } else if (sub === 'modes') {
      const dc = dailyChallenge(this.app.today(), ev);
      const best = s.daily.challengeBest[this.app.today()] || 0;
      const bosses = Object.keys(s.universe.encountered.bosses).filter(b => BOSSES[b] && !BOSSES[b].event);
      body = `<div class="modes">
        <div class="card mode" data-action="launch-endless"><img src="assets/buttons/endless.png"><p>Survive escalating waves. New modifiers every 3 waves, a perk choice after every wave, bosses every 10. Your score multiplier keeps climbing.</p><small>Best wave: <b>${s.stats.bestWave}</b> · High score: <b>${(s.records.endless[0]?.score || 0).toLocaleString()}</b></small></div>
        <div class="card mode ${bosses.length ? '' : 'locked'}"><img src="assets/buttons/bossrush.png"><p>Fight every boss you have encountered, back to back. Ranked S–C on speed and damage taken.</p><small>${bosses.length ? `Bosses unlocked: ${bosses.map(b => BOSSES[b].name).join(', ')}` : 'Encounter a boss in the campaign or contracts to unlock.'}</small>
          ${bosses.length ? `<div class="row">${['normal', 'hard', 'nightmare'].map(d => `<button class="btn small" data-action="launch-bossrush" data-diff="${d}">${d}</button>`).join('')}</div>` : ''}</div>
        <div class="card mode" data-action="launch-experimental"><div class="mode-title"><img src="${icon('help')}"> EXPERIMENTAL ZONE</div><p>Three random mutators — giant enemies, weapon roulette, bent space, ricochet arenas, mirror squadrons… Chaotic but fair. 5 waves.</p><small>Wins: ${s.stats.experimentalWins}</small></div>
        <div class="card mode daily" data-action="brief" data-id="${this.cacheMission(dc)}"><div class="mode-title"><img src="${icon('leaderboards')}"> DAILY CHALLENGE</div><p>${esc(dc.brief)}</p><div class="mc-mods">${dc.modifiers.map(x => `<span class="chip"><img src="${icon(MODIFIERS[x].icon)}">${MODIFIERS[x].name}</span>`).join('')}</div><small>Today's best: <b>${best.toLocaleString()}</b> · resets in <span data-countdown="${this.app.now() + getDailyStatus(s, this.app.now()).nextInMs}">--</span></small></div>
      </div>`;
    } else if (sub === 'event') {
      body = this._eventMissions();
    }
    return `<h2>MISSIONS</h2>${this.subtabs('missions', [['contracts', 'Contracts', s.universe.followUps.length], ['campaign', 'Campaign'], ['modes', 'Game Modes'], ...(ev.length ? [['event', 'Event', true]] : [])])}<div class="scroll">${body}</div>`;
  }

  _eventMissions() {
    const s = this.save; const ev = this.app.activeEvents();
    if (!ev.length) return '<p class="hint">No event is active right now. Check the Events tab for the calendar.</p>';
    return ev.map(id => {
      const E = EVENTS[id]; const key = this.app.eventKey(id); const prog = s.events.progress[key]?.completed || [];
      return `<div class="event-chain" style="--a:${E.colors.a};--b:${E.colors.b}"><h3><img src="${icon(E.icon)}">${E.name}</h3><p>${E.description}</p><div class="cards">${E.chain.map((c, i) => {
        const unlocked = i === 0 || prog.includes(E.chain[i - 1].id);
        const m = eventMission(id, i, s, ev);
        return unlocked ? this.missionCard(m, prog.includes(c.id) ? '<span class="done-tag">completed</span>' : '') : `<div class="card mission locked"><div class="mc-head"><img src="${icon('cancel')}"><div><h3>${c.title}</h3><small>Complete the previous event mission</small></div></div></div>`;
      }).join('')}</div></div>`;
    }).join('');
  }

  openBriefing(m) {
    const s = this.save;
    const d = describeMission(m);
    const shipId = s.ships.selected;
    const lo = s.ships.loadouts[shipId];
    const R = REGIONS[m.region];
    const b = this.root.querySelector('#briefing');
    const ace = m.elite ? ACE_NAMES.personalities[m.elite.personality] : null;
    b.innerHTML = `<div class="brief panel">
      <div class="brief-head"><img src="${icon(OBJECTIVES[m.objective]?.icon || (m.objective === 'waves' ? 'endless' : 'bossrush'))}"><div><small>${(m.mode || 'contract').toUpperCase()} · TIER ${m.tier}</small><h2>${esc(m.title)}</h2></div><button class="btn ghost" data-action="close-brief">✕</button></div>
      <div class="brief-grid">
        <div>
          <p class="brief-text">${esc(m.brief)}</p>
          <div class="kv"><span>Objective</span><b>${d.objective}</b></div>
          <div class="kv"><span>Region</span><b>${R.name}</b></div><p class="small">${R.desc} <em>${R.effect}</em></p>
          <div class="kv"><span>Hostile faction</span><b style="color:${FACTIONS[m.faction]?.color}">${d.faction}</b>${m.altFaction ? ` <small>+ ${FACTIONS[m.altFaction].name}</small>` : ''}</div>
          ${m.boss ? `<div class="kv"><span>Boss</span><b>${BOSSES[m.boss].name}</b></div><p class="small">${BOSSES[m.boss].desc}</p>` : ''}
          ${m.elite ? `<div class="kv"><span>Named elite</span><b>${esc(m.elite.name)}</b></div><p class="small">${ace.desc} (${VARIANTS[m.elite.variant]?.name || ''})</p>` : ''}
          ${m.event ? `<div class="kv"><span>Event</span><b style="color:${EVENTS[m.event].colors.a}">${EVENTS[m.event].name}</b></div>` : ''}
        </div>
        <div>
          <h4>MODIFIERS</h4>${m.modifiers.length ? m.modifiers.map(x => `<div class="modline"><img src="${icon(MODIFIERS[x].icon)}"><div><b>${MODIFIERS[x].name}</b><small>${MODIFIERS[x].desc}</small></div><span class="${MODIFIERS[x].reward >= 0 ? 'pos' : 'neg'}">${MODIFIERS[x].reward >= 0 ? '+' : ''}${Math.round(MODIFIERS[x].reward * 100)}%</span></div>`).join('') : '<p class="small">None</p>'}
          ${(m.mutators || []).length ? `<h4>MUTATORS</h4>${m.mutators.map(x => `<div class="modline"><img src="${icon('help')}"><div><b>${MUTATORS[x].name}</b><small>${MUTATORS[x].desc}</small></div></div>`).join('')}` : ''}
          <h4>OPTIONAL OBJECTIVES <small>(risk / reward)</small></h4>${m.optional.length ? m.optional.map(o => `<div class="modline"><img src="${icon('star')}"><div><b>${OPTIONAL_OBJECTIVES[o].name}</b><small>${OPTIONAL_OBJECTIVES[o].desc}${o === 'speed' ? ` (${Math.floor(m.parTime / 60)}:${String(m.parTime % 60).padStart(2, '0')})` : ''}</small></div><span>${costHtml(OPTIONAL_OBJECTIVES[o].reward)}</span></div>`).join('') : '<p class="small">None</p>'}
          <h4>REWARDS</h4><div class="mc-rew big">${m.rewards.credits ? cur('credits', m.rewards.credits) : ''}${m.rewards.alloy ? cur('alloy', m.rewards.alloy) : ''}${m.rewards.cores ? cur('cores', m.rewards.cores) : ''}${m.rewards.tokens ? cur('tokens', m.rewards.tokens) : ''}<span class="cur">${m.rewards.xp || '—'} XP</span></div>
          <p class="small">Battlefield salvage is always kept. Retreating (hold J) keeps 40% of mission rewards.</p>
        </div>
        <div class="brief-loadout">
          <h4>LOADOUT</h4>
          <div class="lo-ship"><img src="${icon(SHIPS[shipId].icon)}"><div><b>${SHIPS[shipId].name}</b><small>${SHIPS[shipId].role}</small></div></div>
          ${lo.primary.map(w => `<div class="lo-item"><img src="${icon(WEAPONS[w].icon)}">${WEAPONS[w].name}</div>`).join('')}
          <div class="lo-item"><img src="${icon(SECONDARIES[lo.secondary].icon)}">${SECONDARIES[lo.secondary].name}</div>
          <div class="lo-item"><img src="${icon(ABILITIES[lo.ability].icon)}">${ABILITIES[lo.ability].name}</div>
          <button class="btn small" data-action="brief-loadout">Change loadout</button>
          <button class="btn launch" data-action="launch" data-id="${this.cacheMission(m)}">LAUNCH</button>
        </div>
      </div></div>`;
    this.show('briefing');
    this.app.audio.play('click');
  }

  // ------------------------------------------------------------- ships
  tabShips() {
    const s = this.save;
    const sel = this.previewShip || s.ships.selected;
    const statRow = (label, v, max) => `<div class="stat"><span>${label}</span>${bar(v / max)}<b>${Math.round(v)}</b></div>`;
    const cards = SHIP_ORDER.map(id => {
      const S = SHIPS[id], owned = s.ships.owned.includes(id), lvlOk = s.profile.level >= S.unlock.level;
      return `<div class="card shipcard ${sel === id ? 'sel' : ''} ${owned ? '' : 'unowned'} ${s.ships.selected === id ? 'active' : ''}" data-action="preview-ship" data-id="${id}">
        <img src="${icon(S.icon)}"><div><h3>${S.name}</h3><small>${S.role}</small></div>${s.ships.selected === id ? '<span class="tag">ACTIVE</span>' : owned ? '' : lvlOk ? '<span class="tag buy">BUILD</span>' : `<span class="tag lock">LVL ${S.unlock.level}</span>`}</div>`;
    }).join('');
    const S = SHIPS[sel];
    const owned = s.ships.owned.includes(sel);
    const st = computeShipStats(s, sel);
    const lo = s.ships.loadouts[sel];
    const slot = (kind, value, idx = 0) => {
      const list = kind === 'primary' ? s.arsenal.weapons : kind === 'secondary' ? s.arsenal.secondaries : s.arsenal.abilities;
      const table = kind === 'primary' ? WEAPONS : kind === 'secondary' ? SECONDARIES : ABILITIES;
      return `<div class="slot"><label>${kind === 'primary' ? `Primary ${idx + 1}` : kind === 'secondary' ? 'Ordnance' : 'Ability'}</label><div class="chips">${list.map(w => `<button class="chipbtn ${value === w ? 'on' : ''}" data-action="loadout" data-ship="${sel}" data-slot="${kind}" data-idx="${idx}" data-val="${w}" title="${esc(table[w].desc)}"><img src="${icon(table[w].icon)}">${table[w].name}</button>`).join('')}</div></div>`;
    };
    return `<h2>SHIPS</h2><div class="ship-grid">${cards}</div>
      <div class="ship-detail">
        <div class="sd-head"><h3>${S.name} <small>${S.role}</small></h3>${owned ? (s.ships.selected === sel ? '<span class="tag">ACTIVE SHIP</span>' : `<button class="btn" data-action="select-ship" data-id="${sel}">Fly this ship</button>`) : `<button class="btn buy" data-action="buy-ship" data-id="${sel}" ${s.profile.level < S.unlock.level || !canAfford(s, S.cost) ? 'disabled' : ''}>Build — ${costHtml(S.cost, s)}</button>${s.profile.level < S.unlock.level ? `<small class="lockreason">Requires level ${S.unlock.level}</small>` : ''}`}</div>
        <p>${S.desc}</p><p class="trait"><img src="${icon('star')}"> ${S.trait}</p>
        <div class="stats">${statRow('Hull', st.hull, 300)}${statRow('Shield', st.shield, 200)}${statRow('Speed', st.speed, 180)}${statRow('Agility', st.agility * 100, 150)}${statRow('Boost', st.boostMax, 200)}</div>
        ${owned ? `<h4>LOADOUT</h4>${lo.primary.map((w, i) => slot('primary', w, i)).join('')}${slot('secondary', lo.secondary)}${slot('ability', lo.ability)}<p class="hint">Buy more weapons, ordnance and abilities in the Shop.</p>` : '<p class="hint">Build this ship to customize its loadout. Its signature weapons and ability come with it.</p>'}
      </div>`;
  }

  // ------------------------------------------------------------- upgrades
  tabUpgrades() {
    const s = this.save;
    const sel = s.ships.selected;
    const base = computeShipStats(s, sel);
    const rows = Object.entries(UPGRADE_BRANCHES).map(([k, B]) => {
      const t = s.upgrades[k];
      const maxed = t >= UPGRADE_MAX_TIER;
      const cost = maxed ? null : upgradeCost(k, t + 1);
      const next = { ...s.upgrades, [k]: t + 1 };
      const after = maxed ? null : computeShipStats(s, sel, next);
      const cmp = after ? compareStat(k, base, after) : '';
      const pair = MOD_PAIRS.find(p => MODS[p[0]].branch === k);
      const mods = pair ? `<div class="mods">${pair.map(mid => {
        const M = MODS[mid], own = s.mods.owned.includes(mid), eq = s.mods.equipped[k] === mid, avail = t >= MOD_UNLOCK_TIER;
        return `<div class="mod ${eq ? 'eq' : ''} ${own ? 'own' : ''} ${avail ? '' : 'locked'}"><img src="${icon(M.icon)}"><div><b>${M.name}</b><small>${M.desc}</small></div>${own ? `<button class="btn small" data-action="equip-mod" data-id="${mid}">${eq ? 'Unequip' : 'Equip'}</button>` : avail ? `<button class="btn small buy" data-action="buy-mod" data-id="${mid}" ${canAfford(s, MOD_COST) ? '' : 'disabled'}>${costHtml(MOD_COST, s)}</button>` : `<small class="lockreason">Tier ${MOD_UNLOCK_TIER}</small>`}</div>`;
      }).join('<span class="or">OR</span>')}</div>` : '';
      return `<div class="upg"><div class="upg-head"><img src="${icon(B.icon)}"><div><h3>${B.name}</h3><small>${B.fmt(t * B.per)} ${t ? '' : '(none)'}</small></div>
        <div class="pips">${Array.from({ length: UPGRADE_MAX_TIER }, (_, i) => `<i class="${i < t ? 'on' : ''}"></i>`).join('')}</div>
        ${maxed ? '<span class="tag">MAX</span>' : `<button class="btn small buy" data-action="buy-upgrade" data-id="${k}" ${canAfford(s, cost) ? '' : 'disabled'}>${costHtml(cost, s)}</button>`}</div>
        ${cmp ? `<div class="cmp">${cmp}</div>` : ''}${mods}</div>`;
    }).join('');
    return `<h2>UPGRADES</h2><p class="hint">Upgrades apply to every ship. At tier ${MOD_UNLOCK_TIER} a branch unlocks two behaviour-changing mods — equip one per branch and swap freely between missions.</p><div class="scroll upgrades">${rows}</div>`;
  }

  // ------------------------------------------------------------- customize
  tabCustomize() {
    const s = this.save;
    const ship = s.ships.selected;
    const t = this.custType;
    const eq = s.cosmetics.equipped[ship];
    const items = Object.entries(COSMETICS).filter(([, c]) => c.type === t).sort((a, b) => RARITY[a[1].rarity].order - RARITY[b[1].rarity].order);
    const label = { paint: 'Paint', engine: 'Engine Glow', pattern: 'Wing Pattern', emblem: 'Emblem', trail: 'Trail', weapon: 'Weapon Tint' };
    return `<h2>CUSTOMIZE <small>${SHIPS[ship].name}</small></h2>
      <div class="subtabs">${COSMETIC_TYPES.map(x => `<button class="${x === t ? 'active' : ''}" data-action="cust-type" data-type="${x}">${label[x]}</button>`).join('')}</div>
      <p class="hint">Rarity reflects how hard a cosmetic is to earn — never combat power. Changes preview live and persist per ship.</p>
      <div class="scroll cos-grid">${items.map(([id, c]) => {
        const own = s.cosmetics.owned.includes(id); const on = eq[t] === id; const R = RARITY[c.rarity];
        const sw = cosSwatch(c);
        return `<div class="card cos ${own ? '' : 'unowned'} ${on ? 'on' : ''}" style="--r:${R.color}" data-action="${own ? 'equip-cos' : 'cos-info'}" data-id="${id}">${sw}<div><b>${c.name}</b><small style="color:${R.color}">${R.label}</small></div>${on ? '<span class="tag">EQUIPPED</span>' : own ? '' : `<span class="src">${sourceText(c)}</span>`}</div>`;
      }).join('')}</div>`;
  }

  // ------------------------------------------------------------- shop
  tabShop() {
    const s = this.save;
    const sub = this.getSub('shop', 'weapons');
    const ev = this.app.activeEvents();
    let body = '';
    const itemCard = (kind, id, D) => {
      const own = s.arsenal[kind].includes(id), lvl = s.profile.level >= (D.unlock?.level || 1);
      return `<div class="card item ${own ? 'owned' : ''}"><img src="${icon(D.icon)}"><div class="it-body"><h3>${D.name}</h3><p>${D.desc}</p>${D.strengths ? `<small><b class="pos">+</b> ${D.strengths} · <b class="neg">−</b> ${D.weakness}</small>` : ''}${kind === 'weapons' ? `<div class="wstats"><span>DMG ${D.damage}${D.pellets ? '×' + D.pellets : ''}${D.kind === 'beam' ? '/s' : ''}</span>${D.rate ? `<span>RATE ${D.rate}/s</span>` : ''}<span>HEAT ${D.heat}</span>${D.splash ? `<span>SPLASH ${D.splash}m</span>` : ''}</div>` : kind === 'abilities' ? `<div class="wstats"><span>CD ${D.cooldown}s</span><span>DUR ${D.duration}s</span></div>` : `<div class="wstats"><span>DMG ${D.damage}</span><span>AMMO ${D.ammo}</span></div>`}</div>
        <div class="it-buy">${own ? '<span class="tag">OWNED</span>' : lvl ? `<button class="btn small buy" data-action="buy-item" data-kind="${kind}" data-id="${id}" ${canAfford(s, D.cost) ? '' : 'disabled'}>${costHtml(D.cost, s)}</button>` : `<span class="tag lock">LVL ${D.unlock.level}</span>`}</div></div>`;
    };
    if (sub === 'weapons') body = PRIMARY_ORDER.map(id => itemCard('weapons', id, WEAPONS[id])).join('');
    if (sub === 'ordnance') body = SECONDARY_ORDER.map(id => itemCard('secondaries', id, SECONDARIES[id])).join('');
    if (sub === 'abilities') body = ABILITY_ORDER.map(id => itemCard('abilities', id, ABILITIES[id])).join('');
    if (sub === 'cosmetics' || sub === 'event') {
      const list = Object.entries(COSMETICS).filter(([, c]) => c.price && (sub === 'event' ? c.source === 'event' && ev.includes(c.event) : c.source === 'shop'));
      body = list.length ? `<div class="cos-grid">${list.map(([id, c]) => { const own = s.cosmetics.owned.includes(id); const R = RARITY[c.rarity]; return `<div class="card cos ${own ? 'on' : ''}" style="--r:${R.color}">${cosSwatch(c)}<div><b>${c.name}</b><small style="color:${R.color}">${R.label} ${c.type}</small></div>${own ? '<span class="tag">OWNED</span>' : `<button class="btn small buy" data-action="buy-cos" data-id="${id}" ${canAfford(s, c.price) ? '' : 'disabled'}>${costHtml(c.price, s)}</button>`}</div>`; }).join('')}</div>` : '<p class="hint">No event exchange is open right now.</p>';
    }
    return `<h2>SHOP</h2>${this.subtabs('shop', [['weapons', 'Primary Weapons'], ['ordnance', 'Ordnance'], ['abilities', 'Abilities'], ['cosmetics', 'Cosmetics'], ...(ev.length ? [['event', 'Event Exchange', true]] : [])])}<p class="hint">Everything is earned in-game. There are no real-money purchases.</p><div class="scroll items">${body}</div>`;
  }

  // ------------------------------------------------------------- collection
  tabCollection() {
    const s = this.save;
    const sub = this.getSub('collection', 'ships');
    let body = '';
    if (sub === 'ships') body = `<div class="col-grid">${SHIP_ORDER.map(id => `<div class="card colitem ${s.ships.owned.includes(id) ? '' : 'unowned'}" data-action="inspect" data-kind="ship" data-id="${id}"><img src="${icon(SHIPS[id].icon)}"><b>${SHIPS[id].name}</b><small>${s.ships.owned.includes(id) ? SHIPS[id].role : 'Not owned'}</small></div>`).join('')}</div>`;
    if (sub === 'cosmetics') {
      const counts = {}; for (const r of Object.keys(RARITY)) counts[r] = [0, 0];
      for (const [id, c] of Object.entries(COSMETICS)) { counts[c.rarity][1]++; if (s.cosmetics.owned.includes(id)) counts[c.rarity][0]++; }
      body = `<div class="rarity-row">${Object.entries(RARITY).map(([r, R]) => `<div style="--r:${R.color}"><img src="${icon(R.icon)}"><b>${counts[r][0]}/${counts[r][1]}</b><small>${R.label}</small></div>`).join('')}</div><div class="cos-grid">${Object.entries(COSMETICS).map(([id, c]) => { const own = s.cosmetics.owned.includes(id); const R = RARITY[c.rarity]; return `<div class="card cos ${own ? '' : 'unowned'}" style="--r:${R.color}">${cosSwatch(c)}<div><b>${own ? c.name : '???'}</b><small style="color:${R.color}">${R.label} ${c.type}</small></div>${own ? '' : `<span class="src">${sourceText(c)}</span>`}</div>`; }).join('')}</div>`;
    }
    if (sub === 'bestiary') body = `<div class="col-grid">${ENEMY_ORDER.map(id => { const seen = s.universe.encountered.enemies[id]; const kills = s.stats.enemyKills[id] || 0; return `<div class="card colitem ${seen ? '' : 'unowned'}" ${seen ? `data-action="inspect" data-kind="unit" data-id="${id}"` : ''}><b>${seen ? ENEMIES[id].name : '???'}</b><small>${seen ? `${ENEMIES[id].role} · ${kills} destroyed` : 'Not yet encountered'}</small></div>`; }).join('')}</div>${this.selected.unit ? this._bestiaryEntry(this.selected.unit) : ''}`;
    if (sub === 'bosses') body = `<div class="col-grid">${BOSS_ORDER.map(id => { const seen = s.universe.encountered.bosses[id]; const k = s.stats.bossesDefeated[id] || 0; return `<div class="card colitem ${seen ? '' : 'unowned'}" ${seen ? `data-action="inspect" data-kind="boss" data-id="${id}"` : ''}><img src="${icon(BOSSES[id].icon)}"><b>${seen ? BOSSES[id].name : '???'}</b><small>${seen ? `${k} defeated` : BOSSES[id].event ? 'Event boss' : 'Not yet encountered'}</small></div>`; }).join('')}</div>${this.selected.boss ? `<div class="entry panel"><h3>${BOSSES[this.selected.boss].name}</h3><small>${BOSSES[this.selected.boss].title}</small><p>${BOSSES[this.selected.boss].desc}</p><p><b>Phases:</b> ${BOSSES[this.selected.boss].phases.join(' → ')}</p></div>` : ''}`;
    if (sub === 'discoveries') body = s.universe.discoveries.length ? `<div class="col-grid">${s.universe.discoveries.map((d, i) => `<div class="card colitem"><img src="${icon('emblem_prism')}"><b>Lattice Relic #${i + 1}</b><small>${esc(d.split('-')[1] || '')}</small></div>`).join('')}</div>` : '<p class="hint">Rare discoveries appear in derelicts, hidden signals and anomalous readings. None found yet.</p>';
    return `<h2>COLLECTION</h2>${this.subtabs('collection', [['ships', 'Ships'], ['cosmetics', 'Cosmetics'], ['bestiary', 'Bestiary'], ['bosses', 'Bosses'], ['discoveries', 'Discoveries']])}<p class="hint">Click an entry to inspect it in 3D. Drag to rotate, scroll to zoom.</p><div class="scroll">${body}</div>`;
  }
  _bestiaryEntry(id) {
    const E = ENEMIES[id];
    const tips = { swarm: 'Weak alone. Grids advance in lockstep and speed up as they thin — break the front row.', interceptor: 'Flanks and jinks when you aim at it. Lead your shots or use Arc Caster.', bomber: 'Launches shootable torpedoes at objectives. Kill the launcher during its 1.6s charge.', sniper: 'Red laser sight means 1.5s to move. Break line of sight or dash.', shieldcarrier: 'Absorbs damage for allies inside its aura. Kill it first.', repair: 'Heals the most damaged ally and flees from you. Chase it down.', stealth: 'Cloaks, circles behind you, decloaks with a burst. Listen for the shimmer.', kamikaze: 'Beeps faster as it closes. Kill it before it reaches you.', artillery: 'Red wireframe spheres mark impact zones. Keep moving.', ace: 'Named pilots with distinct personalities. They retreat and come back changed.', sentinel: 'Fires bullet rings every few seconds. Find the gaps.', broodmother: 'Spawns drones and homing spores. Burst it down.', capital: 'Massive hull, flak defenses. Target components.' };
    return `<div class="entry panel"><h3>${E.name}</h3><small>${E.role}</small><p>${tips[id] || ''}</p><div class="wstats"><span>HULL ${E.hp}</span><span>SHIELD ${E.shield}</span><span>SPEED ${E.speed}</span></div></div>`;
  }

  // ------------------------------------------------------------- achievements
  tabAchievements() {
    const s = this.save;
    const done = ACHIEVEMENTS.filter(a => s.achievements[a.id]).length;
    return `<h2>ACHIEVEMENTS <small>${done}/${ACHIEVEMENTS.length}</small></h2><div class="scroll ach-grid">${ACHIEVEMENTS.map(a => {
      const got = s.achievements[a.id]; const p = achievementProgress(s, a);
      const r = a.reward.cosmetic ? `<span class="cos-rew" style="color:${RARITY[COSMETICS[a.reward.cosmetic].rarity].color}">${COSMETICS[a.reward.cosmetic].name}</span>` : costHtml(a.reward);
      return `<div class="card ach ${got ? 'got' : ''}"><img src="${icon(a.icon)}"><div><b>${a.name}</b><small>${a.desc}</small>${got ? `<small class="ok">Unlocked ${new Date(got).toLocaleDateString()}</small>` : bar(p)}</div><div class="ach-rew">${r}</div></div>`;
    }).join('')}</div>`;
  }

  // ------------------------------------------------------------- daily
  tabDaily() {
    const s = this.save; const now = this.app.now();
    const st = getDailyStatus(s, now);
    const days = st.upcoming.map((r, i) => `<div class="dday ${i === 0 && st.canClaim ? 'today' : ''} ${r.day === 7 ? 'big' : ''}"><small>DAY ${r.day}${r.cycle > 1 ? ` · C${r.cycle}` : ''}</small>${r.cosmetic ? `<b style="color:${RARITY[COSMETICS[r.cosmetic].rarity].color}">${COSMETICS[r.cosmetic].name}</b>` : ''}${r.credits ? cur('credits', r.credits) : ''}${r.alloy ? cur('alloy', r.alloy) : ''}${r.cores ? cur('cores', r.cores) : ''}${r.boost ? '<span class="cur">2× XP</span>' : ''}</div>`).join('');
    const dm = dailyMission(this.app.today(), s, this.app.activeEvents());
    const dc = dailyChallenge(this.app.today(), this.app.activeEvents());
    return `<h2>DAILY REWARDS</h2>
      <div class="daily-head panel"><div><div class="streak">${s.daily.streak}</div><small>DAY STREAK</small></div><div class="dh-mid">
        ${st.movedBack ? '<p class="warn">Your system clock appears to have moved backwards. Rewards resume once the date catches up. (Offline games cannot fully prevent clock tampering — that needs a server.)</p>' : st.canClaim ? `<p>Today's reward is ready${st.graceUsed ? ' — you missed a day, but your streak was protected by the grace day.' : st.missed > 1 ? ' — welcome back! Your streak was halved rather than reset.' : '.'}</p><button class="btn claim" data-action="claim-daily">CLAIM DAY ${st.preview.day} REWARD</button>` : `<p>Claimed for today. Next reward in <b data-countdown="${now + st.nextInMs}">${formatDuration(st.nextInMs)}</b></p>`}
        <small>Best streak: ${s.daily.bestStreak}. Rewards are based on calendar days in your timezone. Missing one day is forgiven; longer breaks halve the streak instead of resetting it.</small></div></div>
      <div class="dtrack">${days}</div>
      <h4 class="sec">TODAY</h4><div class="cards">${this.missionCard(dm, s.daily.missionDay === this.app.today() ? '<span class="done-tag">bonus claimed</span>' : '<span class="bonus">daily bonus</span>')}<div class="card mission daily" data-action="brief" data-id="${this.cacheMission(dc)}"><div class="mc-head"><img src="${icon('leaderboards')}"><div><h3>Daily Challenge</h3><small>Fixed seed · score attack</small></div></div><p>${esc(dc.brief)}</p><small>Best today: ${(s.daily.challengeBest[this.app.today()] || 0).toLocaleString()}</small></div></div>`;
  }

  // ------------------------------------------------------------- events
  tabEvents() {
    const s = this.save; const ev = this.app.activeEvents(); const now = this.app.nowDate();
    const active = ev.map(id => { const E = EVENTS[id]; const ends = eventEndsAt(id, now); return `<div class="event-banner" style="--a:${E.colors.a};--b:${E.colors.b};--bg:${E.colors.bg}"><img src="${icon(E.icon)}"><div><h3>${E.name}</h3><p class="tagline">${E.tagline}</p><p>${E.description}</p><small>Ends in <b data-countdown="${ends}">${formatDuration(ends - this.app.now())}</b> · Tokens: ${s.currencies.tokens}</small></div></div>`; }).join('');
    const up = upcomingEvents(now).filter(u => !u.active).map(u => `<div class="upc"><img src="${icon(EVENTS[u.id].icon)}"><b>${EVENTS[u.id].name}</b><small>${new Date(u.start).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</small></div>`).join('');
    return `<h2>EVENTS</h2><div class="scroll">${active || '<p class="hint">No seasonal event is running right now.</p>'}${ev.length ? `<h4 class="sec">EVENT MISSIONS</h4>${this._eventMissions()}<h4 class="sec">EVENT EXCHANGE</h4><button class="btn" data-action="sub" data-tab="shop" data-group="shop" data-sub="event">Open exchange</button>` : ''}<h4 class="sec">CALENDAR</h4><div class="upcoming">${up}<div class="upc"><img src="${icon('blackhole_blue')}"><b>Cosmic Anomaly</b><small>Rare · unannounced</small></div></div>
      ${this.app.dev.dev ? `<h4 class="sec">DEVELOPER OVERRIDE</h4><p class="hint">Dev mode is on (URL ?dev=1). Force an event with <code>&event=halloween</code>, or a date with <code>&date=2026-12-25</code>.</p>` : ''}</div>`;
  }

  // ------------------------------------------------------------- records
  tabRecords() {
    const s = this.save;
    const table = (rows, cols) => rows.length ? `<table><tr>${cols.map(c => `<th>${c[0]}</th>`).join('')}</tr>${rows.map((r, i) => `<tr><td>${i + 1}</td>${cols.slice(1).map(c => `<td>${c[1](r)}</td>`).join('')}</tr>`).join('')}</table>` : '<p class="hint">No runs recorded yet.</p>';
    const st = s.stats;
    return `<h2>RECORDS</h2><p class="hint">Leaderboards are personal and stored offline on this device. Global leaderboards would require a server, which this build intentionally does not depend on.</p>
      <div class="scroll records">
        <div class="rec-stats">${[['Missions won', st.missionsWon], ['Missions played', st.missionsPlayed], ['Enemies destroyed', st.kills], ['Bosses defeated', st.bossKills], ['Best combo', 'x' + st.bestCombo], ['Best endless wave', st.bestWave], ['High score', st.highScore.toLocaleString()], ['Flawless victories', st.flawless], ['Aces downed', st.aceKills], ['Time flown', Math.round(st.playTime / 60) + ' min'], ['Retreats', st.retreats], ['Discoveries', st.discoveries]].map(([k, v]) => `<div><b>${v}</b><small>${k}</small></div>`).join('')}</div>
        <h4 class="sec">ENDLESS FRONTIER</h4>${table(s.records.endless, [['#'], ['Score', r => (r.score || 0).toLocaleString()], ['Wave', r => r.wave], ['Ship', r => SHIPS[r.ship]?.name || ''], ['Date', r => new Date(r.date).toLocaleDateString()]])}
        <h4 class="sec">DAILY CHALLENGE</h4>${table(s.records.daily, [['#'], ['Score', r => (r.score || 0).toLocaleString()], ['Waves', r => r.wave], ['Date', r => new Date(r.date).toLocaleDateString()]])}
        <h4 class="sec">BOSS RUSH</h4>${table(s.records.bossrush, [['#'], ['Score', r => (r.score || 0).toLocaleString()], ['Ranks', r => r.rating || '-'], ['Difficulty', r => r.difficulty || ''], ['Time', r => Math.round(r.time) + 's']])}
        <h4 class="sec">EXPERIMENTAL ZONE</h4>${table(s.records.experimental, [['#'], ['Score', r => (r.score || 0).toLocaleString()], ['Waves', r => r.wave], ['Date', r => new Date(r.date).toLocaleDateString()]])}
      </div>`;
  }

  // ------------------------------------------------------------- settings
  tabSettings() { return `<h2>SETTINGS</h2><div class="scroll">${this.settingsHtml()}</div>`; }
  settingsHtml() {
    const st = this.save.settings;
    const range = (k, label, min, max, step) => `<label class="set"><span>${label}</span><input type="range" min="${min}" max="${max}" step="${step}" value="${st[k]}" data-set="${k}"><b>${k.includes('Volume') ? Math.round(st[k] * 100) + '%' : st[k]}</b></label>`;
    const sel = (k, label, opts) => `<label class="set"><span>${label}</span><select data-set="${k}">${opts.map(([v, l]) => `<option value="${v}" ${String(st[k]) === String(v) ? 'selected' : ''}>${l}</option>`).join('')}</select></label>`;
    const chk = (k, label) => `<label class="set"><span>${label}</span><input type="checkbox" data-set="${k}" ${st[k] ? 'checked' : ''}></label>`;
    const sm = this.app.saveManager;
    return `<div class="settings">
      <div><h4>AUDIO</h4>${range('masterVolume', 'Master volume', 0, 1, 0.05)}${range('musicVolume', 'Music', 0, 1, 0.05)}${range('sfxVolume', 'Effects', 0, 1, 0.05)}</div>
      <div><h4>GRAPHICS</h4>${sel('resolutionScale', 'Resolution scale', [[0.5, '50%'], [0.75, '75%'], [1, '100%'], [1.25, '125%'], [1.5, '150%']])}${sel('shadows', 'Shadows', [['off', 'Off'], ['low', 'Low'], ['high', 'High']])}${sel('particles', 'Particle density', [['low', 'Low'], ['medium', 'Medium'], ['high', 'High']])}${sel('effects', 'Effects quality (bloom)', [['low', 'Low (no bloom)'], ['medium', 'Medium'], ['high', 'High']])}${sel('renderDistance', 'Render distance', [['low', 'Low'], ['medium', 'Medium'], ['high', 'High']])}${sel('fpsCap', 'Frame rate cap', [[0, 'VSync (display rate)'], [30, '30'], [60, '60'], [120, '120']])}${chk('showFps', 'Show FPS')}${chk('autoQuality', 'Lower quality automatically when slow')}</div>
      <div><h4>GAMEPLAY</h4>${sel('difficulty', 'Difficulty', [['auto', `Auto (${DIFFICULTY[resolveDifficulty({})].name})`], ['relaxed', 'Relaxed'], ['standard', 'Standard'], ['ace', 'Ace']])}<p class="small diff-desc">${DIFFICULTY[resolveDifficulty(st)].desc}</p>${chk('cameraLean', 'Camera leans toward locked target')}<p class="small">Quick turn: double-tap dash, press <span class="key">V</span>, or tap FLIP.</p></div>
      <div><h4>CONTROLS</h4>${sel('mouseMode', 'Mouse steering', [['direct', 'Direct (self-centering)'], ['stick', 'Virtual joystick']])}${range('mouseSensitivity', 'Mouse sensitivity', 0.2, 3, 0.1)}${chk('invertY', 'Invert pitch')}${chk('aimAssist', 'Aim assist')}<p class="small">Gamepad: left stick thrust/strafe, right stick steer, RT fire, LT ordnance, A boost, B dash, Y ability, X target, RB swap, Start pause.</p></div>
      <div><h4>ACCESSIBILITY</h4>${chk('reduceShake', 'Reduce screen shake')}${chk('reduceFlashing', 'Reduce flashing')}${chk('damageNumbers', 'Damage numbers')}${chk('skipIntros', 'Skip boss intros')}</div>
      <div><h4>SAVE DATA</h4><p class="small">Save format v${this.save.version} · ${this.app.storageOk ? 'stored in this browser' : '<span class="warn">storage blocked — not persisting</span>'} · last write ${new Date(this.save.updatedAt).toLocaleString()}${sm.status.writeError ? ` · <span class="warn">${sm.status.writeError}</span>` : ''}</p>
        <div class="row"><button class="btn small" data-action="export-save">Export save</button><button class="btn small" data-action="import-save">Import save</button><button class="btn small" data-action="callsign">Change callsign</button></div>
        <div class="row"><button class="btn small danger" data-action="reset-save">Reset all progress…</button><button class="btn small" data-action="replay-tutorial">Replay tutorial tips</button></div></div>
    </div>`;
  }

  // ------------------------------------------------------------- pause / results
  showPause() {
    const p = this.root.querySelector('#pause');
    const g = this.app.game;
    p.innerHTML = `<div class="pause-box panel"><h2>PAUSED</h2><p class="small">${esc(g.mission?.title || '')} — ${esc(g.objective?.status().title || '')}</p>
      <div class="col"><button class="btn" data-action="resume">Resume</button><button class="btn" data-action="restart">Restart mission</button><button class="btn" data-action="pause-settings">Settings</button><button class="btn danger" data-action="abandon">Abandon mission</button></div>
      <div class="pause-help">${document.body.classList.contains('touch') ? '<span class="key">Left thumb</span> steer (drag anywhere on the left half) <span class="key">FIRE</span> primary <span class="key">MSL</span> ordnance (hold on a target to lock) <span class="key">BOOST</span> <span class="key">DASH</span> <span class="key">ABIL</span> ability <span class="key">THR/BRK</span> throttle <span class="key">TGT</span> target <span class="key">SWAP</span> weapon <span class="key">HOLD RETREAT</span> 3 s to retreat' : ''}<div class="kb-help"><span class="key">Mouse</span> steer <span class="key">W/S</span> throttle <span class="key">A/D</span> strafe <span class="key">Q/E</span> roll <span class="key">Shift</span> boost <span class="key">Space</span> dash <span class="key">F</span> ability <span class="key">T</span> target <span class="key">X</span> swap <span class="key">J</span> retreat</div></div>
      <div id="pause-settings" style="display:none">${this.settingsHtml()}</div></div>`;
    p.classList.add('on');
  }
  hidePause() { this.hide('pause'); }

  showResults(mission, result, summary, before) {
    this.hideAll();
    const s = this.save;
    const won = result.outcome === 'victory';
    const r = summary.reward;
    const lvlUp = s.profile.level > before.level;
    const opt = (mission.optional || []).map(o => `<div class="optres ${result.optionalDone.includes(o) ? 'ok' : ''}"><img src="${icon(result.optionalDone.includes(o) ? 'confirm' : 'cancel')}">${OPTIONAL_OBJECTIVES[o].name}</div>`).join('');
    const el = this.root.querySelector('#results');
    const title = won ? (mission.mode === 'endless' ? 'RUN COMPLETE' : 'MISSION COMPLETE') : result.outcome === 'retreat' ? 'TACTICAL RETREAT' : mission.mode === 'endless' ? 'RUN ENDED' : 'MISSION FAILED';
    el.innerHTML = `<div class="results panel ${won ? 'win' : 'lose'}">
      <h1>${title}</h1><p class="sub">${esc(mission.title)}${result.failReason && !won ? ' — ' + esc(result.failReason) : ''}</p>
      <div class="res-grid">
        <div class="res-stats">
          <div><b class="count" data-to="${result.score}">0</b><small>SCORE</small></div>
          <div><b>${result.kills}</b><small>KILLS</small></div>
          <div><b>x${result.bestCombo}</b><small>BEST COMBO</small></div>
          <div><b>${Math.floor(result.time / 60)}:${String(Math.floor(result.time % 60)).padStart(2, '0')}</b><small>TIME</small></div>
          ${result.wave ? `<div><b>${result.wave}</b><small>WAVES</small></div>` : ''}
          <div><b>${Math.round(result.hullDamage)}</b><small>HULL DAMAGE</small></div>
        </div>
        <div class="res-rew"><h4>REWARDS</h4>
          ${summary.breakdown.map(b => `<div class="bd"><span>${esc(b.label)}</span>${b.credits ? cur('credits', b.credits) : ''}${b.alloy ? cur('alloy', b.alloy) : ''}</div>`).join('')}
          <div class="total">${r.credits ? cur('credits', r.credits) : ''}${r.alloy ? cur('alloy', r.alloy) : ''}${r.cores ? cur('cores', r.cores) : ''}${r.tokens ? cur('tokens', r.tokens) : ''}<span class="cur">+${r.xp} XP</span></div>
          ${r.cosmetic ? `<div class="drop" style="--r:${RARITY[COSMETICS[r.cosmetic].rarity].color}"><img src="${icon(RARITY[COSMETICS[r.cosmetic].rarity].icon)}"><div><small>${RARITY[COSMETICS[r.cosmetic].rarity].label} drop</small><b>${COSMETICS[r.cosmetic].name}</b></div></div>` : ''}
          ${result.cosmeticFind ? `<div class="drop"><div><small>Rare find</small><b>${COSMETICS[result.cosmeticFind].name}</b></div></div>` : ''}
          ${opt ? `<h4>OPTIONAL</h4><div class="opts">${opt}</div>` : ''}
        </div>
        <div class="res-prog">
          <h4>PILOT</h4><div class="lvlrow"><div class="lvl">${s.profile.level}</div>${bar(s.profile.xp / xpForLevel(s.profile.level), 'xp')}</div>
          ${lvlUp ? `<div class="levelup">LEVEL UP! ${before.level} → ${s.profile.level}</div>` : ''}
          ${summary.achievements.map(a => `<div class="achpop"><img src="${icon(a.achievement.icon)}"><div><small>ACHIEVEMENT</small><b>${a.achievement.name}</b></div></div>`).join('')}
          ${summary.followUps.map(f => `<div class="followup"><img src="${icon('missions')}"><div><small>NEW SPECIAL CONTRACT</small><b>${esc(f.title)}</b><p>${esc(f.brief)}</p></div></div>`).join('')}
          ${result.discoveries?.length ? '<div class="followup"><img src="' + icon('emblem_prism') + '"><div><small>DISCOVERY</small><b>Lattice relic catalogued</b></div></div>' : ''}
        </div>
      </div>
      <div class="row center"><button class="btn" data-action="retry">${won ? 'Play again' : 'Retry'}</button><button class="btn launch" data-action="to-hangar">Return to Hangar</button></div>
    </div>`;
    this.show('results');
    const cnt = el.querySelector('.count');
    const to = +cnt.dataset.to; const t0 = performance.now();
    const step = () => { const k = Math.min(1, (performance.now() - t0) / 1200); cnt.textContent = Math.round(to * (1 - Math.pow(1 - k, 3))).toLocaleString(); if (k < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
    if (lvlUp) setTimeout(() => this.app.audio.play('levelup'), 700);
    if (summary.achievements.length) setTimeout(() => this.app.audio.play('achievement'), 1300);
    this.app.audio.music?.setMode('menu');
    this.app.menu.active = true; this.app.menu.setMode('hangar');
    this.app.menu.setRegion(this.app._menuRegion(), this.app.activeEvents()[0] || null);
    this._modelKey = null; this._restoreHangarModel();
    this.app.renderer.setScene(this.app.menu.scene);
  }

  // ------------------------------------------------------------- events
  _click(e) {
    const t = e.target.closest('[data-action]');
    if (!t) return;
    const a = t.dataset.action;
    const s = this.save, app = this.app;
    const audio = app.audio;
    if (t.disabled) return;
    const changed = () => { app.persist(); this.refreshTop(); this.renderTab(); };
    const achCheck = () => { const got = checkAchievements(s, app.now()); for (const x of got) { this.toast(`Achievement unlocked: ${x.achievement.name}`, 'good', 4); audio.play('achievement'); } };
    switch (a) {
      case 'title-play': audio.play('click'); app.toHangar('missions'); break;
      case 'title-campaign': audio.play('click'); this.sub.missions = 'campaign'; app.toHangar('missions'); break;
      case 'title-endless': audio.play('click'); this.sub.missions = 'modes'; app.toHangar('missions'); break;
      case 'title-bossrush': audio.play('click'); this.sub.missions = 'modes'; app.toHangar('missions'); break;
      case 'title-daily': audio.play('click'); app.toHangar('daily'); break;
      case 'title-events': audio.play('click'); app.toHangar('events'); break;
      case 'title-settings': audio.play('click'); app.toHangar('settings'); break;
      case 'title-tutorial': audio.play('click'); s.settings.tutorialSeen = false; app.launchMission(this._tutorialMission()); break;
      case 'title-exit': audio.play('back'); this.confirm('Exit Starfall?', 'Your progress is saved automatically. You can close this tab at any time.', () => { this.root.querySelector('#title').innerHTML = '<div class="goodbye"><h1>SEE YOU, PILOT</h1><p>Progress saved. Close the tab, or click to return.</p></div>'; this.root.querySelector('.goodbye').addEventListener('click', () => this.showTitle()); try { window.close(); } catch (er) { /* browsers block this */ } }, 'Exit'); break;
      case 'tab':
        audio.play('click');
        if (t.dataset.tab === 'exit') { app.toTitle(); break; }
        this.tab = t.dataset.tab; this.selected = {}; this.previewShip = null;
        if (app.state !== 'hangar') app.toHangar(this.tab); else this.renderTab();
        break;
      case 'sub':
        audio.play('click');
        this.sub[t.dataset.group || t.dataset.tab] = t.dataset.sub;
        this.tab = t.dataset.tab;
        if (app.state !== 'hangar') app.toHangar(this.tab); else this.renderTab();
        break;
      case 'brief': { const m = this.missionCache.get(t.dataset.id); if (m) this.openBriefing(m); break; }
      case 'brief-campaign': this.openBriefing(campaignMission(+t.dataset.idx, s, app.activeEvents())); break;
      case 'close-brief': audio.play('back'); this.hide('briefing'); break;
      case 'brief-loadout': this.hide('briefing'); this.tab = 'ships'; this.previewShip = null; this.renderTab(); break;
      case 'launch': { const m = this.missionCache.get(t.dataset.id); if (m) { audio.play('gate'); app.launchMission(m); } break; }
      case 'launch-endless': audio.play('gate'); app.launchMission(endlessMission(Date.now())); break;
      case 'launch-experimental': audio.play('gate'); app.launchMission(experimentalMission(Date.now())); break;
      case 'launch-bossrush': audio.play('gate'); app.launchMission(bossRushMission(s, t.dataset.diff)); break;
      case 'refresh-contracts': if (s.currencies.credits >= 100) { s.currencies.credits -= 100; s.universe.contracts.refreshes++; s.universe.contracts.list = generateContracts(s, app.today(), app.activeEvents()); audio.play('buy'); changed(); } break;
      case 'preview-ship': audio.play('click'); this.previewShip = t.dataset.id; this._restoreHangarModel(); this.renderTab(); break;
      case 'select-ship': audio.play('equip'); s.ships.selected = t.dataset.id; this.previewShip = null; changed(); break;
      case 'buy-ship': { const r = buyShip(s, t.dataset.id); if (r.ok) { audio.play('buy'); s.ships.selected = t.dataset.id; this.toast(`${SHIPS[t.dataset.id].name} constructed!`, 'good'); achCheck(); } else { audio.play('error'); this.toast(r.reason, 'warn'); } changed(); break; }
      case 'loadout': { if (setLoadout(s, t.dataset.ship, t.dataset.slot, t.dataset.val, +t.dataset.idx)) audio.play('equip'); changed(); break; }
      case 'buy-item': { const r = buyItem(s, t.dataset.kind, t.dataset.id); if (r.ok) { audio.play('buy'); this.toast('Purchased — equip it from the Ships tab.', 'good'); } else { audio.play('error'); this.toast(r.reason, 'warn'); } changed(); break; }
      case 'buy-upgrade': { const r = buyUpgrade(s, t.dataset.id); if (r.ok) { audio.play('buy'); this.toast(`${UPGRADE_BRANCHES[t.dataset.id].name} upgraded to tier ${r.tier}`, 'good'); achCheck(); } else { audio.play('error'); this.toast(r.reason, 'warn'); } changed(); break; }
      case 'buy-mod': { const r = buyMod(s, t.dataset.id); if (r.ok) { audio.play('buy'); this.toast(`${MODS[t.dataset.id].name} installed`, 'good'); } else { audio.play('error'); this.toast(r.reason, 'warn'); } changed(); break; }
      case 'equip-mod': equipMod(s, t.dataset.id); audio.play('equip'); changed(); break;
      case 'cust-type': audio.play('click'); this.custType = t.dataset.type; this.renderTab(); break;
      case 'equip-cos': equipCosmetic(s, s.ships.selected, t.dataset.id); audio.play('equip'); changed(); break;
      case 'cos-info': { const c = COSMETICS[t.dataset.id]; audio.play('error'); this.toast(`${c.name}: ${sourceText(c)}`, 'info'); break; }
      case 'buy-cos': { const r = buyCosmetic(s, t.dataset.id); if (r.ok) { audio.play('buy'); this.toast(`${COSMETICS[t.dataset.id].name} unlocked — equip it in Customize`, 'good'); achCheck(); } else { audio.play('error'); this.toast(r.reason, 'warn'); } changed(); break; }
      case 'inspect': {
        audio.play('click');
        const k = t.dataset.kind, id = t.dataset.id;
        if (k === 'ship') { this._modelKey = null; app.menu.showShip(id, s.cosmetics.equipped[id]); }
        if (k === 'unit') { this.selected.unit = id; app.menu.showUnit(id, FACTIONS.dominion.roster.includes(id) ? 'dominion' : 'vrell'); this._modelKey = null; this.renderTabKeepModel(); }
        if (k === 'boss') { this.selected.boss = id; app.menu.showBoss(id); this._modelKey = null; this.renderTabKeepModel(); }
        break;
      }
      case 'claim-daily': {
        const r = claimDaily(s, app.now());
        if (!r) { audio.play('error'); break; }
        const lines = grant(s, r);
        audio.play('claim');
        this.toast(`Day ${r.day} reward claimed!${r.cosmetic ? ' New cosmetic: ' + COSMETICS[r.cosmetic].name : ''}`, 'good', 4);
        achCheck(); changed(); break;
      }
      case 'export-save': { const str = app.saveManager.exportString(); this.confirm('Export save', `<textarea class="savebox" readonly>${str}</textarea><br><small>Copy this text to back up or move your progress.</small>`, () => {}, 'Done'); setTimeout(() => this.root.querySelector('.savebox')?.select(), 50); break; }
      case 'import-save': this.confirm('Import save', '<textarea class="savebox" id="importbox" placeholder="Paste exported save here"></textarea><br><small>This replaces your current progress.</small>', () => { const v = this.root.querySelector('#importbox')?.value || ''; try { const issues = app.saveManager.importString(v); this.toast(`Save imported${issues.length ? ` (${issues.length} fields repaired)` : ''}`, 'good'); app.renderer.applySettings(s); this.showHangar('settings'); } catch (er) { this.toast('Import failed: invalid save data', 'warn'); } }, 'Import'); break;
      case 'callsign': this.confirm('Callsign', `<input class="savebox" id="csbox" maxlength="20" value="${esc(s.profile.callsign)}">`, () => { const v = (this.root.querySelector('#csbox')?.value || '').trim().slice(0, 20); if (v) { s.profile.callsign = v; changed(); this.showHangar('settings'); } }, 'Save'); break;
      case 'reset-save': this.confirm('Reset ALL progress?', 'This permanently deletes your level, currencies, ships, cosmetics, achievements and records. Settings are kept. This cannot be undone.', () => this.confirm('Are you absolutely sure?', 'Last chance — your pilot record will be erased.', () => { app.saveManager.reset(); this._modelKey = null; this.toast('Progress reset. Welcome, new pilot.', 'info'); app.toTitle(); }, 'Erase everything'), 'Reset'); break;
      case 'replay-tutorial': s.settings.tutorialSeen = false; app.persist(); this.toast('Control tips will show in your next mission.', 'info'); break;
      case 'modal-yes': { const m = this.root.querySelector('#modal'); const fn = this._modalYes; m.classList.remove('on'); audio.play('click'); fn && fn(); break; }
      case 'modal-no': this.root.querySelector('#modal').classList.remove('on'); audio.play('back'); break;
      case 'resume': app.pause(false); break;
      case 'restart': audio.play('click'); this.hidePause(); app.restartMission(); break;
      case 'abandon': this.confirm('Abandon mission?', 'You will return to the hangar with no rewards.', () => { this.hidePause(); app.abandonMission(); }, 'Abandon'); break;
      case 'pause-settings': { const p = this.root.querySelector('#pause-settings'); p.style.display = p.style.display === 'none' ? '' : 'none'; break; }
      case 'retry': audio.play('click'); this.hide('results'); app.restartMission(); break;
      case 'to-hangar': audio.play('click'); this.hide('results'); app.toHangar('missions'); break;
    }
  }

  renderTabKeepModel() {
    const c = this.root.querySelector('#content');
    const sc = c.querySelector('.scroll')?.scrollTop || 0;
    c.innerHTML = this.tabCollection();
    const s2 = c.querySelector('.scroll'); if (s2) s2.scrollTop = sc;
  }

  _input(e) {
    const t = e.target;
    const k = t.dataset.set;
    if (!k) return;
    const st = this.save.settings;
    let v;
    if (t.type === 'checkbox') v = t.checked;
    else if (t.type === 'range') v = parseFloat(t.value);
    else v = isNaN(+t.value) ? t.value : +t.value;
    st[k] = v;
    const out = t.parentElement.querySelector('b'); if (out) out.textContent = k.includes('Volume') ? Math.round(v * 100) + '%' : v;
    const app = this.app;
    app.audio.setVolumes(st);
    app.input.sensitivity = st.mouseSensitivity; app.input.invertY = st.invertY; app.input.mode = st.mouseMode;
    if (k === 'difficulty') {
      if (app.game.active) app.game.tune = tuning(st); // aim assist and attacker limits apply at once; damage balance from the next mission
      for (const dd of this.root.querySelectorAll('.diff-desc')) dd.textContent = DIFFICULTY[resolveDifficulty(st)].desc;
    }
    if (e.type === 'change' && ['resolutionScale', 'shadows', 'effects', 'renderDistance'].includes(k)) {
      app.renderer.applySettings(st);
      if (k === 'renderDistance' || k === 'shadows') { app.menu.region = null; app.menu.setRegion(app._menuRegion(), app.activeEvents()[0] || null); }
    }
    if (e.type === 'change' && k === 'particles') { app.menu.region = null; app.menu.setRegion(app._menuRegion(), app.activeEvents()[0] || null); }
    if (app.game.active && app.game.effects) app.game.effects.setQuality(st);
    app.persist();
  }

  _tutorialMission() {
    return {
      id: 'tutorial', seed: 'tutorial', mode: 'tutorial', title: 'Flight School', brief: 'Learn to fly. Destroy the training drones.',
      region: 'belt', objective: 'tutorial', faction: 'dominion', altFaction: null, difficulty: 0.7, tier: 1, modifiers: [], optional: [],
      elite: null, event: null, variantPool: [], surprise: null, boss: null, waves: 3, parTime: 300, rewardMult: 0.5, mutators: [],
      rewards: { credits: 150, alloy: 2, xp: 120, cores: 0 },
    };
  }
}

// ---------------------------------------------------------------- helpers
function imgBtn(img, action, label, extra = '') { return `<button class="imgbtn" data-action="${action}" title="${label}"><img src="assets/buttons/${img}.png" alt="${label}">${extra}</button>`; }
function cosSwatch(c) {
  if (c.type === 'paint') return `<div class="sw paint" style="--p:${c.primary};--s:${c.secondary}"></div>`;
  if (c.type === 'engine') return `<div class="sw engine" style="--p:${c.color}"></div>`;
  if (c.type === 'emblem') return c.emblem ? `<img class="sw" src="assets/icons/${c.emblem}.png">` : '<div class="sw none"></div>';
  if (c.type === 'weapon') return `<div class="sw engine" style="--p:${c.tint || '#5fe3ff'}"></div>`;
  if (c.type === 'trail') return `<div class="sw trail t-${c.trail}"></div>`;
  return `<div class="sw pattern p-${c.pattern}"></div>`;
}
function sourceText(c) {
  return { shop: 'Shop', achievement: 'Achievement reward', daily: 'Daily streak reward', drop: 'Rare drop (bosses, caches)', event: `${EVENTS[c.event]?.name || 'Event'} exchange`, default: 'Default' }[c.source] || c.source;
}
function compareStat(branch, a, b) {
  const f = (x, d = 0) => (Math.round(x * Math.pow(10, d)) / Math.pow(10, d)).toString();
  switch (branch) {
    case 'hull': return `Hull <b>${a.hull}</b> → <b class="pos">${b.hull}</b>`;
    case 'shield': return `Shield <b>${a.shield}</b> → <b class="pos">${b.shield}</b>, recharge ${f(a.shieldRegen, 1)} → <b class="pos">${f(b.shieldRegen, 1)}</b>/s`;
    case 'engine': return `Speed <b>${f(a.speed)}</b> → <b class="pos">${f(b.speed)}</b>, boost ${f(a.boostMax)} → <b class="pos">${f(b.boostMax)}</b>`;
    case 'damage': return `Damage <b>${pct(a.damage)}</b> → <b class="pos">${pct(b.damage)}</b>`;
    case 'firerate': return `Fire rate <b>${pct(a.fireRate)}</b> → <b class="pos">${pct(b.fireRate)}</b>`;
    case 'crit': return `Crit chance <b>${pct(a.crit)}</b> → <b class="pos">${pct(b.crit)}</b>`;
    case 'missiles': return `Ordnance capacity <b>${pct(a.ammo)}</b> → <b class="pos">${pct(b.ammo)}</b>`;
    case 'energy': return `Cooling <b>${f(a.cooling)}</b> → <b class="pos">${f(b.cooling)}</b>/s, boost regen ${f(a.boostRegen)} → <b class="pos">${f(b.boostRegen)}</b>`;
    case 'ability': return `Cooldown <b>${pct(a.abilityCd)}</b> → <b class="pos">${pct(b.abilityCd)}</b>, power ${pct(a.abilityPower)} → <b class="pos">${pct(b.abilityPower)}</b>`;
    case 'loot': return `Pickup radius <b>${f(a.lootRadius)}m</b> → <b class="pos">${f(b.lootRadius)}m</b>`;
  }
  return '';
}
