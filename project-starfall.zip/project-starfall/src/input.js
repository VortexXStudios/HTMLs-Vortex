// ============================================================================
// Keyboard / mouse / gamepad input with a virtual flight stick.
// ============================================================================
export const BINDINGS = {
  thrust: ['KeyW', 'ArrowUp'],
  brake: ['KeyS', 'ArrowDown'],
  left: ['KeyA', 'ArrowLeft'],
  right: ['KeyD', 'ArrowRight'],
  rollL: ['KeyQ'],
  rollR: ['KeyE'],
  boost: ['ShiftLeft', 'ShiftRight'],
  dash: ['Space'],
  flip: ['KeyV'],
  ability: ['KeyF'],
  secondary: ['KeyR'],
  target: ['KeyT', 'Tab'],
  swap: ['KeyX', 'Digit1', 'Digit2'],
  interact: ['KeyG'],
  retreat: ['KeyJ'],
  pause: ['Escape', 'KeyP'],
  choice1: ['Digit1', 'Numpad1'], choice2: ['Digit2', 'Numpad2'], choice3: ['Digit3', 'Numpad3'],
  skip: ['Enter', 'Space'],
};

export class Input {
  constructor(canvas) {
    this.canvas = canvas;
    this.down = new Set();
    this.pressedThisFrame = new Set();
    this.mouse = { x: 0, y: 0, nx: 0, ny: 0, left: false, right: false, middle: false, leftPressed: false, rightPressed: false };
    this.stick = { x: 0, y: 0 }; // virtual stick -1..1
    this.locked = false;
    this.sensitivity = 1;
    this.mode = 'direct'; // 'direct' (mouse motion turns the ship, self-centering) or 'stick' (virtual joystick)
    this.invertY = false;
    this.enabled = true;
    this.gamepad = null;
    this.usingGamepad = false;
    this._gpPrev = {};
    this._listeners = [];
    const on = (t, ev, fn, opt) => { t.addEventListener(ev, fn, opt); this._listeners.push([t, ev, fn, opt]); };
    on(window, 'keydown', e => {
      if (e.repeat) return;
      if (['Tab', 'Space', 'ArrowUp', 'ArrowDown'].includes(e.code) && this.enabled && document.activeElement === document.body) e.preventDefault();
      this.down.add(e.code); this.pressedThisFrame.add(e.code); this.usingGamepad = false;
    });
    on(window, 'keyup', e => this.down.delete(e.code));
    on(window, 'blur', () => { this.down.clear(); this.mouse.left = this.mouse.right = false; });
    on(window, 'mousemove', e => {
      // browsers emulate mouse events after touches; the touch stick owns steering then
      if (this.touchSteer || performance.now() - (this.lastTouch || -1e9) < 900) return;
      this.mouse.x = e.clientX; this.mouse.y = e.clientY;
      if (this.locked) {
        const k = (this.mode === 'direct' ? 0.006 : 0.0022) * this.sensitivity;
        this.stick.x = clamp(this.stick.x + e.movementX * k, -1, 1);
        this.stick.y = clamp(this.stick.y + e.movementY * k * (this.invertY ? -1 : 1), -1, 1);
        const len = Math.hypot(this.stick.x, this.stick.y);
        if (len > 1) { this.stick.x /= len; this.stick.y /= len; }
      } else {
        const w = window.innerWidth, h = window.innerHeight, s = Math.min(w, h) * 0.42 / this.sensitivity;
        this.stick.x = clamp((e.clientX - w / 2) / s, -1, 1);
        this.stick.y = clamp((e.clientY - h / 2) / s * (this.invertY ? -1 : 1), -1, 1);
      }
      this.usingGamepad = false;
    });
    on(canvas, 'mousedown', e => {
      if (performance.now() - (this.lastTouch || -1e9) < 900) { if (e.button === 0) this.mouse.leftPressed = true; return; } // a tap still skips cutscenes
      if (e.button === 0) { this.mouse.left = true; this.mouse.leftPressed = true; }
      if (e.button === 2) { this.mouse.right = true; this.mouse.rightPressed = true; }
      if (e.button === 1) this.mouse.middle = true;
    });
    on(window, 'mouseup', e => {
      if (e.button === 0) this.mouse.left = false;
      if (e.button === 2) this.mouse.right = false;
      if (e.button === 1) this.mouse.middle = false;
    });
    on(canvas, 'contextmenu', e => e.preventDefault());
    on(document, 'pointerlockchange', () => { this.locked = document.pointerLockElement === canvas; if (this.locked) { this.stick.x = 0; this.stick.y = 0; } });
    on(window, 'gamepadconnected', e => { this.gamepad = e.gamepad.index; });
    on(window, 'gamepaddisconnected', () => { this.gamepad = null; });
  }

  requestLock() {
    if (this.locked || !this.canvas.requestPointerLock || document.body.classList.contains('touch')) return;
    try { const p = this.canvas.requestPointerLock(); if (p && p.catch) p.catch(() => {}); } catch (e) { /* not allowed */ }
  }
  exitLock() { if (document.pointerLockElement) document.exitPointerLock(); }

  _pollGamepad() {
    if (this.gamepad == null || !navigator.getGamepads) return null;
    const gp = navigator.getGamepads()[this.gamepad];
    if (!gp) return null;
    const dz = v => (Math.abs(v) < 0.15 ? 0 : v);
    const b = i => !!(gp.buttons[i] && gp.buttons[i].pressed);
    const st = {
      lx: dz(gp.axes[0] || 0), ly: dz(gp.axes[1] || 0), rx: dz(gp.axes[2] || 0), ry: dz(gp.axes[3] || 0),
      fire: (gp.buttons[7]?.value || 0) > 0.3, secondary: (gp.buttons[6]?.value || 0) > 0.3,
      boost: b(10) || b(0), dash: b(1), ability: b(3), target: b(2), swap: b(5), rollL: b(4), rollR: b(5) && false, pause: b(9), interact: b(12), flip: b(11),
    };
    if (st.lx || st.ly || st.rx || st.ry || st.fire || st.boost) this.usingGamepad = true;
    // edge detection
    st.pressed = {};
    for (const k of ['dash', 'ability', 'target', 'swap', 'pause', 'secondary', 'interact', 'flip']) { st.pressed[k] = st[k] && !this._gpPrev[k]; this._gpPrev[k] = st[k]; }
    return st;
  }

  // Called once per frame by the game
  sample(dt = 1 / 60) {
    if (this.locked && this.mode === 'direct' && !this.usingGamepad) {
      const k = Math.exp(-dt * 7);
      this.stick.x *= k; this.stick.y *= k;
    }
    const gp = this._pollGamepad();
    this.gp = gp;
    if (gp && this.usingGamepad) { this.stick.x = gp.rx || gp.lx * 0; this.stick.y = gp.ry * (this.invertY ? -1 : 1); }
    return gp;
  }

  isDown(action) {
    if (!this.enabled) return false;
    const gp = this.gp;
    if (gp && this.usingGamepad) {
      if (action === 'fire' && gp.fire) return true;
      if (action === 'secondary' && gp.secondary) return true;
      if (action === 'boost' && gp.boost) return true;
      if (action === 'thrust' && gp.ly < -0.3) return true;
      if (action === 'brake' && gp.ly > 0.3) return true;
      if (action === 'left' && gp.lx < -0.3) return true;
      if (action === 'right' && gp.lx > 0.3) return true;
      if (action === 'rollL' && gp.rollL) return true;
    }
    if (action === 'fire') return this.mouse.left;
    if (action === 'secondary') return this.mouse.right || this.down.has('KeyR');
    return (BINDINGS[action] || []).some(k => this.down.has(k));
  }

  pressed(action) {
    if (!this.enabled) return false;
    const gp = this.gp;
    if (gp && gp.pressed && gp.pressed[action]) return true;
    if (action === 'fire') return this.mouse.leftPressed;
    if (action === 'secondary') return this.mouse.rightPressed || this.pressedThisFrame.has('KeyR');
    return (BINDINGS[action] || []).some(k => this.pressedThisFrame.has(k));
  }
  pressedCode(code) { return this.pressedThisFrame.has(code); }

  endFrame() { this.pressedThisFrame.clear(); this.mouse.leftPressed = false; this.mouse.rightPressed = false; }

  dispose() { for (const [t, ev, fn, opt] of this._listeners) t.removeEventListener(ev, fn, opt); this._listeners = []; }
}

function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
