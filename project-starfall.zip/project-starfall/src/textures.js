// Procedural canvas textures (planets, sprites, nebula puffs, decals)
import * as THREE from 'three';

// --- small value-noise implementation for CPU textures ---
function hash2(x, y, s) {
  let h = (x * 374761393 + y * 668265263 + s * 2147483647) | 0;
  h = (h ^ (h >>> 13)) * 1274126177 | 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
}
function smooth(t) { return t * t * (3 - 2 * t); }
export function vnoise(x, y, seed = 0) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const a = hash2(xi, yi, seed), b = hash2(xi + 1, yi, seed), c = hash2(xi, yi + 1, seed), d = hash2(xi + 1, yi + 1, seed);
  const u = smooth(xf), v = smooth(yf);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
export function fbm(x, y, oct = 5, seed = 0) {
  let s = 0, a = 0.5, f = 1;
  for (let i = 0; i < oct; i++) { s += a * vnoise(x * f, y * f, seed + i * 17); f *= 2; a *= 0.5; }
  return s;
}
// tileable horizontally (for equirect planet textures)
function fbmWrap(u, v, scale, oct, seed) {
  const ang = u * Math.PI * 2;
  const r = scale / (Math.PI * 2);
  const x = Math.cos(ang) * r, z = Math.sin(ang) * r;
  return (fbm(x + 50, v * scale * 0.5 + 10, oct, seed) + fbm(z + 90, v * scale * 0.5 + 30, oct, seed + 3)) * 0.5;
}

const cache = new Map();
function cached(key, fn) { if (!cache.has(key)) cache.set(key, fn()); return cache.get(key); }

function lerpC(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
function hexRgb(hex) { const c = new THREE.Color(hex); return [c.r * 255, c.g * 255, c.b * 255]; }

export function planetTexture(def, seed = 1, size = 256) {
  return cached(`planet-${def.color}-${def.lava}-${def.clouds}-${seed}`, () => {
    const w = size * 2, h = size;
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    const ctx = cv.getContext('2d');
    const img = ctx.createImageData(w, h);
    const base = hexRgb(def.color);
    const dark = base.map(v => v * 0.35);
    const light = base.map(v => Math.min(255, v * 1.4 + 30));
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const u = x / w, v = y / h;
        let n = fbmWrap(u, v, 8, 5, seed);
        let col;
        if (def.lava) {
          const cracks = Math.abs(fbmWrap(u, v, 14, 4, seed + 9) - 0.5);
          const glow = Math.max(0, 1 - cracks * 14);
          col = lerpC([30, 10, 8], [70, 30, 22], n);
          col = lerpC(col, [255, 140, 40], glow * 0.95);
        } else if (def.clouds) {
          const land = n > 0.52;
          col = land ? lerpC([60, 110, 60], [150, 130, 90], (n - 0.52) * 4) : lerpC([10, 40, 90], [30, 80, 150], n);
          const cl = fbmWrap(u + 0.3, v, 10, 5, seed + 5);
          col = lerpC(col, [240, 245, 255], Math.max(0, (cl - 0.55) * 2.5));
        } else {
          const band = Math.sin(v * 22 + n * 6) * 0.5 + 0.5;
          col = lerpC(dark, light, n * 0.7 + band * 0.3);
        }
        const i = (y * w + x) * 4;
        img.data[i] = col[0]; img.data[i + 1] = col[1]; img.data[i + 2] = col[2]; img.data[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    const t = new THREE.CanvasTexture(cv);
    t.colorSpace = THREE.SRGBColorSpace;
    t.wrapS = THREE.RepeatWrapping;
    return t;
  });
}

export function glowSprite(color = '#ffffff', key = 'glow') {
  return cached(`glow-${key}-${color}`, () => {
    const s = 128; const cv = document.createElement('canvas'); cv.width = cv.height = s;
    const ctx = cv.getContext('2d');
    const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    g.addColorStop(0, 'rgba(255,255,255,1)');
    g.addColorStop(0.15, color);
    g.addColorStop(0.5, color.length === 7 ? color + '44' : color);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, s, s);
    const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t;
  });
}

export function galaxyTexture(seed = 1, tint = '#b8a0ff') {
  return cached(`galaxy-${seed}-${tint}`, () => {
    const s = 256; const cv = document.createElement('canvas'); cv.width = cv.height = s;
    const ctx = cv.getContext('2d');
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, s, s);
    ctx.globalCompositeOperation = 'lighter';
    const c = new THREE.Color(tint);
    const arms = 2 + (seed % 3);
    for (let i = 0; i < 2600; i++) {
      const t = Math.random();
      const arm = Math.floor(Math.random() * arms);
      const ang = t * 6 + arm * (Math.PI * 2 / arms) + (Math.random() - 0.5) * 0.6 * (1 - t);
      const r = t * s * 0.45;
      const x = s / 2 + Math.cos(ang) * r, y = s / 2 + Math.sin(ang) * r * 0.55;
      const a = (1 - t) * 0.35;
      ctx.fillStyle = `rgba(${(c.r * 200 + 55) | 0},${(c.g * 200 + 55) | 0},${(c.b * 200 + 55) | 0},${a})`;
      ctx.fillRect(x, y, 1.5, 1.5);
    }
    const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s * 0.15);
    g.addColorStop(0, 'rgba(255,240,220,0.9)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, s, s);
    const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t;
  });
}

export function cloudPuffTexture() {
  return cached('puff', () => {
    const s = 128; const cv = document.createElement('canvas'); cv.width = cv.height = s;
    const ctx = cv.getContext('2d'); const img = ctx.createImageData(s, s);
    for (let y = 0; y < s; y++) for (let x = 0; x < s; x++) {
      const dx = x / s - 0.5, dy = y / s - 0.5; const d = Math.sqrt(dx * dx + dy * dy) * 2;
      const n = fbm(x / 24, y / 24, 4, 7);
      const a = Math.max(0, (1 - d) * (n * 1.4 - 0.2));
      const i = (y * s + x) * 4; img.data[i] = img.data[i + 1] = img.data[i + 2] = 255; img.data[i + 3] = Math.min(255, a * 255);
    }
    ctx.putImageData(img, 0, 0);
    const t = new THREE.CanvasTexture(cv); return t;
  });
}

// Wing pattern decal texture (alpha mask) — drawn in accent colour on the ship.
export function patternTexture(pattern) {
  return cached('pattern-' + pattern, () => {
    const s = 256; const cv = document.createElement('canvas'); cv.width = cv.height = s;
    const ctx = cv.getContext('2d'); ctx.clearRect(0, 0, s, s); ctx.fillStyle = '#fff'; ctx.strokeStyle = '#fff';
    switch (pattern) {
      case 'stripes': ctx.fillRect(0, 70, s, 26); ctx.fillRect(0, 150, s, 26); break;
      case 'chevron': for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(0, 40 + k * 60); ctx.lineTo(s / 2, 80 + k * 60); ctx.lineTo(s, 40 + k * 60); ctx.lineTo(s, 64 + k * 60); ctx.lineTo(s / 2, 104 + k * 60); ctx.lineTo(0, 64 + k * 60); ctx.fill(); } break;
      case 'split': ctx.fillRect(0, 0, s, s / 2); break;
      case 'hazard': for (let k = -s; k < s * 2; k += 48) { ctx.beginPath(); ctx.moveTo(k, 0); ctx.lineTo(k + 24, 0); ctx.lineTo(k + 24 - s, s); ctx.lineTo(k - s, s); ctx.fill(); } break;
      case 'tiger': for (let k = 0; k < 9; k++) { ctx.beginPath(); const y = 20 + k * 27; ctx.moveTo(0, y); ctx.quadraticCurveTo(s * 0.4, y - 18, s * 0.75, y + 6); ctx.lineTo(s * 0.7, y + 14); ctx.quadraticCurveTo(s * 0.35, y + 2, 0, y + 12); ctx.fill(); } break;
      case 'web': ctx.lineWidth = 4; for (let k = 0; k < 8; k++) { const a = k / 8 * Math.PI * 2; ctx.beginPath(); ctx.moveTo(s / 2, s / 2); ctx.lineTo(s / 2 + Math.cos(a) * s, s / 2 + Math.sin(a) * s); ctx.stroke(); } for (let r = 20; r < s; r += 28) { ctx.beginPath(); ctx.arc(s / 2, s / 2, r, 0, Math.PI * 2); ctx.stroke(); } break;
      default: break;
    }
    const t = new THREE.CanvasTexture(cv); return t;
  });
}

// Load an icon image as a texture (for emblems). Cached.
const loader = new THREE.TextureLoader();
export function iconTexture(name) {
  return cached('icon-' + name, () => {
    const t = loader.load(`assets/icons/${name}.png`);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  });
}

// Emblem decal: icon with its dark tile background keyed out to transparency.
export function iconDecalTexture(name) {
  return cached('decal-' + name, () => {
    const s = 128; const cv = document.createElement('canvas'); cv.width = cv.height = s;
    const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace;
    const img = new Image();
    img.onload = () => {
      const ctx = cv.getContext('2d');
      ctx.drawImage(img, 0, 0, s, s);
      const d = ctx.getImageData(0, 0, s, s);
      for (let i = 0; i < d.data.length; i += 4) {
        const mx = Math.max(d.data[i], d.data[i + 1], d.data[i + 2]);
        const mn = Math.min(d.data[i], d.data[i + 1], d.data[i + 2]);
        const k = Math.max(0, Math.min(1, (mx - 70) / 70 + (mx - mn) / 160));
        const x = (i / 4) % s, y = Math.floor(i / 4 / s);
        const edge = Math.min(x, y, s - 1 - x, s - 1 - y) < 10 ? 0 : 1; // drop tile border
        d.data[i + 3] = Math.round(k * edge * 255);
      }
      ctx.putImageData(d, 0, 0);
      t.needsUpdate = true;
    };
    img.src = `assets/icons/${name}.png`;
    return t;
  });
}

export function hexTexture() {
  return cached('hex', () => {
    const s = 256; const cv = document.createElement('canvas'); cv.width = cv.height = s;
    const ctx = cv.getContext('2d'); ctx.clearRect(0, 0, s, s); ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 3;
    const r = 18; const hh = Math.sqrt(3) * r;
    for (let y = -1; y < s / hh + 1; y++) for (let x = -1; x < s / (r * 1.5) + 1; x++) {
      const cx = x * r * 1.5, cy = y * hh + (x % 2 ? hh / 2 : 0);
      ctx.beginPath(); for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); } ctx.closePath(); ctx.stroke();
    }
    const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(4, 2); return t;
  });
}

export function panelTexture() {
  // greebled hull panel normal-ish detail used as roughness/bump map
  return cached('panel', () => {
    const s = 256; const cv = document.createElement('canvas'); cv.width = cv.height = s;
    const ctx = cv.getContext('2d'); ctx.fillStyle = '#808080'; ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 70; i++) {
      const w = 10 + Math.random() * 70, h = 6 + Math.random() * 40, x = Math.random() * s, y = Math.random() * s;
      const g = 100 + Math.random() * 80;
      ctx.fillStyle = `rgb(${g},${g},${g})`; ctx.fillRect(x, y, w, h);
      ctx.strokeStyle = 'rgba(30,30,30,0.9)'; ctx.lineWidth = 1.5; ctx.strokeRect(x, y, w, h);
    }
    for (let i = 0; i < 40; i++) { ctx.fillStyle = 'rgba(40,40,40,0.8)'; ctx.fillRect(Math.random() * s, Math.random() * s, 3, 3); }
    const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
  });
}
