// ============================================================================
// PROJECT STARFALL — static game definitions (no Three.js dependency)
// Everything here is plain data so it can be unit-tested in Node.
// ============================================================================

export const SAVE_VERSION = 3;
export const GAME_VERSION = '1.0.0';

export const RARITY = {
  common:    { label: 'Common',    color: '#b9c3cf', icon: 'rarity_common',    order: 0 },
  uncommon:  { label: 'Uncommon',  color: '#4fd66a', icon: 'rarity_uncommon',  order: 1 },
  rare:      { label: 'Rare',      color: '#3d9bff', icon: 'rarity_rare',      order: 2 },
  epic:      { label: 'Epic',      color: '#b25cff', icon: 'rarity_epic',      order: 3 },
  legendary: { label: 'Legendary', color: '#ffb52e', icon: 'rarity_legendary', order: 4 },
  exotic:    { label: 'Exotic',    color: '#ff5ce1', icon: 'rarity_exotic',    order: 5 },
};

export const CURRENCIES = {
  credits: { label: 'Credits', icon: 'credits', desc: 'Earned from every mission. Spent on upgrades, weapons and cosmetics.' },
  alloy:   { label: 'Alloy',   icon: 'crystal_blue', desc: 'Salvaged from wrecks. Required for higher upgrade tiers and ship construction.' },
  cores:   { label: 'Quantum Cores', icon: 'crystal_purple', desc: 'Rare. Dropped by elites and bosses. Unlocks combat mods and prototype tech.' },
  tokens:  { label: 'Event Tokens', icon: 'crystal_red', desc: 'Earned during seasonal events. Spent in the event exchange.' },
};

// ---------------------------------------------------------------------------
// SHIPS
// ---------------------------------------------------------------------------
export const SHIPS = {
  warden: {
    name: 'Warden', role: 'Gunship', icon: 'ship_white',
    desc: 'Balanced frontline gunship. Forgiving, versatile, and dependable in any mission.',
    hull: 120, shield: 80, speed: 1.0, agility: 1.0, boost: 1.0, size: 1.0,
    primarySlots: 2,
    loadout: { primary: ['pulse', 'scatter'], secondary: 'missiles', ability: 'aegis' },
    unlock: { level: 1 }, cost: null,
    trait: 'Steady Hands — heat builds 10% slower.',
    traitId: 'steady',
  },
  viper: {
    name: 'Viper', role: 'Interceptor', icon: 'ship_red',
    desc: 'Featherweight interceptor. Extreme agility and boost, paper-thin armor.',
    hull: 80, shield: 60, speed: 1.22, agility: 1.45, boost: 1.4, size: 0.85,
    primarySlots: 2,
    loadout: { primary: ['pulse', 'arc'], secondary: 'missiles', ability: 'overdrive' },
    unlock: { level: 3 }, cost: { credits: 1500, alloy: 20 },
    trait: 'Slipstream — evasive dash costs 40% less energy.',
    traitId: 'slipstream',
  },
  bulwark: {
    name: 'Bulwark', role: 'Heavy Armor', icon: 'ship_grey',
    desc: 'Flying fortress. Soaks punishment and hits like a freight train.',
    hull: 210, shield: 120, speed: 0.8, agility: 0.72, boost: 0.8, size: 1.25,
    primarySlots: 2,
    loadout: { primary: ['plasma', 'scatter'], secondary: 'torpedo', ability: 'aegis' },
    unlock: { level: 5 }, cost: { credits: 2600, alloy: 40 },
    trait: 'Reinforced — collisions deal 60% less damage.',
    traitId: 'reinforced',
  },
  specter: {
    name: 'Specter', role: 'Stealth', icon: 'ship_purple',
    desc: 'Signature-dampened hunter. Vanishes, repositions, and strikes from behind.',
    hull: 90, shield: 70, speed: 1.1, agility: 1.2, boost: 1.1, size: 0.95,
    primarySlots: 2,
    loadout: { primary: ['pulse', 'railgun'], secondary: 'missiles', ability: 'cloak' },
    unlock: { level: 8 }, cost: { credits: 3800, alloy: 60 },
    trait: 'Ghost Signature — enemies lose lock 35% faster.',
    traitId: 'ghost',
  },
  longbow: {
    name: 'Longbow', role: 'Artillery', icon: 'ship_gold',
    desc: 'Long-range siege craft. Devastating at distance, vulnerable up close.',
    hull: 110, shield: 90, speed: 0.9, agility: 0.85, boost: 0.9, size: 1.1,
    primarySlots: 2,
    loadout: { primary: ['railgun', 'plasma'], secondary: 'torpedo', ability: 'decoy' },
    unlock: { level: 11 }, cost: { credits: 5200, alloy: 90 },
    trait: 'Marksman — +25% damage to targets beyond 350m.',
    traitId: 'marksman',
  },
  prototype: {
    name: 'XR-0 Prototype', role: 'Experimental', icon: 'ship_green',
    desc: 'Unstable alien-derived prototype. Ability-focused, bends the rules of combat.',
    hull: 100, shield: 110, speed: 1.05, agility: 1.1, boost: 1.0, size: 1.0,
    primarySlots: 2,
    loadout: { primary: ['gravity', 'lance'], secondary: 'drones', ability: 'timedilation' },
    unlock: { level: 14 }, cost: { credits: 7000, alloy: 120, cores: 6 },
    trait: 'Resonance — abilities recharge 25% faster.',
    traitId: 'resonance',
  },
};
export const SHIP_ORDER = ['warden', 'viper', 'bulwark', 'specter', 'longbow', 'prototype'];

// ---------------------------------------------------------------------------
// WEAPONS
// ---------------------------------------------------------------------------
export const WEAPONS = {
  pulse: {
    name: 'Pulse Cannon', kind: 'projectile', icon: 'bullet', color: '#5fe3ff',
    desc: 'Rapid twin-linked energy bolts. Reliable at any range.',
    damage: 8, rate: 10, speed: 620, life: 1.6, spread: 0.006, heat: 2.0, size: 1.0,
    strengths: 'Fast, accurate', weakness: 'Low burst damage',
    unlock: { level: 1 }, cost: null,
  },
  scatter: {
    name: 'Scatter Cannon', kind: 'pellets', icon: 'claws', color: '#ffb347',
    desc: 'Shotgun burst of 9 pellets. Shreds anything within 200m.',
    damage: 6, pellets: 9, rate: 2.4, speed: 520, life: 0.55, spread: 0.075, heat: 10, size: 0.8,
    strengths: 'Close-range burst', weakness: 'Useless at range',
    unlock: { level: 1 }, cost: null,
  },
  plasma: {
    name: 'Plasma Cannon', kind: 'projectile', icon: 'plasma', color: '#c264ff',
    desc: 'Heavy plasma orbs that splash on impact. Great against groups and shields.',
    damage: 34, splash: 16, rate: 2.2, speed: 330, life: 2.4, spread: 0.004, heat: 9, size: 2.4,
    shieldBonus: 1.5,
    strengths: 'Splash, shield breaking', weakness: 'Slow projectiles',
    unlock: { level: 2 }, cost: { credits: 900 },
  },
  railgun: {
    name: 'Railgun', kind: 'hitscan', icon: 'missile', color: '#9fd3ff',
    desc: 'Instant hypervelocity slug. Rewards precision with massive damage.',
    damage: 72, rate: 0.95, range: 1400, heat: 17, crit: 0.15,
    strengths: 'Precision, range', weakness: 'Slow cycle, punishing misses',
    unlock: { level: 4 }, cost: { credits: 1600, alloy: 15 },
  },
  arc: {
    name: 'Arc Caster', kind: 'chain', icon: 'lightning', color: '#7ab8ff',
    desc: 'Lightning that leaps between up to 4 enemies. No aiming precision required.',
    damage: 13, rate: 5, range: 280, chains: 3, chainRange: 110, heat: 4.5, cone: 0.32,
    strengths: 'Crowd control, auto-aim', weakness: 'Short range, falls off on armor',
    unlock: { level: 6 }, cost: { credits: 2200, alloy: 25 },
  },
  lance: {
    name: 'Lance Beam', kind: 'beam', icon: 'laser', color: '#6dff8a',
    desc: 'Continuous focused beam. Damage ramps up the longer it stays on target.',
    damage: 55, range: 560, heat: 24, ramp: 1.8,
    strengths: 'Sustained DPS', weakness: 'Heat hungry, must track target',
    unlock: { level: 9 }, cost: { credits: 3000, alloy: 40 },
  },
  gravity: {
    name: 'Gravity Projector', kind: 'gravity', icon: 'blackhole', color: '#a07bff',
    desc: 'EXPERIMENTAL. Slow singularity that drags enemies together then implodes.',
    damage: 70, splash: 70, pull: 260, rate: 0.75, speed: 170, life: 1.6, heat: 26, size: 4,
    strengths: 'Groups enemies, huge AoE', weakness: 'Very slow, overheats quickly',
    unlock: { level: 13 }, cost: { credits: 4200, alloy: 50, cores: 3 },
  },
};
export const PRIMARY_ORDER = ['pulse', 'scatter', 'plasma', 'railgun', 'arc', 'lance', 'gravity'];

export const SECONDARIES = {
  missiles: {
    name: 'Seeker Missiles', icon: 'missile', color: '#ffd27a',
    desc: 'Lock-on homing missiles fired in pairs. Hold aim on a target to lock.',
    damage: 42, splash: 12, ammo: 16, salvo: 2, speed: 260, turn: 3.2, life: 4.5, cooldown: 0.6, regen: 7,
    unlock: { level: 1 }, cost: null,
  },
  torpedo: {
    name: 'Nova Torpedo', icon: 'torpedo', color: '#ff7a4d',
    desc: 'Dumb-fire heavy torpedo. Enormous blast. Perfect against capital ships.',
    damage: 170, splash: 60, ammo: 6, salvo: 1, speed: 190, turn: 0.4, life: 6, cooldown: 1.4, regen: 14,
    unlock: { level: 3 }, cost: { credits: 1200, alloy: 10 },
  },
  drones: {
    name: 'Hornet Drones', icon: 'drone', color: '#7dffcf',
    desc: 'Launches two autonomous attack drones that hunt nearby enemies for 15s.',
    damage: 6, ammo: 4, salvo: 2, life: 15, cooldown: 3, regen: 22,
    unlock: { level: 7 }, cost: { credits: 2600, alloy: 30 },
  },
};
export const SECONDARY_ORDER = ['missiles', 'torpedo', 'drones'];

export const ABILITIES = {
  aegis:        { name: 'Aegis Barrier', icon: 'shield', cooldown: 18, duration: 3.2, desc: 'Impenetrable barrier. Blocks all damage and reflects bolts.', unlock: { level: 1 }, cost: null },
  overdrive:    { name: 'Overdrive', icon: 'energy', cooldown: 16, duration: 5, desc: 'Engines and weapons overclock: +60% speed, +50% fire rate, no heat.', unlock: { level: 2 }, cost: { credits: 800 } },
  emp:          { name: 'EMP Pulse', icon: 'lightning', cooldown: 20, duration: 3, radius: 230, desc: 'Shockwave strips shields and stuns enemies within 230m.', unlock: { level: 4 }, cost: { credits: 1400, alloy: 10 } },
  repair:       { name: 'Repair Drone', icon: 'repair', cooldown: 24, duration: 6, amount: 45, desc: 'Deploys a drone that restores 45 hull over 6s.', unlock: { level: 3 }, cost: { credits: 1100 } },
  decoy:        { name: 'Holo Decoy', icon: 'ship_dark', cooldown: 17, duration: 6, desc: 'Projects a hologram that draws enemy fire for 6s.', unlock: { level: 5 }, cost: { credits: 1700, alloy: 15 } },
  nova:         { name: 'Nova Burst', icon: 'explosion', cooldown: 32, duration: 0.6, radius: 170, damage: 160, desc: 'Detonates stored energy, devastating everything within 170m.', unlock: { level: 10 }, cost: { credits: 3200, alloy: 40 } },
  timedilation: { name: 'Time Dilation', icon: 'blackhole_blue', cooldown: 24, duration: 4.5, desc: 'Slows all enemies and their projectiles to 30% speed.', unlock: { level: 12 }, cost: { credits: 3600, alloy: 45, cores: 2 } },
  cloak:        { name: 'Phase Cloak', icon: 'ship_purple', cooldown: 20, duration: 5, desc: 'Become invisible. Enemies lose track. First shot from cloak deals 3x damage.', unlock: { level: 8 }, cost: { credits: 2800, alloy: 30 } },
};
export const ABILITY_ORDER = ['aegis', 'overdrive', 'repair', 'emp', 'decoy', 'cloak', 'nova', 'timedilation'];

// ---------------------------------------------------------------------------
// UPGRADES — 5 tiers per branch, plus mutually-exclusive behavior mods.
// ---------------------------------------------------------------------------
export const UPGRADE_BRANCHES = {
  hull:     { name: 'Hull Plating',     icon: 'heart',    per: 0.12, stat: 'Hull',            fmt: p => `+${Math.round(p * 100)}% hull` },
  shield:   { name: 'Shield Capacitor', icon: 'shield',   per: 0.12, stat: 'Shield',          fmt: p => `+${Math.round(p * 100)}% shields, faster recharge` },
  engine:   { name: 'Engines',          icon: 'fuel',     per: 0.06, stat: 'Speed/Boost',     fmt: p => `+${Math.round(p * 100)}% speed, +${Math.round(p * 150)}% boost` },
  damage:   { name: 'Weapon Damage',    icon: 'explosion',per: 0.07, stat: 'Damage',          fmt: p => `+${Math.round(p * 100)}% damage` },
  firerate: { name: 'Fire Control',     icon: 'chevron',  per: 0.06, stat: 'Fire Rate',       fmt: p => `+${Math.round(p * 100)}% fire rate` },
  crit:     { name: 'Targeting Suite',  icon: 'crosshair',per: 0.04, stat: 'Critical Chance', fmt: p => `+${Math.round(p * 100)}% crit chance` },
  missiles: { name: 'Ordnance Racks',   icon: 'torpedo',  per: 0.2,  stat: 'Secondary Ammo',  fmt: p => `+${Math.round(p * 100)}% secondary ammo` },
  energy:   { name: 'Power Core',       icon: 'energy',   per: 0.1,  stat: 'Energy/Cooling',  fmt: p => `+${Math.round(p * 100)}% energy regen & cooling` },
  ability:  { name: 'Ability Matrix',   icon: 'gear',     per: 0.08, stat: 'Ability',         fmt: p => `-${Math.round(p * 100)}% cooldown, +${Math.round(p * 100)}% power` },
  loot:     { name: 'Tractor Field',    icon: 'crate_blue', per: 0.25, stat: 'Pickup Radius', fmt: p => `+${Math.round(p * 100)}% loot radius` },
};
export const UPGRADE_MAX_TIER = 5;
export function upgradeCost(branch, tier) {
  // tier = the tier being purchased (1..5)
  const base = { hull: 300, shield: 300, engine: 280, damage: 360, firerate: 340, crit: 320, missiles: 260, energy: 280, ability: 340, loot: 200 }[branch] || 300;
  const credits = Math.round(base * Math.pow(1.75, tier - 1) / 10) * 10;
  const alloy = tier >= 2 ? Math.round(6 * Math.pow(1.8, tier - 2)) : 0;
  const cores = tier === 5 ? 1 : 0;
  return { credits, alloy, cores };
}

// Behavior-changing mods. Each branch has a pair; you may equip ONE per pair.
export const MODS = {
  leech:       { branch: 'hull',     name: 'Salvage Leech',     icon: 'heart',     desc: 'Each kill repairs 3 hull. Elite kills repair 20.' },
  laststand:   { branch: 'hull',     name: 'Last Stand',        icon: 'rank_skull',desc: 'Below 30% hull: +45% damage and +20% fire rate.' },
  static:      { branch: 'shield',   name: 'Static Discharge',  icon: 'lightning', desc: 'When your shield absorbs a hit, arc lightning shocks the attacker.' },
  reactive:    { branch: 'shield',   name: 'Reactive Collapse', icon: 'explosion', desc: 'When shields break, release an EMP that stuns nearby enemies (8s internal cd).' },
  afterburner: { branch: 'engine',   name: 'Afterburner Wake',  icon: 'fuel',      desc: 'Boosting leaves a burning plasma wake that damages pursuers.' },
  phasedash:   { branch: 'engine',   name: 'Phase Dash',        icon: 'chevron',   desc: 'Evasive dashes grant 0.8s invulnerability and vent all weapon heat.' },
  piercing:    { branch: 'damage',   name: 'Piercing Rounds',   icon: 'missile',   desc: 'Railgun slugs pierce every target. Pulse bolts pierce once.' },
  volatile:    { branch: 'damage',   name: 'Volatile Payload',  icon: 'explosion', desc: 'Killed enemies explode for 35% of their max hull to nearby foes.' },
  split:       { branch: 'missiles', name: 'Splitter Warheads', icon: 'claws',     desc: 'Missiles split into 3 bomblets on impact.' },
  swarm:       { branch: 'missiles', name: 'Swarm Salvo',       icon: 'drone',     desc: 'Each salvo fires 2 extra mini-missiles at nearby targets.' },
  echo:        { branch: 'ability',  name: 'Echo Capacitor',    icon: 'restart',   desc: 'Killing an elite or mini-boss fully recharges your ability.' },
  amplify:     { branch: 'ability',  name: 'Amplifier',         icon: 'energy',    desc: 'Ability duration +50%, radius +30%.' },
};
export const MOD_PAIRS = [['leech', 'laststand'], ['static', 'reactive'], ['afterburner', 'phasedash'], ['piercing', 'volatile'], ['split', 'swarm'], ['echo', 'amplify']];
export const MOD_UNLOCK_TIER = 3;
export const MOD_COST = { credits: 1200, cores: 1 };

// ---------------------------------------------------------------------------
// COSMETICS
// ---------------------------------------------------------------------------
export const COSMETICS = {
  // Paints: primary hull, secondary accents, metalness, roughness
  paint_standard:   { type: 'paint', name: 'Fleet Standard', rarity: 'common',    primary: '#c9d3df', secondary: '#2a6fd6', metal: 0.75, rough: 0.35, source: 'default' },
  paint_gunmetal:   { type: 'paint', name: 'Gunmetal',       rarity: 'common',    primary: '#5a616b', secondary: '#d8dee6', metal: 0.85, rough: 0.4, source: 'shop', price: { credits: 300 } },
  paint_crimson:    { type: 'paint', name: 'Crimson Fang',   rarity: 'uncommon',  primary: '#8e1b24', secondary: '#1a1a1e', metal: 0.6, rough: 0.35, source: 'shop', price: { credits: 600 } },
  paint_arctic:     { type: 'paint', name: 'Arctic Recon',   rarity: 'rare',      primary: '#eef4fb', secondary: '#5aa9d6', metal: 0.3, rough: 0.5, source: 'shop', price: { credits: 1100 } },
  paint_onyx:       { type: 'paint', name: 'Onyx Shadow',    rarity: 'epic',      primary: '#16171c', secondary: '#9b5cff', metal: 0.9, rough: 0.25, source: 'shop', price: { credits: 2200, alloy: 20 } },
  paint_solargold:  { type: 'paint', name: 'Solar Regalia',  rarity: 'legendary', primary: '#d9a73a', secondary: '#3a2a12', metal: 1.0, rough: 0.2, source: 'achievement' },
  paint_void:       { type: 'paint', name: 'Voidglass',      rarity: 'exotic',    primary: '#1b1035', secondary: '#ff5ce1', metal: 1.0, rough: 0.08, iridescent: true, source: 'drop' },
  paint_jungle:     { type: 'paint', name: 'Deep Canopy',    rarity: 'uncommon',  primary: '#2f4a2a', secondary: '#c4a64a', metal: 0.4, rough: 0.55, source: 'daily' },
  paint_haunted:    { type: 'paint', name: 'Hollow Hull',    rarity: 'epic',      primary: '#1b1f1a', secondary: '#7dff6a', metal: 0.5, rough: 0.6, source: 'event', event: 'halloween', price: { tokens: 40 } },
  paint_pumpkin:    { type: 'paint', name: 'Jack-o-Lantern', rarity: 'rare',      primary: '#d4600f', secondary: '#1a0f05', metal: 0.3, rough: 0.5, source: 'event', event: 'halloween', price: { tokens: 20 } },
  paint_frost:      { type: 'paint', name: 'Rimefrost',      rarity: 'epic',      primary: '#cfe9ff', secondary: '#6fc8ff', metal: 0.6, rough: 0.15, source: 'event', event: 'winter', price: { tokens: 40 } },
  paint_blossom:    { type: 'paint', name: 'Blossom Drift',  rarity: 'epic',      primary: '#f6c3d8', secondary: '#58b36a', metal: 0.2, rough: 0.45, source: 'event', event: 'spring', price: { tokens: 40 } },
  paint_solarflare: { type: 'paint', name: 'Coronal Flare',  rarity: 'epic',      primary: '#ff9a1f', secondary: '#ffe27a', metal: 0.7, rough: 0.25, source: 'event', event: 'summer', price: { tokens: 40 } },
  paint_jubilee:    { type: 'paint', name: 'Jubilee',        rarity: 'legendary', primary: '#ecebf5', secondary: '#ffc83d', metal: 0.9, rough: 0.15, source: 'event', event: 'anniversary', price: { tokens: 60 } },
  paint_anomaly:    { type: 'paint', name: 'Event Horizon',  rarity: 'exotic',    primary: '#05060a', secondary: '#6af0ff', metal: 1.0, rough: 0.05, iridescent: true, source: 'event', event: 'anomaly', price: { tokens: 80 } },

  engine_cyan:     { type: 'engine', name: 'Ion Cyan',      rarity: 'common',    color: '#4fdcff', source: 'default' },
  engine_amber:    { type: 'engine', name: 'Amber Burn',    rarity: 'common',    color: '#ff9a3c', source: 'shop', price: { credits: 250 } },
  engine_violet:   { type: 'engine', name: 'Violet Plasma', rarity: 'rare',      color: '#b26bff', source: 'shop', price: { credits: 900 } },
  engine_emerald:  { type: 'engine', name: 'Emerald Fusion',rarity: 'rare',      color: '#43ff8e', source: 'shop', price: { credits: 900 } },
  engine_white:    { type: 'engine', name: 'White Dwarf',   rarity: 'epic',      color: '#f4f8ff', source: 'achievement' },
  engine_crimson:  { type: 'engine', name: 'Red Giant',     rarity: 'uncommon',  color: '#ff3b3b', source: 'daily' },
  engine_prism:    { type: 'engine', name: 'Prismatic Drive', rarity: 'exotic',  color: '#ff5ce1', cycle: true, source: 'drop' },
  engine_ghost:    { type: 'engine', name: 'Ghostfire',     rarity: 'epic',      color: '#7dff6a', source: 'event', event: 'halloween', price: { tokens: 30 } },
  engine_frost:    { type: 'engine', name: 'Glacial Jet',   rarity: 'rare',      color: '#bfeaff', source: 'event', event: 'winter', price: { tokens: 25 } },
  engine_solar:    { type: 'engine', name: 'Sunspot',       rarity: 'rare',      color: '#ffd23a', source: 'event', event: 'summer', price: { tokens: 25 } },

  pattern_none:    { type: 'pattern', name: 'Clean',        rarity: 'common',   pattern: 'none', source: 'default' },
  pattern_stripes: { type: 'pattern', name: 'Twin Stripes', rarity: 'common',   pattern: 'stripes', source: 'shop', price: { credits: 350 } },
  pattern_chevron: { type: 'pattern', name: 'Chevron',      rarity: 'uncommon', pattern: 'chevron', source: 'shop', price: { credits: 700 } },
  pattern_split:   { type: 'pattern', name: 'Split Wing',   rarity: 'rare',     pattern: 'split', source: 'shop', price: { credits: 1200 } },
  pattern_hazard:  { type: 'pattern', name: 'Hazard Band',  rarity: 'rare',     pattern: 'hazard', source: 'achievement' },
  pattern_tiger:   { type: 'pattern', name: 'Tiger Claw',   rarity: 'epic',     pattern: 'tiger', source: 'daily' },
  pattern_web:     { type: 'pattern', name: 'Spider Web',   rarity: 'epic',     pattern: 'web', source: 'event', event: 'halloween', price: { tokens: 25 } },

  emblem_none:     { type: 'emblem', name: 'None',          rarity: 'common',   emblem: null, source: 'default' },
  emblem_eagle:    { type: 'emblem', name: 'Starfall Eagle',rarity: 'common',   emblem: 'emblem_eagle', source: 'default' },
  emblem_phoenix:  { type: 'emblem', name: 'Phoenix',       rarity: 'rare',     emblem: 'emblem_phoenix', source: 'shop', price: { credits: 800 } },
  emblem_sun:      { type: 'emblem', name: 'Sunburst',      rarity: 'rare',     emblem: 'emblem_sun', source: 'shop', price: { credits: 800 } },
  emblem_prism:    { type: 'emblem', name: 'Prism Sigil',   rarity: 'epic',     emblem: 'emblem_prism', source: 'achievement' },
  emblem_alien:    { type: 'emblem', name: 'Xeno Mark',     rarity: 'epic',     emblem: 'emblem_alien', source: 'drop' },
  emblem_demon:    { type: 'emblem', name: 'Hellion',       rarity: 'legendary',emblem: 'emblem_demon', source: 'event', event: 'halloween', price: { tokens: 50 } },
  emblem_skull:    { type: 'emblem', name: 'Ace Killer',    rarity: 'legendary',emblem: 'rank_skull', source: 'achievement' },
  emblem_crown:    { type: 'emblem', name: 'Sovereign',     rarity: 'legendary',emblem: 'rank_crown', source: 'daily' },

  trail_standard:  { type: 'trail', name: 'Standard Exhaust', rarity: 'common',  trail: 'standard', source: 'default' },
  trail_long:      { type: 'trail', name: 'Comet Tail',       rarity: 'uncommon',trail: 'long', source: 'shop', price: { credits: 600 } },
  trail_ion:       { type: 'trail', name: 'Ion Sparkle',      rarity: 'rare',    trail: 'ion', source: 'shop', price: { credits: 1300 } },
  trail_ember:     { type: 'trail', name: 'Ember Wake',       rarity: 'epic',    trail: 'ember', source: 'achievement' },
  trail_spectral:  { type: 'trail', name: 'Spectral Wisp',    rarity: 'epic',    trail: 'spectral', source: 'event', event: 'halloween', price: { tokens: 35 } },
  trail_snow:      { type: 'trail', name: 'Snowdrift',        rarity: 'rare',    trail: 'snow', source: 'event', event: 'winter', price: { tokens: 25 } },
  trail_petal:     { type: 'trail', name: 'Petal Stream',     rarity: 'rare',    trail: 'petal', source: 'event', event: 'spring', price: { tokens: 25 } },
  trail_confetti:  { type: 'trail', name: 'Confetti',         rarity: 'legendary', trail: 'confetti', source: 'event', event: 'anniversary', price: { tokens: 50 } },

  weapon_default:  { type: 'weapon', name: 'Factory Spec',  rarity: 'common',   tint: null, source: 'default' },
  weapon_crimson:  { type: 'weapon', name: 'Crimson Bolts', rarity: 'uncommon', tint: '#ff4a4a', source: 'shop', price: { credits: 500 } },
  weapon_emerald:  { type: 'weapon', name: 'Venom Green',   rarity: 'rare',     tint: '#4dff7a', source: 'shop', price: { credits: 900 } },
  weapon_gold:     { type: 'weapon', name: 'Gilded Fire',   rarity: 'legendary',tint: '#ffd04a', source: 'achievement' },
  weapon_ghost:    { type: 'weapon', name: 'Ectoplasm',     rarity: 'epic',     tint: '#9dff5a', source: 'event', event: 'halloween', price: { tokens: 30 } },
  weapon_ice:      { type: 'weapon', name: 'Icicle Rounds', rarity: 'rare',     tint: '#bdf1ff', source: 'event', event: 'winter', price: { tokens: 25 } },
};
export const COSMETIC_TYPES = ['paint', 'engine', 'pattern', 'emblem', 'trail', 'weapon'];
export const DEFAULT_COSMETICS = Object.keys(COSMETICS).filter(k => COSMETICS[k].source === 'default');
export const DEFAULT_EQUIP = { paint: 'paint_standard', engine: 'engine_cyan', pattern: 'pattern_none', emblem: 'emblem_eagle', trail: 'trail_standard', weapon: 'weapon_default' };

// ---------------------------------------------------------------------------
// FACTIONS & ENEMIES
// ---------------------------------------------------------------------------
export const FACTIONS = {
  dominion: { name: 'Iron Dominion',     color: '#ff5a3c', accent: '#ffb38a', desc: 'Militarist machine-empire. Heavy armor, artillery, capital ships.', roster: ['interceptor', 'bomber', 'artillery', 'shieldcarrier', 'repair', 'sniper', 'swarm'] },
  vrell:    { name: 'Vrell Swarm',       color: '#9cff3c', accent: '#e8ff9a', desc: 'Bio-organic hive. Overwhelming numbers, kamikaze broods.', roster: ['swarm', 'kamikaze', 'interceptor', 'repair', 'bomber', 'artillery'] },
  syndicate:{ name: 'Phantom Syndicate', color: '#c05cff', accent: '#f0c8ff', desc: 'Pirate cartel of aces. Stealth, snipers, dirty tricks.', roster: ['stealth', 'sniper', 'interceptor', 'kamikaze', 'shieldcarrier', 'swarm'] },
  choir:    { name: 'Null Choir',        color: '#4ff0ff', accent: '#d0fbff', desc: 'Crystalline intelligences from beyond the anomaly.', roster: ['shieldcarrier', 'repair', 'sniper', 'swarm', 'artillery', 'stealth'] },
};

export const ENEMIES = {
  swarm:        { name: 'Swarm Drone',    role: 'Swarm',      hp: 14,  shield: 0,  speed: 150, accel: 260, turn: 3.5, radius: 4,  score: 50,  credits: 4,  xp: 4,  weapon: { dmg: 4, rate: 0.7, speed: 300, spread: 0.06 }, behavior: 'swarm', cost: 1 },
  interceptor:  { name: 'Interceptor',    role: 'Flanker',    hp: 42,  shield: 18, speed: 175, accel: 230, turn: 2.8, radius: 6,  score: 120, credits: 9,  xp: 9,  weapon: { dmg: 6, rate: 2.2, speed: 380, spread: 0.03, burst: 3 }, behavior: 'flank', cost: 3 },
  bomber:       { name: 'Bomber',         role: 'Bomber',     hp: 120, shield: 30, speed: 70,  accel: 60,  turn: 0.9, radius: 10, score: 220, credits: 16, xp: 15, weapon: { dmg: 28, rate: 0.22, speed: 120, torpedo: true }, behavior: 'bomber', cost: 5 },
  sniper:       { name: 'Longshot',       role: 'Sniper',     hp: 55,  shield: 25, speed: 90,  accel: 120, turn: 1.6, radius: 7,  score: 200, credits: 14, xp: 13, weapon: { dmg: 26, rate: 0.28, speed: 1100, telegraph: 1.5 }, behavior: 'sniper', cost: 4 },
  shieldcarrier:{ name: 'Bastion',        role: 'Shield Carrier', hp: 100, shield: 80, speed: 80, accel: 90, turn: 1.2, radius: 11, score: 240, credits: 18, xp: 16, weapon: { dmg: 5, rate: 1, speed: 300, spread: 0.05 }, behavior: 'support_shield', aura: 140, cost: 5 },
  repair:       { name: 'Mender',         role: 'Repair',     hp: 75,  shield: 20, speed: 110, accel: 140, turn: 2, radius: 8,  score: 200, credits: 15, xp: 14, weapon: null, behavior: 'support_repair', heal: 14, cost: 4 },
  stealth:      { name: 'Wraith',         role: 'Stealth Hunter', hp: 55, shield: 0, speed: 160, accel: 260, turn: 3, radius: 6, score: 210, credits: 14, xp: 14, weapon: { dmg: 9, rate: 4, speed: 420, spread: 0.02, burst: 6 }, behavior: 'stealth', cost: 4 },
  kamikaze:     { name: 'Burner',         role: 'Kamikaze',   hp: 26,  shield: 0,  speed: 200, accel: 300, turn: 2.6, radius: 5,  score: 90,  credits: 6,  xp: 6,  weapon: null, behavior: 'kamikaze', blast: 42, blastDmg: 34, cost: 2 },
  artillery:    { name: 'Siegebreaker',   role: 'Artillery',  hp: 150, shield: 40, speed: 50,  accel: 50,  turn: 0.8, radius: 13, score: 260, credits: 20, xp: 18, weapon: { dmg: 40, rate: 0.18, speed: 150, shell: true, blast: 55 }, behavior: 'artillery', cost: 6 },
  ace:          { name: 'Elite Ace',      role: 'Elite',      hp: 360, shield: 120, speed: 190, accel: 280, turn: 3.2, radius: 8, score: 1500, credits: 120, xp: 80, weapon: { dmg: 8, rate: 6, speed: 520, spread: 0.02, burst: 8 }, behavior: 'ace', cost: 14, elite: true },
  sentinel:     { name: 'Sentinel Platform', role: 'Mini-Boss', hp: 900, shield: 300, speed: 25, accel: 30, turn: 0.5, radius: 26, score: 2500, credits: 200, xp: 120, weapon: { dmg: 10, rate: 3, speed: 360, spread: 0.02 }, behavior: 'sentinel', cost: 20, elite: true, miniboss: true },
  broodmother:  { name: 'Brood Mother',   role: 'Mini-Boss',  hp: 800, shield: 0,  speed: 60, accel: 60, turn: 0.8, radius: 24, score: 2500, credits: 200, xp: 120, weapon: { dmg: 14, rate: 0.8, speed: 200, spread: 0.2, spore: true }, behavior: 'brood', cost: 20, elite: true, miniboss: true },
  capital:      { name: 'Dominion Cruiser', role: 'Capital Ship', hp: 2400, shield: 600, speed: 18, accel: 10, turn: 0.15, radius: 60, score: 5000, credits: 400, xp: 250, weapon: null, behavior: 'capital', cost: 40, elite: true },
};
export const ENEMY_ORDER = ['swarm', 'interceptor', 'bomber', 'sniper', 'shieldcarrier', 'repair', 'stealth', 'kamikaze', 'artillery', 'ace', 'sentinel', 'broodmother', 'capital'];

export const VARIANTS = {
  armored:     { name: 'Armored',     hp: 1.6, speed: 0.85, dmg: 1.0, tint: '#8a8f99', desc: '+60% hull, slower' },
  overcharged: { name: 'Overcharged', hp: 1.0, speed: 1.0, dmg: 1.35, rate: 1.3, tint: '#ff3b3b', desc: '+35% damage, +30% fire rate' },
  veteran:     { name: 'Veteran',     hp: 1.25, speed: 1.1, dmg: 1.1, dodge: 0.35, tint: '#ffcc33', desc: 'Dodges incoming fire' },
  swift:       { name: 'Swift',       hp: 0.9, speed: 1.35, dmg: 1.0, tint: '#55ffee', desc: '+35% speed' },
  shielded:    { name: 'Shielded',    hp: 1.0, speed: 1.0, dmg: 1.0, shield: 2.2, tint: '#4f9dff', desc: 'Heavy shields' },
  // Seasonal variants (only appear during events)
  ghost:       { name: 'Ghostly',     hp: 1.0, speed: 1.1, dmg: 1.0, phase: true, tint: '#7dff6a', desc: 'Phases out of reality — shots pass through while faded', event: 'halloween' },
  frost:       { name: 'Frostbound',  hp: 1.15, speed: 0.95, dmg: 1.0, chill: true, tint: '#9fe6ff', desc: 'Hits chill your engines', event: 'winter' },
  bloom:       { name: 'Bloomspawn',  hp: 0.9, speed: 1.0, dmg: 1.0, spores: true, tint: '#ff8fd0', desc: 'Bursts into spore drones on death', event: 'spring' },
  solar:       { name: 'Solarborn',   hp: 1.0, speed: 1.05, dmg: 1.2, deathBlast: true, tint: '#ffb02e', desc: 'Detonates on death', event: 'summer' },
};

export const ACE_NAMES = {
  first: ['Red', 'Silent', 'Iron', 'Grim', 'Hex', 'Vex', 'Null', 'Burning', 'Cold', 'Black', 'Saint', 'Rust'],
  last: ['Talon', 'Mira', 'Grinder', 'Vanguard', 'Lotus', 'Jackal', 'Requiem', 'Corsair', 'Halo', 'Viper', 'Marrow', 'Widow'],
  personalities: {
    aggressive: { desc: 'Charges in with relentless strafing runs.', weapon: 'burst' },
    evasive:    { desc: 'Never stays still. Jinks constantly and punishes over-commitment.', weapon: 'rail' },
    tactical:   { desc: 'Calls in drones and fights behind a shield.', weapon: 'missiles' },
  },
};

// ---------------------------------------------------------------------------
// BOSSES
// ---------------------------------------------------------------------------
export const BOSSES = {
  dreadnought: { name: 'The Dreadnought', title: 'Iron Dominion Flagship "Sovereign Wrath"', icon: 'emblem_demon', faction: 'dominion',
    desc: 'A 300m siege flagship. Shield generators, tracking turrets, engine weak points and an exposed reactor.',
    phases: ['Shield Generators', 'Engine Batteries', 'Reactor Exposed', 'Last Light'],
    rewards: { credits: 1400, alloy: 45, cores: 3, xp: 600, cosmeticPool: ['emblem_skull', 'pattern_hazard', 'paint_void'] } },
  swarmqueen:  { name: 'The Swarm Queen', title: 'Vrell Hive Sovereign', icon: 'emblem_alien', faction: 'vrell',
    desc: 'Commands every drone in the sector. Shifts formation, shelters in brood-shields, evolves mid-battle.',
    phases: ['Brood Rings', 'Shielded Hive', 'Evolution'],
    rewards: { credits: 1300, alloy: 40, cores: 3, xp: 580, cosmeticPool: ['emblem_alien', 'engine_emerald', 'pattern_tiger'] } },
  phantom:     { name: 'The Phantom Ace', title: 'Kaeso Vant, "The Phantom"', icon: 'emblem_phoenix', faction: 'syndicate',
    desc: 'The deadliest pilot alive. Decoys, cloaking, and adapts to how you fight.',
    phases: ['Duel', 'Mirror Images', 'Desperation'],
    rewards: { credits: 1200, alloy: 35, cores: 4, xp: 560, cosmeticPool: ['emblem_skull', 'trail_ember', 'paint_onyx'] } },
  anomaly:     { name: 'The Anomaly', title: 'The Thing Beyond the Horizon', icon: 'blackhole', faction: 'choir',
    desc: 'A crystalline intelligence that bends gravity, light and the arena itself.',
    phases: ['Gravity Wells', 'Folded Space', 'Collapse'],
    rewards: { credits: 1600, alloy: 50, cores: 5, xp: 700, cosmeticPool: ['paint_void', 'engine_prism', 'emblem_prism'] } },
  hollow:      { name: 'The Hollow Warden', title: 'Ghost Galleon of the Dead Lanes', icon: 'ev_halloween', faction: 'syndicate', event: 'halloween',
    desc: 'A haunted dreadnought that sails between worlds. Only vulnerable while its lanterns burn.',
    phases: ['Lanterns Lit', 'Wisp Storm', 'Witching Hour'],
    rewards: { credits: 1200, alloy: 30, cores: 3, tokens: 30, xp: 600, cosmeticPool: ['paint_haunted', 'engine_ghost', 'emblem_demon'] } },
};
export const BOSS_ORDER = ['dreadnought', 'swarmqueen', 'phantom', 'anomaly', 'hollow'];

// ---------------------------------------------------------------------------
// REGIONS
// ---------------------------------------------------------------------------
export const REGIONS = {
  belt: { name: 'Kessler Belt', icon: 'asteroid', desc: 'Dense asteroid belt. Rocks block shots and punish careless flying.',
    sky: ['#0a1426', '#3a5f8f', '#a37a52'], fog: 0.0009, sun: '#ffe9c4', sunDir: [1, 0.4, 0.2], asteroids: 220, asteroidScale: 1.2,
    planet: { color: '#a0694a', size: 600, pos: [-2600, -600, -3400], ring: true }, hazards: ['asteroids'], factions: ['dominion', 'vrell'],
    effect: 'Asteroids obstruct targeting and cause collisions.' },
  city: { name: 'Ruins of Halcyon', icon: 'station', desc: 'A shattered orbital city. Tight lanes between drifting megastructures.',
    sky: ['#0b0b18', '#45307a', '#ff8a5a'], fog: 0.0011, sun: '#ffd2b0', sunDir: [-0.6, 0.5, 0.3], asteroids: 40, asteroidScale: 0.8,
    planet: { color: '#3f6bb0', size: 900, pos: [1800, -1600, -3600], ring: false, atmo: '#7ab8ff' }, hazards: ['structures'], factions: ['dominion', 'syndicate'],
    effect: 'Ruined structures provide cover for both sides.' },
  volcanic: { name: 'Pyre of Ashkar', icon: 'planet_lava', desc: 'Orbit of a molten world. Solar-magma flares sweep the battlefield.',
    sky: ['#140606', '#6b1a0c', '#ff7a2a'], fog: 0.001, sun: '#ff9a5a', sunDir: [0.3, -0.2, -1], asteroids: 90, asteroidScale: 1,
    planet: { color: '#ff4a1a', size: 1100, pos: [0, -1900, -2600], lava: true, atmo: '#ff5a1a' }, hazards: ['flares'], factions: ['dominion', 'vrell'],
    effect: 'Periodic magma flares — telegraphed burning zones.' },
  graveyard: { name: 'The Boneyard', icon: 'ship_dark', desc: 'Graveyard of a thousand warships. Debris, mines, and things that should be dead.',
    sky: ['#06080c', '#22303a', '#6a7a6a'], fog: 0.0016, sun: '#cfe0ff', sunDir: [0.2, 1, 0.1], asteroids: 60, asteroidScale: 0.7, debris: true,
    planet: { color: '#666f78', size: 500, pos: [2400, 900, -3800] }, hazards: ['mines', 'debris'], factions: ['syndicate', 'dominion'],
    effect: 'Drifting mines and wreckage. Low visibility.' },
  nebula: { name: 'Veil Nebula', icon: 'nebula', desc: 'Ionized gas cloud. Sensors falter; lightning storms drain shields.',
    sky: ['#120820', '#7a2fbf', '#2fd0ff'], fog: 0.0024, sun: '#d8b0ff', sunDir: [0.5, 0.8, -0.2], asteroids: 30, asteroidScale: 0.9,
    planet: null, hazards: ['ionstorm'], factions: ['syndicate', 'choir', 'vrell'],
    effect: 'Heavy fog shortens lock range. Ion storms strike shields.' },
  megastructure: { name: 'The Lattice', icon: 'galaxy', desc: 'An alien megastructure of rotating rings. Gravity behaves strangely here.',
    sky: ['#020510', '#0f4a6a', '#4ff0ff'], fog: 0.0008, sun: '#bff6ff', sunDir: [-0.3, 0.6, 0.7], asteroids: 20, asteroidScale: 0.6, rings: true,
    planet: { color: '#2a2f55', size: 700, pos: [-2200, 1200, -3600], atmo: '#4ff0ff' }, hazards: ['gravity'], factions: ['choir'],
    effect: 'Gravity wells pull ships and bend projectiles.' },
  frontier: { name: 'Dominion Frontline', icon: 'planet_earth', desc: 'Heavily fortified enemy territory. Defense platforms and patrols everywhere.',
    sky: ['#05070f', '#1a2a55', '#ff3b3b'], fog: 0.0007, sun: '#ffffff', sunDir: [0.7, 0.3, 0.5], asteroids: 50, asteroidScale: 0.9,
    planet: { color: '#3c7a5a', size: 1300, pos: [-500, -2200, -3000], atmo: '#8ad0ff', clouds: true }, hazards: ['turrets'], factions: ['dominion'],
    effect: 'Automated defense turrets. Rewards +25%.', rewardMult: 1.25 },
};
export const REGION_ORDER = ['belt', 'city', 'volcanic', 'graveyard', 'nebula', 'megastructure', 'frontier'];

// ---------------------------------------------------------------------------
// MISSION OBJECTIVES & MODIFIERS
// ---------------------------------------------------------------------------
export const OBJECTIVES = {
  intercept: { name: 'Intercept',          icon: 'crosshair', desc: 'An invasion fleet is inbound to a civilian station. Destroy it before it arrives.', regions: ['belt', 'city', 'frontier', 'volcanic'], tags: ['defense'] },
  escort:    { name: 'Escort',             icon: 'shield',    desc: 'Protect a crippled allied battleship while its engines are repaired.', regions: ['belt', 'nebula', 'graveyard', 'city'], tags: ['defense'] },
  shieldgen: { name: 'Shield Breaker',     icon: 'shield_orb',desc: 'Destroy the shield generators, then finish the cruiser they protect.', regions: ['frontier', 'volcanic', 'city', 'megastructure'], tags: ['assault'] },
  survive:   { name: 'Storm Run',          icon: 'asteroid',  desc: 'Survive an asteroid storm while a pursuit squadron hunts you.', regions: ['belt', 'volcanic', 'graveyard'], tags: ['survival'] },
  comms:     { name: 'Signal Blackout',    icon: 'station',   desc: 'Disable the communications array before reinforcements are called.', regions: ['city', 'frontier', 'nebula', 'megastructure'], tags: ['assault', 'timed'] },
  acehunt:   { name: 'Ace Hunt',           icon: 'rank_skull',desc: 'A named enemy ace is operating here. Hunt them down — they will not fight fair.', regions: ['graveyard', 'nebula', 'belt', 'city'], tags: ['hunt'] },
  colony:    { name: 'Colony Defense',     icon: 'planet_earth', desc: 'Defend the mining colony domes against attacks from multiple directions.', regions: ['belt', 'volcanic', 'frontier'], tags: ['defense'] },
  convoy:    { name: 'Convoy Raid',        icon: 'crate_metal', desc: 'Destroy armored freighters and steal their energy cores before the convoy jumps.', regions: ['nebula', 'frontier', 'city', 'belt'], tags: ['raid', 'timed'] },
  derelict:  { name: 'Derelict Signal',    icon: 'ship_dark', desc: 'Investigate an abandoned warship broadcasting a distress call.', regions: ['graveyard', 'nebula', 'megastructure'], tags: ['explore'] },
  escape:    { name: 'Collapse',           icon: 'fastforward', desc: 'A station is breaking apart. Race through the escape gates before it detonates.', regions: ['city', 'megastructure', 'volcanic'], tags: ['race', 'timed'] },
  carrier:   { name: 'Carrier Strike',     icon: 'emblem_eagle', desc: 'A Dominion carrier is launching fighters. Destroy its engines, turrets, then the reactor.', regions: ['frontier', 'belt', 'volcanic'], tags: ['assault'] },
  anomaly:   { name: 'Anomaly Breach',     icon: 'blackhole', desc: 'Enter an unstable anomaly and destroy the crystal pylons feeding it.', regions: ['megastructure', 'nebula'], tags: ['explore'] },
  boss:      { name: 'Boss Encounter',     icon: 'bossrush', desc: 'A major threat has entered the sector.', regions: REGION_ORDER, tags: ['boss'] },
};

export const MODIFIERS = {
  drones:      { name: 'Drone Carriers',     icon: 'drone',     desc: 'Enemies deploy extra swarm drones.', reward: 0.15, difficulty: 1 },
  radarjam:    { name: 'Radar Jamming',      icon: 'crosshair', desc: 'Radar is unreliable and flickers.', reward: 0.15, difficulty: 1 },
  densefield:  { name: 'Dense Field',        icon: 'asteroid',  desc: 'Extra asteroids obscure targeting.', reward: 0.1, difficulty: 1, excludes: ['nebula'] },
  regen:       { name: 'Regenerative Shields', icon: 'shield',  desc: 'Enemy shields regenerate quickly.', reward: 0.2, difficulty: 2 },
  overheat:    { name: 'Thermal Stress',     icon: 'fuel',      desc: 'Your weapons overheat 50% faster.', reward: 0.2, difficulty: 2 },
  allies:      { name: 'Allied Wing',        icon: 'ship_white',desc: 'Friendly fighters join the battle.', reward: -0.1, difficulty: -1 },
  cargo:       { name: 'Valuable Cargo',     icon: 'crate_blue',desc: 'Cargo pods full of resources drift through the area.', reward: 0.0, difficulty: 0 },
  hunters:     { name: 'Hunter Pack',        icon: 'rank_skull',desc: 'Elite hunters are tracking you.', reward: 0.3, difficulty: 2 },
  gravity:     { name: 'Gravitic Rift',      icon: 'blackhole', desc: 'A roaming gravity anomaly pulls ships off course.', reward: 0.15, difficulty: 1 },
  glass:       { name: 'Glass Cannons',      icon: 'crystal_red', desc: 'Everyone deals double damage.', reward: 0.25, difficulty: 2 },
  ironclad:    { name: 'Ironclad',           icon: 'crate_metal', desc: 'Enemies are armored variants.', reward: 0.2, difficulty: 2 },
};

export const OPTIONAL_OBJECTIVES = {
  nohull:    { name: 'Untouchable',   desc: 'Finish without taking hull damage.', reward: { credits: 250, alloy: 8 } },
  speed:     { name: 'Swift Victory', desc: 'Complete within the par time.', reward: { credits: 200, alloy: 5 } },
  secondary: { name: 'Ordnance Expert', desc: 'Destroy 8 enemies with secondary weapons.', reward: { credits: 180, alloy: 6 } },
  elite:     { name: 'Elite Bounty',  desc: 'Destroy the marked elite.', reward: { credits: 300, cores: 1 } },
  salvage:   { name: 'Scavenger',     desc: 'Collect 25 salvage pickups.', reward: { credits: 150, alloy: 10 } },
  combo:     { name: 'Chain Reaction',desc: 'Reach a x8 combo.', reward: { credits: 220, alloy: 6 } },
  variety:   { name: 'Arsenal',       desc: 'Score kills with 3 different weapons.', reward: { credits: 200, alloy: 6 } },
};

// ---------------------------------------------------------------------------
// CAMPAIGN
// ---------------------------------------------------------------------------
export const CAMPAIGN = [
  { id: 'c1', title: 'First Light', region: 'belt', objective: 'intercept', faction: 'dominion', difficulty: 1,
    brief: 'Commander, the Iron Dominion has crossed the Kessler line. A civilian refinery is in their path. You are the only fighter close enough. Stop them.',
    rival: null, boss: null, optional: ['nohull', 'combo'] },
  { id: 'c2', title: 'Iron Tide', region: 'volcanic', objective: 'colony', faction: 'dominion', difficulty: 1.2,
    brief: 'The Ashkar mining colony is under siege from three vectors. Hold until the evacuation transports clear orbit.',
    optional: ['salvage', 'variety'] },
  { id: 'c3', title: 'Broken Signal', region: 'city', objective: 'comms', faction: 'dominion', difficulty: 1.35,
    brief: 'A Dominion relay in the Halcyon ruins is coordinating the invasion. Black it out before they call the fleet.',
    optional: ['speed', 'secondary'] },
  { id: 'c4', title: 'The Phantom', region: 'graveyard', objective: 'boss', boss: 'phantom', faction: 'syndicate', difficulty: 1.45, phantomRetreat: true,
    brief: 'Syndicate mercenaries are hitting our supply lanes, led by Kaeso Vant — the Phantom. Nobody has survived a duel with him. Be the first.',
    optional: ['nohull'] },
  { id: 'c5', title: 'Veil Raid', region: 'nebula', objective: 'convoy', faction: 'syndicate', difficulty: 1.55,
    brief: 'The Phantom\'s convoy is moving stolen quantum cores through the Veil. Take them. Sensors will be unreliable.',
    optional: ['salvage', 'combo'] },
  { id: 'c6', title: 'Sovereign Wrath', region: 'frontier', objective: 'boss', boss: 'dreadnought', faction: 'dominion', difficulty: 1.7,
    brief: 'The Dominion flagship is in range. Bring down its shields, cripple its engines, and put a torpedo in its reactor.',
    optional: ['speed', 'nohull'] },
  { id: 'c7', title: 'The Hive Wakes', region: 'nebula', objective: 'boss', boss: 'swarmqueen', faction: 'vrell', difficulty: 1.85,
    brief: 'With the Dominion broken, the Vrell Swarm floods into the vacuum. Something enormous commands them from the nebula core.',
    optional: ['combo', 'variety'] },
  { id: 'c8', title: 'Collapse', region: 'city', objective: 'escape', faction: 'vrell', difficulty: 1.95,
    brief: 'The Vrell have hollowed out Halcyon Station. It\'s coming apart. Get through the gates before the core goes critical.',
    optional: ['nohull'] },
  { id: 'c9', title: 'Phantom\'s Return', region: 'graveyard', objective: 'boss', boss: 'phantom', faction: 'syndicate', difficulty: 2.1,
    brief: 'Vant is back — and he has studied you. He\'s waiting in the Boneyard. This time, finish it.',
    optional: ['nohull', 'speed'] },
  { id: 'c10', title: 'Event Horizon', region: 'megastructure', objective: 'boss', boss: 'anomaly', faction: 'choir', difficulty: 2.3,
    brief: 'The source of it all: an intelligence inside the Lattice, pulling every faction toward war. Enter the anomaly. End it.',
    optional: ['combo'] },
];

// ---------------------------------------------------------------------------
// ENDLESS FRONTIER PERKS (run-only, roguelite)
// ---------------------------------------------------------------------------
export const ENDLESS_PERKS = {
  dmg:      { name: 'Overclocked Barrels', icon: 'explosion', desc: '+15% weapon damage.' },
  rate:     { name: 'Rapid Cycler', icon: 'chevron', desc: '+12% fire rate.' },
  hull:     { name: 'Field Repairs', icon: 'heart', desc: 'Restore 50% hull, +15% max hull.' },
  shieldr:  { name: 'Fast Capacitors', icon: 'shield', desc: 'Shields recharge 40% faster.' },
  ammo:     { name: 'Munitions Drop', icon: 'torpedo', desc: 'Refill secondary ammo, +3 capacity.' },
  magnet:   { name: 'Magnetar', icon: 'crate_blue', desc: 'Doubles pickup radius.' },
  crit:     { name: 'Killer Instinct', icon: 'crosshair', desc: '+8% critical chance.' },
  cooling:  { name: 'Cryo Vents', icon: 'fuel', desc: '+30% weapon cooling.' },
  ability:  { name: 'Quick Matrix', icon: 'gear', desc: '-25% ability cooldown.' },
  leech:    { name: 'Vampiric Rounds', icon: 'heart', desc: 'Kills restore 2 hull.' },
  ricochet: { name: 'Ricochet', icon: 'restart', desc: 'Primary bolts bounce to a second target.' },
  greed:    { name: 'Bounty Hunter', icon: 'credits', desc: '+30% credits for the rest of the run, enemies +10% hull.' },
};

// ---------------------------------------------------------------------------
// EXPERIMENTAL ZONE MUTATORS
// ---------------------------------------------------------------------------
export const MUTATORS = {
  giants:    { name: 'Giants', desc: 'Enemies are huge, slow and tough.' },
  tiny:      { name: 'Micro Swarm', desc: 'Enemies are tiny, fast and fragile — and numerous.' },
  roulette:  { name: 'Weapon Roulette', desc: 'Your primary weapon changes every 20 seconds.' },
  curve:     { name: 'Bent Space', desc: 'A central singularity bends every projectile.' },
  bounce:    { name: 'Ricochet Arena', desc: 'Projectiles bounce off the arena boundary.' },
  mirror:    { name: 'Mirror Squadron', desc: 'Enemy pilots fly copies of your ship.' },
  lowgrav:   { name: 'Zero Damping', desc: 'Inertia carries — ships drift like on ice.' },
  glass:     { name: 'Glass Cannons', desc: 'Everyone deals double damage.' },
  vampire:   { name: 'Blood Pact', desc: 'Your shields are disabled, but kills heal you heavily.' },
  chaos:     { name: 'Chaos Factions', desc: 'All four factions fight — including each other.' },
};

// ---------------------------------------------------------------------------
// ACHIEVEMENTS — checked by progression.checkAchievements(stats)
// ---------------------------------------------------------------------------
export const ACHIEVEMENTS = [
  { id: 'first_blood',  name: 'First Blood',       icon: 'rank_1',      desc: 'Destroy your first enemy.', stat: 'kills', goal: 1, reward: { credits: 100 } },
  { id: 'kills_100',    name: 'Ace in the Making', icon: 'rank_2',      desc: 'Destroy 100 enemies.', stat: 'kills', goal: 100, reward: { credits: 400 } },
  { id: 'kills_1000',   name: 'Legend of the Reach', icon: 'rank_3',    desc: 'Destroy 1,000 enemies.', stat: 'kills', goal: 1000, reward: { credits: 2000, cores: 2 } },
  { id: 'mission_1',    name: 'Wings Earned',      icon: 'emblem_eagle',desc: 'Complete a mission.', stat: 'missionsWon', goal: 1, reward: { credits: 150 } },
  { id: 'mission_25',   name: 'Veteran',           icon: 'rank_laurel', desc: 'Complete 25 missions.', stat: 'missionsWon', goal: 25, reward: { credits: 1500, alloy: 30 } },
  { id: 'boss_1',       name: 'Giant Slayer',      icon: 'rank_skull',  desc: 'Defeat a boss.', stat: 'bossKills', goal: 1, reward: { cosmetic: 'emblem_skull' } },
  { id: 'boss_all',     name: 'Nemesis of All',    icon: 'rank_crown',  desc: 'Defeat all four main bosses.', stat: 'uniqueBosses', goal: 4, reward: { cosmetic: 'paint_solargold' } },
  { id: 'campaign',     name: 'Event Horizon',     icon: 'galaxy',      desc: 'Complete the campaign.', stat: 'campaignDone', goal: 1, reward: { cores: 5, cosmetic: 'engine_white' } },
  { id: 'combo_10',     name: 'Chain Reaction',    icon: 'lightning',   desc: 'Reach a x10 combo.', stat: 'bestCombo', goal: 10, reward: { cosmetic: 'trail_ember' } },
  { id: 'combo_25',     name: 'Unstoppable',       icon: 'energy',      desc: 'Reach a x25 combo.', stat: 'bestCombo', goal: 25, reward: { cosmetic: 'weapon_gold' } },
  { id: 'endless_10',   name: 'Frontier Survivor', icon: 'endless',     desc: 'Reach wave 10 in Endless Frontier.', stat: 'bestWave', goal: 10, reward: { credits: 800, alloy: 15 } },
  { id: 'endless_25',   name: 'Eternal',           icon: 'rank_diamond',desc: 'Reach wave 25 in Endless Frontier.', stat: 'bestWave', goal: 25, reward: { cosmetic: 'emblem_prism' } },
  { id: 'ships_3',      name: 'Fleet Admiral',     icon: 'ships',       desc: 'Own 3 ships.', stat: 'shipsOwned', goal: 3, reward: { credits: 600 } },
  { id: 'ships_all',    name: 'Full Hangar',       icon: 'hangar',      desc: 'Own every ship.', stat: 'shipsOwned', goal: 6, reward: { cores: 3 } },
  { id: 'cosmetic_15',  name: 'Fashion Forward',   icon: 'customize',   desc: 'Collect 15 cosmetics.', stat: 'cosmeticsOwned', goal: 15, reward: { cosmetic: 'pattern_hazard' } },
  { id: 'upgrade_max',  name: 'Fully Tuned',       icon: 'upgrades',    desc: 'Max out any upgrade branch.', stat: 'maxBranch', goal: 5, reward: { cores: 1 } },
  { id: 'nohull',       name: 'Untouchable',       icon: 'shield',      desc: 'Win a mission without hull damage.', stat: 'flawless', goal: 1, reward: { credits: 500 } },
  { id: 'streak_7',     name: 'Regular',           icon: 'daily',       desc: 'Reach a 7-day login streak.', stat: 'bestStreak', goal: 7, reward: { cosmetic: 'emblem_crown' } },
  { id: 'daily_ch',     name: 'Daily Contender',   icon: 'leaderboards',desc: 'Complete a daily challenge.', stat: 'dailyChallenges', goal: 1, reward: { credits: 300 } },
  { id: 'event_1',      name: 'Festive Pilot',     icon: 'events',      desc: 'Complete an event mission.', stat: 'eventMissions', goal: 1, reward: { tokens: 10 } },
  { id: 'aces_5',       name: 'Ace Hunter',        icon: 'emblem_phoenix', desc: 'Destroy 5 named aces.', stat: 'aceKills', goal: 5, reward: { cores: 2 } },
  { id: 'discovery',    name: 'Xenoarchaeologist', icon: 'crate_metal', desc: 'Make 3 rare discoveries.', stat: 'discoveries', goal: 3, reward: { cosmetic: 'emblem_alien' } },
  { id: 'secondary_50', name: 'Ordnance Officer',  icon: 'torpedo',     desc: 'Destroy 50 enemies with secondaries.', stat: 'secondaryKills', goal: 50, reward: { credits: 700 } },
  { id: 'experimental', name: 'Mad Scientist',     icon: 'help',        desc: 'Win an Experimental Zone run.', stat: 'experimentalWins', goal: 1, reward: { credits: 500, cores: 1 } },
  { id: 'bossrush',     name: 'Gauntlet',          icon: 'bossrush',    desc: 'Complete a Boss Rush.', stat: 'bossRushWins', goal: 1, reward: { cores: 3 } },
  { id: 'level_10',     name: 'Commander',         icon: 'rank_star',   desc: 'Reach pilot level 10.', stat: 'level', goal: 10, reward: { credits: 1000 } },
  { id: 'level_20',     name: 'Wing Commander',    icon: 'rank_crown',  desc: 'Reach pilot level 20.', stat: 'level', goal: 20, reward: { cores: 4 } },
];

// ---------------------------------------------------------------------------
// LEVEL MILESTONES
// ---------------------------------------------------------------------------
export function xpForLevel(level) { // XP needed to go from `level` to `level+1`
  return Math.round(400 + (level - 1) * 260 + Math.pow(level - 1, 1.6) * 40);
}
export const MAX_LEVEL = 50;
export const LEVEL_REWARDS = {
  2: { credits: 300 }, 3: { credits: 400, alloy: 10 }, 4: { credits: 500 }, 5: { alloy: 20, cores: 1 },
  6: { credits: 600 }, 7: { credits: 600, alloy: 15 }, 8: { cores: 1 }, 9: { credits: 800 }, 10: { credits: 1000, cores: 2 },
  12: { alloy: 40 }, 14: { cores: 2 }, 15: { cosmetic: 'pattern_split' }, 18: { cores: 2 }, 20: { cosmetic: 'paint_onyx' },
  25: { cores: 5 }, 30: { cosmetic: 'paint_void' },
};

// Daily login reward table (7-day cycle; days beyond 7 repeat with growing bonus)
export const DAILY_REWARDS = [
  { credits: 200 },
  { credits: 300, alloy: 5 },
  { credits: 350, alloy: 8 },
  { credits: 400, cores: 1 },
  { credits: 500, alloy: 12 },
  { credits: 600, alloy: 15, boost: 'xp2' },
  { credits: 800, cores: 2, cosmeticPool: ['paint_jungle', 'engine_crimson', 'pattern_tiger', 'emblem_crown'] },
];
