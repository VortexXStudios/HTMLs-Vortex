// ============================================================================
// Multi-phase boss encounters. Each boss is a controller that owns a model,
// one or more damageable Units (weak points, proxies) and phase logic.
// ============================================================================
import * as THREE from 'three';
import { BOSSES } from './data.js';
import { buildDreadnought, buildSwarmQueen, buildPhantom, buildAnomaly, buildHollowWarden, buildUnit } from './models.js';
import { hexTexture } from './textures.js';

const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3(), tmp3 = new THREE.Vector3();
const UP = new THREE.Vector3(0, 1, 0);

function bubbleMesh(radius, color) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(radius, 40, 24), new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(1.1), map: hexTexture(), transparent: true, opacity: 0.1, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.FrontSide, toneMapped: false }));
  return m;
}

class BossBase {
  constructor(game, id, opts = {}) {
    this.game = game; this.id = id; this.def = BOSSES[id];
    this.diff = opts.difficulty || 1;
    this.phase = 0; this.time = 0; this.dying = -1; this.defeated = false; this.retreated = false;
    this.units = [];
    this.variant = opts.variant || null;
    this.event = opts.event || null;
  }
  get name() { return this.def.name; }
  hpMult() { return this.diff * this.game.bossHpMult; }
  addPart(mesh, opts) {
    const g = this.game;
    const u = g.spawnUnit('part', { mesh, part: true, parentBoss: this, team: 'enemy', faction: this.def.faction, hpMult: 1, ...opts });
    this.units.push(u);
    return u;
  }
  setPhase(i, announce = true) {
    if (this.phase === i) return;
    this.phase = i;
    if (announce) {
      this.game.hud.banner(this.def.phases[i] || '', `${this.def.name} — Phase ${i + 1}`, 2.4);
      this.game.audio.play('alert');
      this.game.effects.addShake(0.6);
    }
  }
  hpFrac() { return 1; }
  phaseName() { return this.def.phases[this.phase] || ''; }
  startDeath(pos) {
    if (this.dying >= 0) return;
    this.dying = 0;
    this.game.hud.banner('TARGET DESTROYED', this.def.name, 3);
    this.game.audio.play('explosionBoss');
    for (const u of this.units) if (u.alive) this.game.removeUnit(u, 'boss-dead');
    this.game.projectiles.clearTeam('enemy');
  }
  updateDeath(dt, center, extent) {
    const g = this.game;
    this.dying += dt;
    if (Math.random() < 0.35) {
      tmp.set((Math.random() - 0.5) * extent.x, (Math.random() - 0.5) * extent.y, (Math.random() - 0.5) * extent.z).applyQuaternion(this.group.quaternion).add(center);
      g.effects.explosion(tmp, 1.5 + Math.random() * 2.5, Math.random() < 0.5 ? '#ffaa44' : '#ff6a2a');
      g.effects.addShake(0.3);
      if (Math.random() < 0.4) g.audio.play('explosionL', { pos: tmp });
    }
    if (this.dying > 3.2 && !this.defeated) {
      this.defeated = true;
      g.effects.explosion(center, 9, '#ffd8a0');
      g.effects.ring(center, 400, '#ffd8a0', 1.4);
      g.effects.flash(center, 160, '#ffffff', 0.6);
      g.effects.addShake(2);
      g.audio.play('explosionBoss');
      this.group.visible = false;
      g.onBossDefeated(this);
    }
  }
  dispose() {
    if (this.group) {
      this.game.scene.remove(this.group);
      this.group.traverse(o => { if (o.geometry && o.userData.own) o.geometry.dispose(); });
    }
  }
}

// ===========================================================================
// THE DREADNOUGHT
// ===========================================================================
export class Dreadnought extends BossBase {
  constructor(game, opts) {
    super(game, 'dreadnought', opts);
    const m = buildDreadnought(this.variant);
    this.group = m.group; this.parts = m.parts; this.mats = m.mats;
    this.group.position.set(0, -40, 520);
    this.group.lookAt(0, -40, 0);
    game.scene.add(this.group);
    this.group.updateMatrixWorld(true);
    const H = this.hpMult();
    this.gens = this.parts.gens.map((mesh, i) => this.addPart(mesh, { name: 'Shield Generator', hp: 700 * H, radius: 16, onDeath: () => this._genDown(i), marker: 'GEN' }));
    this.turrets = this.parts.turrets.map(mesh => this.addPart(mesh, { name: 'Battery Turret', hp: 420 * H, shield: 100 * H, radius: 13, behavior: 'part' }));
    this.engines = this.parts.engines.map((mesh, i) => this.addPart(mesh, { name: 'Main Engine', hp: 1600 * H, radius: 24, invulnerable: true, onDeath: () => this._engineDown(i) }));
    this.reactor = this.addPart(this.parts.reactor, { name: 'Reactor Core', hp: 3000 * H, radius: 20, invulnerable: true, untargetable: true, onDeath: () => this.startDeath(this.group.position) });
    this.reactor.untargetable = true;
    // armored hull proxies (deflect shots, teach players to hit weak points)
    this.hull = [];
    for (let i = 0; i < 5; i++) {
      const anchor = new THREE.Object3D(); anchor.position.set(0, 0, -120 + i * 60); this.group.add(anchor);
      const u = this.addPart(anchor, { name: 'Armored Hull', hp: 1e9, radius: 32, armored: true });
      u.armored = true; this.hull.push(u);
    }
    this.bubble = bubbleMesh(220, this.variant === 'cryo' ? '#9fe6ff' : '#ff7a5a');
    this.group.add(this.bubble);
    this.launchT = 12; this.beamT = 8; this.beam = null; this.lastLight = -1; this.pulseT = 0;
    this.extent = new THREE.Vector3(120, 40, 300);
  }
  _genDown() {
    const g = this.game;
    g.effects.explosion(this.gens.find(x => !x.alive)?.pos || this.group.position, 3, '#ff9a5a');
    const left = this.gens.filter(x => x.alive).length;
    g.hud.toast(left ? `SHIELD GENERATOR DESTROYED — ${left} REMAIN` : 'SHIELDS DOWN — HIT THE ENGINES', 'good', 2);
    if (!left) {
      this.bubble.visible = false;
      g.effects.ring(this.group.position, 260, '#ff9a5a', 1);
      g.audio.play('shieldBreak');
      for (const e of this.engines) e.invulnerable = false;
      this.setPhase(1);
    }
  }
  _engineDown(i) {
    const g = this.game;
    const e = this.parts.engines[i];
    e.userData.flame.visible = false;
    const left = this.engines.filter(x => x.alive).length;
    g.hud.toast(left ? 'ENGINE DESTROYED' : 'ENGINES DOWN — REACTOR EXPOSED', 'good', 2);
    if (!left) {
      this.reactor.invulnerable = false; this.reactor.untargetable = false;
      this.reactor.marker = 'REACTOR'; this.game.hud.trackUnit(this.reactor);
      for (const h of this.hull) h.untargetable = true; // hatches open: armor no longer shields the core
      this.setPhase(2);
    }
  }
  hpFrac() {
    const sum = (arr) => arr.reduce((a, u) => a + Math.max(0, u.hp) / u.maxHp, 0);
    const p = (sum(this.gens) / 4) * 0.3 + (sum(this.engines) / 2) * 0.3 + (Math.max(0, this.reactor.hp) / this.reactor.maxHp) * 0.4;
    return p;
  }
  update(dt) {
    const g = this.game, P = g.player;
    this.time += dt;
    if (this.dying >= 0) { this.updateDeath(dt, this.group.position, this.extent); return; }
    // slow broadside drift
    this.group.position.x = Math.sin(this.time * 0.05) * 120;
    this.group.rotation.y = Math.PI + Math.sin(this.time * 0.04) * 0.25;
    this.group.updateMatrixWorld(true);
    this.bubble.rotation.y += dt * 0.1; this.bubble.material.opacity = 0.08 + Math.sin(this.time * 2) * 0.03;
    // hatches open in phase 3
    if (this.phase >= 2) for (const h of this.parts.hatches) h.position.x += (h.userData.side * 40 - h.position.x) * dt;
    if (this.phase >= 2) this.reactor.mesh.rotation.y += dt * (this.lastLight >= 0 ? 4 : 1);
    // turrets track and fire
    const rate = this.phase >= 2 ? 1.6 : 1;
    for (const t of this.turrets) {
      if (!t.alive || !P.alive) continue;
      t.ai.cd -= dt * rate;
      tmp.copy(P.pos).sub(t.pos);
      if (t.ai.cd <= 0 && tmp.length() < 900) {
        t.ai.cd = 1.4 + Math.random();
        for (let k = 0; k < 3; k++) {
          const from = t.pos.clone().add(new THREE.Vector3(0, 8, 0));
          const aim = P.pos.clone().addScaledVector(P.vel, from.distanceTo(P.pos) / 420).sub(from).normalize();
          aim.x += (Math.random() - 0.5) * 0.06; aim.y += (Math.random() - 0.5) * 0.06;
          g.projectiles.spawn({ kind: 'bolt', team: 'enemy', pos: from, vel: aim.normalize().multiplyScalar(420), life: 3, dmg: 8 * g.enemyDamageMult, radius: 1.8, size: 1.6, len: 6, color: this.variant === 'cryo' ? '#9fe6ff' : '#ff5a3c', source: t, chill: this.variant === 'cryo' });
        }
        g.audio.play('enemyShot', { pos: t.pos, volume: 0.6 });
      }
    }
    // fighter launches
    this.launchT -= dt;
    if (this.launchT <= 0) {
      this.launchT = this.phase >= 2 ? 14 : 22;
      const bay = tmp.set(0, -10, 150).applyMatrix4(this.group.matrixWorld).clone();
      for (let k = 0; k < 4; k++) g.spawnUnit(k % 2 ? 'interceptor' : 'swarm', { pos: bay.clone().add(new THREE.Vector3(k * 12 - 18, 0, 0)), faction: 'dominion', variant: this.variant === 'cryo' ? 'frost' : null });
      g.hud.toast('FIGHTERS LAUNCHED', 'warn', 1.4);
    }
    // phase 2+: sweeping beam batteries (telegraphed)
    if (this.phase >= 1) this._updateBeam(dt);
    // Last Light — desperate final attack
    if (this.phase >= 2 && this.reactor.alive && this.reactor.hp / this.reactor.maxHp < 0.25) {
      if (this.lastLight < 0) { this.lastLight = 7; this.setPhase(3); g.hud.warn('REACTOR OVERLOAD — GET 450m CLEAR!', 7); g.audio.loop('alarm', true, { volume: 0.06 }); }
    }
    if (this.lastLight > 0) {
      this.lastLight -= dt;
      const s = 1 + (7 - this.lastLight) * 0.4;
      this.reactor.mesh.scale.setScalar(s);
      if (Math.random() < 0.4) g.effects.sparks(this.reactor.pos, '#ffcc66', 3, 120, 3, 0.6);
      if (this.lastLight <= 0) {
        g.audio.loop('alarm', false);
        g.effects.explosion(this.reactor.pos, 6, '#ffdd88', { debris: false });
        g.effects.ring(this.reactor.pos, 450, '#ffcc66', 1.2);
        g.damageArea(this.reactor.pos, 450, 90 * g.enemyDamageMult, 'enemy', { falloff: 0.3 });
        g.effects.addShake(2);
        this.lastLight = -2; this.pulseT = 18;
        this.reactor.mesh.scale.setScalar(1);
      }
    }
    if (this.lastLight === -2) { this.pulseT -= dt; if (this.pulseT <= 0) { this.lastLight = 7; g.hud.warn('REACTOR OVERLOAD — GET 450m CLEAR!', 7); g.audio.loop('alarm', true, { volume: 0.06 }); } }
  }
  _updateBeam(dt) {
    const g = this.game, P = g.player;
    this.beamT -= dt;
    if (!this.beam && this.beamT <= 0 && P.alive) {
      const origin = tmp.set(0, 20, 140).applyMatrix4(this.group.matrixWorld).clone();
      const side = new THREE.Vector3().crossVectors(UP, P.pos.clone().sub(origin).normalize()).normalize();
      this.beam = { origin, t: 0, from: P.pos.clone().addScaledVector(side, -200), to: P.pos.clone().addScaledVector(side, 200) };
      g.hud.warn('BEAM BATTERY CHARGING', 2);
      g.audio.play('sniperCharge', { pos: origin });
    }
    if (this.beam) {
      const b = this.beam; b.t += dt;
      const sweep = Math.min(1, Math.max(0, (b.t - 2) / 1.6));
      const aim = tmp2.lerpVectors(b.from, b.to, b.t < 2 ? 0 : sweep);
      const dir = tmp3.copy(aim).sub(b.origin).normalize();
      const end = b.origin.clone().addScaledVector(dir, 1300);
      if (b.t < 2) {
        g.effects.sight(b.origin, end, '#ff3a2a', 0.3 + b.t * 0.3);
        g.effects.sight(b.origin, tmp.lerpVectors(b.from, b.to, 1).sub(b.origin).normalize().multiplyScalar(1300).add(b.origin), '#ff3a2a', 0.25);
      } else {
        g.effects.beam(b.origin, end, this.variant === 'cryo' ? '#9fe6ff' : '#ff5a3c', 6, dt * 2);
        g.effects.beam(b.origin, end, '#ffffff', 2, dt * 2);
        g.audio.loop('beam', true, { volume: 0.15 });
        // segment distance to player
        const ap = tmp.copy(P.pos).sub(b.origin); const t = Math.max(0, Math.min(1300, ap.dot(dir)));
        const closest = b.origin.clone().addScaledVector(dir, t);
        if (P.alive && closest.distanceTo(P.pos) < 14 + P.radius) g.damagePlayer(70 * dt * g.enemyDamageMult, { pos: closest });
        if (b.t > 3.6) { this.beam = null; this.beamT = this.phase >= 2 ? 7 : 10; g.audio.loop('beam', false); }
      }
    }
  }
  dispose() { this.game.audio.loop('alarm', false); this.bubble.geometry.dispose(); this.bubble.material.dispose(); super.dispose(); }
}

// ===========================================================================
// THE SWARM QUEEN
// ===========================================================================
class QueenRing {
  constructor(queen, count, radius, tilt) { this.queen = queen; this.count = count; this.radius = radius; this.tilt = tilt; this.broken = false; this.time = 0; this.vel = new THREE.Vector3(); this.heading = new THREE.Vector3(0, 0, -1); this.target = queen.game.player; this.members = []; }
  slotPos(i, out) {
    const a = i / this.count * Math.PI * 2 + this.time * 0.9 * (this.tilt > 0 ? 1 : -1);
    out.set(Math.cos(a) * this.radius, Math.sin(a) * this.radius * Math.cos(this.tilt), Math.sin(a) * this.radius * Math.sin(this.tilt));
    return out.add(this.queen.body.pos);
  }
  isFrontRow(i) { return i % 3 === 0; }
  update(dt) { this.time += dt; this.heading.copy(this.queen.game.player.pos).sub(this.queen.body.pos).normalize(); }
  break() { this.broken = true; for (const m of this.members) if (m.formation === this) m.formation = null; }
}

export class SwarmQueen extends BossBase {
  constructor(game, opts) {
    super(game, 'swarmqueen', opts);
    const m = buildSwarmQueen(this.event);
    this.group = m.group; this.parts = m.parts;
    this.group.position.set(0, 20, 450); this.group.lookAt(0, 20, 0);
    game.scene.add(this.group); this.group.updateMatrixWorld(true);
    const H = this.hpMult();
    const anchor = new THREE.Object3D(); anchor.position.set(0, 0, 0); this.group.add(anchor);
    this.body = this.addPart(anchor, { name: this.def.name, hp: 7000 * H, radius: 42, faction: 'vrell', onDeath: () => this.startDeath(this.group.position) });
    this.body.bossMain = true;
    const tail = new THREE.Object3D(); tail.position.set(0, 0, -45); this.group.add(tail);
    this.tail = this.addPart(tail, { name: this.def.name, radius: 36, hp: 1e9 }); this.tail.proxy = this.body; this.tail.proxyMult = 0.6;
    const head = new THREE.Object3D(); head.position.set(0, 8, 34); this.group.add(head);
    this.head = this.addPart(head, { name: this.def.name, radius: 16, hp: 1e9 }); this.head.proxy = this.body; this.head.proxyMult = 1.5;
    this.rings = []; this.ringT = 2; this.sporeT = 5; this.nodes = []; this.vulnT = 0; this.dash = null; this.dashT = 8;
    this.bubble = bubbleMesh(70, '#a6ff3c'); this.bubble.visible = false; this.group.add(this.bubble);
    this.extent = new THREE.Vector3(60, 40, 120);
    this.home = this.group.position.clone();
  }
  hpFrac() { return Math.max(0, this.body.hp) / this.body.maxHp; }
  _spawnRing(count, radius, tilt) {
    const g = this.game;
    const r = new QueenRing(this, count, radius, tilt);
    for (let i = 0; i < count; i++) {
      const u = g.spawnUnit('swarm', { pos: r.slotPos(i, new THREE.Vector3()), faction: 'vrell', variant: this.event === 'spring' ? 'bloom' : null });
      u.formation = r; u.slot = i; r.members.push(u);
    }
    this.rings.push(r);
    g.effects.ring(this.body.pos, radius, '#a6ff3c', 0.6);
  }
  _spawnNodes(n) {
    const g = this.game;
    for (let i = 0; i < n; i++) {
      const a = i / n * Math.PI * 2 + Math.random();
      const pos = this.body.pos.clone().add(new THREE.Vector3(Math.cos(a) * 170, (Math.random() - 0.5) * 80, Math.sin(a) * 170));
      const u = g.spawnUnit('shieldgen', { pos, faction: 'vrell', name: 'Hive Node', hp: 500 * this.hpMult(), marker: 'NODE', tint: '#a6ff3c' });
      this.nodes.push(u);
    }
    g.hud.toast('HIVE NODES SHIELD THE QUEEN — DESTROY THEM', 'warn', 2.5);
  }
  update(dt) {
    const g = this.game, P = g.player;
    this.time += dt;
    if (this.dying >= 0) { this.updateDeath(dt, this.group.position, this.extent); return; }
    const f = this.hpFrac();
    if (this.phase === 0 && f < 0.65) { this.setPhase(1); this._spawnNodes(3); for (const r of this.rings) r.break(); }
    if (this.phase === 1 && f < 0.3) { this.setPhase(2); }
    // wing flutter and core pulse
    for (const [i, w] of this.parts.wings.entries()) w.rotation.z = Math.sin(this.time * (this.phase === 2 ? 18 : 9)) * 0.25 * (i ? 1 : -1);
    const s = 1 + Math.sin(this.time * 4) * 0.08; this.parts.core.scale.setScalar(s);
    for (const p of this.parts.plates) p.rotation.z = this.phase === 2 ? 0.6 : 0;
    // movement
    if (this.dash) {
      const d = this.dash; d.t += dt;
      if (d.t < 1.2) { g.effects.sight(this.body.pos, d.end, '#a6ff3c', 0.3 + d.t * 0.4); }
      else {
        tmp.copy(d.end).sub(this.group.position); const dist = tmp.length();
        if (dist > 20 && d.t < 3) { this.group.position.addScaledVector(tmp.normalize(), Math.min(dist, 620 * dt)); if (P.alive && P.pos.distanceTo(this.body.pos) < 55) { g.damagePlayer(40 * g.enemyDamageMult, { pos: this.body.pos }); P.vel.addScaledVector(tmp, 300); } }
        else { this.dash = null; this.dashT = 7; }
      }
    } else {
      const want = tmp.copy(P.pos).sub(this.group.position); const d = want.length();
      const keep = this.phase === 2 ? 220 : 360;
      if (d > keep) this.group.position.addScaledVector(want.normalize(), Math.min(40, d - keep) * dt);
      this.group.position.y += Math.sin(this.time * 0.6) * 6 * dt;
      tmp2.copy(P.pos); this.group.lookAt(tmp2);
    }
    this.group.updateMatrixWorld(true);
    // rings of drones
    for (const r of this.rings) r.update(dt);
    this.rings = this.rings.filter(r => !r.broken && r.members.some(m => m.alive));
    this.ringT -= dt;
    if (this.ringT <= 0) {
      this.ringT = this.phase === 0 ? 14 : 18;
      if (this.rings.length < 2) this._spawnRing(this.phase === 0 ? 10 : 8, 90 + this.rings.length * 40, this.rings.length ? 0.8 : -0.4);
      else { this.rings[0].break(); g.hud.toast('THE BROOD ATTACKS', 'warn', 1.2); }
    }
    // spore volleys
    this.sporeT -= dt;
    if (this.sporeT <= 0 && P.alive) {
      this.sporeT = this.phase === 2 ? 3.5 : 6;
      const n = this.phase === 2 ? 10 : 7;
      for (let k = 0; k < n; k++) {
        const v = P.pos.clone().sub(this.body.pos).normalize().add(new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(0.9)).normalize().multiplyScalar(150);
        g.projectiles.spawn({ kind: 'orb', team: 'enemy', pos: this.parts.eyes[0].getWorldPosition(new THREE.Vector3()), vel: v, life: 6, dmg: 12 * g.enemyDamageMult, radius: 2.6, size: 2.8, color: this.event === 'spring' ? '#ff8fd0' : '#a6ff3c', target: P, turn: 0.9, splash: 12, splashDmg: 8, spore: true, source: this.body });
      }
      g.audio.play('enemyHeavy', { pos: this.body.pos });
    }
    // phase 2: shielded by hive nodes
    if (this.phase >= 1) {
      this.nodes = this.nodes.filter(n => n.alive);
      const shielded = this.nodes.length > 0;
      this.body.invulnerable = shielded; this.bubble.visible = shielded;
      if (shielded) { this.bubble.rotation.y += dt; for (const n of this.nodes) if (Math.random() < 0.15) g.effects.beam(n.pos, this.body.pos, '#a6ff3c', 0.5, 0.1); }
      else { this.vulnT += dt; if (this.vulnT > 20 && this.phase === 1) { this.vulnT = 0; this._spawnNodes(2); } }
    }
    // phase 3: evolved — dash attacks and kamikaze broods
    if (this.phase === 2 && !this.dash) {
      this.dashT -= dt;
      if (this.dashT <= 0 && P.alive) {
        const end = P.pos.clone().addScaledVector(P.vel, 1.2);
        this.dash = { t: 0, end };
        g.hud.warn('THE QUEEN IS CHARGING', 1.2);
        g.audio.play('bossIntro', { volume: 0.5 });
        for (let k = 0; k < 3; k++) g.spawnUnit('kamikaze', { pos: this.body.pos.clone().add(new THREE.Vector3(k * 20 - 20, 20, 0)), faction: 'vrell' });
      }
    }
  }
  dispose() { for (const r of this.rings) r.break(); this.bubble.geometry.dispose(); this.bubble.material.dispose(); super.dispose(); }
}

// ===========================================================================
// THE PHANTOM ACE — duelist who adapts to your tactics
// ===========================================================================
export class PhantomAce extends BossBase {
  constructor(game, opts) {
    super(game, 'phantom', opts);
    this.retreatMode = !!opts.retreat;
    this.returning = !!opts.returning;
    const m = buildPhantom();
    this.group = m.group;
    this.group.position.set(0, 40, 500);
    game.scene.add(this.group);
    const H = this.hpMult() * (this.returning ? 1.2 : 1);
    this.main = game.spawnUnit('ace', { mesh: this.group, faction: 'syndicate', name: 'Kaeso Vant', hp: 2600 * H, shield: 900 * H, radius: 14, boss: true, behavior: 'part', onDeath: () => this.startDeath(this.group.position.clone()) });
    this.main.speed = 210; this.main.accel = 320; this.main.turn = 3.4;
    this.units.push(this.main);
    this.decoys = []; this.bladeT = 6; this.adaptT = 12; this.flareT = 0; this.cloakT = 0; this.cloaked = 0; this.jinkMult = 1; this.mode = 'duel';
    this.adapt = { flares: false, jink: false, close: false, keep: false };
    this.extent = new THREE.Vector3(20, 8, 20);
    this.burstCd = 1; this.burst = 0;
    if (this.returning) { this.adapt.jink = true; this.jinkMult = 1.6; }
  }
  hpFrac() { return Math.max(0, this.main.hp) / this.main.maxHp; }
  update(dt) {
    const g = this.game, P = g.player, u = this.main;
    this.time += dt;
    if (this.dying >= 0) { this.updateDeath(dt, this.group.position, this.extent); return; }
    if (this.retreated) return;
    const f = this.hpFrac();
    if (this.retreatMode && f < 0.5) { this._retreat(); return; }
    if (this.phase === 0 && f < 0.6) { this.setPhase(1); this._spawnDecoys(3); }
    if (this.phase === 1 && f < 0.25) { this.setPhase(2); }
    // --- adaptive analysis of how the player fights
    this.adaptT -= dt;
    if (this.adaptT <= 0) { this.adaptT = 14; this._adapt(); }
    // --- movement: evasive duelist
    const to = tmp.copy(P.pos).sub(u.pos); const d = to.length(); to.divideScalar(d || 1);
    let ideal = this.adapt.close ? 160 : this.adapt.keep ? 480 : 320;
    const radial = d > ideal + 60 ? 1 : d < ideal - 60 ? -1 : 0;
    const want = tmp2.copy(to).multiplyScalar(radial * u.speed);
    const side = tmp3.copy(to).cross(UP).normalize().multiplyScalar(Math.sin(this.time * 1.3) * u.speed * 0.9);
    want.add(side); want.y += Math.cos(this.time * 0.9) * u.speed * 0.5;
    u.steer(want, dt, to.clone());
    // jinks when you line up a shot
    u.ai.jinkCd -= dt;
    tmp3.copy(u.pos).sub(P.pos).normalize();
    if (u.ai.jinkCd <= 0 && tmp3.dot(P.forward) > 0.985 && d < 800) { const tj = g.tune ? g.tune.jink : 1; u.vel.addScaledVector(new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).cross(u.forward).normalize(), 260 * this.jinkMult * (0.5 + 0.5 * tj)); u.ai.jinkCd = ((this.adapt.jink ? 0.5 : 1.1) + Math.random() * 0.5) / Math.max(0.45, tj); g.effects.trailPuff(u.pos, '#ff2a4a', 3, 0.3); }
    this.group.updateMatrixWorld(true);
    // --- weapons: bursts + phantom blades (bolt walls)
    if (this.cloaked <= 0) {
      this.burstCd -= dt;
      if (this.burst > 0) { this.burstT -= dt; if (this.burstT <= 0) { this.burst--; this.burstT = 0.07; u.fire(P, { weapon: { dmg: 7, speed: 560, spread: 0.02 }, dmg: 7, color: '#ff2a4a' }); } }
      else if (this.burstCd <= 0 && u.inFront(P.pos, 0.9) && d < 650) { this.burst = 8; this.burstT = 0; this.burstCd = 2 + Math.random(); }
      this.bladeT -= dt;
      if (this.bladeT <= 0 && d < 700) {
        this.bladeT = this.phase >= 1 ? 5 : 7.5;
        const right = new THREE.Vector3().crossVectors(UP, to).normalize();
        const tilt = Math.random() < 0.5 ? right : new THREE.Vector3().crossVectors(to, right).normalize();
        for (let k = -4; k <= 4; k++) {
          if (k === Math.round(Math.random() * 6 - 3)) continue; // always leave a gap to slip through
          const from = u.pos.clone().addScaledVector(tilt, k * 9);
          g.projectiles.spawn({ kind: 'bolt', team: 'enemy', pos: from, vel: to.clone().multiplyScalar(360), life: 3, dmg: 14 * g.enemyDamageMult, radius: 2.2, size: 2, len: 6, color: '#ff2a4a', source: u });
        }
        g.audio.play('enemyHeavy', { pos: u.pos });
      }
    }
    // --- flares vs missiles
    if (this.adapt.flares) {
      this.flareT -= dt;
      if (this.flareT <= 0) {
        let decoyed = false;
        for (const pool of Object.values(g.projectiles.pools)) for (const p of pool) if (p.active && p.team === 'player' && p.kind === 'missile' && p.target && (p.target === u || this.decoys.includes(p.target)) && p.pos.distanceTo(u.pos) < 200) { p.target = null; p.turn = 0; decoyed = true; }
        if (decoyed) { this.flareT = 3; for (let k = 0; k < 6; k++) g.effects.sparks(u.pos, '#ffd27a', 4, 100, 2.4, 1.2); g.audio.play('dash', { pos: u.pos }); }
      }
    }
    // --- mirror images
    this.decoys = this.decoys.filter(x => x.alive);
    for (const dcy of this.decoys) {
      const a = this.time * 1.2 + dcy.ai.phase;
      const slot = tmp.set(Math.cos(a) * 60, Math.sin(a * 1.4) * 30, Math.sin(a) * 60).add(u.pos);
      dcy.steer(slot.sub(dcy.pos).multiplyScalar(3), dt, P.pos.clone().sub(dcy.pos));
      dcy.ai.cd -= dt; if (dcy.ai.cd <= 0 && dcy.inFront(P.pos, 0.85)) { dcy.ai.cd = 0.9 + Math.random(); dcy.fire(P, { weapon: { dmg: 3, speed: 500, spread: 0.05 }, dmg: 3, color: '#ff2a4a', sound: false }); }
    }
    if (this.phase >= 1 && this.decoys.length === 0 && Math.random() < dt * 0.08) this._spawnDecoys(2);
    // swap places with a decoy now and then (mind games)
    if (this.decoys.length && Math.random() < dt * 0.12) {
      const dcy = this.decoys[Math.floor(Math.random() * this.decoys.length)];
      const p = u.pos.clone(); u.pos.copy(dcy.pos); dcy.pos.copy(p);
      g.effects.ring(u.pos, 16, '#ff2a4a', 0.3); g.effects.ring(dcy.pos, 16, '#ff2a4a', 0.3); g.audio.play('phase', { pos: u.pos });
    }
    // --- desperation: cloak ambushes
    if (this.phase === 2) {
      if (this.cloaked > 0) {
        this.cloaked -= dt;
        if (this.cloaked <= 0) {
          u.pos.copy(P.pos).addScaledVector(P.forward, -110).addScaledVector(UP, 20);
          this.group.visible = true; u.untargetable = false;
          g.effects.ring(u.pos, 20, '#ff2a4a', 0.4); g.audio.play('phase', { pos: u.pos });
          this.burst = 12; this.burstT = 0.3;
          g.hud.warn('BEHIND YOU!', 1);
        }
      } else {
        this.cloakT -= dt;
        if (this.cloakT <= 0) { this.cloakT = 9; this.cloaked = 2.5; this.group.visible = false; u.untargetable = true; g.audio.play('cloak', { pos: u.pos }); }
      }
    }
  }
  _spawnDecoys(n) {
    const g = this.game;
    for (let k = 0; k < n; k++) {
      const m = buildPhantom().group;
      const dcy = g.spawnUnit('ace', { mesh: m, faction: 'syndicate', name: 'Kaeso Vant', hp: 1, shield: 0, radius: 12, behavior: 'part', score: 100 });
      dcy.pos.copy(this.main.pos).add(new THREE.Vector3(Math.random() * 60 - 30, Math.random() * 30, Math.random() * 60 - 30));
      dcy.isDecoy = true; dcy.ai.cd = 1;
      g.scene.add(m);
      this.decoys.push(dcy);
    }
    g.effects.ring(this.main.pos, 40, '#ff2a4a', 0.5);
    g.hud.toast('MIRROR IMAGES — FIND THE REAL ONE', 'warn', 2);
  }
  _adapt() {
    const g = this.game; const h = g.stats.damageByKind || {};
    const total = Object.values(h).reduce((a, b) => a + b, 0) || 1;
    const msgs = [];
    if ((h.missile || 0) / total > 0.25 && !this.adapt.flares) { this.adapt.flares = true; msgs.push('deploys countermeasure flares'); }
    if (((h.hitscan || 0) + (h.beam || 0)) / total > 0.35 && !this.adapt.jink) { this.adapt.jink = true; this.jinkMult = 1.7; msgs.push('jinks harder against precision fire'); }
    const avgRange = g.stats.avgRange || 300;
    if (avgRange > 420 && !this.adapt.close) { this.adapt.close = true; this.adapt.keep = false; msgs.push('closes to knife-fight range'); }
    else if (avgRange < 200 && !this.adapt.keep) { this.adapt.keep = true; this.adapt.close = false; msgs.push('keeps his distance'); }
    if (msgs.length) g.hud.toast(`THE PHANTOM ADAPTS: ${msgs.join(', ').toUpperCase()}`, 'warn', 3);
  }
  _retreat() {
    const g = this.game;
    this.retreated = true;
    g.hud.banner('"You\'re better than they said."', 'Kaeso Vant warps out — he will be back.', 3.5);
    g.effects.ring(this.main.pos, 40, '#ff2a4a', 0.6); g.effects.flash(this.main.pos, 30, '#ff2a4a', 0.4);
    g.audio.play('phase');
    for (const d of this.decoys) if (d.alive) g.removeUnit(d, 'warp');
    g.removeUnit(this.main, 'warp');
    this.group.visible = false;
    g.onBossRetreat(this);
  }
  dispose() { for (const d of this.decoys) if (d.mesh.parent) d.mesh.parent.remove(d.mesh); super.dispose(); }
}

// ===========================================================================
// THE ANOMALY — manipulates gravity, space and the arena
// ===========================================================================
export class Anomaly extends BossBase {
  constructor(game, opts) {
    super(game, 'anomaly', opts);
    const m = buildAnomaly();
    this.group = m.group; this.parts = m.parts;
    this.group.position.set(0, 0, 380);
    game.scene.add(this.group); this.group.updateMatrixWorld(true);
    const H = this.hpMult();
    const anchor = new THREE.Object3D(); this.group.add(anchor);
    this.core = this.addPart(anchor, { name: this.def.name, hp: 7500 * H, shield: 1200 * H, radius: 34, faction: 'choir', onDeath: () => this.startDeath(this.group.position.clone()) });
    this.core.bossMain = true;
    this.shards = this.parts.shards.map(s => { const u = this.addPart(s, { name: 'Resonance Shard', hp: 350 * H, radius: 11, faction: 'choir' }); return u; });
    this.wells = [];
    for (let i = 0; i < 3; i++) {
      const w = { pos: new THREE.Vector3(), radius: 260, strength: 0.6, a: i / 3 * Math.PI * 2 };
      const vis = new THREE.Mesh(new THREE.SphereGeometry(12, 20, 14), new THREE.MeshBasicMaterial({ color: 0x000000 }));
      const halo = new THREE.Mesh(new THREE.TorusGeometry(22, 2, 6, 40), new THREE.MeshBasicMaterial({ color: new THREE.Color('#b26bff').multiplyScalar(2.4), toneMapped: false }));
      vis.add(halo); vis.userData.own = true; halo.userData.own = true;
      game.scene.add(vis); w.vis = vis; w.halo = halo;
      this.wells.push(w); game.gravityWells.push(w);
    }
    this.shotT = 3; this.teleT = 10; this.riftT = 6; this.pulse = null; this.pulseT = 10;
    this.extent = new THREE.Vector3(60, 60, 60);
  }
  hpFrac() { return Math.max(0, this.core.hp) / this.core.maxHp; }
  update(dt) {
    const g = this.game, P = g.player;
    this.time += dt;
    if (this.dying >= 0) { this.updateDeath(dt, this.group.position, this.extent); return; }
    const f = this.hpFrac();
    if (this.phase === 0 && f < 0.66) {
      this.setPhase(1);
      g.setArenaShrink(650); g.env.setFogMultiplier(2.2); g.flags.drift = true;
      g.hud.toast('SPACE IS FOLDING — MOMENTUM IS UNRELIABLE', 'warn', 2.5);
    }
    if (this.phase === 1 && f < 0.33) { this.setPhase(2); for (const w of this.wells) { w.strength = 1.1; w.radius = 320; } }
    const P0 = this.group.position;
    // crystalline motion
    this.parts.core.rotation.x += dt * 0.3; this.parts.core.rotation.y += dt * 0.4;
    this.parts.inner.rotation.y -= dt * 1.2;
    for (const [i, r] of this.parts.rings.entries()) { r.rotation.x += dt * (0.3 + i * 0.2); r.rotation.y += dt * 0.2; }
    for (const s of this.parts.shards) {
      s.userData.a += dt * 0.6 * (this.phase + 1) * 0.6;
      s.position.set(Math.cos(s.userData.a) * s.userData.r, Math.sin(s.userData.a * 1.3 + s.userData.tilt) * 30, Math.sin(s.userData.a) * s.userData.r);
      s.rotation.y += dt * 2;
    }
    // gravity wells orbit the core
    for (const w of this.wells) {
      w.a += dt * 0.25;
      w.pos.set(Math.cos(w.a) * 300, Math.sin(w.a * 2) * 60, Math.sin(w.a) * 300).add(P0).add(tmp.set(0, 0, -200));
      w.vis.position.copy(w.pos); w.halo.rotation.x += dt * 2; w.halo.rotation.y += dt;
      if (Math.random() < 0.4) g.effects.trailPuff(tmp.copy(w.pos).add(tmp2.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(80)), '#b26bff', 3, 0.8, tmp3.copy(w.pos).sub(tmp).multiplyScalar(1.2));
      // pull the player
      if (P.alive) { tmp.copy(w.pos).sub(P.pos); const d = tmp.length(); if (d < w.radius) P.vel.addScaledVector(tmp.normalize(), w.strength * 90 * dt * (1 - d / w.radius) * 2); if (d < 18) g.damagePlayer(30 * dt, { pos: w.pos, environmental: true }); }
    }
    this.group.updateMatrixWorld(true);
    // shard-protection: each living shard reduces core damage taken
    const alive = this.shards.filter(s => s.alive).length;
    this.core.damageTakenMult = 1 - alive * 0.07;
    // shard beams (telegraphed)
    this.shotT -= dt;
    if (this.shotT <= 0 && P.alive) {
      this.shotT = this.phase === 2 ? 1.2 : 2.2;
      const shooters = this.shards.filter(s => s.alive);
      const s = shooters[Math.floor(Math.random() * shooters.length)] || this.core;
      const from = s.pos.clone();
      const aim = P.pos.clone().addScaledVector(P.vel, 0.6);
      g.effects.sight(from, aim, '#4ff0ff', 0.8);
      setTimeout(() => { if (!this.defeated && this.dying < 0 && g.active) g.projectiles.spawn({ kind: 'bolt', team: 'enemy', pos: from, vel: aim.sub(from).normalize().multiplyScalar(700), life: 2, dmg: 16 * g.enemyDamageMult, radius: 2, size: 2, len: 12, color: '#4ff0ff', source: this.core }); }, 500);
    }
    // phase 2+: teleport & choir reinforcements
    if (this.phase >= 1) {
      this.teleT -= dt;
      if (this.teleT <= 0) {
        this.teleT = 11;
        g.effects.flash(P0, 60, '#4ff0ff', 0.4); g.effects.ring(P0, 120, '#4ff0ff', 0.6);
        P0.set((Math.random() - 0.5) * 500, (Math.random() - 0.5) * 200, (Math.random() - 0.5) * 500);
        g.effects.flash(P0, 60, '#4ff0ff', 0.4); g.audio.play('phase');
        for (let k = 0; k < 2; k++) g.spawnUnit(Math.random() < 0.5 ? 'sniper' : 'shieldcarrier', { pos: P0.clone().add(new THREE.Vector3(k * 50 - 25, 40, 0)), faction: 'choir' });
      }
    }
    // phase 3: rifts spew other factions + gravity pulse rings
    if (this.phase === 2) {
      this.riftT -= dt;
      if (this.riftT <= 0) {
        this.riftT = 9;
        const fac = ['dominion', 'vrell', 'syndicate'][Math.floor(Math.random() * 3)];
        const pos = new THREE.Vector3((Math.random() - 0.5) * 800, (Math.random() - 0.5) * 300, (Math.random() - 0.5) * 800);
        g.effects.ring(pos, 60, '#b26bff', 0.8); g.effects.flash(pos, 40, '#b26bff', 0.4);
        for (let k = 0; k < 4; k++) g.spawnUnit(['interceptor', 'kamikaze', 'swarm', 'stealth'][k], { pos: pos.clone().add(new THREE.Vector3(k * 10, 0, 0)), faction: fac });
        g.hud.toast('A RIFT TEARS OPEN', 'warn', 1.4);
      }
      this.pulseT -= dt;
      if (!this.pulse && this.pulseT <= 0) { this.pulse = { r: 0, hit: false }; g.hud.warn('GRAVITY PULSE — DASH THROUGH IT!', 2); g.audio.play('nova'); }
      if (this.pulse) {
        this.pulse.r += 260 * dt;
        if (Math.random() < 0.5) g.effects.ring(P0, this.pulse.r, '#b26bff', 0.12);
        const d = P.pos.distanceTo(P0);
        if (!this.pulse.hit && Math.abs(d - this.pulse.r) < 12) { this.pulse.hit = true; if (P.invuln <= 0) { g.damagePlayer(35 * g.enemyDamageMult, { pos: P0 }); P.vel.addScaledVector(P.pos.clone().sub(P0).normalize(), 250); } }
        if (this.pulse.r > 900) { this.pulse = null; this.pulseT = 8; }
      }
    }
  }
  dispose() {
    const g = this.game;
    for (const w of this.wells) { g.scene.remove(w.vis); w.vis.geometry.dispose(); w.vis.material.dispose(); w.halo.geometry.dispose(); w.halo.material.dispose(); const i = g.gravityWells.indexOf(w); if (i >= 0) g.gravityWells.splice(i, 1); }
    g.flags.drift = false;
    super.dispose();
  }
}

// ===========================================================================
// THE HOLLOW WARDEN (Halloween event boss)
// ===========================================================================
export class HollowWarden extends BossBase {
  constructor(game, opts) {
    super(game, 'hollow', opts);
    const m = buildHollowWarden();
    this.group = m.group; this.parts = m.parts; this.sailMat = m.sailMat; this.mats = m.mats;
    this.group.position.set(0, 0, 480); this.group.lookAt(0, 0, 0);
    game.scene.add(this.group); this.group.updateMatrixWorld(true);
    const H = this.hpMult();
    const anchor = new THREE.Object3D(); this.group.add(anchor);
    this.body = this.addPart(anchor, { name: this.def.name, hp: 6000 * H, shield: 0, radius: 40, faction: 'syndicate', onDeath: () => this.startDeath(this.group.position.clone()) });
    this.body.bossMain = true;
    for (const z of [-50, 45]) { const a = new THREE.Object3D(); a.position.set(0, 0, z); this.group.add(a); const p = this.addPart(a, { name: this.def.name, hp: 1e9, radius: 30 }); p.proxy = this.body; p.proxyMult = 0.8; }
    this.lanterns = this.parts.lanterns.map(l => this.addPart(l, { name: 'Soul Lantern', hp: 450 * H, radius: 7, marker: 'LANTERN', onDeath: () => this._lanternDown() }));
    this.manifest = true; this.cycle = 10; this.broadT = 3; this.wispT = 4; this.mineT = 6;
    this.extent = new THREE.Vector3(50, 40, 140);
  }
  hpFrac() { return Math.max(0, this.body.hp) / this.body.maxHp; }
  _lanternDown() {
    const lit = this.lanterns.filter(l => l.alive).length;
    this.game.hud.toast(`LANTERN EXTINGUISHED — THE WARDEN WEAKENS (${lit} LEFT)`, 'good', 2);
    this.body.damageTakenMult = 1 + (4 - lit) * 0.25;
  }
  _setManifest(on) {
    const g = this.game;
    this.manifest = on;
    this.body.invulnerable = !on;
    for (const l of this.lanterns) if (l.alive) { l.mesh.visible = on; l.untargetable = !on; }
    this.sailMat.opacity = on ? 0.32 : 0.08;
    this.mats.hull.transparent = true; this.mats.hull.opacity = on ? 1 : 0.25;
    g.effects.ring(this.group.position, 160, '#7dff6a', 0.6);
    g.audio.play(on ? 'bossIntro' : 'cloak', { volume: 0.5 });
    g.hud.toast(on ? 'THE WARDEN MANIFESTS — STRIKE NOW!' : 'THE WARDEN FADES INTO THE VOID', on ? 'good' : 'warn', 1.6);
  }
  update(dt) {
    const g = this.game, P = g.player;
    this.time += dt;
    if (this.dying >= 0) { this.updateDeath(dt, this.group.position, this.extent); return; }
    const f = this.hpFrac();
    if (this.phase === 0 && f < 0.6) this.setPhase(1);
    if (this.phase === 1 && f < 0.25) { this.setPhase(2); g.env.setFogMultiplier(2); }
    this.cycle -= dt;
    if (this.cycle <= 0) { this._setManifest(!this.manifest); this.cycle = this.manifest ? (this.phase === 2 ? 7 : 10) : (this.phase === 2 ? 4 : 6); }
    // drift through the void — faster while faded
    const sp = this.manifest ? 18 : 70;
    const want = tmp.copy(P.pos).sub(this.group.position); const d = want.length();
    if (d > (this.manifest ? 300 : 150)) this.group.position.addScaledVector(want.normalize(), sp * dt);
    this.group.position.y += Math.sin(this.time * 0.8) * 10 * dt;
    const look = tmp2.copy(this.group.position).add(new THREE.Vector3().crossVectors(UP, tmp.copy(P.pos).sub(this.group.position).normalize()));
    this.group.lookAt(look);
    this.group.updateMatrixWorld(true);
    for (const [i, s] of this.parts.sails.entries()) s.rotation.y = Math.sin(this.time * 1.2 + i) * 0.08;
    for (const l of this.parts.lanterns) l.scale.setScalar(1 + Math.sin(this.time * 6 + l.position.x) * 0.15);
    // broadside cannons while manifested
    if (this.manifest) {
      this.broadT -= dt;
      if (this.broadT <= 0 && P.alive) {
        this.broadT = this.phase === 2 ? 2 : 3.2;
        for (let k = 0; k < 10; k++) {
          const side = tmp.copy(P.pos).sub(this.group.position).dot(new THREE.Vector3(1, 0, 0).applyQuaternion(this.group.quaternion)) > 0 ? 1 : -1;
          const from = new THREE.Vector3(side * 28, 0, -50 + k * 11).applyMatrix4(this.group.matrixWorld);
          const aim = P.pos.clone().addScaledVector(P.vel, from.distanceTo(P.pos) / 300).sub(from).normalize();
          aim.y += (Math.random() - 0.5) * 0.08; aim.x += (Math.random() - 0.5) * 0.08;
          g.projectiles.spawn({ kind: 'orb', team: 'enemy', pos: from, vel: aim.normalize().multiplyScalar(300), life: 4, dmg: 10 * g.enemyDamageMult, radius: 2.4, size: 2.2, color: '#7dff6a', source: this.body });
        }
        g.audio.play('explosionS', { pos: this.group.position, volume: 0.6 });
      }
    }
    // wisps (ghost kamikazes)
    this.wispT -= dt;
    if (this.wispT <= 0) {
      this.wispT = this.phase >= 1 ? 6 : 10;
      for (let k = 0; k < (this.phase >= 1 ? 5 : 3); k++) g.spawnUnit('kamikaze', { pos: this.group.position.clone().add(new THREE.Vector3(Math.random() * 60 - 30, 40, Math.random() * 60 - 30)), faction: 'ghost', variant: 'ghost', name: 'Wisp' });
    }
    // witching hour: pumpkin mines
    if (this.phase === 2) {
      this.mineT -= dt;
      if (this.mineT <= 0) { this.mineT = 5; for (let k = 0; k < 3; k++) g.spawnUnit('mine', { pos: P.pos.clone().add(new THREE.Vector3(Math.random() * 200 - 100, Math.random() * 80 - 40, Math.random() * 200 - 100)), faction: 'neutral', tint: '#ff8a1a' }); }
    }
  }
}

export function createBoss(game, id, opts = {}) {
  switch (id) {
    case 'dreadnought': return new Dreadnought(game, opts);
    case 'swarmqueen': return new SwarmQueen(game, opts);
    case 'phantom': return new PhantomAce(game, opts);
    case 'anomaly': return new Anomaly(game, opts);
    case 'hollow': return new HollowWarden(game, opts);
    default: return new Dreadnought(game, opts);
  }
}
