// ============================================================================
// Procedural model library. Every ship, enemy, boss and structure is built
// from primitives (lathe fuselages, extruded wings, greebles) and merged per
// material for efficient rendering. Convention: nose = +Z, up = +Y.
// ============================================================================
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { COSMETICS, FACTIONS } from './data.js';
import { patternTexture, iconDecalTexture, panelTexture } from './textures.js';

// ---------------------------------------------------------------------------
// Geometry kit
// ---------------------------------------------------------------------------
const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(), _v = new THREE.Vector3(), _s = new THREE.Vector3();

function prep(geo) {
  let g = geo.index ? geo.toNonIndexed() : geo.clone();
  for (const k of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(k)) g.deleteAttribute(k);
  if (!g.attributes.normal) g.computeVertexNormals();
  if (!g.attributes.uv) g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(g.attributes.position.count * 2), 2));
  g.clearGroups();
  return g;
}
function flipWinding(g) {
  for (const name of Object.keys(g.attributes)) {
    const a = g.attributes[name], n = a.itemSize, arr = a.array;
    for (let t = 0; t < a.count; t += 3) {
      for (let k = 0; k < n; k++) {
        const i1 = (t + 1) * n + k, i2 = (t + 2) * n + k;
        const tmp = arr[i1]; arr[i1] = arr[i2]; arr[i2] = tmp;
      }
    }
  }
}

export class Kit {
  constructor() { this.lists = {}; }
  add(mat, geo, p = [0, 0, 0], r = [0, 0, 0], s = 1, mirror = false) {
    const sc = typeof s === 'number' ? [s, s, s] : s;
    _m.compose(_v.set(p[0], p[1], p[2]), _q.setFromEuler(_e.set(r[0], r[1], r[2])), _s.set(sc[0], sc[1], sc[2]));
    const g = prep(geo); g.applyMatrix4(_m);
    (this.lists[mat] = this.lists[mat] || []).push(g);
    if (mirror) {
      const g2 = g.clone(); g2.applyMatrix4(new THREE.Matrix4().makeScale(-1, 1, 1)); flipWinding(g2);
      this.lists[mat].push(g2);
    }
    geo.dispose();
    return this;
  }
  build() {
    const out = {};
    for (const [k, list] of Object.entries(this.lists)) {
      out[k] = mergeGeometries(list, false);
      out[k].computeBoundingSphere();
      for (const g of list) g.dispose();
    }
    return out;
  }
}

// Primitive helpers
const box = (w, h, d) => new THREE.BoxGeometry(w, h, d);
const cyl = (rt, rb, h, seg = 12) => new THREE.CylinderGeometry(rt, rb, h, seg); // along Y
const cylZ = (rt, rb, h, seg = 12) => { const g = new THREE.CylinderGeometry(rt, rb, h, seg); g.rotateX(Math.PI / 2); return g; }; // along Z, top at +Z
const sph = (r, ws = 14, hs = 10) => new THREE.SphereGeometry(r, ws, hs);
const tor = (r, t, rs = 8, ts = 24, arc = Math.PI * 2) => new THREE.TorusGeometry(r, t, rs, ts, arc);
const oct = (r, d = 0) => new THREE.OctahedronGeometry(r, d);
const ico = (r, d = 0) => new THREE.IcosahedronGeometry(r, d);
const coneZ = (r, h, seg = 8) => { const g = new THREE.ConeGeometry(r, h, seg); g.rotateX(Math.PI / 2); return g; }; // tip at +Z
// Fuselage via lathe: profile [[radius, z], ...] from tail to nose
function lathe(profile, seg = 8) {
  const pts = profile.map(([r, z]) => new THREE.Vector2(Math.max(0.001, r), z));
  const g = new THREE.LatheGeometry(pts, seg);
  g.rotateX(Math.PI / 2); // lathe Y -> ship Z
  return g;
}
// Wing from planform points [[x(span), z(length)], ...] extruded to thickness (Y)
function wing(points, thick = 0.4, bevel = 0.12) {
  const sh = new THREE.Shape();
  sh.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i < points.length; i++) sh.lineTo(points[i][0], points[i][1]);
  sh.closePath();
  const g = new THREE.ExtrudeGeometry(sh, { depth: thick, bevelEnabled: bevel > 0, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 1, steps: 1 });
  g.translate(0, 0, -thick / 2);
  g.rotateX(Math.PI / 2); // shape y -> +Z, extrude -> -Y
  return g;
}
function curvedShape(fn, thick = 0.3) {
  const sh = new THREE.Shape(); fn(sh);
  const g = new THREE.ExtrudeGeometry(sh, { depth: thick, bevelEnabled: true, bevelThickness: 0.08, bevelSize: 0.08, bevelSegments: 1, curveSegments: 10 });
  g.translate(0, 0, -thick / 2); g.rotateX(Math.PI / 2);
  return g;
}

// ---------------------------------------------------------------------------
// Materials
// ---------------------------------------------------------------------------
const matCache = new Map();
export function glowMaterial(color, intensity = 2.5, opts = {}) {
  const key = `glow-${color}-${intensity}-${opts.transparent ? 1 : 0}-${opts.opacity ?? 1}`;
  if (!matCache.has(key)) {
    matCache.set(key, new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(intensity), toneMapped: false, transparent: !!opts.transparent, opacity: opts.opacity ?? 1, blending: opts.additive ? THREE.AdditiveBlending : THREE.NormalBlending, depthWrite: !opts.transparent, side: opts.side || THREE.FrontSide }));
  }
  return matCache.get(key);
}
const DARK = () => new THREE.MeshStandardMaterial({ color: '#23272e', metalness: 0.85, roughness: 0.42 });
const GLASS = () => new THREE.MeshPhysicalMaterial({ color: '#081428', metalness: 0.9, roughness: 0.05, clearcoat: 1, emissive: '#0d2d55', emissiveIntensity: 0.6 });

export function shipMaterials(cos) {
  const paint = COSMETICS[cos.paint] || COSMETICS.paint_standard;
  const eng = COSMETICS[cos.engine] || COSMETICS.engine_cyan;
  const bump = panelTexture();
  const mk = (color, metal, rough) => paint.iridescent
    ? new THREE.MeshPhysicalMaterial({ color, metalness: metal, roughness: rough, iridescence: 1, iridescenceIOR: 1.6, clearcoat: 1, bumpMap: bump, bumpScale: 0.6 })
    : new THREE.MeshStandardMaterial({ color, metalness: metal, roughness: rough, bumpMap: bump, bumpScale: 0.6 });
  return {
    hull: mk(paint.primary, paint.metal, paint.rough),
    accent: mk(paint.secondary, Math.min(1, paint.metal + 0.1), paint.rough * 0.8),
    dark: DARK(),
    glass: GLASS(),
    glow: new THREE.MeshBasicMaterial({ color: new THREE.Color(eng.color).multiplyScalar(0.95), toneMapped: false }),
    engineColor: new THREE.Color(eng.color), engineCycle: !!eng.cycle, paint,
  };
}

const FACTION_LOOK = {
  dominion: { hull: '#3d4149', metal: 0.85, rough: 0.4, accent: '#7a2a20', glow: '#ff4a2a' },
  vrell: { hull: '#3c4a24', metal: 0.15, rough: 0.75, accent: '#6a7a2a', glow: '#a6ff3c' },
  syndicate: { hull: '#2a2433', metal: 0.75, rough: 0.35, accent: '#4a2a5a', glow: '#c95cff' },
  choir: { hull: '#9fdcec', metal: 0.95, rough: 0.12, accent: '#3a6a8a', glow: '#4ff0ff' },
  ally: { hull: '#b8c2ce', metal: 0.7, rough: 0.4, accent: '#2a5ab6', glow: '#4fdcff' },
  neutral: { hull: '#5a4a2e', metal: 0.8, rough: 0.35, accent: '#d9a73a', glow: '#ffcc55' },
  ghost: { hull: '#1a2a1e', metal: 0.4, rough: 0.6, accent: '#2a4a2a', glow: '#7dff6a' },
};
export function factionMaterials(faction, variantTint = null) {
  const L = FACTION_LOOK[faction] || FACTION_LOOK.dominion;
  const key = `fac-${faction}-${variantTint}`;
  if (!matCache.has(key)) {
    const glowCol = variantTint || L.glow;
    matCache.set(key, {
      hull: new THREE.MeshStandardMaterial({ color: L.hull, metalness: L.metal, roughness: L.rough, bumpMap: panelTexture(), bumpScale: 0.5 }),
      accent: new THREE.MeshStandardMaterial({ color: variantTint ? new THREE.Color(L.accent).lerp(new THREE.Color(variantTint), 0.5) : L.accent, metalness: L.metal, roughness: L.rough }),
      dark: DARK(),
      glass: GLASS(),
      glow: new THREE.MeshBasicMaterial({ color: new THREE.Color(glowCol).multiplyScalar(2.6), toneMapped: false }),
      engineColor: new THREE.Color(glowCol),
    });
  }
  return matCache.get(key);
}

// ---------------------------------------------------------------------------
// Player ships
// ---------------------------------------------------------------------------
const SHIP_BUILDERS = {
  warden(k) {
    k.add('hull', lathe([[0.2, -7], [1.3, -6.6], [1.9, -3], [1.8, 1.5], [1.2, 4.8], [0.35, 7.4], [0.01, 7.8]], 8));
    k.add('glass', sph(1, 14, 10), [0, 1.25, 2.4], [0, 0, 0], [0.85, 0.6, 2.1]);
    k.add('hull', wing([[1.2, 2.2], [7.4, -2.6], [7.8, -4.6], [1.5, -4.2]], 0.35), [0, -0.2, 0], [0, 0, -0.06], 1, true);
    k.add('accent', wing([[5.6, -1.6], [7.5, -2.7], [7.8, -4.6], [6.0, -4.4]], 0.4), [0, -0.2, 0], [0, 0, -0.06], 1, true);
    k.add('accent', wing([[0, -2], [0, -6.5], [2.6, -7.2], [2.4, -5.6]], 0.22), [0.9, 0.9, 0], [0, 0, 1.15], 1, true); // tail fins
    k.add('dark', cylZ(0.8, 0.95, 3.2, 10), [1.35, 0, -5.8], [0, 0, 0], 1, true);
    k.add('dark', tor(0.72, 0.16, 6, 14), [1.35, 0, -7.4], [0, 0, 0], 1, true);
    k.add('dark', cylZ(0.16, 0.2, 3.4, 6), [2.7, -0.3, 2.0], [0, 0, 0], 1, true); // cannons
    k.add('accent', box(0.9, 0.7, 2.4), [1.6, 0.4, 0.4], [0, 0, 0], 1, true); // intakes
    k.add('dark', box(0.5, 0.25, 1.6), [0, 1.6, -2.8]);
    return { engines: [[1.35, 0, -7.5, 0.62], [-1.35, 0, -7.5, 0.62]], guns: [[2.7, -0.3, 3.7], [-2.7, -0.3, 3.7]], decals: [[4.6, 0.02, -2.6, 3.2, 0.06], [-4.6, 0.02, -2.6, 3.2, -0.06]], emblem: [0, 1.95, -1.2, 1.5], length: 15 };
  },
  viper(k) {
    k.add('hull', lathe([[0.2, -6], [1.0, -5.6], [1.3, -2], [1.1, 3], [0.6, 7], [0.05, 10]], 6));
    k.add('glass', sph(1, 12, 8), [0, 0.85, 2.4], [0, 0, 0], [0.6, 0.5, 1.8]);
    k.add('hull', wing([[0.8, -3.8], [6.6, 0.6], [7.0, -0.2], [1.0, -5.4]], 0.25), [0, -0.1, 0], [0, 0, -0.12], 1, true); // forward swept
    k.add('accent', wing([[5.2, -0.6], [6.6, 0.6], [7.0, -0.2], [5.6, -1.4]], 0.3), [0, -0.1, 0], [0, 0, -0.12], 1, true);
    k.add('accent', wing([[0.5, 4.5], [2.6, 3.4], [2.6, 2.8], [0.6, 3.2]], 0.15), [0, 0, 0], [0, 0, 0], 1, true); // canards
    k.add('accent', wing([[0, -2.5], [0, -5.6], [2.2, -6.2]], 0.18), [0, 0.8, 0], [0, 0, Math.PI / 2], 1, false); // dorsal fin
    k.add('dark', cylZ(1.0, 1.15, 2.6, 12), [0, 0, -6.2]);
    k.add('dark', tor(0.95, 0.18, 6, 16), [0, 0, -7.5]);
    k.add('dark', cylZ(0.12, 0.15, 3.2, 6), [6.8, -0.1, 0.6], [0, 0, 0], 1, true);
    return { engines: [[0, 0, -7.6, 0.85]], guns: [[6.8, -0.1, 2.2], [-6.8, -0.1, 2.2]], decals: [[3.8, 0.02, -2.2, 2.6, 0.12], [-3.8, 0.02, -2.2, 2.6, -0.12]], emblem: [0, 1.25, -2.5, 1.1], length: 16 };
  },
  bulwark(k) {
    k.add('hull', box(4.4, 2.6, 12), [0, 0, 0]);
    k.add('hull', lathe([[2.4, 5.8], [2.2, 7.5], [1.2, 9.5], [0.2, 10.2]], 6), [0, -0.1, 0], [0, 0, Math.PI / 6]);
    k.add('accent', box(4.8, 0.6, 3.2), [0, 1.5, 2.5]); k.add('accent', box(4.8, 0.6, 3.2), [0, 1.5, -1.2]); k.add('accent', box(4.6, 0.5, 2.6), [0, 1.4, -4.6]);
    k.add('glass', sph(1, 12, 8), [0, 1.9, 5.0], [0, 0, 0], [1.0, 0.55, 1.4]);
    k.add('hull', wing([[2.1, 2.5], [6.2, 0], [6.2, -4], [2.1, -4.5]], 0.7), [0, -0.3, 0], [0, 0, 0], 1, true);
    k.add('accent', box(1.6, 1.6, 6), [6.4, -0.3, -0.8], [0, 0, 0], 1, true); // weapon pods
    k.add('dark', cylZ(0.3, 0.35, 3, 8), [6.4, -0.3, 3.4], [0, 0, 0], 1, true);
    for (const [x, y] of [[1.2, 0.7], [1.2, -0.7]]) k.add('dark', cylZ(0.75, 0.85, 2.4, 10), [x, y, -6.6], [0, 0, 0], 1, true);
    k.add('dark', box(5, 0.4, 0.8), [0, -1.4, 3.5]); k.add('dark', box(5, 0.4, 0.8), [0, -1.4, -2]);
    return { engines: [[1.2, 0.7, -7.9, 0.6], [-1.2, 0.7, -7.9, 0.6], [1.2, -0.7, -7.9, 0.6], [-1.2, -0.7, -7.9, 0.6]], guns: [[6.4, -0.3, 5], [-6.4, -0.3, 5]], decals: [[4.2, 0.08, -1, 3, 0], [-4.2, 0.08, -1, 3, 0]], emblem: [2.22, 0.2, -2.6, 1.6, 'side'], length: 18 };
  },
  specter(k) {
    k.add('hull', wing([[0, 8.5], [8.5, -4.5], [6.2, -6], [2.2, -4.2], [0, -5.4], [-2.2, -4.2], [-6.2, -6], [-8.5, -4.5]], 0.8, 0.25));
    k.add('hull', lathe([[0.4, -4.5], [1.7, -3.5], [1.9, 0], [1.2, 4], [0.2, 7]], 6), [0, 0.35, 0], [0, 0, 0], [1, 0.55, 1]);
    k.add('glass', sph(1, 12, 8), [0, 0.95, 2.4], [0, 0, 0], [0.7, 0.35, 1.6]);
    k.add('glow', box(0.12, 0.12, 6.4), [3.2, 0.45, -0.6], [0, -0.75, 0], 1, true);
    k.add('glow', box(0.12, 0.12, 4.0), [5.4, 0.45, -3.2], [0, -0.75, 0], 1, true);
    k.add('accent', wing([[0, -3], [0, -5.2], [1.6, -5.8], [1.4, -4]], 0.15), [2.6, 0.4, 0], [0, 0, 0.9], 1, true);
    k.add('dark', box(1.4, 0.5, 1.2), [1.4, 0.1, -4.8], [0, 0, 0], 1, true);
    return { engines: [[1.4, 0.1, -5.5, 0.45], [-1.4, 0.1, -5.5, 0.45]], guns: [[1.0, -0.3, 6.5], [-1.0, -0.3, 6.5]], decals: [[4.5, 0.45, -2.5, 3.4, 0], [-4.5, 0.45, -2.5, 3.4, 0]], emblem: [0, 1.0, -2.5, 1.4], length: 15 };
  },
  longbow(k) {
    k.add('hull', lathe([[0.2, -7], [1.4, -6.5], [1.8, -2], [1.5, 3], [0.8, 6], [0.2, 7.5]], 8));
    k.add('glass', sph(1, 12, 8), [0, 1.2, 3.2], [0, 0, 0], [0.7, 0.5, 1.5]);
    k.add('accent', box(0.5, 0.5, 15), [0.55, 1.9, 3.0], [0, 0, 0], 1, true); // rails
    k.add('dark', box(0.9, 0.3, 14), [0, 1.55, 2.6]);
    for (let i = 0; i < 5; i++) k.add('glow', tor(0.95, 0.09, 4, 16), [0, 1.9, -2 + i * 2.6]);
    for (const a of [0.6, -0.6]) {
      k.add('hull', wing([[1.2, -1], [6.8, -4.8], [7.0, -6], [1.4, -5]], 0.3), [0, 0, 0], [0, 0, a], 1, true);
    }
    k.add('accent', wing([[5.2, -3.8], [6.8, -4.8], [7.0, -6], [5.6, -5.6]], 0.34), [0, 0, 0], [0, 0, 0.6], 1, true);
    k.add('dark', cylZ(0.75, 0.9, 2.8, 10), [1.25, -0.2, -6.4], [0, 0, 0], 1, true);
    return { engines: [[1.25, -0.2, -7.9, 0.6], [-1.25, -0.2, -7.9, 0.6]], guns: [[0, 1.9, 10.6], [0, 1.9, 10.6]], decals: [[3.6, 2.15, -3.4, 2.4, 0.6], [-3.6, 2.15, -3.4, 2.4, -0.6]], emblem: [1.85, 0, -2, 1.3, 'side'], length: 18 };
  },
  prototype(k) {
    k.add('hull', lathe([[0.2, -5], [1.6, -4.2], [2.3, -1], [2.0, 2.5], [1.0, 5.5], [0.1, 7]], 12));
    k.add('glass', sph(1, 14, 10), [0, 1.3, 1.6], [0, 0, 0], [0.9, 0.6, 1.8]);
    k.add('accent', tor(4.6, 0.45, 8, 40), [0, 0, -1.2]);
    k.add('glow', tor(4.6, 0.12, 4, 48), [0, 0, -0.75]);
    k.add('glow', sph(0.9, 12, 10), [0, 0, 4.6]);
    for (let i = 0; i < 3; i++) {
      const a = i / 3 * Math.PI * 2 + Math.PI / 2;
      k.add('hull', curvedShape(sh => { sh.moveTo(0, 2); sh.quadraticCurveTo(3.2, 0.5, 4.4, -3.6); sh.lineTo(3.6, -4.2); sh.quadraticCurveTo(1.6, -1.6, 0, -2.5); }, 0.3), [0, 0, -1], [0, 0, a - Math.PI / 2]);
      k.add('dark', cylZ(0.55, 0.7, 2.2, 10), [Math.cos(a) * 1.5, Math.sin(a) * 1.5, -5.2]);
      k.add('dark', box(0.4, 0.4, 2.2), [Math.cos(a) * 3.4, Math.sin(a) * 3.4, -1.2], [0, 0, a]);
    }
    const eng = [0, 1, 2].map(i => { const a = i / 3 * Math.PI * 2 + Math.PI / 2; return [Math.cos(a) * 1.5, Math.sin(a) * 1.5, -6.3, 0.5]; });
    return { engines: eng, guns: [[1.2, -0.6, 6], [-1.2, -0.6, 6]], decals: [], emblem: [2.1, 0.6, -0.5, 1.2, 'side'], length: 14 };
  },
};

const shipGeoCache = new Map();
function shipGeometry(id) {
  if (!shipGeoCache.has(id)) {
    const k = new Kit();
    const meta = SHIP_BUILDERS[id](k);
    shipGeoCache.set(id, { geos: k.build(), meta });
  }
  return shipGeoCache.get(id);
}

function engineFlame(color) {
  const g = new THREE.ConeGeometry(1, 1, 12, 1, true);
  g.translate(0, 0.5, 0); g.rotateX(-Math.PI / 2); // wide base at z=0, tip trails to z=-1
  const m = new THREE.ShaderMaterial({
    uniforms: { uColor: { value: color.clone() }, uTime: { value: 0 }, uPower: { value: 1 } },
    vertexShader: `varying vec2 vUv; varying float vZ; void main(){ vUv = uv; vZ = position.z; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
    fragmentShader: `uniform vec3 uColor; uniform float uTime; uniform float uPower; varying vec2 vUv; varying float vZ;
      void main(){ float t = clamp(-vZ, 0.0, 1.0); float flick = 0.85 + 0.15*sin(uTime*60.0 + t*20.0);
        float a = (1.0 - t) * flick; vec3 c = mix(vec3(1.0), uColor, smoothstep(0.0, 0.18, t));
        gl_FragColor = vec4(c * 0.85 * uPower, a * 0.45 * uPower); }`,
    transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false,
  });
  return new THREE.Mesh(g, m);
}

/** Build a player ship with cosmetics. Returns Group with userData {engines, guns, flames, materials, radius}. */
export function buildPlayerShip(shipId, cosmetics) {
  const { geos, meta } = shipGeometry(shipId);
  const mats = shipMaterials(cosmetics);
  const group = new THREE.Group();
  for (const [k, g] of Object.entries(geos)) {
    const mesh = new THREE.Mesh(g, mats[k]);
    mesh.castShadow = true; mesh.receiveShadow = true;
    group.add(mesh);
  }
  // Wing pattern decals
  const pat = COSMETICS[cosmetics.pattern]?.pattern;
  if (pat && pat !== 'none') {
    const pm = new THREE.MeshStandardMaterial({ color: mats.paint.secondary, alphaMap: patternTexture(pat), transparent: true, metalness: 0.6, roughness: 0.4, polygonOffset: true, polygonOffsetFactor: -2, depthWrite: false });
    for (const [x, y, z, s, rz] of meta.decals) {
      const d = new THREE.Mesh(new THREE.PlaneGeometry(s, s), pm);
      d.rotation.set(-Math.PI / 2, 0, 0); d.rotateOnWorldAxis(new THREE.Vector3(0, 0, 1), rz || 0);
      d.position.set(x, y + 0.2, z);
      group.add(d);
    }
  }
  const emb = COSMETICS[cosmetics.emblem]?.emblem;
  if (emb && meta.emblem) {
    const [x, y, z, s, side] = meta.emblem;
    const em = new THREE.MeshBasicMaterial({ map: iconDecalTexture(emb), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, toneMapped: true });
    const mk = (mx) => {
      const d = new THREE.Mesh(new THREE.PlaneGeometry(s, s), em);
      if (side === 'side') { d.rotation.set(0, mx * Math.PI / 2, 0); d.position.set(mx * (x + 0.06), y, z); }
      else { d.rotation.set(-Math.PI / 2, 0, Math.PI); d.position.set(x, y + 0.05, z); }
      group.add(d);
    };
    mk(1); if (side === 'side') mk(-1);
  }
  // Engine flames
  const flames = [];
  for (const [x, y, z, r] of meta.engines) {
    const disc = new THREE.Mesh(new THREE.CircleGeometry(r, 16), mats.glow);
    disc.position.set(x, y, z - 0.02); disc.rotation.y = Math.PI;
    group.add(disc);
    const f = engineFlame(mats.engineColor);
    f.position.set(x, y, z); f.scale.set(r * 0.9, r * 0.9, r * 5);
    group.add(f); flames.push(f);
  }
  group.userData = { engines: meta.engines.map(e => new THREE.Vector3(e[0], e[1], e[2] - 0.5)), guns: meta.guns.map(g => new THREE.Vector3(...g)), flames, materials: mats, radius: meta.length * 0.32, length: meta.length };
  return group;
}

// ---------------------------------------------------------------------------
// Enemy models
// ---------------------------------------------------------------------------
const ENEMY_BUILDERS = {
  swarm(k) {
    k.add('hull', oct(1.6, 0), [0, 0, 0], [0, 0, 0], [1, 0.8, 1.6]);
    for (let i = 0; i < 3; i++) { const a = i / 3 * Math.PI * 2 + Math.PI / 2; k.add('accent', coneZ(0.45, 4.2, 5), [Math.cos(a) * 1.6, Math.sin(a) * 1.6, -0.8], [0.0, 0, 0], [1, 1, 1]); k.add('hull', wing([[0, 0.8], [2.8, -1.8], [2.4, -2.4], [0, -1]], 0.15, 0.05), [0, 0, 0], [0, 0, a - Math.PI / 2]); }
    k.add('glow', sph(0.55, 10, 8), [0, 0, 2.2]);
    return { engines: [[0, 0, -2.4, 0.4]], guns: [[0, 0, 2.6]], radius: 4 };
  },
  interceptor(k) {
    k.add('hull', lathe([[0.2, -4.5], [0.9, -4], [1.2, -1], [0.9, 2.5], [0.1, 5.5]], 6));
    k.add('accent', wing([[0.8, -2.5], [5.2, 1.5], [5.4, 0.6], [1.0, -3.6]], 0.2), [0, 0.35, 0], [0, 0, -0.15], 1, true);
    k.add('hull', wing([[0.8, -1.5], [4.6, -3.8], [4.8, -4.6], [0.9, -3.8]], 0.2), [0, -0.35, 0], [0, 0, 0.18], 1, true);
    k.add('glow', box(0.8, 0.3, 0.8), [0, 0.6, 2]);
    k.add('dark', cylZ(0.55, 0.7, 1.8, 8), [0, 0, -4.6]);
    return { engines: [[0, 0, -5.4, 0.5]], guns: [[5.3, 0.35, 2], [-5.3, 0.35, 2]], radius: 6 };
  },
  bomber(k) {
    k.add('hull', wing([[0, 6], [11, -2], [10, -4.5], [0, -3.5], [-10, -4.5], [-11, -2]], 1.4, 0.3));
    k.add('hull', box(3.6, 2.6, 10), [0, 0.4, 0]);
    k.add('accent', box(3.0, 0.6, 6), [0, 1.9, -0.5]);
    k.add('dark', sph(1.2, 10, 8), [3.4, -1.3, 0.5], [0, 0, 0], [1, 1, 2], true);
    k.add('glow', box(2, 0.25, 0.4), [0, 0.8, 5.1]);
    for (const x of [-4, 0, 4]) k.add('dark', cylZ(0.8, 1, 2, 8), [x, 0, -4.6]);
    return { engines: [[4, 0, -5.6, 0.7], [0, 0, -5.6, 0.7], [-4, 0, -5.6, 0.7]], guns: [[0, -1, 5]], radius: 10 };
  },
  sniper(k) {
    k.add('hull', lathe([[0.2, -5], [1.0, -4.5], [1.2, 0], [0.8, 3], [0.4, 4]], 6));
    k.add('dark', cylZ(0.25, 0.3, 11, 8), [0, 0, 8.5]);
    for (let i = 0; i < 3; i++) k.add('glow', tor(0.6, 0.1, 4, 14), [0, 0, 5 + i * 2.6]);
    k.add('accent', wing([[0.6, -2], [3.4, -4.6], [3.4, -5.2], [0.6, -4]], 0.18), [0, 0, 0], [0, 0, 0], 1, true);
    k.add('accent', wing([[0.6, -2], [3.4, -4.6], [3.4, -5.2], [0.6, -4]], 0.18), [0, 0, 0], [0, 0, Math.PI / 2], 1, false);
    k.add('glow', sph(0.35, 8, 6), [0, 0.9, 1]);
    return { engines: [[0, 0, -5.4, 0.5]], guns: [[0, 0, 14.2]], radius: 7 };
  },
  shieldcarrier(k) {
    k.add('hull', cylZ(3.2, 3.6, 9, 6), [0, 0, 0], [0, 0, Math.PI / 6]);
    k.add('accent', box(1.4, 1.4, 9.4), [3.4, 0, 0], [0, 0, 0], 1, true);
    k.add('accent', tor(5.8, 0.4, 6, 32), [0, 0, 0.5], [Math.PI / 2, 0, 0]);
    k.add('glow', tor(5.8, 0.15, 4, 40), [0, 0.45, 0.5], [Math.PI / 2, 0, 0]);
    k.add('glow', sph(1.2, 12, 10), [0, 3.4, 0]);
    k.add('dark', cyl(0.6, 1, 2.2, 8), [0, 2.4, 0]);
    k.add('dark', cylZ(1.2, 1.4, 1.5, 8), [0, 0, -5]);
    return { engines: [[0, 0, -5.8, 1]], guns: [[0, 0, 5]], radius: 11 };
  },
  repair(k) {
    k.add('hull', sph(2.2, 12, 10));
    for (let i = 0; i < 4; i++) { const a = i / 4 * Math.PI * 2 + Math.PI / 4; k.add('accent', box(0.8, 0.8, 4.2), [Math.cos(a) * 2.6, Math.sin(a) * 2.6, 0], [0, 0, a]); k.add('glow', sph(0.45, 8, 6), [Math.cos(a) * 3.6, Math.sin(a) * 3.6, 2.1]); }
    k.add('glow', box(2.2, 0.5, 0.5), [0, 2.4, 0]); k.add('glow', box(0.5, 0.5, 2.2), [0, 2.4, 0]);
    k.add('dark', cylZ(0.8, 0.9, 1.4, 8), [0, 0, -2.6]);
    return { engines: [[0, 0, -3.3, 0.6]], guns: [[0, 0, 2.5]], radius: 8 };
  },
  stealth(k) {
    k.add('hull', wing([[0, 6], [5.5, -3.5], [3, -2.5], [0, -4], [-3, -2.5], [-5.5, -3.5]], 0.7, 0.2));
    k.add('hull', oct(1.4, 0), [0, 0.45, 0.6], [0, 0, 0], [1, 0.45, 2.6]);
    k.add('glow', box(0.1, 0.1, 4.0), [2.0, 0.42, 0.4], [0, -0.55, 0], 1, true);
    k.add('dark', box(1, 0.4, 1), [1.2, 0, -3.2], [0, 0, 0], 1, true);
    return { engines: [[1.2, 0, -3.8, 0.35], [-1.2, 0, -3.8, 0.35]], guns: [[0.7, 0, 5], [-0.7, 0, 5]], radius: 6 };
  },
  kamikaze(k) {
    k.add('hull', coneZ(1.6, 7, 6), [0, 0, 1.5]);
    k.add('glow', sph(1.2, 12, 10), [0, 0, -2]);
    k.add('accent', tor(1.5, 0.3, 5, 14), [0, 0, -2]);
    for (let i = 0; i < 4; i++) { const a = i / 4 * Math.PI * 2; k.add('accent', wing([[0, -1], [2.6, -3.4], [2.4, -4], [0, -3.2]], 0.15, 0.04), [0, 0, 0], [0, 0, a]); }
    return { engines: [[0, 0, -3.5, 0.7]], guns: [[0, 0, 5]], radius: 5 };
  },
  artillery(k) {
    k.add('hull', box(6, 4, 12), [0, -1, 0]);
    k.add('accent', box(6.6, 1.2, 8), [0, 1.4, -1]);
    k.add('dark', cylZ(1.2, 1.5, 16, 10), [0, 2.2, 6]);
    k.add('dark', cyl(2.2, 2.2, 1.8, 12), [0, 2.4, -1]);
    k.add('glow', tor(1.4, 0.15, 4, 16), [0, 2.2, 13.8]);
    k.add('dark', cyl(1.6, 1.6, 6.4, 10), [3.6, -1, -1], [Math.PI / 2, 0, 0], 1, true);
    for (const x of [-2, 2]) k.add('dark', cylZ(1, 1.2, 2, 8), [x, -1, -6.8]);
    return { engines: [[2, -1, -7.9, 0.8], [-2, -1, -7.9, 0.8]], guns: [[0, 2.2, 14.5]], radius: 13 };
  },
  ace(k) {
    k.add('hull', lathe([[0.2, -5], [1.0, -4.6], [1.3, -1], [1.0, 3], [0.4, 6.5], [0.05, 8]], 6));
    k.add('glass', sph(1, 10, 8), [0, 0.8, 2.2], [0, 0, 0], [0.55, 0.45, 1.6]);
    k.add('accent', wing([[0.8, -1], [6.5, -3.2], [6.8, -4.6], [1.0, -4.2]], 0.22), [0, 0, 0], [0, 0, -0.08], 1, true);
    k.add('hull', wing([[0.5, 2.5], [3.2, 4.8], [3.4, 4.2], [0.6, 1.4]], 0.18), [0, 0, 0], [0, 0, 0], 1, true);
    k.add('accent', wing([[0, -2], [0, -5], [2.4, -5.8], [2, -4]], 0.16), [0.7, 0.6, 0], [0, 0, 1.0], 1, true);
    k.add('accent', wing([[0, -2], [0, -5], [2.4, -5.8], [2, -4]], 0.16), [0.7, -0.6, 0], [0, 0, -1.0], 1, true);
    k.add('dark', cylZ(0.75, 0.9, 2, 10), [0, 0, -5.2]);
    k.add('glow', box(1.0, 0.18, 0.18), [0, 0.95, 3.6]);
    return { engines: [[0, 0, -6.2, 0.7]], guns: [[6.6, 0, 1], [-6.6, 0, 1]], radius: 8 };
  },
  sentinel(k) {
    k.add('hull', tor(14, 2.4, 8, 32), [0, 0, 0], [Math.PI / 2, 0, 0]);
    k.add('hull', cyl(5, 6, 6, 8));
    k.add('accent', cyl(6.4, 6.4, 1.2, 8), [0, 3.4, 0]);
    k.add('glow', sph(3, 16, 12), [0, 0, 0], [0, 0, 0], [1, 1.4, 1]);
    for (let i = 0; i < 4; i++) {
      const a = i / 4 * Math.PI * 2;
      k.add('hull', box(1.6, 1.6, 12), [Math.cos(a) * 7, 0, Math.sin(a) * 7], [0, -a, 0]);
      k.add('dark', box(3, 2.4, 3), [Math.cos(a) * 14, 2.4, Math.sin(a) * 14]);
      k.add('dark', cylZ(0.3, 0.35, 4, 6), [Math.cos(a) * 14, 2.6, Math.sin(a) * 14 + 2.4]);
    }
    return { engines: [[0, -3.5, 0, 2]], guns: [0, 1, 2, 3].map(i => { const a = i / 4 * Math.PI * 2; return [Math.cos(a) * 14, 2.6, Math.sin(a) * 14 + 4]; }), radius: 26 };
  },
  broodmother(k) {
    k.add('hull', sph(10, 18, 14), [0, 0, 0], [0, 0, 0], [1.1, 0.9, 1.7]);
    k.add('accent', sph(6, 14, 10), [0, 2, 13], [0, 0, 0], [1, 0.8, 1.1]);
    for (let i = 0; i < 14; i++) { const a = i / 14 * Math.PI * 2; k.add('accent', coneZ(1.2, 9, 5), [Math.cos(a) * 8.5, Math.sin(a) * 7.5, -6 + (i % 3) * 5], [Math.sin(a) * 0.9, -Math.cos(a) * 0.9 + 0.3, 0]); }
    for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; k.add('glow', sph(2.2, 10, 8), [Math.cos(a) * 9.5, Math.sin(a) * 8, -4]); }
    k.add('glow', sph(1.6, 10, 8), [2.5, 3.5, 17], [0, 0, 0], 1, true);
    return { engines: [[0, 0, -17, 3]], guns: [[0, 0, 18]], radius: 24 };
  },
};

// Capital-class ships (enemy cruiser / carrier, allied battleship)
function capitalHull(k, len = 160, w = 22) {
  k.add('hull', lathe([[w * 0.55, -len / 2], [w * 0.8, -len * 0.42], [w, -len * 0.15], [w * 0.85, len * 0.2], [w * 0.45, len * 0.42], [w * 0.1, len / 2]], 6), [0, 0, 0], [0, 0, Math.PI / 6], [1, 0.55, 1]);
  k.add('accent', box(w * 1.1, 6, len * 0.4), [0, w * 0.45, -len * 0.05]);
  k.add('hull', box(w * 0.5, 16, 18), [0, w * 0.45 + 10, -len * 0.18]); // bridge tower
  k.add('glass', box(w * 0.52, 2.4, 4), [0, w * 0.45 + 14, -len * 0.18 + 8]);
  k.add('dark', box(w * 1.8, 4, len * 0.3), [0, -2, -len * 0.1]); // sponsons
  for (let i = 0; i < 6; i++) k.add('dark', box(3, 3, 3), [w * 0.9, w * 0.3, -len * 0.3 + i * len * 0.12], [0, 0, 0], 1, true);
  for (let i = 0; i < 3; i++) k.add('glow', box(1, 1, len * 0.05), [w * 0.86, 0, -len * 0.25 + i * len * 0.2], [0, 0, 0], 1, true);
  for (const [x, y] of [[w * 0.35, 4], [-w * 0.35, 4], [w * 0.35, -6], [-w * 0.35, -6]]) k.add('dark', cylZ(5, 6.5, 10, 10), [x, y, -len / 2 - 3]);
}
const CAPITAL_BUILDERS = {
  capital(k) { capitalHull(k, 170, 22); k.add('glow', box(14, 5, 1), [0, -8, 60]); return { engines: [[7.7, 4, -90, 4.5], [-7.7, 4, -90, 4.5], [7.7, -6, -90, 4.5], [-7.7, -6, -90, 4.5]], guns: [], radius: 60 }; },
  battleship(k) { capitalHull(k, 190, 24); k.add('accent', box(30, 2, 40), [0, 18, 20]); return { engines: [[8.4, 4, -100, 5], [-8.4, 4, -100, 5], [8.4, -6, -100, 5], [-8.4, -6, -100, 5]], guns: [], radius: 70 }; },
  freighter(k) {
    k.add('hull', box(8, 8, 26), [0, 0, 6]);
    k.add('hull', lathe([[4, 18], [3, 24], [1, 27]], 6), [0, 0, 0]);
    for (let i = 0; i < 5; i++) for (const s of [-1, 1]) k.add('accent', box(6, 6, 7), [s * 7, 0, -18 + i * 8.5]);
    k.add('dark', box(3, 3, 46), [0, 0, -2]);
    k.add('glow', box(2, 2, 2), [0, 5, 18]);
    k.add('dark', cylZ(3, 4, 6, 10), [0, 0, -26]);
    return { engines: [[0, 0, -29.5, 3]], guns: [], radius: 24 };
  },
  station(k) {
    k.add('hull', cyl(12, 12, 60, 12));
    k.add('accent', tor(55, 5, 8, 48), [0, 0, 0], [Math.PI / 2, 0, 0]);
    for (let i = 0; i < 4; i++) { const a = i / 4 * Math.PI * 2; k.add('dark', box(3, 3, 44), [Math.cos(a) * 30, 0, Math.sin(a) * 30], [0, -a + Math.PI / 2, 0]); }
    for (const y of [-38, 38]) k.add('accent', box(80, 1, 18), [0, y, 0]);
    k.add('glow', tor(55.5, 1.2, 4, 64), [0, 2, 0], [Math.PI / 2, 0, 0]);
    k.add('glow', sph(4, 10, 8), [0, 32, 0]);
    return { engines: [], guns: [], radius: 60 };
  },
  dome(k) {
    k.add('hull', cyl(22, 24, 8, 16), [0, -4, 0]);
    k.add('glass', new THREE.SphereGeometry(20, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2));
    k.add('glow', tor(21, 0.6, 4, 48), [0, 0.2, 0], [Math.PI / 2, 0, 0]);
    for (let i = 0; i < 3; i++) { const a = i / 3 * Math.PI * 2; k.add('dark', box(4, 30, 4), [Math.cos(a) * 26, -18, Math.sin(a) * 26]); }
    return { engines: [], guns: [], radius: 26 };
  },
  comms(k) {
    k.add('dark', cyl(1.6, 2.6, 40, 8), [0, 0, 0]);
    k.add('hull', new THREE.SphereGeometry(16, 20, 8, 0, Math.PI * 2, 0, 0.9), [0, 22, 0], [Math.PI, 0, 0]);
    k.add('dark', cyl(0.4, 0.4, 14, 6), [0, 20, 0]);
    k.add('glow', sph(1.6, 10, 8), [0, 27, 0]);
    k.add('accent', box(16, 4, 16), [0, -20, 0]);
    return { engines: [], guns: [], radius: 18 };
  },
  shieldgen(k) {
    k.add('hull', oct(6, 0), [0, 0, 0], [0, 0, 0], [1, 2.2, 1]);
    k.add('accent', tor(8, 0.8, 6, 24), [0, 4, 0], [Math.PI / 2, 0, 0]);
    k.add('accent', tor(8, 0.8, 6, 24), [0, -4, 0], [Math.PI / 2, 0, 0]);
    k.add('glow', sph(3.2, 14, 10), [0, 0, 0]);
    return { engines: [], guns: [], radius: 12 };
  },
  pylon(k) {
    for (let i = 0; i < 5; i++) { const a = i / 5 * Math.PI * 2; k.add('glow', oct(3, 0), [Math.cos(a) * 3, i * 2 - 3, Math.sin(a) * 3], [0.2 * i, a, 0.3], [1, 3 + (i % 2) * 1.5, 1]); }
    k.add('hull', oct(5, 0), [0, 0, 0], [0, 0, 0], [1, 3.4, 1]);
    return { engines: [], guns: [], radius: 12 };
  },
  gate(k) {
    k.add('hull', tor(36, 3.2, 8, 40));
    k.add('glow', tor(32.5, 0.7, 4, 48));
    for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; k.add('accent', box(5, 8, 5), [Math.cos(a) * 36, Math.sin(a) * 36, 0], [0, 0, a]); }
    return { engines: [], guns: [], radius: 36 };
  },
  trader(k) {
    k.add('hull', sph(9, 16, 12), [0, 0, 0], [0, 0, 0], [1, 0.75, 1.8]);
    k.add('accent', tor(10, 1.2, 6, 24), [0, 0, -2]);
    k.add('dark', cylZ(3, 4, 6, 10), [0, 0, -17]);
    for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; k.add('glow', sph(1, 8, 6), [Math.cos(a) * 10.5, Math.sin(a) * 10.5, -2]); }
    k.add('glass', sph(3, 10, 8), [0, 4, 10], [0, 0, 0], [1, 0.6, 1.4]);
    return { engines: [[0, 0, -20, 3]], guns: [], radius: 18 };
  },
  mine(k) {
    k.add('dark', ico(2.2, 0));
    for (let i = 0; i < 8; i++) { const v = new THREE.Vector3(Math.sin(i * 2.4), Math.cos(i * 1.7), Math.sin(i * 0.9 + 1)).normalize(); const g = new THREE.ConeGeometry(0.4, 2, 5); g.translate(0, 2.4, 0); const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), v); g.applyQuaternion(q); k.add('accent', g); }
    k.add('glow', sph(0.9, 8, 6));
    return { engines: [], guns: [], radius: 3.5 };
  },
  turret(k) {
    k.add('hull', cyl(8, 10, 6, 8));
    k.add('accent', sph(5, 12, 8), [0, 4, 0], [0, 0, 0], [1, 0.7, 1]);
    k.add('dark', cylZ(0.8, 1, 10, 8), [1.8, 5, 6], [0, 0, 0], 1, true);
    k.add('glow', box(3, 0.6, 0.6), [0, 6.5, 3]);
    return { engines: [], guns: [[1.8, 5, 11], [-1.8, 5, 11]], radius: 11 };
  },
  derelict(k) {
    capitalHull(k, 140, 20);
    return { engines: [], guns: [], radius: 55 };
  },
  cargo(k) {
    k.add('accent', box(4, 4, 4)); k.add('dark', box(4.4, 0.6, 4.4), [0, 2, 0]); k.add('dark', box(4.4, 0.6, 4.4), [0, -2, 0]); k.add('glow', box(4.2, 0.3, 0.3), [0, 0, 2.05]);
    return { engines: [], guns: [], radius: 4 };
  },
  drone(k) {
    k.add('hull', sph(0.9, 8, 6)); k.add('accent', tor(1.3, 0.2, 4, 12)); k.add('glow', sph(0.35, 6, 6), [0, 0, 0.9]);
    return { engines: [[0, 0, -1, 0.3]], guns: [[0, 0, 1.2]], radius: 2 };
  },
};

const unitGeoCache = new Map();
function unitGeometry(type) {
  if (!unitGeoCache.has(type)) {
    const builder = ENEMY_BUILDERS[type] || CAPITAL_BUILDERS[type];
    if (!builder) throw new Error('No model for ' + type);
    const k = new Kit(); const meta = builder(k);
    unitGeoCache.set(type, { geos: k.build(), meta });
  }
  return unitGeoCache.get(type);
}

/** Build a unit (enemy, ally or structure). Hull material is cloned so it can flash on hit. */
export function buildUnit(type, faction = 'dominion', opts = {}) {
  const { geos, meta } = unitGeometry(type);
  const mats = factionMaterials(faction, opts.tint || null);
  const group = new THREE.Group();
  const hullMat = mats.hull.clone();
  hullMat.emissive = new THREE.Color(0); hullMat.emissiveIntensity = 1;
  const accentMat = opts.cloneAccent ? mats.accent.clone() : mats.accent;
  const meshes = [];
  for (const [k, g] of Object.entries(geos)) {
    const m = k === 'hull' ? hullMat : k === 'accent' ? accentMat : mats[k];
    const mesh = new THREE.Mesh(g, m);
    mesh.castShadow = !opts.noShadow; mesh.receiveShadow = !opts.noShadow;
    group.add(mesh); meshes.push(mesh);
  }
  const flames = [];
  if (!opts.noFlames) {
    for (const [x, y, z, r] of meta.engines) {
      const f = engineFlame(mats.engineColor);
      f.position.set(x, y, z); f.scale.set(r * 0.9, r * 0.9, r * 4);
      group.add(f); flames.push(f);
    }
  }
  if (opts.scale) group.scale.setScalar(opts.scale);
  group.userData = { hullMat, meshes, flames, radius: meta.radius * (opts.scale || 1), guns: meta.guns.map(g => new THREE.Vector3(...g)), engines: meta.engines.map(e => new THREE.Vector3(e[0], e[1], e[2])) };
  return group;
}

export function disposeUnit(group) {
  // shared geometries & materials are cached; only clones are disposed
  if (group.userData.hullMat) group.userData.hullMat.dispose();
  for (const f of group.userData.flames || []) f.material.dispose();
}

// ---------------------------------------------------------------------------
// Environment set pieces (fresh geometry/materials — disposed with region)
// ---------------------------------------------------------------------------
export function buildWreckPiece(rng) {
  const k = new Kit();
  const len = rng.range(40, 110), w = rng.range(10, 22);
  k.add('hull', lathe([[w * 0.5, -len / 2], [w, -len * 0.2], [w * 0.8, len * 0.3], [w * 0.3, len / 2]], 6), [0, 0, 0], [0, 0, rng.range(0, 1)], [1, rng.range(0.4, 0.8), 1]);
  for (let i = 0; i < 6; i++) k.add('dark', box(rng.range(3, 10), rng.range(3, 10), rng.range(6, 24)), [rng.range(-w, w), rng.range(-w * 0.6, w * 0.6), rng.range(-len / 2, len / 2)], [rng.range(0, 1), rng.range(0, 1), 0]);
  for (let i = 0; i < 5; i++) k.add('dark', cyl(0.6, 0.6, rng.range(10, 30), 5), [rng.range(-w, w), rng.range(-w, w), rng.range(-len / 2, len / 2)], [rng.range(0, 3), 0, rng.range(0, 3)]);
  const geos = k.build();
  const g = new THREE.Group();
  const hm = new THREE.MeshStandardMaterial({ color: '#4a4f57', metalness: 0.7, roughness: 0.75, bumpMap: panelTexture(), bumpScale: 0.8 });
  const dm = new THREE.MeshStandardMaterial({ color: '#25282d', metalness: 0.8, roughness: 0.6 });
  for (const [key, geo] of Object.entries(geos)) { const m = new THREE.Mesh(geo, key === 'hull' ? hm : dm); m.castShadow = true; m.receiveShadow = true; g.add(m); }
  if (rng.chance(0.5)) { const l = new THREE.Mesh(new THREE.SphereGeometry(1.5, 6, 6), new THREE.MeshBasicMaterial({ color: new THREE.Color('#ff9a3a').multiplyScalar(3), toneMapped: false })); l.position.set(w * 0.5, 0, 0); g.add(l); }
  g.userData.radius = Math.max(len * 0.45, w);
  return g;
}

export function buildRuinPiece(rng) {
  const k = new Kit();
  const type = rng.int(0, 2);
  if (type === 0) { // tower
    const h = rng.range(80, 180);
    k.add('hull', box(rng.range(18, 30), h, rng.range(18, 30)));
    for (let i = 0; i < 8; i++) k.add('accent', box(rng.range(20, 34), 3, rng.range(20, 34)), [0, -h / 2 + i * h / 8, 0]);
    for (let i = 0; i < 10; i++) k.add('glow', box(1.2, 1.2, 1.2), [rng.range(-12, 12), rng.range(-h / 2, h / 2), 15.5]);
  } else if (type === 1) { // ring segment
    k.add('hull', tor(rng.range(60, 110), rng.range(6, 10), 6, 24, rng.range(0.8, 2.2)));
    k.add('accent', tor(rng.range(60, 110), 2, 4, 24, rng.range(0.5, 1.5)), [0, 0, 8]);
  } else { // habitat module
    k.add('hull', cyl(20, 20, 60, 10), [0, 0, 0], [Math.PI / 2, 0, 0]);
    for (let i = 0; i < 4; i++) k.add('accent', tor(21, 2, 6, 20), [0, 0, -24 + i * 16]);
    k.add('glass', box(4, 4, 40), [20, 0, 0]);
  }
  const geos = k.build();
  const g = new THREE.Group();
  const mats = {
    hull: new THREE.MeshStandardMaterial({ color: '#505664', metalness: 0.75, roughness: 0.55, bumpMap: panelTexture(), bumpScale: 0.8 }),
    accent: new THREE.MeshStandardMaterial({ color: '#2b2f38', metalness: 0.85, roughness: 0.4 }),
    glow: new THREE.MeshBasicMaterial({ color: new THREE.Color('#ffb47a').multiplyScalar(2.4), toneMapped: false }),
    glass: new THREE.MeshStandardMaterial({ color: '#0a1a2a', metalness: 1, roughness: 0.1, emissive: '#1a3a6a', emissiveIntensity: 0.5 }),
  };
  for (const [key, geo] of Object.entries(geos)) { const m = new THREE.Mesh(geo, mats[key]); m.castShadow = true; m.receiveShadow = true; g.add(m); }
  geos.hull.computeBoundingSphere();
  g.userData.radius = geos.hull.boundingSphere.radius * 0.7;
  return g;
}

// ---------------------------------------------------------------------------
// Boss models — return { group, parts:{name: Object3D[]}, meta }
// ---------------------------------------------------------------------------
function meshesFrom(geos, mats, group) {
  for (const [k, g] of Object.entries(geos)) {
    const m = new THREE.Mesh(g, mats[k] || mats.hull);
    m.castShadow = true; m.receiveShadow = true; group.add(m);
  }
  return group;
}
function bossMats(faction, glow) {
  const base = factionMaterials(faction);
  return { hull: base.hull.clone(), accent: base.accent, dark: base.dark, glass: base.glass, glow: glow ? new THREE.MeshBasicMaterial({ color: new THREE.Color(glow).multiplyScalar(2.6), toneMapped: false }) : base.glow, engineColor: base.engineColor };
}

export function buildDreadnought(variant = null) {
  const faction = 'dominion';
  const mats = bossMats(faction, variant === 'cryo' ? '#9fe6ff' : '#ff4a2a');
  if (variant === 'cryo') { mats.hull.color.set('#9ab8cc'); mats.hull.roughness = 0.2; }
  mats.hull.emissive = new THREE.Color(0);
  const group = new THREE.Group();
  const k = new Kit();
  const L = 320, W = 46;
  k.add('hull', lathe([[W * 0.5, -L / 2], [W * 0.85, -L * 0.4], [W, -L * 0.1], [W * 0.9, L * 0.15], [W * 0.55, L * 0.38], [W * 0.15, L / 2]], 6), [0, 0, 0], [0, 0, Math.PI / 6], [1.3, 0.5, 1]);
  k.add('hull', wing([[0, 140], [70, -80], [60, -120], [0, -100], [-60, -120], [-70, -80]], 10, 2), [0, -6, 0]);
  k.add('accent', box(W * 1.5, 10, L * 0.55), [0, 14, -20]);
  k.add('hull', box(28, 34, 40), [0, 38, -80]);
  k.add('glass', box(29, 4, 6), [0, 48, -60]);
  k.add('dark', box(8, 60, 8), [0, 50, -110]);
  for (let i = 0; i < 8; i++) k.add('dark', box(6, 6, 30), [W * 1.0, 0, -130 + i * 34], [0, 0, 0], 1, true);
  for (let i = 0; i < 12; i++) k.add('glow', box(2, 2, 8), [W * 1.18, 6, -140 + i * 24], [0, 0, 0], 1, true);
  k.add('glow', box(60, 3, 3), [0, -4, 158]);
  meshesFrom(k.build(), mats, group);
  const parts = { gens: [], turrets: [], engines: [], reactor: null, hatches: [] };
  // Shield generators on the spine
  for (let i = 0; i < 4; i++) {
    const g = buildUnit('shieldgen', faction, { tint: variant === 'cryo' ? '#9fe6ff' : null, noFlames: true });
    g.position.set((i % 2 ? 1 : -1) * 34, 40, -40 + i * 40); g.scale.setScalar(1.3);
    group.add(g); parts.gens.push(g);
  }
  // Turrets along the flanks
  for (let i = 0; i < 6; i++) {
    const t = buildUnit('turret', faction, { noFlames: true });
    const side = i % 2 ? 1 : -1;
    t.position.set(side * 62, 6, -100 + Math.floor(i / 2) * 80); t.scale.setScalar(1.2);
    group.add(t); parts.turrets.push(t);
  }
  // Engines (weak points)
  for (const x of [-30, 30]) {
    const e = new THREE.Group();
    const ek = new Kit();
    ek.add('dark', cylZ(18, 22, 30, 14), [0, 0, 0]);
    ek.add('accent', tor(19, 2.6, 6, 24), [0, 0, -14]);
    meshesFrom(ek.build(), { dark: mats.dark, accent: mats.accent }, e);
    const core = new THREE.Mesh(new THREE.CircleGeometry(16, 24), mats.glow); core.rotation.y = Math.PI; core.position.z = -15.2; e.add(core);
    const f = engineFlame(mats.engineColor); f.position.z = -15; f.scale.set(16, 16, 60); e.add(f);
    e.position.set(x, 0, -L / 2 - 6);
    e.userData.flame = f;
    group.add(e); parts.engines.push(e);
  }
  // Reactor (hidden under hatches)
  const reactor = new THREE.Mesh(new THREE.IcosahedronGeometry(16, 1), new THREE.MeshBasicMaterial({ color: new THREE.Color(variant === 'cryo' ? '#9fe6ff' : '#ffaa33').multiplyScalar(3), toneMapped: false }));
  reactor.position.set(0, -20, -10); group.add(reactor); parts.reactor = reactor;
  for (const s of [-1, 1]) {
    const h = new THREE.Mesh(new THREE.BoxGeometry(26, 4, 50), mats.hull);
    h.position.set(s * 13, -24, -10); h.userData.closedX = s * 13; h.userData.side = s;
    group.add(h); parts.hatches.push(h);
  }
  return { group, parts, mats, length: L };
}

export function buildSwarmQueen(event = null) {
  const mats = bossMats('vrell', event === 'spring' ? '#ff8fd0' : '#a6ff3c');
  if (event === 'spring') { mats.hull.color.set('#5a3a5a'); }
  mats.hull.emissive = new THREE.Color(0);
  const group = new THREE.Group();
  const k = new Kit();
  k.add('hull', sph(28, 22, 16), [0, 0, -40], [0, 0, 0], [1, 0.8, 1.6]); // abdomen
  k.add('hull', sph(18, 18, 14), [0, 4, 8], [0, 0, 0], [1.2, 0.9, 1.2]); // thorax
  k.add('accent', sph(12, 16, 12), [0, 8, 32], [0, 0, 0], [1, 0.8, 1.1]); // head
  for (let i = 0; i < 18; i++) { const a = i / 18 * Math.PI * 2; k.add('accent', coneZ(3, 26, 5), [Math.cos(a) * 22, Math.sin(a) * 18, -40 + (i % 3) * 10], [Math.sin(a) * 1.1, -Math.cos(a) * 1.1, 0]); }
  for (const s of [-1, 1]) {
    k.add('accent', coneZ(2.4, 22, 5), [s * 8, 2, 46], [0.2, s * 0.3, 0]); // mandibles
    for (let j = 0; j < 3; j++) k.add('dark', cyl(1.6, 0.8, 34, 6), [s * 22, -14, 14 - j * 12], [0.4, 0, s * 0.9]); // legs
  }
  meshesFrom(k.build(), mats, group);
  // translucent wings
  const wm = new THREE.MeshBasicMaterial({ color: new THREE.Color(event === 'spring' ? '#ff9fd2' : '#c8ff8a'), transparent: true, opacity: 0.22, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending });
  const wings = [];
  for (const s of [-1, 1]) {
    const sh = new THREE.Shape(); sh.moveTo(0, 0); sh.quadraticCurveTo(s * 60, 30, s * 90, -20); sh.quadraticCurveTo(s * 50, -30, 0, -10);
    const w = new THREE.Mesh(new THREE.ShapeGeometry(sh, 12), wm);
    w.rotation.x = -Math.PI / 2; w.position.set(s * 8, 22, 6);
    group.add(w); wings.push(w);
  }
  const core = new THREE.Mesh(new THREE.SphereGeometry(9, 16, 12), mats.glow);
  core.position.set(0, -6, 12); group.add(core);
  const plates = [];
  for (const s of [-1, 1]) { const p = new THREE.Mesh(new THREE.SphereGeometry(12, 12, 8, 0, Math.PI), mats.accent); p.rotation.y = s * Math.PI / 2; p.position.set(s * 2, -8, 14); group.add(p); plates.push(p); }
  const eyes = [];
  for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(2.6, 10, 8), mats.glow); e.position.set(s * 6, 12, 40); group.add(e); eyes.push(e); }
  return { group, parts: { wings, core, plates, eyes }, mats, length: 120 };
}

export function buildPhantom() {
  const g = buildUnit('ace', 'syndicate', { scale: 1.8, tint: '#ff2a4a' });
  // dark cape wings
  const cape = new THREE.Mesh(wing([[1, 0], [9, -6], [7, -9], [1, -6]], 0.15, 0.04), new THREE.MeshStandardMaterial({ color: '#120a18', metalness: 0.9, roughness: 0.3 }));
  g.add(cape);
  const cape2 = cape.clone(); cape2.scale.x = -1; g.add(cape2);
  return { group: g, parts: {}, length: 16 };
}

export function buildAnomaly() {
  const group = new THREE.Group();
  const crystal = new THREE.MeshPhysicalMaterial({ color: '#7ad8ff', metalness: 0.2, roughness: 0.05, transmission: 0.0, emissive: '#2a6aff', emissiveIntensity: 0.8, clearcoat: 1, flatShading: true });
  const core = new THREE.Mesh(new THREE.IcosahedronGeometry(32, 0), crystal);
  group.add(core);
  const inner = new THREE.Mesh(new THREE.IcosahedronGeometry(18, 1), new THREE.MeshBasicMaterial({ color: new THREE.Color('#ffffff').multiplyScalar(3), toneMapped: false }));
  group.add(inner);
  const shards = [];
  for (let i = 0; i < 10; i++) {
    const s = new THREE.Mesh(new THREE.OctahedronGeometry(7, 0), crystal);
    s.scale.set(1, 2.6, 1); s.userData.a = i / 10 * Math.PI * 2; s.userData.r = 70 + (i % 3) * 18; s.userData.tilt = (i % 4) * 0.4;
    group.add(s); shards.push(s);
  }
  const rings = [];
  for (let i = 0; i < 3; i++) {
    const r = new THREE.Mesh(new THREE.TorusGeometry(50 + i * 16, 1.2, 4, 64), new THREE.MeshBasicMaterial({ color: new THREE.Color(i === 1 ? '#b26bff' : '#4ff0ff').multiplyScalar(2.2), toneMapped: false }));
    r.rotation.set(i * 1.1, i * 0.7, 0); group.add(r); rings.push(r);
  }
  return { group, parts: { core, inner, shards, rings }, mats: { crystal }, length: 80 };
}

export function buildHollowWarden() {
  const mats = bossMats('ghost', '#7dff6a');
  mats.hull.emissive = new THREE.Color(0);
  const group = new THREE.Group();
  const k = new Kit();
  k.add('hull', lathe([[14, -70], [22, -50], [26, -10], [22, 30], [10, 60], [1, 75]], 10), [0, 0, 0], [0, 0, 0], [1, 0.6, 1]);
  k.add('accent', box(30, 16, 30), [0, 14, -52]); // stern castle
  k.add('accent', box(22, 8, 20), [0, 12, 40]);
  for (const z of [-25, 5, 32]) k.add('dark', cyl(1.6, 2, 70, 6), [0, 40, z]);
  for (let i = 0; i < 10; i++) k.add('dark', cylZ(1.2, 1.4, 8, 6), [24, 0, -50 + i * 11], [0, Math.PI / 2, 0], 1, true); // cannons
  meshesFrom(k.build(), mats, group);
  const sailMat = new THREE.MeshBasicMaterial({ color: new THREE.Color('#7dff6a').multiplyScalar(0.8), transparent: true, opacity: 0.28, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending });
  const sails = [];
  for (const [z, w, h] of [[-25, 50, 40], [5, 56, 46], [32, 40, 32]]) {
    const geo = new THREE.PlaneGeometry(w, h, 8, 6);
    const p = geo.attributes.position; for (let i = 0; i < p.count; i++) p.setZ(i, Math.sin(p.getX(i) / w * Math.PI) * 6);
    const s = new THREE.Mesh(geo, sailMat); s.position.set(0, 46, z + 2); group.add(s); sails.push(s);
  }
  const lanterns = [];
  for (const [x, y, z] of [[20, 20, -40], [-20, 20, -40], [18, 14, 30], [-18, 14, 30]]) {
    const l = new THREE.Mesh(new THREE.SphereGeometry(4, 12, 10), new THREE.MeshBasicMaterial({ color: new THREE.Color('#ff8a1a').multiplyScalar(3), toneMapped: false }));
    l.position.set(x, y, z); group.add(l); lanterns.push(l);
  }
  return { group, parts: { sails, lanterns }, mats, sailMat, length: 150 };
}

export const MODEL_TYPES = { ENEMY: Object.keys(ENEMY_BUILDERS), OTHER: Object.keys(CAPITAL_BUILDERS) };
