// ============================================================================
// PROJECT STARFALL — campaign story. Pure data: cast, 30 chapters in 3 acts,
// staged objectives with the commander's orders, in-mission chatter, three
// choices and two endings. "{cs}" is replaced with the player's callsign.
// ============================================================================

export const CAST = {
  okafor: { name: 'Cmdr. Ines Okafor', role: 'RESOLUTE ACTUAL', color: '#4fdcff', accent: '#bff3ff', shape: 'officer', skin: '#7a5238', hair: '#15100c', pitch: 0.9 },
  rook: { name: 'Lt. Tamsin "Rook" Reyes', role: 'WINGMATE', color: '#ffb52e', accent: '#ffe4a8', shape: 'pilot', skin: '#c89874', hair: '#3b2416', pitch: 1.25 },
  dex: { name: 'Dex Kowal', role: 'CHIEF ENGINEER', color: '#43ff8e', accent: '#c8ffd8', shape: 'officer', skin: '#e2bc9a', hair: '#c96a2b', pitch: 1.1 },
  vant: { name: 'Kaeso Vant', role: 'THE PHANTOM', color: '#ffcc33', accent: '#fff0b0', shape: 'pilot', skin: '#b88a6a', hair: '#0c0c0c', pitch: 0.8 },
  thale: { name: 'Grand Admiral Thale', role: 'IRON DOMINION', color: '#ff5a3c', accent: '#ffd0c0', shape: 'admiral', pitch: 0.7 },
  hive: { name: 'The Vrell Hive', role: 'TRANSLATED', color: '#7dff6a', accent: '#e8ff9a', shape: 'hive', pitch: 1.6 },
  choir: { name: 'The Null Choir', role: 'UNKNOWN SIGNAL', color: '#b26bff', accent: '#f0d8ff', shape: 'choir', pitch: 0.6 },
  mara: { name: 'Capt. Mara Ashkar-Lin', role: 'ASHKAR MILITIA', color: '#ff8a5a', accent: '#ffd6c0', shape: 'pilot', skin: '#a7744f', hair: '#2a1a10', pitch: 1.05 },
};

export const ACTS = [
  { n: 1, title: 'The Kessler Line', desc: 'The Iron Dominion invades the Reach. You are the only fighter standing between them and everyone you know.' },
  { n: 2, title: 'Ghosts of the Veil', desc: 'Your old instructor leads the raiders hitting the supply lanes. Chasing him wakes something far older.' },
  { n: 3, title: 'Event Horizon', desc: 'Every war in the Reach has the same author. Go to the Lattice and answer it.' },
];

// Chapter fields:
//   intro: lines played over the opening scene      stages: objectives in order
//   stage.obj: objective type    stage.set: properties overridden after setup (e.g. waves, duration)
//   stage.m: mission fields for that stage (boss, elite, ...)    stage.say / stage.done: lines at start / on completion
//   stage.at: [[seconds, who, line]] timed lines    outro: lines after the last stage
//   choice: { id, when: 'before' | 'after', ... }   variant: per-choice overrides of the chapter
const A = (n, t) => ({ act: n, title: t });
export const CHAPTERS = [
  // ===================================================================== ACT I
  { id: 'c1', ...A(1, 'First Light'), region: 'belt', faction: 'dominion', difficulty: 1,
    brief: 'Dominion warships have crossed the Kessler line. A civilian refinery sits in their path and you are the closest fighter.',
    intro: [
      ['okafor', "Resolute Actual to {cs}. Sorry to wake you. The Iron Dominion just crossed the Kessler line."],
      ['okafor', "Thirty-one years of peace, gone in an afternoon. There's a refinery in their path with four hundred workers aboard."],
      ['rook', "Rook here, I'm on your wing. Don't worry, I'll keep the bad guys off you. Mostly."],
      ['okafor', "Hold the line until the evacuation ships arrive. Okafor out."],
    ],
    stages: [
      { obj: 'intercept', set: { waves: 2 }, say: [['okafor', "Bombers inbound on the refinery. Intercept them before they get a firing solution."]],
        done: [['okafor', "Refinery's holding. Good flying, {cs}."]],
        at: [[25, 'rook', "Wow. They really don't like that refinery."]] },
      { obj: 'waves', m: { waves: 2 }, say: [['okafor', "Stragglers are regrouping in the debris field. Clear them out so the evacuation ships can dock."], ['rook', "Mop-up duty. My favourite."]],
        done: [['okafor', "Evacuation ships are docking. That's four hundred people who get to go home."]] },
    ],
    outro: [['okafor', "Come home, {cs}. The admiral who ordered this has a name, and we'll be hearing it a lot: Severin Thale."]] },

  { id: 'c2', ...A(1, 'Ember Fall'), region: 'volcanic', faction: 'dominion', difficulty: 1.05,
    brief: 'Dominion raiders are hunting transports over the volcanic moon of Ashkar. Clear the skies, then bring the convoy home.',
    intro: [
      ['dex', "Hi! Dex Kowal, chief engineer. I tuned your ship last night. Please don't scratch it."],
      ['dex', "Also, the magma flares out there will fry your shields, so maybe fly around those."],
      ['okafor', "Ashkar's colony ships are running a blockade. We clear the corridor, then we escort them out."],
    ],
    stages: [
      { obj: 'waves', m: { waves: 2 }, say: [['okafor', "Corridor's thick with raiders. Thin them out."]], done: [['okafor', "Corridor is clear. Transports, you are go."]],
        at: [[18, 'rook', "Watch the flares. My paint job is already crying."]] },
      { obj: 'escort', say: [['okafor', "Stay close to that freighter. If it dies, the colony doesn't eat this winter."]], done: [['okafor', "Freighter is through. Ashkar owes you a drink."]] },
    ],
    outro: [['rook', "Was it just me, or were those Dominion pilots... scared of something?"]] },

  { id: 'c3', ...A(1, 'Ashkar Under Siege'), region: 'volcanic', faction: 'dominion', difficulty: 1.1,
    brief: 'The Dominion has found the Ashkar colony. Hold every approach until the colony shield comes back online.',
    intro: [
      ['mara', "This is Captain Mara Ashkar-Lin of the colony militia. We have six pilots and no shields. Please tell me you're the cavalry."],
      ['okafor', "We're the cavalry, Captain. {cs}, they're coming from three directions. You can't be everywhere, so be where it hurts."],
    ],
    stages: [
      { obj: 'colony', say: [['mara', "Habitat ring is open to vacuum on the north side. Anything that gets through, we can't patch."]],
        done: [['mara', "Shield's back up! You just saved eleven thousand people, pilot."]], at: [[40, 'rook', "Three vectors, two of us. I like these odds less every minute."]] },
    ],
    outro: [['mara', "If you ever need us, the Ashkar militia flies for you. That's a promise."], ['okafor', "Hold onto that, {cs}. We're going to need friends."]] },

  { id: 'c4', ...A(1, 'Static'), region: 'city', faction: 'dominion', difficulty: 1.15,
    brief: 'Something in the Halcyon ruins is relaying Dominion fleet orders. Find the source and silence it.',
    intro: [
      ['dex', "Weird thing. The Dominion fleet is using a relay in the Halcyon ruins, but it's broadcasting on a frequency nobody uses."],
      ['dex', "Like, nobody. It's not a Dominion code. It's not anyone's code."],
      ['okafor', "Find the relay. First check the derelict near it. Its black box may tell us who built it."],
    ],
    stages: [
      { obj: 'derelict', say: [['okafor', "Approach the derelict and scan it. Expect company."]], done: [['dex', "Got the logs. The ship was Dominion, and its last order wasn't from Thale. It just says 'SING'."]] },
      { obj: 'comms', say: [['okafor', "Relay towers ahead. Black them out before they call the fleet."]], done: [['okafor', "Relay's dark. Whatever was talking through it just went quiet."]] },
    ],
    outro: [['dex', "I kept a copy of that frequency. It was... humming. I'm going to have nightmares."]] },

  { id: 'c5', ...A(1, 'Shield Wall'), region: 'frontier', faction: 'dominion', difficulty: 1.2,
    brief: 'The Dominion forward base is protected by shield generators. Bring them down and break the garrison.',
    intro: [
      ['okafor', "We're taking the fight to them. The forward base at Tarsus shields their whole supply line."],
      ['rook', "Big guns, lots of turrets, zero sense of humour. Classic Dominion."],
    ],
    stages: [
      { obj: 'shieldgen', say: [['okafor', "Generators first. When the wall drops, everything behind it is exposed."]], done: [['okafor', "Shield wall is down! All wings, hit the garrison."]] },
      { obj: 'waves', m: { waves: 2 }, say: [['rook', "Here they come, and they're angry about their wall."]], done: [['okafor', "Tarsus is ours. Thale will feel that one."]] },
    ],
    outro: [['thale', "Pilot. You've cost me a base and three hundred good soldiers. I'll remember your callsign. Remember mine."]] },

  { id: 'c6', ...A(1, 'Red Talon'), region: 'belt', faction: 'dominion', difficulty: 1.25,
    brief: "Escort a fuel tender through the belt. The Dominion's best ace, Commodore Rask, is hunting it.",
    intro: [
      ['okafor', "Our fuel's running low and the tender carrying more just got tagged by Commodore Rask, the Red Talon."],
      ['rook', "Rask has forty kills. I have nine. You have... enough. Let's make it forty and out."],
    ],
    stages: [
      { obj: 'escort', say: [['okafor', "Get the tender through the belt. Rask will make his move when you're busy."]], done: [['okafor', "Tender is safe. Now he's angry."]] },
      { obj: 'acehunt', m: { elite: { name: 'Commodore Rask', personality: 'tactical', variant: 'veteran', faction: 'dominion' } },
        say: [['okafor', "Rask is in the open. Take him down before he regroups."]], done: [['rook', "The Red Talon is down! Someone owes me five credits."]] },
    ],
    outro: [['okafor', "Thale is pulling forces back toward Ashkar and Halcyon at the same time. Get some sleep. Tomorrow you choose."]] },

  { id: 'c7', ...A(1, 'Two Fires'), region: 'volcanic', faction: 'dominion', difficulty: 1.3,
    brief: 'Thale strikes the Ashkar colony and the Halcyon relay at once. You can only reach one in time.',
    choice: { id: 'ashkar', when: 'before', title: 'TWO FIRES', subtitle: 'Thale is attacking two targets at once. The Resolute can only send you to one.',
      options: [
        { id: 'colony', icon: 'planet_lava', title: 'Defend Ashkar', desc: "Save the colony's evacuation. Mara's militia will remember it." },
        { id: 'relay', icon: 'station', title: 'Strike the relay', desc: 'Seize the Halcyon relay and steal the Dominion fleet codes. Ashkar will have to hold alone.' },
      ] },
    variant: {
      'ashkar=colony': { region: 'volcanic',
        intro: [['okafor', "You chose Ashkar. I'd have chosen the same."], ['mara', "Pilot! They brought everything this time. Tell me you've got something left."]],
        stages: [
          { obj: 'colony', say: [['mara', "Evacuation transports are lifting off. Keep the bombers off them!"]], done: [['mara', "Last transport is clear. Every single one."]] },
          { obj: 'survive', set: { duration: 70 }, say: [['okafor', "Thale is throwing everything into the storm to catch you. Survive until the Resolute jumps in."]], done: [['okafor', "Resolute is on station. We've got you."]] },
        ],
        outro: [['mara', "Ashkar flies with you now, {cs}. Wherever you go."], ['dex', "We lost the relay, though. Those codes are gone."]] },
      'ashkar=relay': { region: 'city',
        intro: [['okafor', "Halcyon it is. It's the right call, but it's not an easy one."], ['dex', "If we get the codes, we'll know every move the Dominion makes."]],
        stages: [
          { obj: 'comms', say: [['okafor', "Take the relay's defences offline, and Dex will pull the codes."]], done: [['dex', "Got the codes! And... something else is in here. That same humming."]] },
          { obj: 'survive', set: { duration: 70 }, say: [['okafor', "They know what we took. Hold out until the Resolute can pull you out."]], done: [['okafor', "Resolute is on station. We've got you."]] },
        ],
        outro: [['mara', "...Ashkar held. Barely. We lost a lot of people today, pilot."], ['okafor', "We'll carry that, {cs}. Make the codes count."]] },
    },
    stages: [], outro: [] },

  { id: 'c8', ...A(1, 'Iron Carrier'), region: 'frontier', faction: 'dominion', difficulty: 1.35,
    brief: "A Dominion carrier is feeding fighters into the war. Clear its screen, then take it apart.",
    intro: [
      ['okafor', "The carrier Obdurate launches forty fighters a minute. As long as it flies, we're losing."],
      ['rook', "So we kill the carrier. Love a plan with one step."],
    ],
    stages: [
      { obj: 'waves', m: { waves: 2 }, say: [['okafor', "Clear the fighter screen first."]], done: [['okafor', "Screen's thin. Go for the carrier."]] },
      { obj: 'carrier', say: [['okafor', "Engines, then turrets, then the reactor. It can't run if it can't move."]], done: [['rook', "Carrier's going down! Look at it burn!"]] },
    ],
    outro: [['thale', "Clever little pilot. Come to Sovereign, then. Let me show you what the Dominion really is."]] },

  { id: 'c9', ...A(1, 'Breaking the Line'), region: 'frontier', faction: 'dominion', difficulty: 1.4,
    brief: 'Punch a hole in the Dominion line so the Resolute can reach the flagship.',
    intro: [
      ['okafor', "The Sovereign sits behind a picket of shield stations. Break the picket, and the whole fleet can reach Thale."],
      ['dex', "Your ship has been upgraded twice since breakfast. I'm very proud of us."],
    ],
    stages: [
      { obj: 'shieldgen', say: [['okafor', "Picket generators. Drop them all."]], done: [['okafor', "The picket's open! Hold the breach."]] },
      { obj: 'intercept', set: { waves: 2 }, say: [['okafor', "They're sending everything at our forward station. Keep it alive until the fleet comes through."]], done: [['okafor', "Fleet's through the line. Tomorrow we go for the Sovereign."]] },
    ],
    outro: [['rook', "Hey. Whatever happens tomorrow? It's been an honour, {cs}."]] },

  { id: 'c10', ...A(1, 'Sovereign'), region: 'frontier', faction: 'dominion', difficulty: 1.5,
    brief: 'The Dominion flagship is in range. Break its escorts, then bring the Sovereign down.',
    intro: [
      ['thale', "So this is the pilot. Smaller than I imagined."],
      ['okafor', "Admiral Thale, this is Commander Okafor. Turn your fleet around and we'll let you leave."],
      ['thale', "Leave? Commander, I don't even know why I came. But I know I must finish it."],
      ['dex', "...Did he just say he doesn't know why he's here?"],
    ],
    stages: [
      { obj: 'waves', m: { waves: 1 }, say: [['okafor', "Escort wing first. Then the big one."]], done: [['okafor', "Escorts down. {cs}: it's all yours."]] },
      { obj: 'boss', m: { boss: 'dreadnought' }, say: [['thale', "Sovereign, all batteries. Erase them."]], done: [['thale', "Strange... the song is quiet now..."], ['okafor', "The Sovereign is down! The Dominion fleet is turning back!"]],
        phase: { 1: [['dex', "Beam batteries are online. Don't sit still in front of them!"]], 2: [['okafor', "Engines are down. It's opening up. Hit the reactor!"]], 3: [['thale', "If I fall, I fall singing..."]] } },
    ],
    outro: [['okafor', "The Dominion is leaving the Reach. Take a breath, everyone. You've earned it."], ['dex', "That song Thale mentioned... I'm hearing it in the Veil now. It's louder."]] },

  // ===================================================================== ACT II
  { id: 'c11', ...A(2, 'Smoke and Mirrors'), region: 'nebula', faction: 'syndicate', difficulty: 1.5,
    brief: 'Syndicate raiders are stripping the convoys that the Dominion left behind. Clear them out and take their cargo.',
    intro: [
      ['okafor', "With the Dominion gone, the Syndicate is moving in. They're raiding everything in the Veil."],
      ['rook', "Pirates. Finally, an enemy I'm allowed to dislike for fun."],
      ['dex', "Sensors are bad in the nebula. Trust your eyes, not the radar."],
    ],
    stages: [
      { obj: 'waves', m: { waves: 2 }, say: [['okafor', "Raider screen. Push through."]], done: [['okafor', "Their convoy is exposed."]] },
      { obj: 'convoy', say: [['okafor', "Those freighters are carrying stolen quantum cores. Disable them and collect what they drop."]], done: [['dex', "These cores are stamped with a Starfall crest. Our crest. From before the war."]] },
    ],
    outro: [['okafor', "Starfall cores, in Syndicate hands... There's only one pilot who would know where we kept those."]] },

  { id: 'c12', ...A(2, 'The Boneyard'), region: 'graveyard', faction: 'syndicate', difficulty: 1.55,
    brief: 'A Starfall-program ship lost in the Kessler Incident is broadcasting again from the Boneyard.',
    intro: [
      ['okafor', "Eight years ago, the Kessler Incident wiped out half the Starfall program. One ship was never found."],
      ['okafor', "That ship is transmitting again, from the Boneyard. It was Kaeso Vant's."],
      ['rook', "Vant. Your old instructor. The one who deserted?"],
    ],
    stages: [
      { obj: 'derelict', say: [['okafor', "Scan the wreck. If it's a trap, it's a good one."]], done: [['vant', "Hello, cadet. You got good. I'm proud of you."], ['vant', "Now please go home."]] },
      { obj: 'waves', m: { waves: 2 }, say: [['rook', "Syndicate fighters dropping out of every wreck! It WAS a trap!"]], done: [['okafor', "They've scattered. {cs}... was that really him?"]] },
    ],
    outro: [['vant', "Okafor. Tell your pilot the truth about Kessler, or I will."]] },

  { id: 'c13', ...A(2, 'Marked for Death'), region: 'graveyard', faction: 'syndicate', difficulty: 1.6,
    brief: "The Syndicate put a bounty on you. Their best hunter, Silk, has come to collect it.",
    intro: [
      ['dex', "Good news: you're famous. Bad news: the Syndicate put a bounty on you. It's a really big number."],
      ['rook', "A hunter called Silk took the contract. She's never missed."],
      ['okafor', "Then she can try. We'll make her pay for it."],
    ],
    stages: [
      { obj: 'acehunt', m: { elite: { name: 'Silk', personality: 'evasive', variant: 'veteran', faction: 'syndicate' } },
        say: [['okafor', "Silk is in the Boneyard. She'll run and come back. Keep pressure on her."]], done: [['rook', "Silk is down. The bounty goes up, I bet."]] },
    ],
    outro: [['okafor', "{cs}, about Kessler. I'll tell you everything when this is over. I promise."]] },

  { id: 'c14', ...A(2, 'The Phantom'), region: 'graveyard', faction: 'syndicate', difficulty: 1.65, phantomRetreat: true,
    brief: "Vant is escorting stolen cores out of the Boneyard himself. Protect our salvage tug, then face him.",
    intro: [
      ['vant', "You came. Of course you came. I taught you to always come."],
      ['okafor', "Kaeso, stand down. Whatever this is, we can talk."],
      ['vant', "We talked eight years ago, Ines. You didn't listen then either."],
    ],
    stages: [
      { obj: 'escort', say: [['okafor', "Our tug is recovering cores from the wreck field. Keep it alive."]], done: [['okafor', "Tug is clear... Contact! The Phantom himself."]] },
      { obj: 'boss', m: { boss: 'phantom', phantomRetreat: true }, say: [['vant', "Show me what you learned, cadet."]],
        phase: { 1: [['vant', "Can you tell which one of me is real? I couldn't either, the first time."]], 2: [['rook', "He's cloaking! Watch your six!"]] },
        done: [['vant', "Not bad. Not yet, though. I'll see you in the Veil."]] },
    ],
    outro: [['okafor', "...He's right. I owe you the truth."], ['okafor', "At Kessler, something spoke to us through the comms. Half the squadron turned on the other half. Vant was the only one who heard it and refused."]] },

  { id: 'c15', ...A(2, 'Veil Raid'), region: 'nebula', faction: 'syndicate', difficulty: 1.7,
    brief: "Vant's main convoy is crossing the Veil. Take its cargo before it reaches the deep nebula.",
    intro: [
      ['okafor', "Vant is moving the cores deeper into the Veil. We don't know why, and that scares me."],
      ['dex', "The cores are tuned to the same frequency as the Halcyon relay. The humming one. He's building something."],
    ],
    stages: [
      { obj: 'convoy', say: [['okafor', "Hit the convoy and grab the cores."]], done: [['dex', "Cores recovered! Wait... they're warm. Why are they warm?"]] },
      { obj: 'waves', m: { waves: 2 }, say: [['rook', "Syndicate reinforcements! And... something else on long range. Not Syndicate."]], done: [['okafor', "Area clear. Dex, what was that second contact?"]] },
    ],
    outro: [['dex', "Commander... it wasn't a ship. It was alive."]] },

  { id: 'c16', ...A(2, 'Something Woke Up'), region: 'nebula', faction: 'vrell', difficulty: 1.75,
    brief: 'A Syndicate outpost in the Veil has gone silent. Find out why, and survive whatever did it.',
    intro: [
      ['okafor', "The Syndicate outpost at Veil-9 stopped transmitting an hour ago. Its last message was a scream."],
      ['rook', "Great. Love that. Totally normal mission."],
    ],
    stages: [
      { obj: 'derelict', say: [['okafor', "Scan what's left of the outpost."]], done: [['hive', "THE SONG / CALLED US / WE ARE / AWAKE"], ['dex', "That's the Vrell. They're supposed to be extinct!"]] },
      { obj: 'survive', set: { duration: 80 }, say: [['okafor', "The swarm is all around you! Hold on until we can jump you out!"]], done: [['okafor', "Jump drive is spun up. Get clear!"]],
        at: [[30, 'hive', "SMALL BRIGHT ONE / WHY / DO YOU NOT SING"]] },
    ],
    outro: [['vant', "Now you've met them. The Vrell slept for ten thousand years. Something woke them up the same day the Dominion invaded. Think about that."]] },

  { id: 'c17', ...A(2, 'Brood'), region: 'nebula', faction: 'vrell', difficulty: 1.8,
    brief: 'The Vrell are swarming a refugee colony on the edge of the Veil. Break the swarm and hold the colony.',
    intro: [
      ['okafor', "The swarm is moving toward Thessaly, a refugee colony. Ten thousand people fled there from the Dominion war."],
      ['rook', "They've run from one war already. Not running from this one."],
    ],
    stages: [
      { obj: 'waves', m: { waves: 2 }, say: [['okafor', "Thin the swarm before it reaches the colony."]], done: [['okafor', "Swarm's thinning! The colony is next."]] },
      { obj: 'colony', say: [['okafor', "They're hitting the habitats from all sides. Hold until the shields come up."]], done: [['okafor', "Thessaly's shields are up. You did it."]] },
    ],
    outro: [['hive', "THE QUEEN / SINGS / IN THE HEART OF THE VEIL"], ['dex', "If they have a queen, we can kill the queen. That's how swarms work. Right? Right??"]] },

  { id: 'c18', ...A(2, 'Queen of Nothing'), region: 'nebula', faction: 'vrell', difficulty: 1.9,
    brief: 'The Vrell Swarm Queen is in the heart of the Veil. Cut through her guard and kill her.',
    intro: [
      ['okafor', "Dex traced the swarm's signals to the nebula core. Something enormous is waiting there."],
      ['hive', "SMALL ONE / COMES / TO THE QUEEN"],
      ['rook', "I'll be right behind you. Way, way behind you. Kidding."],
    ],
    stages: [
      { obj: 'waves', m: { waves: 1 }, say: [['okafor', "Royal guard. Break it."]], done: [['okafor', "The Queen is moving. Here she comes."]] },
      { obj: 'boss', m: { boss: 'swarmqueen' }, say: [['hive', "WE / ARE / ENDLESS"]],
        phase: { 1: [['dex', "She's hiding behind hive nodes. Pop the nodes!"]], 2: [['hive', "THE SONG / THE SONG / SHE CANNOT HEAR IT ANYMORE"]] },
        done: [['hive', "...silence... at last..."], ['okafor', "The Queen is dead. The swarm is scattering!"]] },
    ],
    outro: [['vant', "You just killed the only thing in the Veil that was trying to stop listening. Meet me in the belt, cadet. Alone, if you can."]] },

  { id: 'c19', ...A(2, 'Old Debts'), region: 'belt', faction: 'syndicate', difficulty: 1.9,
    brief: "Vant's lieutenant Hask has turned on him and is hunting his defectors. Protect the defectors and deal with Hask.",
    intro: [
      ['vant', "My own people are hunting me. Hask has been hearing the song. They all start hearing it eventually."],
      ['vant', "A shuttle with my defectors is coming through the belt. Protect it, and I'll tell you everything."],
      ['okafor', "...Do it, {cs}. But keep your guns warm."],
    ],
    stages: [
      { obj: 'escort', say: [['vant', "That shuttle is everyone I have left. Please."]], done: [['vant', "They're safe. Thank you, cadet."]] },
      { obj: 'acehunt', m: { elite: { name: 'Hask', personality: 'aggressive', variant: 'veteran', faction: 'syndicate' } },
        say: [['okafor', "Hask is coming in hot. Take him down."]], done: [['rook', "Hask is done. That was personal for him, huh."]] },
    ],
    outro: [['vant', "The thing that spoke at Kessler is called the Null Choir. It lives inside the Lattice. It sings, and people go to war."], ['vant', "I've been trying to build a weapon to silence it. With stolen cores. Now meet me in the Boneyard. One more dance, then we'll decide what I am."]] },

  { id: 'c20', ...A(2, 'Last Dance'), region: 'graveyard', faction: 'syndicate', difficulty: 2.0,
    brief: 'Vant wants one last duel before he gives himself up. Or before he becomes something worse.',
    intro: [
      ['vant', "I can hear it now, cadet. The Choir. It's in my head. I need to know if I can still trust my own hands."],
      ['okafor', "Kaeso, let us help you."],
      ['vant', "You can. Beat me. Then decide."],
    ],
    choice: { id: 'vant', when: 'after', title: 'THE PHANTOM FALLS', subtitle: "Vant's ship is crippled. He's alive, and he's waiting to hear what you decide.",
      options: [
        { id: 'spare', icon: 'shield', title: 'Spare him', desc: 'Bring him home. He knows the Choir better than anyone, and he might still be your friend.' },
        { id: 'finish', icon: 'crosshair', title: 'Finish it', desc: 'The Choir is in his head. Take his data core: everything he learned about the Choir dies with him, except what the core holds.' },
      ] },
    stages: [
      { obj: 'waves', m: { waves: 1 }, say: [['vant', "My last loyal wing. Get past them."]], done: [['vant', "Now. Just you and me."]] },
      { obj: 'boss', m: { boss: 'phantom', phantomReturn: true }, say: [['vant', "No holding back this time."]],
        phase: { 1: [['vant', "Every trick I have, cadet! Every one!"]], 2: [['vant', "The song is so LOUD..."]] },
        done: [['vant', "...Well flown. Well flown."]] },
    ],
    variant: {
      'vant=spare': { outro: [['vant', "You spared me. Ines would have. I'm glad you're more like her than me."], ['okafor', "Welcome back to the Starfall program, Kaeso."]] },
      'vant=finish': { outro: [['dex', "...I've got his data core. It has everything he knew about the Choir."], ['okafor', "He was my friend, {cs}. ...You did what you thought was right."]] },
    },
    outro: [] },

  // ===================================================================== ACT III
  { id: 'c21', ...A(3, 'Aftermath'), region: 'belt', faction: 'vrell', difficulty: 2.0,
    brief: 'Without their Queen the Vrell swarm without direction. Clear the shipping lanes and escort the relief ships.',
    intro: [
      ['okafor', "The swarm has gone feral. They're attacking anything that moves."],
      ['dex', "And the Choir signal is everywhere now. It's coming from the Lattice."],
    ],
    stages: [
      { obj: 'waves', m: { waves: 2 }, say: [['okafor', "Clear the shipping lane."]], done: [['okafor', "Lane is clear. Relief ships, you are go."]] },
      { obj: 'escort', say: [['okafor', "Escort the relief freighter to Thessaly."]], done: [['okafor', "Relief is through. Good work."]] },
    ],
    outro: [['okafor', "Next stop: Halcyon Station. It's been quiet for a week. That's what worries me."]] },

  { id: 'c22', ...A(3, 'Halcyon Falls'), region: 'city', faction: 'vrell', difficulty: 2.05,
    brief: 'The Vrell have nested inside Halcyon Station. Hold the docks while civilians escape, then get out before it falls apart.',
    intro: [
      ['okafor', "The Vrell got into Halcyon. There are still civilians in the docks."],
      ['rook', "We get them out, then we get out. Simple. Ha. Simple."],
    ],
    stages: [
      { obj: 'colony', say: [['okafor', "Hold the docks. Every minute is another shuttle away."]], done: [['okafor', "Last shuttle is away! The station core is going critical. MOVE!"]] },
      { obj: 'escape', say: [['okafor', "Follow the gates out. Don't stop for anything!"]], done: [['rook', "We're out! WE'RE OUT! Halcyon's gone..."]] },
    ],
    outro: [['choir', "little bright one. you run so beautifully. come to us. we will teach you the song."]] },

  { id: 'c23', ...A(3, 'Into the Lattice'), region: 'megastructure', faction: 'choir', difficulty: 2.1,
    brief: 'Enter the Lattice megastructure. Scan its ruins and break the anomaly guarding its outer gate.',
    intro: [
      ['okafor', "The Lattice is older than any species in the Reach. Nobody has gone inside and come back the same."],
      ['dex', "I'm boosting your comm filters, so the song shouldn't get into your head. Probably shouldn't."],
    ],
    stages: [
      { obj: 'derelict', say: [['okafor', "There's a probe wreck at the outer ring. Scan it."]], done: [['dex', "It's not a ship... it's a Choir node. It was waiting for us."]] },
      { obj: 'anomaly', say: [['okafor', "The anomaly at the gate is pulling you in. Break it!"]], done: [['okafor', "The gate is open. We're through."]] },
    ],
    outro: [['choir', "you destroy and destroy. so like the others. so like us."]] },

  { id: 'c24', ...A(3, 'Choir Song'), region: 'megastructure', faction: 'choir', difficulty: 2.15,
    brief: 'The Choir is broadcasting through relay spires inside the Lattice. Silence them and survive its answer.',
    intro: [
      ['dex', "Those spires inside the Lattice are amplifiers. Every war in the Reach was started by that broadcast."],
      ['okafor', "Then we cut the broadcast."],
    ],
    stages: [
      { obj: 'comms', say: [['okafor', "Take down the spires."]], done: [['choir', "you cannot silence a song by breaking the instruments."]] },
      { obj: 'survive', set: { duration: 80 }, say: [['okafor', "Everything in the Lattice is coming for you! Hold on!"]], done: [['okafor', "We've got you. Jumping out."]],
        at: [[35, 'choir', "listen. listen. LISTEN."]] },
    ],
    outro: [['dex', "Bad news. The Choir is reaching for the Sovereign's wreck. The whole Dominion flagship."]] },

  { id: 'c25', ...A(3, 'Shield of the Reach'), region: 'frontier', faction: 'vrell', difficulty: 2.2,
    brief: 'Choir-controlled forces are fortifying the frontier. Drop their shield grid and take their carrier.',
    intro: [
      ['okafor', "The Choir is building a fleet out of everything it touched: Dominion wrecks, Vrell, Syndicate ships."],
      ['rook', "The weirdest army in history. Let's make it the shortest-lived."],
    ],
    stages: [
      { obj: 'shieldgen', say: [['okafor', "Shield grid first."]], done: [['okafor', "Grid is down! Their carrier is exposed!"]] },
      { obj: 'carrier', say: [['okafor', "Take that carrier apart."]], done: [['okafor', "Carrier destroyed. The frontier holds."]] },
    ],
    outro: [['thale', "...pilot... it's me... it's still me... help..."]] },

  { id: 'c26', ...A(3, 'Sovereign Reborn'), region: 'frontier', faction: 'dominion', difficulty: 2.25,
    brief: "The Choir has raised Thale's dreadnought from the dead. Finish what you started.",
    intro: [
      ['dex', "The Sovereign is moving. Its reactor is dead, but it's moving."],
      ['thale', "I am a puppet with a flagship, pilot. Cut the strings. Please."],
      ['okafor', "We'll give you peace, Admiral. One way or another."],
    ],
    stages: [
      { obj: 'waves', m: { waves: 1 }, say: [['okafor', "Clear its escorts."]], done: [['okafor', "Here it comes."]] },
      { obj: 'boss', m: { boss: 'dreadnought' }, say: [['choir', "we will wear this ship until you listen."]],
        phase: { 1: [['thale', "The beams! Even now, I can't stop them!"]], 2: [['thale', "The reactor! Strike true this time!"]] },
        done: [['thale', "...Quiet. Finally... thank you..."]] },
    ],
    outro: [['okafor', "Rest well, Admiral."]] },

  { id: 'c27', ...A(3, 'The Matriarch'), region: 'nebula', faction: 'vrell', difficulty: 2.3,
    brief: 'A new Vrell matriarch has risen in the Veil, fed by the Choir. Survive the swarm and kill her.',
    intro: [
      ['hive', "NEW QUEEN / NEW SONG / LOUDER"],
      ['dex', "The Choir grew a new queen. Bigger. Of course it's bigger."],
    ],
    stages: [
      { obj: 'survive', set: { duration: 70 }, say: [['okafor', "Hold out in the storm until the Matriarch surfaces!"]], done: [['okafor', "She's here!"]] },
      { obj: 'boss', m: { boss: 'swarmqueen' }, say: [['hive', "THE SONG / IS ALL"]],
        phase: { 1: [['rook', "Nodes are up again! Same trick, same answer!"]], 2: [['hive', "WHY / WON'T YOU / LISTEN"]] },
        done: [['hive', "...free..."], ['okafor', "The Matriarch is down. The Vrell are... going home. Into the deep Veil."]] },
    ],
    outro: [['okafor', "Only the Choir is left. One last convoy, then we go for the Lattice core."]] },

  { id: 'c28', ...A(3, 'Last Convoy'), region: 'belt', faction: 'choir', difficulty: 2.35,
    brief: "The Choir is moving resonance cores to the Lattice core. Take them, then escort Dex's weapon to the gate.",
    intro: [
      ['dex', "I built something. Using the cores, Vant's notes, and a lot of coffee. It's a resonance lance. It can reach the Choir's heart."],
      ['okafor', "Then let's get it there."],
    ],
    stages: [
      { obj: 'convoy', say: [['okafor', "Choir convoy. Take their cores, so Dex can charge the lance."]], done: [['dex', "Lance charged! Okay. Okay okay okay."]] },
      { obj: 'escort', say: [['okafor', "Escort the lance to the gate. Everything we have depends on it."]], done: [['okafor', "The lance is at the gate. This is it, everyone."]] },
    ],
    outro: [['rook', "{cs}... whatever's in there. We go in together."]] },

  { id: 'c29', ...A(3, 'The Gate'), region: 'megastructure', faction: 'choir', difficulty: 2.4,
    brief: 'Force the Lattice core gate open. Then decide what to do with the Choir.',
    intro: [
      ['choir', "you have come so far to end a song you never heard. let us sing it to you, once."],
      ['okafor', "Don't listen to it, {cs}. ...Or do. I honestly don't know anymore."],
    ],
    choice: { id: 'lattice', when: 'after', title: 'THE CHOIR SPEAKS', subtitle: "\"we were the last of a people who destroyed themselves. we sang so no one would ever be alone again. we did not know the song was war.\"",
      options: [
        { id: 'silence', icon: 'explosion', title: 'Silence it', desc: "Fire Dex's lance into the core. The Choir dies, and the Lattice may die with it." },
        { id: 'chorus', icon: 'galaxy', title: 'Answer it', desc: 'Open a channel and teach the Choir what its song has done. It has never been told no.' },
      ] },
    stages: [
      { obj: 'anomaly', say: [['okafor', "The gate is fighting back. Break it!"]], done: [['okafor', "Gate is open. Clear the core chamber."]] },
      { obj: 'waves', m: { waves: 2 }, say: [['choir', "please. stop. listen."]], done: [['choir', "we are listening, little bright one. what will you do?"]] },
    ],
    variant: {
      'lattice=silence': { outro: [['dex', "Lance is ready. One shot. Get to the core."]] },
      'lattice=chorus': { outro: [['dex', "Channel is open. I'm routing everything through your ship. Talk to it, {cs}."]] },
    },
    outro: [] },

  { id: 'c30', ...A(3, 'Event Horizon'), region: 'megastructure', faction: 'choir', difficulty: 2.5,
    brief: 'The heart of the Lattice. End the Choir, or change it.',
    intro: [
      ['okafor', "This is where every war in the Reach began. Let's make sure it's where they end."],
      ['rook', "Together, {cs}. Like I promised."],
    ],
    stages: [
      { obj: 'waves', m: { waves: 1 }, say: [['okafor', "Core defences. Push through!"]], done: [['okafor', "The core is waking up..."]] },
      { obj: 'boss', m: { boss: 'anomaly' }, say: [['choir', "then let the last song be sung."]],
        phase: { 1: [['dex', "Space is folding! Don't trust your instruments!"]], 2: [['okafor', "It's opening rifts! Hold on, {cs}, you're almost there!"]] },
        done: [] },
    ],
    variant: {
      'lattice=silence': { finalLines: [['dex', "Lance is away!"], ['choir', "...so this is silence... it is... not so bad..."]] },
      'lattice=chorus': { finalLines: [['choir', "...we hear you. we hear all of you. we did not know the song was pain."], ['choir', "we will learn a new one."]] },
    },
    outro: [] },
];

// Allies who join because of earlier choices
export const ALLIES = {
  militia: { when: c => c.ashkar === 'colony', chapters: ['c9', 'c10', 'c17', 'c22', 'c25', 'c28', 'c30'], count: 2,
    lines: [['mara', "Ashkar militia, on your wing! We said we'd come."]] },
  vant: { when: c => c.vant === 'spare', chapters: ['c21', 'c23', 'c26', 'c29', 'c30'], count: 1,
    lines: [['vant', "Phantom, flying with you. Just like old times, cadet."]] },
};

// Choice effects other than allies
export const EFFECTS = {
  relayCodes: { when: c => c.ashkar === 'relay', chapters: ['c8', 'c9', 'c10'], ambientScale: 0.75,
    lines: [['dex', "Using the stolen fleet codes. Their reinforcements will be late. You're welcome."]] },
  vantCore: { when: c => c.vant === 'finish', chapters: ['c23', 'c30'], bossHp: 0.85,
    lines: [['dex', "Vant's data core mapped the Choir's weak points. It won't be as tough as it thinks."]] },
};

// Chatter during any chapter (picked when nothing else is being said)
export const BARKS = {
  lowHull: [['rook', "{cs}, you're trailing smoke! Get clear!"], ['dex', "Hull integrity is VERY low. Please stop getting shot!"], ['okafor', "{cs}, your hull is failing. Disengage and recover."]],
  shieldDown: [['dex', "Shields down! Give them a second to come back."], ['rook', "Your shields just popped. I'm covering you!"]],
  combo: [['rook', "Look at you go!"], ['okafor', "Excellent shooting, {cs}."], ['rook', "Save some for me!"], ['dex', "I'm writing these kill numbers down. For science."]],
  elite: [['okafor', "Elite contact! Be careful with that one."], ['rook', "That one's got fancy paint. Means trouble."]],
  ally: [['mara', "Ashkar is taking hits! Help us out!"]],
};

export const ENDINGS = {
  silence: {
    title: 'SILENCE',
    lines: [
      "The lance struck the heart of the Lattice, and for the first time in ten thousand years, the Reach was quiet.",
      "The Lattice went dark. Its gates closed, and with them, every road out of the Reach.",
      "No one knows what else is out there now. But no one in the Reach has heard the song since.",
    ],
  },
  chorus: {
    title: 'CHORUS',
    lines: [
      "You opened the channel and told the Choir the truth: every war it had ever started.",
      "The Choir listened. For the first time, it heard something besides its own song.",
      "The Lattice did not go dark. Its gates opened, onto a galaxy nobody in the Reach had ever seen. The Choir went with them, a little quieter, as a guide.",
    ],
  },
  // epilogue lines that depend on earlier choices
  epilogue: {
    'ashkar=colony': "Ashkar rebuilt its habitat ring. Mara Ashkar-Lin still flies the colony patrol, and she still owes you that drink.",
    'ashkar=relay': "With the stolen fleet codes, Okafor negotiated the first real treaty with the Dominion. Ashkar keeps a memorial for the people who were lost the day it held alone.",
    'vant=spare': "Kaeso Vant teaches at the new Starfall academy. He tells cadets never to trust a voice they can't see. He says it every class.",
    'vant=finish': "Vant's data core sits in the Resolute's memorial hall, beside the names of the pilots lost at Kessler. Okafor visits it every year.",
  },
};

export const CREDITS = [
  ['VORTEX STUDIOS', 'presents'],
  ['PROJECT STARFALL', ''],
  ['Story', 'The Kessler Line · Ghosts of the Veil · Event Horizon'],
  ['Cast', 'Cmdr. Ines Okafor · Lt. Tamsin "Rook" Reyes · Dex Kowal · Kaeso Vant · Grand Admiral Severin Thale · Capt. Mara Ashkar-Lin · The Vrell Hive · The Null Choir'],
  ['Built with', 'HTML5 · CSS · JavaScript · Three.js · Web Audio'],
  ['And starring', '{cs}'],
  ['Thank you for playing', ''],
];

// Resolve a chapter for the player's current choices: applies the matching variant
export function resolveChapter(ch, choices = {}) {
  let out = { ...ch };
  for (const [key, v] of Object.entries(ch.variant || {})) {
    const [cid, opt] = key.split('=');
    if (choices[cid] === opt) out = { ...out, ...v };
  }
  return out;
}

export function fillCallsign(text, cs) { return String(text).replace(/\{cs\}/g, cs || 'Starfall'); }
