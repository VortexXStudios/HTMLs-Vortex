// ============================================================================
// Comms: radio dialogue during missions and story scenes. A portrait, the
// speaker's name, typed-out text and a voice blip. Lines queue up; story lines
// always play, chatter ("barks") is dropped when the channel is busy. Nothing
// here pauses the game.
// ============================================================================
import { CAST } from './story.js';

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// Small procedural portraits, one per speaker shape
export function portraitSVG(id) {
  const c = CAST[id] || CAST.okafor;
  const a = c.color, b = c.accent || '#ffffff';
  const bg = `<defs><radialGradient id="pg-${id}" cx="50%" cy="35%" r="70%"><stop offset="0" stop-color="${a}" stop-opacity=".55"/><stop offset="1" stop-color="#050a16"/></radialGradient></defs><rect width="64" height="64" fill="url(#pg-${id})"/>`;
  let body = '';
  switch (c.shape) {
    case 'hive':
      body = `<path d="M32 10 L46 26 L40 50 L32 56 L24 50 L18 26 Z" fill="#0b1a10" stroke="${a}" stroke-width="2"/>
        <path d="M22 24 L12 14 M42 24 L52 14" stroke="${a}" stroke-width="2"/>
        <ellipse cx="26" cy="30" rx="4" ry="6" fill="${b}"/><ellipse cx="38" cy="30" rx="4" ry="6" fill="${b}"/>
        <path d="M27 44 Q32 48 37 44" stroke="${b}" stroke-width="1.5" fill="none"/>`;
      break;
    case 'choir':
      body = `<circle cx="32" cy="32" r="22" fill="none" stroke="${a}" stroke-width="1.5" opacity=".6"/><circle cx="32" cy="32" r="15" fill="none" stroke="${a}" stroke-width="2"/>
        <circle cx="32" cy="32" r="8" fill="${b}"/><circle cx="32" cy="32" r="3" fill="#050a16"/>
        <path d="M6 32 H18 M46 32 H58 M32 6 V18 M32 46 V58" stroke="${a}" stroke-width="1.5"/>`;
      break;
    case 'admiral':
      body = `<path d="M10 64 Q12 44 32 44 Q52 44 54 64 Z" fill="#2a0c0c" stroke="${a}" stroke-width="1.5"/>
        <circle cx="32" cy="27" r="12" fill="#c9a58d"/><path d="M19 22 Q32 6 45 22 L45 18 Q32 2 19 18 Z" fill="#30363f"/>
        <rect x="20" y="16" width="24" height="5" fill="${a}"/><rect x="25" y="26" width="5" height="2" fill="#1a1010"/><rect x="34" y="26" width="5" height="2" fill="#1a1010"/>
        <path d="M27 35 H37" stroke="#5a3a30" stroke-width="1.5"/><path d="M22 50 L28 47 M42 50 L36 47" stroke="${b}" stroke-width="2"/>`;
      break;
    default: { // pilot / officer
      const skin = c.skin || '#c69c7f', hair = c.hair || '#1d1712';
      const helmet = c.shape === 'pilot';
      body = `<path d="M8 64 Q10 44 32 43 Q54 44 56 64 Z" fill="#101c33" stroke="${a}" stroke-width="1.5"/>
        <circle cx="32" cy="27" r="12" fill="${skin}"/>
        ${helmet ? `<path d="M18 28 Q18 10 32 10 Q46 10 46 28 L46 22 Q46 12 32 12 Q18 12 18 22 Z" fill="${hair}"/><path d="M17 27 Q17 8 32 8 Q47 8 47 27 L44 27 Q44 13 32 13 Q20 13 20 27 Z" fill="#283548" stroke="${a}" stroke-width="1"/><rect x="21" y="22" width="22" height="6" rx="2" fill="${b}" opacity=".85"/>`
          : `<path d="M20 26 Q19 13 32 13 Q45 13 44 26 Q40 18 32 18 Q24 18 20 26 Z" fill="${hair}"/><rect x="25" y="26" width="4" height="2" rx="1" fill="#141414"/><rect x="35" y="26" width="4" height="2" rx="1" fill="#141414"/>`}
        <path d="M28 34 Q32 36 36 34" stroke="#5a3a30" stroke-width="1.5" fill="none"/>
        <path d="M26 46 L32 52 L38 46" stroke="${b}" stroke-width="2" fill="none"/>`;
    }
  }
  return `<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">${bg}${body}</svg>`;
}

export class Comms {
  constructor(root, audio) {
    this.audio = audio;
    this.el = document.createElement('div');
    this.el.className = 'hud-comms';
    this.el.innerHTML = '<div class="cm-portrait"></div><div class="cm-body"><div class="cm-name"></div><div class="cm-text"></div></div><div class="cm-skip">click to skip ▸</div>';
    root.appendChild(this.el);
    this.portrait = this.el.querySelector('.cm-portrait');
    this.nameEl = this.el.querySelector('.cm-name');
    this.textEl = this.el.querySelector('.cm-text');
    this.el.addEventListener('pointerdown', e => { e.stopPropagation(); this.skip(); });
    this.queue = [];
    this.cur = null;
    this.barkCd = 0;
    this.log = []; // everything said this mission (for the debrief log)
    this.spoken = 0;
  }

  reset() { this.queue = []; this.cur = null; this.barkCd = 0; this.log = []; this.el.classList.remove('on'); }

  // who: CAST id; text: line; opts.bark = optional chatter (dropped when busy)
  say(who, text, opts = {}) {
    if (!text) return;
    if (opts.bark) {
      if (this.barkCd > 0 || this.cur || this.queue.length) return false;
      this.barkCd = opts.cooldown ?? 9;
    }
    this.queue.push({ who, text, delay: opts.delay || 0, hold: opts.hold });
    return true;
  }
  sayAll(lines, opts = {}) { for (const l of lines || []) this.say(l[0], l[1], opts); }
  get busy() { return !!this.cur || this.queue.length > 0; }
  get pending() { return (this.cur ? 1 : 0) + this.queue.length; }

  skip() {
    if (!this.cur) return;
    if (this.cur.shown < this.cur.text.length) { this.cur.shown = this.cur.text.length; this._render(); this.cur.t = Math.min(this.cur.t, 0.6); }
    else this.cur.t = 0;
  }
  skipAll() { this.queue = []; if (this.cur) this.cur.t = 0; }

  update(dt) {
    this.barkCd = Math.max(0, this.barkCd - dt);
    if (!this.cur) {
      const next = this.queue[0];
      if (!next) { if (this.el.classList.contains('on')) this.el.classList.remove('on'); return; }
      if (next.delay > 0) { next.delay -= dt; return; }
      this.queue.shift();
      const c = CAST[next.who] || { name: next.who, role: '', color: '#4fdcff' };
      this.cur = { ...next, shown: 0, acc: 0, t: next.hold ?? (1.8 + next.text.length / 20), blipT: 0, c };
      this.portrait.innerHTML = portraitSVG(next.who);
      this.nameEl.innerHTML = `${esc(c.name)}${c.role ? ` <small>${esc(c.role)}</small>` : ''}`;
      this.el.style.setProperty('--cc', c.color);
      this.el.classList.add('on');
      this.textEl.textContent = '';
      this.log.push([next.who, next.text]); this.spoken++;
      this.audio?.play('comm');
    }
    const cur = this.cur;
    if (cur.shown < cur.text.length) {
      cur.acc += dt * 55;
      const n = Math.min(cur.text.length, Math.floor(cur.acc));
      if (n !== cur.shown) { cur.shown = n; this._render(); }
      cur.blipT -= dt;
      if (cur.blipT <= 0) { cur.blipT = 0.07; this.audio?.play('blip', { pitch: cur.c.pitch || 1, volume: 0.5 }); }
    } else {
      cur.t -= dt;
      if (cur.t <= 0) { this.cur = null; if (!this.queue.length) this.el.classList.remove('on'); }
    }
  }
  _render() { this.textEl.textContent = this.cur.text.slice(0, this.cur.shown); }
}
