// ============================================================================
// Touch controls: a floating flight stick on the left half of the screen and
// thumb buttons on the right. Buttons feed the same Input state the keyboard
// and mouse use, so gameplay code needs no special cases.
// ============================================================================
export const isTouchDevice = () =>
  typeof window !== 'undefined' && (('ontouchstart' in window) || navigator.maxTouchPoints > 0) &&
  (matchMedia('(pointer: coarse)').matches || !matchMedia('(hover: hover)').matches);

// id, label, key code it drives (or 'fire'), hold (true) vs tap
const BUTTONS = [
  { id: 'fire', label: 'FIRE', code: 'fire', hold: true },
  { id: 'msl', label: 'MSL', code: 'KeyR', hold: true },
  { id: 'boost', label: 'BOOST', code: 'ShiftLeft', hold: true },
  { id: 'dash', label: 'DASH', code: 'Space' },
  { id: 'flip', label: 'FLIP', code: 'KeyV' },
  { id: 'abil', label: 'ABIL', code: 'KeyF' },
  { id: 'swap', label: 'SWAP', code: 'KeyX' },
  { id: 'tgt', label: 'TGT', code: 'KeyT' },
  { id: 'thr', label: 'THR', code: 'KeyW', hold: true },
  { id: 'brk', label: 'BRK', code: 'KeyS', hold: true },
  { id: 'hail', label: 'HAIL', code: 'KeyG' },
  { id: 'rtb', label: 'HOLD\nRETREAT', code: 'KeyJ', hold: true },
];

export class TouchControls {
  constructor(app) {
    this.app = app;
    this.input = app.input;
    this.enabled = isTouchDevice();
    document.body.classList.toggle('touch', this.enabled);
    if (!this.enabled) return;
    const root = this.root = document.createElement('div');
    root.id = 'touch';
    root.innerHTML = `
      <div class="t-zone" id="t-zone"></div>
      <div class="t-stick" id="t-stick"><i></i></div>
      <button class="t-pause" id="t-pause" aria-label="Pause"><span></span><span></span></button>
      ${BUTTONS.map(b => `<button class="t-btn t-${b.id}" data-id="${b.id}">${b.label.replace('\n', '<br>')}</button>`).join('')}`;
    document.body.appendChild(root);
    this.zone = root.querySelector('#t-zone');
    this.stickEl = root.querySelector('#t-stick');
    this.knob = this.stickEl.querySelector('i');
    this.stickId = null;
    this.btnTouches = new Map(); // touch id -> button def
    this.btnEls = {};
    for (const b of BUTTONS) this.btnEls[b.id] = root.querySelector(`.t-${b.id}`);

    const opt = { passive: false };
    const mark = () => { this.input.lastTouch = performance.now(); };
    window.addEventListener('touchstart', mark, { passive: true, capture: true });

    // ---- flight stick (floating: it appears where the thumb lands)
    this.zone.addEventListener('touchstart', e => {
      e.preventDefault();
      if (this.stickId != null) return;
      const t = e.changedTouches[0];
      this.stickId = t.identifier; this.ox = t.clientX; this.oy = t.clientY;
      this.stickEl.style.transform = `translate(${this.ox}px, ${this.oy}px)`;
      this.stickEl.classList.add('on');
      this._moveStick(t.clientX, t.clientY);
    }, opt);
    const moveStick = e => {
      for (const t of e.changedTouches) if (t.identifier === this.stickId) { e.preventDefault(); this._moveStick(t.clientX, t.clientY); }
    };
    const endStick = e => {
      for (const t of e.changedTouches) if (t.identifier === this.stickId) {
        this.stickId = null; this.input.stick.x = 0; this.input.stick.y = 0; this.input.touchSteer = false;
        this.stickEl.classList.remove('on'); this.knob.style.transform = '';
      }
    };
    window.addEventListener('touchmove', moveStick, opt);
    window.addEventListener('touchend', endStick); window.addEventListener('touchcancel', endStick);

    // ---- buttons
    for (const b of BUTTONS) {
      const el = this.btnEls[b.id];
      el.addEventListener('touchstart', e => {
        e.preventDefault();
        for (const t of e.changedTouches) this.btnTouches.set(t.identifier, b);
        this._press(b, true); el.classList.add('down');
      }, opt);
      const up = e => {
        e.preventDefault();
        let still = false;
        for (const t of e.changedTouches) this.btnTouches.delete(t.identifier);
        for (const v of this.btnTouches.values()) if (v === b) still = true;
        if (!still) { this._press(b, false); el.classList.remove('down'); }
      };
      el.addEventListener('touchend', up, opt); el.addEventListener('touchcancel', up, opt);
    }
    root.querySelector('#t-pause').addEventListener('touchstart', e => { e.preventDefault(); this.app.pause(true); }, opt);
    root.querySelector('#t-pause').addEventListener('click', () => this.app.pause(true));
  }

  _moveStick(x, y) {
    const R = Math.max(46, Math.min(70, Math.min(innerWidth, innerHeight) * 0.13));
    let dx = x - this.ox, dy = y - this.oy;
    const len = Math.hypot(dx, dy);
    if (len > R) { dx *= R / len; dy *= R / len; }
    this.knob.style.transform = `translate(${dx}px, ${dy}px)`;
    const s = this.input.sensitivity || 1;
    const clamp = v => Math.max(-1, Math.min(1, v));
    this.input.stick.x = clamp(dx / R * s);
    this.input.stick.y = clamp(dy / R * s * (this.input.invertY ? -1 : 1));
    this.input.touchSteer = true; this.input.usingGamepad = false; this.input.mouseAim = false;
  }

  _press(b, on) {
    const inp = this.input;
    if (b.code === 'fire') {
      inp.mouse.left = on; if (on) inp.mouse.leftPressed = true;
      return;
    }
    if (on) { inp.down.add(b.code); inp.pressedThisFrame.add(b.code); }
    else inp.down.delete(b.code);
  }

  _releaseAll() {
    for (const b of BUTTONS) { this._press(b, false); this.btnEls[b.id].classList.remove('down'); }
    this.btnTouches.clear();
    this.stickId = null; this.input.stick.x = 0; this.input.stick.y = 0; this.input.touchSteer = false;
    this.stickEl.classList.remove('on');
  }

  // Called every frame: show the controls only while actually flying
  update() {
    // keep the hangar's tab strip below the (wrapping) top bar on small screens
    if ((this._tbT = (this._tbT || 0) + 1) % 20 === 0) {
      const tb = document.querySelector('.screen.on .topbar');
      if (tb && tb.offsetHeight !== this._tbH) { this._tbH = tb.offsetHeight; document.documentElement.style.setProperty('--tb', (tb.offsetHeight + 6) + 'px'); }
    }
    if (!this.enabled) return;
    const app = this.app, g = app.game;
    const flying = app.state === 'mission' && !app.paused && g.active && !g.cinematic && !g.choice && g.player?.alive !== false;
    if (flying !== this.visible) {
      this.visible = flying;
      this.root.classList.toggle('on', flying);
      if (!flying) this._releaseAll();
    }
    if (!flying) return;
    const d = g.director;
    this.btnEls.hail.classList.toggle('show', !!(d && d.trader && d.traderState === 'waiting'));
    this.btnEls.rtb.classList.toggle('show', g.mission?.mode !== 'bossrush');
    const P = g.player;
    if (P) {
      this.btnEls.abil.classList.toggle('ready', P.ability && P.ability.cd <= 0);
      this.btnEls.msl.classList.toggle('locked', !!P.weapons?.locked);
    }
  }
}
