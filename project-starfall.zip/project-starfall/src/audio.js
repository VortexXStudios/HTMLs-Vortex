// ============================================================================
// Web Audio: layered synthesized SFX (randomized to avoid repetition) and an
// adaptive procedural music system. Starts only after a user gesture.
// ============================================================================

const NOTE = n => 440 * Math.pow(2, (n - 69) / 12);

export class AudioSystem {
  constructor() {
    this.ctx = null;
    this.ready = false;
    this.volumes = { master: 0.8, music: 0.55, sfx: 0.8 };
    this.lastPlayed = {};
    this.voices = {};
    this.listener = { x: 0, y: 0, z: 0, rx: 1, ry: 0, rz: 0 };
    this.music = null;
    this.loops = {};
  }

  init() {
    if (this.ready) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    const c = this.ctx;
    this.master = c.createGain();
    this.comp = c.createDynamicsCompressor();
    this.comp.threshold.value = -16; this.comp.knee.value = 12; this.comp.ratio.value = 5; this.comp.attack.value = 0.003; this.comp.release.value = 0.18;
    this.master.connect(this.comp); this.comp.connect(c.destination);
    this.sfxBus = c.createGain(); this.sfxBus.connect(this.master);
    this.musicBus = c.createGain(); this.musicBus.connect(this.master);
    // shared reverb send for space ambience
    this.reverb = c.createConvolver(); this.reverb.buffer = this._impulse(2.4, 2.2);
    this.reverbSend = c.createGain(); this.reverbSend.gain.value = 0.25;
    this.reverbSend.connect(this.reverb); this.reverb.connect(this.master);
    this.noiseBuf = this._noise(2);
    this.ready = true;
    this.applyVolumes();
    this.music = new Music(this);
  }

  setVolumes(s) { this.volumes = { master: s.masterVolume, music: s.musicVolume, sfx: s.sfxVolume }; this.applyVolumes(); }
  applyVolumes() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.volumes.master, t, 0.05);
    this.sfxBus.gain.setTargetAtTime(this.volumes.sfx, t, 0.05);
    this.musicBus.gain.setTargetAtTime(this.volumes.music * 0.55, t, 0.05);
  }
  suspend() { if (this.ready && this.ctx.state === 'running') this.ctx.suspend(); }
  resume() { if (this.ready && this.ctx.state === 'suspended') this.ctx.resume(); }

  setListener(pos, right) { this.listener.x = pos.x; this.listener.y = pos.y; this.listener.z = pos.z; if (right) { this.listener.rx = right.x; this.listener.ry = right.y; this.listener.rz = right.z; } }

  _noise(sec) {
    const b = this.ctx.createBuffer(1, this.ctx.sampleRate * sec, this.ctx.sampleRate);
    const d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return b;
  }
  _impulse(sec, decay) {
    const len = this.ctx.sampleRate * sec; const b = this.ctx.createBuffer(2, len, this.ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay); }
    return b;
  }

  // Output node with distance attenuation + stereo pan for positional sounds.
  _out(vol = 1, pos = null, reverb = 0.15) {
    const c = this.ctx;
    const g = c.createGain();
    let v = vol;
    let pan = 0;
    if (pos) {
      const dx = pos.x - this.listener.x, dy = pos.y - this.listener.y, dz = pos.z - this.listener.z;
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      v *= 1 / (1 + Math.pow(d / 180, 1.6));
      if (d > 1) pan = Math.max(-1, Math.min(1, -(dx * this.listener.rx + dy * this.listener.ry + dz * this.listener.rz) / d)) * 0.8;
      if (v < 0.01) return null;
    }
    if (!Number.isFinite(v) || !Number.isFinite(pan)) { if (window.__debugNaN) console.warn('[Starfall] NaN audio', JSON.stringify(pos), vol, new Error().stack.split('\n').slice(2, 5).join(' | ')); if (pos) return null; v = Number.isFinite(v) ? v : 0.5; pan = 0; }
    g.gain.value = v;
    if (c.createStereoPanner) { const p = c.createStereoPanner(); p.pan.value = pan; g.connect(p); p.connect(this.sfxBus); if (reverb > 0) { const s = c.createGain(); s.gain.value = reverb; p.connect(s); s.connect(this.reverbSend); } }
    else g.connect(this.sfxBus);
    return g;
  }

  _throttle(name, minGap, maxVoices = 8) {
    const now = this.ctx.currentTime;
    // global voice budget keeps the audio graph bounded no matter how busy the battle gets
    if (!this._gT || now - this._gT > 0.25) { this._gT = now; let n = 0; for (const k in this.voices) { this.voices[k] = this.voices[k].filter(t => t > now); n += this.voices[k].length; } this._gN = n; }
    if (this._gN >= 40) return false;
    if (this.lastPlayed[name] && now - this.lastPlayed[name] < minGap) return false;
    this.voices[name] = (this.voices[name] || []).filter(t => t > now);
    if (this.voices[name].length >= maxVoices) return false;
    this.lastPlayed[name] = now;
    return true;
  }
  _track(name, dur) { (this.voices[name] = this.voices[name] || []).push(this.ctx.currentTime + dur); this._gN = (this._gN || 0) + 1; }

  osc(type, f0, f1, dur, vol, out, t0 = 0, curve = 'exp') {
    const c = this.ctx, t = c.currentTime + t0;
    const o = c.createOscillator(); o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) { if (curve === 'exp') o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur); else o.frequency.linearRampToValueAtTime(f1, t + dur); }
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.01, dur * 0.2)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(out); o.start(t); o.stop(t + dur + 0.05);
    return o;
  }
  noise(dur, vol, out, filter = 'lowpass', f0 = 2000, f1 = 200, q = 0.7, t0 = 0) {
    const c = this.ctx, t = c.currentTime + t0;
    const s = c.createBufferSource(); s.buffer = this.noiseBuf; s.playbackRate.value = 0.8 + Math.random() * 0.4;
    const f = c.createBiquadFilter(); f.type = filter; f.Q.value = q; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(out); s.start(t, Math.random() * 1.5); s.stop(t + dur + 0.05);
  }

  play(name, opts = {}) {
    if (!this.ready || this.ctx.state !== 'running') return;
    const fn = SFX[name];
    if (!fn) return;
    const def = SFX_META[name] || [0.02, 6];
    if (!this._throttle(name, def[0], def[1])) return;
    const r = (a = 0.92, b = 1.08) => a + Math.random() * (b - a); // pitch variation
    const out = this._out((opts.volume ?? 1), opts.pos || null, opts.reverb ?? 0.15);
    if (!out) return;
    const dur = fn(this, out, r, opts) || 0.3;
    this._track(name, dur);
  }

  // Continuous loops (beam weapon, boost, alarms)
  loop(name, on, opts = {}) {
    if (!this.ready) return;
    const c = this.ctx;
    if (on && !this.loops[name]) {
      const out = c.createGain(); out.gain.value = 0; out.connect(this.sfxBus);
      let nodes = [];
      if (name === 'beam') {
        const o1 = c.createOscillator(); o1.type = 'sawtooth'; o1.frequency.value = 110;
        const o2 = c.createOscillator(); o2.type = 'square'; o2.frequency.value = 221;
        const lfo = c.createOscillator(); lfo.frequency.value = 17; const lg = c.createGain(); lg.gain.value = 30; lfo.connect(lg); lg.connect(o2.frequency);
        const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 900; f.Q.value = 2;
        o1.connect(f); o2.connect(f); f.connect(out); nodes = [o1, o2, lfo];
      } else if (name === 'boost') {
        const s = c.createBufferSource(); s.buffer = this.noiseBuf; s.loop = true;
        const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 600; f.Q.value = 0.8;
        s.connect(f); f.connect(out); nodes = [s]; this.loops._boostFilter = f;
      } else if (name === 'alarm') {
        const o = c.createOscillator(); o.type = 'square'; o.frequency.value = 880;
        const lfo = c.createOscillator(); lfo.type = 'square'; lfo.frequency.value = 3; const lg = c.createGain(); lg.gain.value = 220; lfo.connect(lg); lg.connect(o.frequency);
        const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 1800; o.connect(f); f.connect(out); nodes = [o, lfo];
      } else if (name === 'engine') {
        const o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 48;
        const s = c.createBufferSource(); s.buffer = this.noiseBuf; s.loop = true;
        const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 240;
        o.connect(f); s.connect(f); f.connect(out); nodes = [o, s]; this.loops._engineOsc = o; this.loops._engineFilter = f;
      }
      for (const n of nodes) n.start();
      out.gain.setTargetAtTime(opts.volume ?? 0.15, c.currentTime, 0.04);
      this.loops[name] = { out, nodes };
    } else if (!on && this.loops[name]) {
      const l = this.loops[name]; delete this.loops[name];
      l.out.gain.setTargetAtTime(0, c.currentTime, 0.05);
      setTimeout(() => { for (const n of l.nodes) { try { n.stop(); } catch (e) { /* */ } } l.out.disconnect(); }, 300);
    } else if (on && this.loops[name] && opts.volume != null) {
      this.loops[name].out.gain.setTargetAtTime(opts.volume, c.currentTime, 0.08);
    }
  }
  engineParams(speed01, boost) {
    if (!this.loops.engine) return;
    const t = this.ctx.currentTime;
    this.loops._engineOsc.frequency.setTargetAtTime(40 + speed01 * 40 + (boost ? 25 : 0), t, 0.1);
    this.loops._engineFilter.frequency.setTargetAtTime(180 + speed01 * 300 + (boost ? 500 : 0), t, 0.1);
  }
  stopAllLoops() { for (const k of Object.keys(this.loops)) if (!k.startsWith('_')) this.loop(k, false); }
}

// [minGap seconds, max simultaneous voices]
const SFX_META = {
  pulse: [0.035, 6], scatter: [0.08, 3], plasma: [0.1, 3], rail: [0.15, 2], arc: [0.06, 3], gravity: [0.2, 2], missile: [0.06, 4], torpedo: [0.3, 2], drone: [0.2, 2],
  enemyShot: [0.05, 5], enemyHeavy: [0.12, 3], sniperCharge: [0.3, 2], sniperShot: [0.1, 2], artillery: [0.2, 3],
  hitShield: [0.04, 4], hitHull: [0.03, 5], hitArmor: [0.05, 3], playerShieldHit: [0.06, 2], playerHullHit: [0.06, 2], shieldBreak: [0.4, 1],
  explosionS: [0.03, 6], explosionM: [0.06, 4], explosionL: [0.15, 3], explosionBoss: [0.5, 2],
  pickup: [0.05, 4], coin: [0.04, 4], levelup: [1, 1], achievement: [0.5, 1],
  click: [0.03, 3], hover: [0.04, 2], back: [0.05, 2], buy: [0.1, 2], error: [0.1, 2], equip: [0.08, 2], claim: [0.3, 1],
  complete: [1, 1], fail: [1, 1], bossIntro: [2, 1], warning: [0.5, 1], lock: [0.25, 1], locking: [0.12, 1],
  dash: [0.2, 2], ability: [0.2, 2], emp: [0.5, 1], nova: [0.5, 1], cloak: [0.3, 1], overheat: [0.5, 1], kamikaze: [0.15, 3],
  gate: [0.3, 1], scan: [0.4, 1], alert: [1, 1], wave: [1, 1], reflect: [0.05, 3], heal: [0.5, 1], deflect: [0.06, 3], phase: [0.3, 2], whoosh: [0.2, 2],
};

const SFX = {
  pulse(a, out, r) { const p = r(); a.osc('square', 1400 * p, 380 * p, 0.09, 0.18, out); a.osc('sine', 700 * p, 200 * p, 0.07, 0.15, out); return 0.1; },
  scatter(a, out, r) { a.noise(0.22, 0.6, out, 'lowpass', 5000 * r(), 300, 0.7); a.osc('sawtooth', 180 * r(), 50, 0.18, 0.25, out); return 0.25; },
  plasma(a, out, r) { const p = r(); a.osc('sawtooth', 420 * p, 80 * p, 0.28, 0.25, out); a.osc('sine', 160 * p, 40, 0.3, 0.35, out); a.noise(0.15, 0.2, out, 'bandpass', 1800, 400, 3); return 0.3; },
  rail(a, out, r) { a.noise(0.06, 0.9, out, 'highpass', 6000, 2000, 0.5); a.osc('sawtooth', 3000 * r(), 120, 0.45, 0.22, out); a.osc('sine', 90, 30, 0.5, 0.5, out); return 0.5; },
  arc(a, out, r) { for (let i = 0; i < 3; i++) a.osc('square', 200 + Math.random() * 1600, 100 + Math.random() * 300, 0.05, 0.08, out, i * 0.02, 'lin'); a.noise(0.12, 0.35, out, 'bandpass', 3000 * r(), 1500, 4); return 0.15; },
  gravity(a, out, r) { a.osc('sine', 80, 30, 0.8, 0.5, out); a.osc('sawtooth', 300 * r(), 60, 0.6, 0.12, out); return 0.8; },
  missile(a, out, r) { a.noise(0.5, 0.35, out, 'bandpass', 800 * r(), 3000, 1.5); a.osc('sawtooth', 200 * r(), 500, 0.25, 0.08, out); return 0.5; },
  torpedo(a, out, r) { a.noise(0.9, 0.5, out, 'lowpass', 600, 2500, 1); a.osc('sine', 60, 120, 0.8, 0.5, out, 0, 'lin'); return 0.9; },
  drone(a, out, r) { a.osc('triangle', 600 * r(), 1200, 0.15, 0.15, out); a.osc('triangle', 900 * r(), 1800, 0.15, 0.12, out, 0.12); return 0.3; },
  enemyShot(a, out, r) { const p = r(0.8, 1.2); a.osc('sawtooth', 700 * p, 220 * p, 0.12, 0.12, out); return 0.12; },
  enemyHeavy(a, out, r) { a.osc('sawtooth', 260 * r(), 50, 0.35, 0.25, out); a.noise(0.2, 0.2, out, 'lowpass', 1500, 200); return 0.35; },
  sniperCharge(a, out, r) { a.osc('sine', 300, 1800, 1.4, 0.16, out); a.osc('square', 600, 3600, 1.4, 0.04, out); return 1.4; },
  sniperShot(a, out, r) { a.noise(0.08, 0.7, out, 'highpass', 5000, 1500); a.osc('sawtooth', 2400, 200, 0.3, 0.25, out); return 0.3; },
  artillery(a, out, r) { a.osc('sine', 120, 40, 0.5, 0.5, out); a.noise(0.4, 0.3, out, 'lowpass', 900, 100); return 0.5; },
  hitShield(a, out, r) { a.osc('sine', 1800 * r(), 900, 0.08, 0.12, out); a.osc('triangle', 2600 * r(), 1300, 0.06, 0.06, out); return 0.1; },
  hitHull(a, out, r) { a.noise(0.06, 0.25, out, 'bandpass', 2500 * r(), 800, 2); a.osc('square', 220 * r(), 90, 0.05, 0.08, out); return 0.07; },
  hitArmor(a, out, r) { a.osc('triangle', 3200 * r(), 2600, 0.12, 0.1, out); a.noise(0.05, 0.2, out, 'highpass', 6000, 4000); return 0.12; },
  deflect(a, out, r) { a.osc('triangle', 4200 * r(), 3600, 0.08, 0.08, out); return 0.08; },
  playerShieldHit(a, out, r) { a.osc('sine', 500 * r(), 1400, 0.18, 0.3, out); a.noise(0.15, 0.3, out, 'bandpass', 2000, 4000, 2); return 0.2; },
  playerHullHit(a, out, r) { a.noise(0.3, 0.8, out, 'lowpass', 1800, 100); a.osc('sine', 110, 40, 0.3, 0.6, out); a.osc('square', 1600 * r(), 400, 0.1, 0.06, out); return 0.3; },
  shieldBreak(a, out) { a.osc('sawtooth', 1200, 60, 0.6, 0.3, out); a.noise(0.5, 0.5, out, 'highpass', 3000, 300, 1); return 0.6; },
  explosionS(a, out, r) { a.noise(0.45 * r(), 0.7, out, 'lowpass', 2600 * r(), 120, 0.8); a.osc('sine', 140 * r(), 40, 0.35, 0.45, out); return 0.45; },
  explosionM(a, out, r) { a.noise(0.9 * r(), 0.9, out, 'lowpass', 1800 * r(), 70, 0.7); a.osc('sine', 90 * r(), 25, 0.8, 0.7, out); a.noise(0.2, 0.4, out, 'highpass', 4000, 1000, 0.5); return 0.9; },
  explosionL(a, out, r) { a.noise(1.8, 1, out, 'lowpass', 1200 * r(), 40, 0.6); a.osc('sine', 60 * r(), 18, 1.6, 0.9, out); a.osc('sawtooth', 50, 20, 1.2, 0.2, out); a.noise(1.2, 0.3, out, 'bandpass', 300, 80, 1, 0.25); return 1.8; },
  explosionBoss(a, out) { for (let i = 0; i < 5; i++) { a.noise(2.2, 0.8, out, 'lowpass', 1400, 30, 0.6, i * 0.35); a.osc('sine', 70 - i * 6, 15, 2, 0.6, out, i * 0.35); } return 4; },
  pickup(a, out, r) { const b = 880 * r(0.98, 1.02); a.osc('triangle', b, b, 0.08, 0.15, out); a.osc('triangle', b * 1.5, b * 1.5, 0.1, 0.12, out, 0.06); return 0.18; },
  coin(a, out) { a.osc('square', 1318, 1318, 0.06, 0.08, out); a.osc('square', 1760, 1760, 0.12, 0.08, out, 0.05); return 0.18; },
  levelup(a, out) { [0, 4, 7, 12, 16].forEach((n, i) => a.osc('triangle', NOTE(72 + n), NOTE(72 + n), 0.35, 0.18, out, i * 0.08)); return 0.9; },
  achievement(a, out) { [0, 7, 12, 19].forEach((n, i) => { a.osc('sine', NOTE(76 + n), NOTE(76 + n), 0.6, 0.15, out, i * 0.1); a.osc('triangle', NOTE(64 + n), NOTE(64 + n), 0.5, 0.08, out, i * 0.1); }); return 1; },
  click(a, out) { a.osc('square', 1200, 800, 0.04, 0.06, out); return 0.05; },
  hover(a, out) { a.osc('sine', 1800, 2000, 0.03, 0.03, out); return 0.04; },
  back(a, out) { a.osc('square', 700, 400, 0.06, 0.06, out); return 0.07; },
  equip(a, out) { a.osc('triangle', 600, 900, 0.08, 0.1, out); a.noise(0.08, 0.15, out, 'highpass', 4000, 2000); return 0.1; },
  buy(a, out) { [0, 5, 9].forEach((n, i) => a.osc('square', NOTE(79 + n), NOTE(79 + n), 0.12, 0.07, out, i * 0.06)); return 0.3; },
  claim(a, out) { [0, 4, 7, 11, 14].forEach((n, i) => a.osc('triangle', NOTE(67 + n), NOTE(67 + n), 0.5, 0.12, out, i * 0.09)); a.noise(0.6, 0.1, out, 'highpass', 8000, 4000, 0.5, 0.3); return 1; },
  error(a, out) { a.osc('square', 220, 180, 0.15, 0.08, out); a.osc('square', 180, 150, 0.15, 0.08, out, 0.12); return 0.3; },
  complete(a, out) { [[60, 64, 67], [65, 69, 72], [67, 71, 74], [72, 76, 79]].forEach((ch, i) => ch.forEach(n => a.osc('sawtooth', NOTE(n), NOTE(n), 0.6, 0.05, out, i * 0.22))); return 1.5; },
  fail(a, out) { [[57, 60, 64], [53, 57, 60], [52, 55, 59]].forEach((ch, i) => ch.forEach(n => a.osc('sawtooth', NOTE(n - 12), NOTE(n - 12), 0.9, 0.06, out, i * 0.45))); return 1.8; },
  bossIntro(a, out) { a.osc('sawtooth', NOTE(33), NOTE(33), 2.5, 0.25, out); a.osc('sawtooth', NOTE(40), NOTE(40), 2.5, 0.18, out, 0.1); a.osc('sine', 40, 30, 3, 0.5, out); a.noise(2.5, 0.3, out, 'lowpass', 200, 2000, 2); return 3; },
  warning(a, out) { a.osc('square', 880, 880, 0.12, 0.08, out); a.osc('square', 660, 660, 0.12, 0.08, out, 0.15); return 0.3; },
  lock(a, out) { a.osc('square', 1760, 1760, 0.2, 0.06, out); return 0.2; },
  locking(a, out) { a.osc('square', 1320, 1320, 0.04, 0.04, out); return 0.05; },
  dash(a, out, r) { a.noise(0.3, 0.5, out, 'bandpass', 600 * r(), 3000, 1.5); return 0.3; },
  whoosh(a, out, r) { a.noise(0.5, 0.35, out, 'bandpass', 300 * r(), 1500, 1); return 0.5; },
  ability(a, out) { a.osc('sine', 300, 1200, 0.4, 0.25, out); a.osc('triangle', 600, 2400, 0.4, 0.1, out); return 0.45; },
  emp(a, out) { a.osc('sawtooth', 1600, 40, 0.9, 0.3, out); a.noise(0.8, 0.5, out, 'bandpass', 4000, 200, 2); return 0.9; },
  nova(a, out) { a.osc('sine', 60, 20, 1.6, 0.9, out); a.noise(1.5, 0.9, out, 'lowpass', 3000, 50, 0.5); a.osc('sawtooth', 800, 50, 1, 0.2, out); return 1.6; },
  cloak(a, out) { a.osc('sine', 1200, 200, 0.5, 0.2, out); a.noise(0.5, 0.2, out, 'highpass', 8000, 2000); return 0.5; },
  phase(a, out) { a.osc('sine', 200, 1400, 0.3, 0.12, out); return 0.3; },
  overheat(a, out) { a.noise(0.8, 0.45, out, 'highpass', 3000, 6000, 0.7); a.osc('square', 220, 110, 0.3, 0.06, out); return 0.8; },
  kamikaze(a, out) { a.osc('square', 1500, 1500, 0.05, 0.05, out); return 0.06; },
  gate(a, out) { [0, 7, 12].forEach((n, i) => a.osc('triangle', NOTE(74 + n), NOTE(74 + n), 0.25, 0.1, out, i * 0.05)); a.noise(0.4, 0.3, out, 'bandpass', 500, 4000, 1); return 0.5; },
  scan(a, out) { a.osc('sine', 600, 1600, 0.25, 0.08, out); return 0.25; },
  alert(a, out) { for (let i = 0; i < 3; i++) a.osc('sawtooth', 520, 520, 0.18, 0.08, out, i * 0.28); return 0.9; },
  wave(a, out) { a.osc('sawtooth', NOTE(45), NOTE(45), 0.8, 0.12, out); a.osc('sawtooth', NOTE(52), NOTE(52), 0.8, 0.08, out); a.noise(0.8, 0.15, out, 'lowpass', 300, 2000); return 0.8; },
  reflect(a, out) { a.osc('triangle', 2400, 3600, 0.08, 0.08, out); return 0.08; },
  heal(a, out) { [0, 4, 7].forEach((n, i) => a.osc('sine', NOTE(76 + n), NOTE(76 + n), 0.3, 0.1, out, i * 0.07)); return 0.4; },
};

// ---------------------------------------------------------------------------
// Adaptive music: lookahead scheduler, layered stems, intensity crossfades.
// ---------------------------------------------------------------------------
const PROGRESSIONS = {
  menu:   { bpm: 76,  root: 50, chords: [[0, 3, 7, 10, 14], [-4, 0, 3, 7, 10], [-7, -3, 0, 5, 9], [-2, 2, 5, 9, 12]] },
  combat: { bpm: 118, root: 52, chords: [[0, 3, 7], [-4, 0, 3], [-2, 2, 5], [-5, -2, 2]] },
  boss:   { bpm: 132, root: 48, chords: [[0, 3, 7], [-4, -1, 3], [-2, 1, 5], [-5, -1, 2]] },
  event:  { bpm: 96,  root: 53, chords: [[0, 3, 7], [1, 4, 8], [0, 3, 7], [-2, 1, 5]] },
};

class Music {
  constructor(audio) {
    this.a = audio; this.ctx = audio.ctx;
    this.mode = 'menu'; this.intensity = 0; this.step = 0; this.nextTime = 0; this.playing = false;
    const c = this.ctx;
    this.layers = {};
    for (const k of ['pad', 'bass', 'arp', 'drums', 'lead']) { const g = c.createGain(); g.gain.value = 0; g.connect(audio.musicBus); this.layers[k] = g; }
    const send = c.createGain(); send.gain.value = 0.5; this.layers.pad.connect(send); this.layers.arp.connect(send); this.layers.lead.connect(send); send.connect(audio.reverbSend);
    this.padFilter = c.createBiquadFilter(); this.padFilter.type = 'lowpass'; this.padFilter.frequency.value = 900; this.padFilter.connect(this.layers.pad);
    this.timer = null;
  }
  start(mode = 'menu') {
    this.setMode(mode);
    if (this.playing) return;
    this.playing = true; this.nextTime = this.ctx.currentTime + 0.1;
    this.timer = setInterval(() => this._schedule(), 25);
  }
  stop() { this.playing = false; clearInterval(this.timer); this.timer = null; for (const g of Object.values(this.layers)) g.gain.setTargetAtTime(0, this.ctx.currentTime, 0.5); }
  setMode(mode) {
    if (!PROGRESSIONS[mode]) mode = 'menu';
    this.mode = mode;
    this.setIntensity(mode === 'menu' ? 0 : mode === 'boss' ? 3 : Math.max(1, this.intensity));
  }
  setIntensity(level) {
    this.intensity = level;
    const t = this.ctx.currentTime;
    const tgt = [
      { pad: 0.5, bass: 0, arp: 0.18, drums: 0, lead: 0 },
      { pad: 0.35, bass: 0.35, arp: 0.15, drums: 0.18, lead: 0 },
      { pad: 0.3, bass: 0.45, arp: 0.22, drums: 0.35, lead: 0.08 },
      { pad: 0.3, bass: 0.55, arp: 0.25, drums: 0.45, lead: 0.16 },
    ][Math.max(0, Math.min(3, level))];
    for (const [k, v] of Object.entries(tgt)) this.layers[k].gain.setTargetAtTime(v, t, 1.2);
    this.padFilter.frequency.setTargetAtTime(level === 0 ? 900 : 1400 + level * 500, t, 1);
  }
  _schedule() {
    const P = PROGRESSIONS[this.mode];
    const spb = 60 / P.bpm / 4; // 16th notes
    while (this.nextTime < this.ctx.currentTime + 0.12) {
      this._playStep(this.step, this.nextTime, P, spb);
      this.nextTime += spb; this.step = (this.step + 1) % 256;
    }
  }
  _note(type, freq, t, dur, vol, dest, attack = 0.01) {
    const c = this.ctx; const o = c.createOscillator(); o.type = type; o.frequency.value = freq;
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + attack); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + 0.05);
    return o;
  }
  _playStep(step, t, P, spb) {
    const bar = Math.floor(step / 16) % P.chords.length;
    const chord = P.chords[bar];
    const s16 = step % 16;
    const root = P.root;
    // pad: new chord each bar
    if (s16 === 0) for (const n of chord) { const o = this._note('sawtooth', NOTE(root + 12 + n), t, spb * 16.5, 0.05, this.padFilter, 0.8); o.detune.value = (Math.random() - 0.5) * 14; }
    // bass: driving 8ths in combat, root pulses
    if (this.intensity > 0 && s16 % 2 === 0) {
      const n = chord[0] + (s16 === 6 || s16 === 14 ? 7 : 0);
      this._note(this.mode === 'boss' ? 'sawtooth' : 'triangle', NOTE(root - 12 + n), t, spb * 1.6, 0.32, this.layers.bass);
    }
    // arp
    if ((this.intensity === 0 && s16 % 4 === 0) || (this.intensity > 0 && s16 % 2 === 1)) {
      const idx = Math.floor(step / (this.intensity ? 2 : 4)) % chord.length;
      const oct = (Math.floor(step / 8) % 2) * 12;
      this._note('square', NOTE(root + 24 + chord[idx] + oct), t, spb * 1.4, 0.06, this.layers.arp);
    }
    // drums
    if (this.intensity > 0) {
      const c = this.ctx;
      if (s16 % 4 === 0) { const o = c.createOscillator(); o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.15); const g = c.createGain(); g.gain.setValueAtTime(0.9, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.25); o.connect(g); g.connect(this.layers.drums); o.start(t); o.stop(t + 0.3); }
      if (s16 === 4 || s16 === 12) this._noiseHit(t, 0.18, 'bandpass', 1800, 0.6);
      if (this.intensity >= 2 && s16 % 2 === 1) this._noiseHit(t, 0.04, 'highpass', 8000, 0.25);
      if (this.intensity >= 3 && s16 % 4 === 2) this._noiseHit(t, 0.04, 'highpass', 9000, 0.2);
    }
    // lead motif
    if (this.intensity >= 2 && (s16 === 0 || s16 === 3 || s16 === 6 || s16 === 10)) {
      const motif = [0, 3, 7, 5, 3, 2, 0, -2];
      const n = motif[(Math.floor(step / 4) + bar) % motif.length];
      this._note('sawtooth', NOTE(root + 24 + chord[0] + n), t, spb * 3, 0.05, this.layers.lead, 0.02);
    }
  }
  _noiseHit(t, dur, type, freq, vol) {
    const c = this.ctx; const s = c.createBufferSource(); s.buffer = this.a.noiseBuf;
    const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq;
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f); f.connect(g); g.connect(this.layers.drums); s.start(t, Math.random()); s.stop(t + dur + 0.02);
  }
}
