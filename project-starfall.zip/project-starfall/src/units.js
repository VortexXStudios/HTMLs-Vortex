// ============================================================================
// Units: enemies, allies, structures — plus AI behaviours and formations.
// ============================================================================
import * as THREE from 'three';
import { ENEMIES, VARIANTS } from './data.js';
import { buildUnit, disposeUnit } from './models.js';
import { hexTexture } from './textures.js';
import { holdStation, frontFlankPoint } from './combat.js';

const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3(), tmp3 = new THREE.Vector3(), tmpQ = new THREE.Quaternion(), tmpM = new THREE.Matrix4();
const UP = new THREE.Vector3(0, 1, 0), Z = new THREE.Vector3(0, 0, 1);

export const STRUCTURES = {
  station:    { name: 'Civilian Refinery', hp: 3400, shield: 900, radius: 56, model: 'station', team: 'ally', structure: true, faction: 'ally', behavior: 'spin' },
  dome:       { name: 'Habitat Dome', hp: 1200, shield: 300, radius: 26, model: 'dome', team: 'ally', structure: true, faction: 'ally', behavior: 'static' },
  battleship: { name: 'ISS Resolute', hp: 5200, shield: 1600, radius: 66, model: 'battleship', team: 'ally', faction: 'ally', behavior: 'battleship', speed: 0 },
  comms:      { name: 'Relay Dish', hp: 560, shield: 200, radius: 20, model: 'comms', team: 'enemy', structure: true, behavior: 'spin', score: 600, credits: 30 },
  shieldgen:  { name: 'Shield Generator', hp: 650, shield: 0, radius: 14, model: 'shieldgen', team: 'enemy', structure: true, behavior: 'spin', score: 500, credits: 25 },
  pylon:      { name: 'Crystal Pylon', hp: 850, shield: 150, radius: 14, model: 'pylon', team: 'enemy', structure: true, faction: 'choir', behavior: 'spin', score: 700, credits: 30 },
  freighter:  { name: 'Armored Freighter', hp: 950, shield: 350, radius: 24, model: 'freighter', team: 'enemy', behavior: 'freighter', speed: 34, score: 800, credits: 40 },
  derelict:   { name: 'Derelict Warship', hp: 1e9, radius: 52, model: 'derelict', team: 'neutral', structure: true, invulnerable: true, faction: 'dominion', behavior: 'spin' },
  trader:     { name: 'The Wanderer', hp: 2500, radius: 18, model: 'trader', team: 'neutral', faction: 'neutral', behavior: 'trader' },
  cargo:      { name: 'Cargo Pod', hp: 30, radius: 5, model: 'cargo', team: 'enemy', behavior: 'drift', faction: 'neutral', loot: 'cargo', score: 50, passive: true },
  mine:       { name: 'Proximity Mine', hp: 12, radius: 4, model: 'mine', team: 'enemy', behavior: 'mine', score: 30, passive: true },
  turret:     { name: 'Defense Turret', hp: 400, shield: 120, radius: 11, model: 'turret', team: 'enemy', behavior: 'turret', structure: true, score: 300, credits: 15 },
  etorpedo:   { name: 'Torpedo', hp: 16, radius: 3.4, model: 'kamikaze', team: 'enemy', behavior: 'etorpedo', scale: 0.6, score: 40, passive: true },
  wingman:    { name: 'Allied Fighter', hp: 180, shield: 60, radius: 6, model: 'interceptor', faction: 'ally', team: 'ally', behavior: 'wingman', speed: 170, accel: 230, turn: 2.6, weapon: { dmg: 5, rate: 3, speed: 520, spread: 0.03 } },
  pdrone:     { name: 'Hornet Drone', hp: 40, radius: 2.5, model: 'drone', faction: 'ally', team: 'ally', behavior: 'pdrone', speed: 260, accel: 600, turn: 6 },
  cruiser:    { name: 'Dominion Cruiser', hp: 3600, shield: 1200, radius: 58, model: 'capital', team: 'enemy', behavior: 'capital', speed: 10, score: 5000, credits: 300, elite: true },
  carrier:    { name: 'Dominion Carrier', hp: 4000, shield: 800, radius: 66, model: 'capital', team: 'enemy', behavior: 'carrier', speed: 8, scale: 1.15, score: 6000, credits: 350, elite: true },
  gate:       { name: 'Escape Gate', hp: 1e9, radius: 36, model: 'gate', team: 'neutral', structure: true, invulnerable: true, intangible: true, faction: 'ally', behavior: 'static' },
  part:       { name: 'Component', hp: 500, radius: 10, team: 'enemy', behavior: 'part' },
};

let UID = 1;

export class Unit {
  constructor(game, type, opts = {}) {
    this.game = game;
    this.id = UID++;
    this.type = type;
    const def = this.def = { ...(ENEMIES[type] || STRUCTURES[type] || STRUCTURES.part), ...(opts.def || {}) };
    this.name = opts.name || def.name;
    this.faction = opts.faction || def.faction || 'dominion';
    this.team = opts.team || def.team || 'enemy';
    this.variant = opts.variant ? VARIANTS[opts.variant] : null;
    this.variantId = opts.variant || null;
    const mut = game.mutators;
    const sizeMult = opts.scale || def.scale || (this.team === 'enemy' && !def.structure && !opts.boss && !opts.part ? (mut.has('giants') ? 2 : mut.has('tiny') ? 0.55 : 1) : 1);
    if (opts.mesh) this.mesh = opts.mesh;
    else this.mesh = buildUnit(def.model || type, this.faction === 'neutral' && def.model !== 'trader' && def.model !== 'cargo' ? 'dominion' : this.faction, { tint: this.variant?.tint || opts.tint || null, scale: sizeMult, noFlames: def.structure });
    this.radius = (opts.radius || def.radius) * (opts.mesh ? 1 : sizeMult);
    const dm = opts.hpMult ?? (this.team === 'enemy' ? game.enemyHpMult : 1);
    const vm = this.variant ? this.variant.hp : 1;
    const giant = mut.has('giants') && this.team === 'enemy' && !def.structure ? 2.5 : mut.has('tiny') && this.team === 'enemy' && !def.structure ? 0.5 : 1;
    this.maxHp = (opts.hp || def.hp) * dm * vm * giant;
    this.hp = this.maxHp;
    this.maxShield = (opts.shield ?? def.shield ?? 0) * dm * (this.variant?.shield || 1) * (this.team === 'enemy' && game.mission.modifiers.includes('regen') ? 1.3 : 1);
    this.shield = this.maxShield;
    this.shieldDelay = 0;
    this.speed = (def.speed || 100) * (this.variant?.speed || 1) * (mut.has('giants') && this.team === 'enemy' ? 0.7 : mut.has('tiny') && this.team === 'enemy' ? 1.3 : 1);
    this.accel = def.accel || this.speed * 1.5;
    this.turn = def.turn || 1.5;
    this.baseTurn = this.turn; this.baseAccel = this.accel;
    if (this.team === 'enemy' && !def.structure && !opts.boss && !opts.part && game.tune) { this.turn *= game.tune.turn; this.accel *= game.tune.accel; }
    this.dmgMult = (this.variant?.dmg || 1) * (this.team === 'enemy' ? game.enemyDamageMult : 1);
    this.rateMult = this.variant?.rate || 1;
    this.behavior = opts.behavior || def.behavior || 'static';
    this.structure = !!def.structure;
    this.invulnerable = !!def.invulnerable || !!opts.invulnerable;
    this.intangible = !!def.intangible;
    this.untargetable = false;
    this.elite = !!def.elite || !!opts.elite;
    this.boss = !!opts.boss; this.part = !!opts.part; this.parentBoss = opts.parentBoss || null;
    this.alive = true;
    this.pos = this.part ? new THREE.Vector3() : this.mesh.position;
    this.vel = new THREE.Vector3();
    this.quat = this.mesh.quaternion;
    this.forward = new THREE.Vector3(0, 0, 1);
    this.ai = { t: Math.random() * 10, phase: Math.random() * Math.PI * 2, state: 'init', cd: 1 + Math.random() * 2, jinkCd: 1 + Math.random() * 2 };
    this.weaponCd = 0.5 + Math.random() * 1.5;
    this.stunned = 0; this.flash = 0; this.slowed = 0;
    this.lastHit = -10; this.lastAttacker = null;
    this.score = opts.score ?? def.score ?? 50;
    this.marker = opts.marker || null; // HUD marker label
    this.objective = !!opts.objective;
    this.onDeath = opts.onDeath || null;
    this.phased = false;
    this.protector = null;
    this.hostile = opts.hostile || false;
    this.loot = opts.loot ?? def.loot ?? null;
    this.formation = null; this.slot = 0;
    this.target = null;
    this.spawnTime = game.time;
    this.killedBy = null;
    this.passive = !!def.passive;
    if (opts.pos) this.pos.copy(opts.pos);
    if (opts.vel) this.vel.copy(opts.vel);
    if (opts.lookAt) this.mesh.lookAt(opts.lookAt);
    if (def.aura) this._buildAura(def.aura);
    if (this.variant?.phase) this.phaseT = Math.random() * 4;
  }

  _buildAura(r) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 16), new THREE.MeshBasicMaterial({ color: new THREE.Color('#5ab8ff').multiplyScalar(1.4), map: hexTexture(), transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
    m.scale.setScalar(r / this.mesh.scale.x);
    this.mesh.add(m);
    this.aura = m;
  }

  get hpFrac() { return this.hp / this.maxHp; }

  // Accelerate toward a desired velocity and turn to face movement (or `face`)
  steer(desired, dt, face = null, bank = true) {
    tmp.copy(desired).sub(this.vel);
    const maxDv = this.accel * dt;
    const l = tmp.length();
    if (l > maxDv) tmp.multiplyScalar(maxDv / l);
    this.vel.add(tmp);
    const lookDir = face || this.vel;
    if (lookDir.lengthSq() > 1) {
      tmp2.copy(lookDir).normalize();
      tmpM.lookAt(tmp3.set(0, 0, 0), tmp2.negate(), UP); // object lookAt convention: +Z toward target
      tmpQ.setFromRotationMatrix(tmpM);
      if (bank) { // roll into turns
        const side = tmp.dot(tmp3.set(1, 0, 0).applyQuaternion(this.quat));
        tmpQ.multiply(new THREE.Quaternion().setFromAxisAngle(Z, THREE.MathUtils.clamp(-side * 0.02, -0.7, 0.7)));
      }
      this.quat.slerp(tmpQ, Math.min(1, this.turn * dt * 1.6));
    }
  }
  faceTowards(dir, dt, rate = null) {
    tmp2.copy(dir).normalize();
    tmpM.lookAt(tmp3.set(0, 0, 0), tmp2.negate(), UP);
    tmpQ.setFromRotationMatrix(tmpM);
    this.quat.slerp(tmpQ, Math.min(1, (rate ?? this.turn) * dt * 1.6));
  }

  gunWorld(i = 0, out = new THREE.Vector3()) {
    const guns = this.mesh.userData.guns || [];
    if (!guns.length) return out.copy(this.pos);
    return out.copy(guns[i % guns.length]).applyMatrix4(this.mesh.matrixWorld);
  }

  // Fire a bolt toward a target with lead + spread
  fire(target, opts = {}) {
    const g = this.game, w = opts.weapon || this.def.weapon;
    if (!w) return;
    const from = this.gunWorld(this.ai.gun = (this.ai.gun || 0) + 1, new THREE.Vector3());
    const speed = opts.speed || w.speed;
    const d = from.distanceTo(target.pos);
    const lead = opts.noLead ? 0 : d / speed * (this.variantId === 'veteran' ? 1 : 0.85);
    const aim = tmp.copy(target.pos).addScaledVector(target.vel || tmp3.set(0, 0, 0), lead).sub(from).normalize();
    const sp = (opts.spread ?? w.spread ?? 0.03) * (this.def.elite ? 0.6 : 1);
    aim.x += (Math.random() - 0.5) * sp * 2; aim.y += (Math.random() - 0.5) * sp * 2; aim.z += (Math.random() - 0.5) * sp * 2; aim.normalize();
    const color = opts.color || this.mesh.userData.engines && g.factionColor(this.faction, this.variantId);
    g.projectiles.spawn({
      kind: opts.kind || 'bolt', team: this.team === 'ally' ? 'ally' : 'enemy', pos: from, vel: aim.multiplyScalar(speed),
      life: opts.life || 3.2, dmg: (opts.dmg || w.dmg) * this.dmgMult, radius: opts.radius || 1.4, size: opts.size || 1.2, len: opts.len || 5,
      color, source: this, splash: opts.splash || 0, splashDmg: opts.splashDmg, target: opts.homing ? target : null, turn: opts.turn || 0,
      chill: this.variant?.chill, trail: opts.trail || null, spore: opts.spore,
    });
    if (opts.sound !== false) g.audio.play(opts.heavy ? 'enemyHeavy' : 'enemyShot', { pos: from, volume: 0.5 });
  }

  inFront(pos, cos = 0.95) { tmp.copy(pos).sub(this.pos).normalize(); return tmp.dot(this.forward) > cos; }

  update(dt) {
    const g = this.game;
    if (this.part) {
      this.mesh.getWorldPosition(this.pos);
    }
    this.forward.copy(Z).applyQuaternion(this.part ? this.mesh.getWorldQuaternion(tmpQ) : this.quat);
    this.ai.t += dt;
    if (this.flash > 0) { this.flash = Math.max(0, this.flash - dt * 6); const hm = this.mesh.userData.hullMat; if (hm) hm.emissive.setRGB(this.flash * 1.4, this.flash * 0.9, this.flash * 0.6); }
    if (this.maxShield > 0 && this.shield < this.maxShield) {
      this.shieldDelay -= dt;
      const regen = g.mission.modifiers.includes('regen') && this.team === 'enemy' ? 0.25 : 0.06;
      if (this.shieldDelay <= 0) this.shield = Math.min(this.maxShield, this.shield + this.maxShield * regen * dt);
    }
    // seasonal ghost phasing
    if (this.variant?.phase) {
      this.phaseT += dt;
      const wasPhased = this.phased;
      this.phased = (this.phaseT % 4) > 2.8;
      if (this.phased !== wasPhased) { this.mesh.visible = !this.phased || true; this._setOpacity(this.phased ? 0.25 : 1); }
    }
    if (this.stunned > 0) {
      this.stunned -= dt;
      this.vel.multiplyScalar(1 - 1.5 * dt);
      if (Math.random() < 0.3) g.effects.sparks(this.pos, '#9fd8ff', 1, 30, 1.2, 0.3);
    } else if (!this.part) {
      const fn = BEHAVIORS[this.behavior];
      if (fn) fn(this, dt, g);
    } else if (BEHAVIORS[this.behavior]) {
      BEHAVIORS[this.behavior](this, dt, g);
    }
    if (!this.part) {
      if (!Number.isFinite(this.vel.x + this.vel.y + this.vel.z)) { if (!g._nanWarned) { g._nanWarned = true; console.warn('[Starfall] non-finite velocity on', this.type, this.behavior); } this.vel.set(0, 0, 0); }
      if (g.mutators.has('lowgrav')) this.vel.multiplyScalar(1 - 0.05 * dt);
      this.pos.addScaledVector(this.vel, dt);
      // gravity wells affect enemies too
      for (const w of g.gravityWells) {
        if (this.structure || this.boss) break;
        if (w.projectilesOnly) continue;
        tmp.copy(w.pos).sub(this.pos); const d2 = Math.max(900, tmp.lengthSq());
        if (d2 < w.radius * w.radius) this.vel.addScaledVector(tmp.normalize(), w.strength * 2400 / Math.sqrt(d2) * dt);
      }
    }
    // engine flame flicker
    const fl = this.mesh.userData.flames;
    if (fl && fl.length) {
      const pw = Math.min(1.2, 0.35 + this.vel.length() / Math.max(1, this.speed));
      for (const f of fl) { f.material.uniforms.uTime.value = g.time; f.material.uniforms.uPower.value = pw; }
    }
  }

  _setOpacity(a) {
    for (const m of this.mesh.userData.meshes || []) {
      if (m.material === this.mesh.userData.hullMat) { m.material.transparent = a < 1; m.material.opacity = a; }
    }
  }

  dispose() {
    if (this.aura) { this.aura.geometry.dispose(); this.aura.material.dispose(); }
    if (!this.part) disposeUnit(this.mesh);
  }
}

// ---------------------------------------------------------------------------
// Behaviours
// ---------------------------------------------------------------------------
function dirTo(u, pos, out = tmp) { return out.copy(pos).sub(u.pos); }
function avoid(u, g, out) {
  // light separation from neighbours + big obstacles
  for (const o of g.env.obstacles) { tmp3.copy(u.pos).sub(o.pos); const d = tmp3.length(); const r = o.radius + 30; if (d < r) out.addScaledVector(tmp3.normalize(), (r - d) * 3); }
  return out;
}
function playerAimingAt(u, g, cos = 0.985) {
  const P = g.player; if (!P.alive) return false;
  tmp3.copy(u.pos).sub(P.pos); const d = tmp3.length(); if (d > 700) return false;
  return tmp3.divideScalar(d).dot(P.forward) > cos;
}
function jink(u, g, dt, strength = 140) {
  u.ai.jinkCd -= dt;
  if (u.ai.commit > 0) return; // committed to a straight attack run: the player's window to shoot
  const vet = u.variantId === 'veteran' || u.elite;
  const k = g.tune ? g.tune.jink : 1;
  if (u.ai.jinkCd <= 0 && playerAimingAt(u, g, vet ? 0.975 : 0.99)) {
    tmp3.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).cross(u.forward).normalize();
    u.vel.addScaledVector(tmp3, strength * (vet ? 1.4 : 1) * k);
    u.ai.jinkCd = (vet ? 0.8 + Math.random() : 1.6 + Math.random() * 2) / Math.max(0.3, k);
  }
}
const assisted = g => g.tune && g.tune.maxAttackers !== Infinity;
const holding = (u, g, t) => u.engaged === false && t === g.player;
function tryFire(u, g, target, dt, cos = 0.94, range = 520) {
  const w = u.def.weapon; if (!w || !target) return;
  u.weaponCd -= dt;
  if (u.ai.burstLeft > 0) {
    u.ai.burstT -= dt;
    if (u.ai.burstT <= 0) { u.ai.burstLeft--; u.ai.burstT = 0.08; u.fire(target); }
    return;
  }
  if (u.weaponCd > 0) return;
  const d = u.pos.distanceTo(target.pos);
  if (d > range || !u.inFront(target.pos, cos)) return;
  u.weaponCd = (1 / (w.rate * u.rateMult)) * (w.burst ? w.burst * 0.5 : 1) * (0.8 + Math.random() * 0.4);
  if (w.burst) { u.ai.burstLeft = w.burst - 1; u.ai.burstT = 0.08; }
  u.fire(target);
}

export const BEHAVIORS = {
  static(u, dt) { u.vel.multiplyScalar(0.9); },
  spin(u, dt) { u.vel.multiplyScalar(0.9); u.mesh.rotation.y += dt * 0.15; },
  drift(u, dt) { u.mesh.rotation.x += dt * 0.4; u.mesh.rotation.y += dt * 0.3; },
  part(u, dt, g) { /* driven by boss controller */ },

  swarm(u, dt, g) {
    const f = u.formation;
    if (f && !f.broken) {
      const sp = f.slotPos(u.slot, tmp2);
      const to = dirTo(u, sp);
      const d = to.length();
      const want = to.multiplyScalar(Math.min(1, d / 30) * u.speed * 1.4 / Math.max(1, d)).addScaledVector(f.vel, 1);
      u.steer(want, dt, f.heading);
      // Invasion-grid tradition: front row fires down the lane
      if (f.isFrontRow(u.slot)) { const t = f.target; if (t && t.alive) { u.weaponCd -= dt * 0.6; if (u.weaponCd <= 0 && u.pos.distanceTo(t.pos) < 700) { u.weaponCd = 1.2 + Math.random() * 2.2; u.fire(t, { spread: 0.05 }); } } }
      return;
    }
    const t = u.target = g.enemyTarget(u);
    if (!t) { u.steer(tmp.set(0, 0, 0), dt); return; }
    if (holding(u, g, t)) { holdStation(u, g, dt, true); return; }
    const to = dirTo(u, t.pos); const d = to.length(); to.divideScalar(d || 1);
    if (u.ai.state === 'swoop') {
      u.ai.swoop -= dt; if (u.ai.swoop <= 0) u.ai.state = 'attack';
      u.steer(tmp2.copy(u.ai.away).multiplyScalar(u.speed), dt);
    } else {
      if (d < (assisted(g) ? 110 : 70)) {
        u.ai.state = 'swoop'; u.ai.swoop = 1.2 + Math.random();
        // assisted: peel off back toward the player's front instead of diving past onto their tail
        u.ai.away = t === g.player && assisted(g) ? frontFlankPoint(g, Math.random() < 0.5 ? -1 : 1, 320, new THREE.Vector3()).sub(u.pos).normalize()
          : to.clone().negate().add(new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5)).normalize();
      }
      const ph = u.ai.t * 3 + u.ai.phase;
      tmp2.copy(to).cross(UP).normalize().multiplyScalar(Math.sin(ph) * 0.5);
      tmp2.y += Math.cos(ph * 0.7) * 0.35;
      tmp2.add(to).normalize().multiplyScalar(u.speed);
      avoid(u, g, tmp2);
      u.steer(tmp2, dt);
      tryFire(u, g, t, dt, 0.93, 420);
    }
  },

  flank(u, dt, g) {
    const t = u.target = g.enemyTarget(u);
    if (!t) return;
    const ai = u.ai;
    if (holding(u, g, t)) { holdStation(u, g, dt, true); return; }
    const to = dirTo(u, t.pos, tmp2); const d = to.length();
    if (ai.state === 'init' || ai.state === 'hold') { ai.state = 'flank'; ai.timer = 4; ai.side = ai.side || (Math.random() < 0.5 ? 1 : -1); }
    ai.timer -= dt; ai.commit = Math.max(0, (ai.commit || 0) - dt);
    const front = t === g.player && assisted(g);
    if (ai.state === 'flank') {
      // set up the run from beside the target. Assisted: beside and AHEAD of the player, so the run comes in where it can be seen
      let side;
      if (front) side = frontFlankPoint(g, ai.side, 240, tmp);
      else { const tf = t.forward || tmp3.set(0, 0, 1); side = tmp.copy(tf).cross(UP).normalize().multiplyScalar(ai.side * 200).add(t.pos).addScaledVector(UP, Math.sin(ai.phase) * 80); }
      const dd = dirTo(u, side, tmp3); const dl = dd.length();
      u.steer(dd.multiplyScalar(u.speed / Math.max(1, dl)), dt);
      if (dl < 60 || ai.timer <= 0) { ai.state = 'attack'; ai.timer = 3.2; ai.commit = front ? 0.9 : 0; }
    } else if (ai.state === 'attack') {
      u.steer(to.multiplyScalar(u.speed * (ai.commit > 0 ? 0.85 : 1.05) / Math.max(1, d)), dt);
      if (ai.commit <= 0.3) tryFire(u, g, t, dt, 0.95, 560); // straight-in approach first, then open fire
      if (d < (front ? g.tune.breakDist : 90) || ai.timer <= 0) {
        ai.state = 'break'; ai.timer = 1.8;
        ai.away = front ? frontFlankPoint(g, -ai.side, 420, new THREE.Vector3()).sub(u.pos).normalize()
          : new THREE.Vector3().copy(u.forward).add(new THREE.Vector3(Math.random() - 0.5, Math.random() * 0.6, Math.random() - 0.5)).normalize();
      }
    } else if (ai.state === 'break') {
      if (front && ai.timer < 1.2) ai.away.copy(frontFlankPoint(g, -ai.side, 420, tmp3)).sub(u.pos).normalize(); // keep curving back into view
      u.steer(tmp.copy(ai.away).multiplyScalar(u.speed * 1.1), dt);
      if (ai.timer <= 0) { ai.state = 'flank'; ai.timer = 4; ai.side *= -1; }
    }
    jink(u, g, dt);
  },

  bomber(u, dt, g) {
    const t = u.target = g.objectiveTarget(u) || g.enemyTarget(u);
    if (!t) return;
    const ai = u.ai;
    const to = dirTo(u, t.pos, tmp2); const d = to.length();
    const want = d > 380 ? to.multiplyScalar(u.speed / d) : tmp.copy(to).cross(UP).normalize().multiplyScalar(u.speed * 0.5);
    u.steer(want, dt, to.clone());
    ai.cd -= dt * u.rateMult;
    if (ai.charging > 0) {
      ai.charging -= dt;
      if (Math.random() < 0.6) g.effects.sparks(u.gunWorld(0, tmp3), '#ffcc66', 2, 25, 2, 0.3);
      if (ai.charging <= 0) {
        const torp = g.spawnUnit('etorpedo', { pos: u.gunWorld(0, new THREE.Vector3()), faction: u.faction, def: { blastDmg: u.def.weapon.dmg * u.dmgMult } });
        torp.ai.target = t; torp.vel.copy(u.forward).multiplyScalar(60);
        g.audio.play('torpedo', { pos: u.pos, volume: 0.8 });
      }
    } else if (ai.cd <= 0 && d < 700) {
      ai.cd = 1 / u.def.weapon.rate; ai.charging = 1.6;
      g.audio.play('sniperCharge', { pos: u.pos, volume: 0.4 });
      if (t === g.player) g.hud.warn('TORPEDO LAUNCH DETECTED', 1.6);
    }
    // tail gunner
    const P = g.player;
    if (P.alive && u.pos.distanceTo(P.pos) < 260) { u.ai.tail = (u.ai.tail || 0) - dt; if (u.ai.tail <= 0) { u.ai.tail = 0.5; u.fire(P, { weapon: { dmg: 4, speed: 360, spread: 0.08 }, dmg: 4, sound: false }); } }
  },

  sniper(u, dt, g) {
    const t = u.target = g.enemyTarget(u);
    if (!t) return;
    const ai = u.ai;
    const to = dirTo(u, t.pos, tmp2); const d = to.length(); to.divideScalar(d || 1);
    let want;
    if (d < 520) want = tmp.copy(to).multiplyScalar(-u.speed);
    else if (d > 820) want = tmp.copy(to).multiplyScalar(u.speed);
    else want = tmp.copy(to).cross(UP).multiplyScalar(u.speed * 0.4 * Math.sin(ai.t * 0.4 + ai.phase));
    u.steer(want, dt, to.clone(), false);
    ai.cd -= dt * u.rateMult;
    if (ai.charge > 0) {
      ai.charge -= dt;
      if (ai.charge > 0.3) ai.aimPos = (ai.aimPos || new THREE.Vector3()).copy(t.pos).addScaledVector(t.vel || tmp3.set(0, 0, 0), d / u.def.weapon.speed);
      const gp = u.gunWorld(0, tmp3);
      const blink = ai.charge < 0.3 ? (Math.sin(g.time * 60) > 0 ? 1 : 0.3) : 0.35 + (1.5 - ai.charge) * 0.3;
      g.effects.sight(gp, ai.aimPos, '#ff2a2a', blink);
      if (ai.charge <= 0) {
        const from = gp.clone();
        const dir = ai.aimPos.clone().sub(from).normalize();
        g.projectiles.spawn({ kind: 'bolt', team: 'enemy', pos: from, vel: dir.multiplyScalar(u.def.weapon.speed), life: 1.6, dmg: u.def.weapon.dmg * u.dmgMult, radius: 2.2, size: 2.2, len: 14, color: '#ff4a4a', source: u });
        g.effects.glowPuff(from, '#ff4a4a', 8, 0.15);
        g.audio.play('sniperShot', { pos: from });
      }
    } else if (ai.cd <= 0 && d < 1100 && g.hasLOS(u.pos, t.pos)) {
      ai.cd = 1 / u.def.weapon.rate; ai.charge = u.def.weapon.telegraph;
      g.audio.play('sniperCharge', { pos: u.pos, volume: 0.6 });
      if (t === g.player) g.hud.warn('SNIPER LOCK', 1.2);
    }
  },

  support_shield(u, dt, g) {
    const allies = g.enemiesNear(u.pos, 500, x => x !== u && !x.structure && !x.boss);
    const P = g.player;
    let goal;
    if (allies.length) { goal = tmp.set(0, 0, 0); for (const a of allies) goal.add(a.pos); goal.divideScalar(allies.length); }
    else goal = tmp.copy(P.pos);
    const to = dirTo(u, goal, tmp2); const d = to.length();
    const keep = allies.length ? 30 : 380;
    u.steer(d > keep ? to.multiplyScalar(u.speed / d) : to.multiplyScalar(0), dt, P.alive ? tmp3.copy(P.pos).sub(u.pos) : null);
    const r = u.def.aura;
    for (const a of allies) { if (a.pos.distanceToSquared(u.pos) < r * r && u.shield > 0) a.protector = u; else if (a.protector === u) a.protector = null; }
    if (u.aura) { u.aura.visible = u.shield > 0; u.aura.material.opacity = 0.08 + 0.06 * Math.sin(g.time * 3); u.aura.rotation.y += dt * 0.3; }
    if (P.alive) tryFire(u, g, P, dt, 0.8, 450);
  },

  support_repair(u, dt, g) {
    const P = g.player;
    let best = null, bestF = 0.92;
    for (const a of g.units) {
      if (!a.alive || a === u || a.team !== 'enemy' || a.passive) continue;
      const f = a.hp / a.maxHp; if (f < bestF && a.pos.distanceToSquared(u.pos) < 700 * 700) { best = a; bestF = f; }
    }
    const pd = P.alive ? u.pos.distanceTo(P.pos) : 9999;
    if (pd < 170) { // flee from the player
      tmp2.copy(u.pos).sub(P.pos).normalize().multiplyScalar(u.speed * 1.2);
      u.steer(tmp2, dt);
      u.ai.healing = null;
      return;
    }
    if (best) {
      const to = dirTo(u, best.pos, tmp2); const d = to.length();
      const want = d > 55 + best.radius ? to.multiplyScalar(u.speed / d) : tmp.set(0, 0, 0);
      u.steer(want, dt, tmp3.copy(best.pos).sub(u.pos));
      if (d < 110 + best.radius) {
        best.hp = Math.min(best.maxHp, best.hp + u.def.heal * dt * (best.maxHp > 500 ? 3 : 1));
        g.effects.beam(u.gunWorld(0, tmp3).clone(), best.pos, '#43ff8e', 0.5, dt * 1.6);
        if (Math.random() < 0.2) g.effects.sparks(best.pos, '#43ff8e', 2, 30, 1.5, 0.5);
      }
    } else {
      const c = g.enemiesNear(u.pos, 600)[0];
      if (c && c !== u) u.steer(dirTo(u, c.pos, tmp2).normalize().multiplyScalar(u.speed * 0.4), dt);
      else u.steer(tmp.set(0, 0, 0), dt);
    }
  },

  stealth(u, dt, g) {
    const P = g.player; const ai = u.ai;
    const t = u.target = g.enemyTarget(u);
    if (!t) return;
    if (ai.state === 'init') { ai.state = 'cloaked'; ai.timer = 3 + Math.random() * 3; }
    if (holding(u, g, t)) { u.untargetable = false; u.mesh.visible = true; holdStation(u, g, dt, true); return; }
    if (ai.state === 'hold') { ai.state = 'cloaked'; ai.timer = 2 + Math.random() * 2; }
    ai.timer -= dt;
    const cloaked = ai.state === 'cloaked';
    u.untargetable = cloaked;
    u.mesh.visible = !cloaked || Math.sin(g.time * 30 + ai.phase) > 0.97;
    if (cloaked) {
      // sneak behind the target
      // classic: sneak onto the target's tail. Assisted: decloak off the player's wing, inside their view
      const behind = t === g.player && assisted(g) ? frontFlankPoint(g, Math.sin(ai.phase) > 0 ? 1 : -1, 170, tmp)
        : tmp.copy(t.forward || UP).multiplyScalar(-140).add(t.pos).addScaledVector(UP, 30);
      const to = dirTo(u, behind, tmp2); const d = to.length();
      u.steer(to.multiplyScalar(u.speed * 1.2 / Math.max(1, d)), dt);
      if (Math.random() < 0.05) g.effects.sparks(u.pos, '#c05cff', 1, 10, 2, 0.5);
      if (d < 50 || ai.timer <= 0) { ai.state = 'decloak'; ai.timer = 0.6; g.audio.play('phase', { pos: u.pos }); g.effects.ring(u.pos, 18, '#c05cff', 0.4); }
    } else if (ai.state === 'decloak') {
      u.steer(dirTo(u, t.pos, tmp2).normalize().multiplyScalar(u.speed * 0.4), dt);
      if (ai.timer <= 0) { ai.state = 'attack'; ai.timer = 2.8; }
    } else if (ai.state === 'attack') {
      const to = dirTo(u, t.pos, tmp2); const d = to.length();
      u.steer(to.multiplyScalar((d > 120 ? u.speed : -u.speed * 0.3) / Math.max(1, d)), dt, tmp3.copy(t.pos).sub(u.pos));
      tryFire(u, g, t, dt, 0.9, 450);
      jink(u, g, dt, 100);
      if (ai.timer <= 0) { ai.state = 'cloaked'; ai.timer = 4 + Math.random() * 3; g.audio.play('cloak', { pos: u.pos, volume: 0.5 }); }
    }
  },

  kamikaze(u, dt, g) {
    const t = u.target = g.objectiveTarget(u, 0.3) || g.enemyTarget(u);
    if (!t) return;
    const to = dirTo(u, t.pos, tmp2); const d = to.length();
    const lead = tmp.copy(t.pos).addScaledVector(t.vel || tmp3.set(0, 0, 0), Math.min(1.2, d / (u.speed * 1.5))).sub(u.pos).normalize();
    const boost = d < 300 ? 1.5 : 1;
    u.steer(lead.multiplyScalar(u.speed * boost), dt);
    u.ai.beep = (u.ai.beep || 0) - dt;
    if (u.ai.beep <= 0) { u.ai.beep = Math.max(0.08, d / 1200); if (d < 500) g.audio.play('kamikaze', { pos: u.pos, volume: 0.6 }); }
    const blink = Math.sin(g.time * (10 + 3000 / Math.max(40, d))) > 0;
    if (u.mesh.userData.hullMat) u.mesh.userData.hullMat.emissive.setRGB(blink ? 0.8 : 0, 0, 0);
    if (d < u.radius + (t.radius || 6) + 4) g.detonate(u, u.def.blast, u.def.blastDmg * u.dmgMult);
  },

  etorpedo(u, dt, g) {
    const t = u.ai.target;
    u.ai.life = (u.ai.life ?? 12) - dt;
    if (!t || !t.alive || u.ai.life <= 0) { g.detonate(u, 25, 5); return; }
    const to = dirTo(u, t.pos, tmp2); const d = to.length();
    u.turn = 1.4; u.speed = 130; u.accel = 120;
    u.steer(to.multiplyScalar(u.speed / Math.max(1, d)), dt);
    if (Math.random() < 0.8) g.effects.trailPuff(u.pos, '#ff7a3a', 2.2, 0.5);
    if (d < u.radius + (t.radius || 6) + 3) g.detonate(u, 32, u.def.blastDmg || 28);
  },

  artillery(u, dt, g) {
    const t = u.target = g.objectiveTarget(u, 0.5) || g.enemyTarget(u);
    if (!t) return;
    const ai = u.ai;
    const to = dirTo(u, t.pos, tmp2); const d = to.length(); to.divideScalar(d || 1);
    const want = d < 600 ? tmp.copy(to).multiplyScalar(-u.speed) : d > 950 ? tmp.copy(to).multiplyScalar(u.speed) : tmp.set(0, 0, 0);
    u.steer(want, dt, to.clone());
    ai.cd -= dt * u.rateMult;
    if (ai.cd <= 0 && d < 1300) {
      ai.cd = 1 / u.def.weapon.rate;
      const w = u.def.weapon;
      const from = u.gunWorld(0, new THREE.Vector3());
      const flight = Math.max(1.6, from.distanceTo(t.pos) / w.speed);
      const aim = new THREE.Vector3().copy(t.pos).addScaledVector(t.vel || tmp3.set(0, 0, 0), flight * 0.8);
      const vel = aim.clone().sub(from).divideScalar(flight);
      g.effects.marker(aim, w.blast, flight + 0.1, '#ff5a2a');
      g.projectiles.spawn({ kind: 'orb', team: 'enemy', pos: from, vel, life: flight + 0.2, dmg: 0, radius: 3, size: 3.2, color: '#ff7a2a', shell: true, aim, splash: w.blast, splashDmg: w.dmg * u.dmgMult, source: u, trail: '#ff7a2a' });
      g.audio.play('artillery', { pos: from });
    }
  },

  ace(u, dt, g) {
    const t = u.target = g.enemyTarget(u);
    if (!t) return;
    const ai = u.ai;
    const pers = ai.personality || 'aggressive';
    const to = dirTo(u, t.pos, tmp2); const d = to.length(); to.divideScalar(d || 1);
    // retreat when badly hurt (handled by objective via retreatAt)
    if (u.retreatAt && u.hp / u.maxHp < u.retreatAt && !ai.retreated) { ai.retreated = true; g.unitRetreat(u); return; }
    if (holding(u, g, t)) { holdStation(u, g, dt, true); return; }
    if (pers === 'aggressive') {
      BEHAVIORS.flank(u, dt, g);
      return;
    }
    if (pers === 'evasive') {
      const ideal = 380;
      const radial = d > ideal + 80 ? 1 : d < ideal - 80 ? -1 : 0;
      tmp.copy(to).multiplyScalar(radial * u.speed);
      tmp3.copy(to).cross(UP).normalize().multiplyScalar(Math.sin(ai.t * 1.7 + ai.phase) * u.speed);
      tmp.add(tmp3); tmp.y += Math.cos(ai.t * 1.3) * u.speed * 0.4;
      u.steer(tmp, dt, to.clone());
      jink(u, g, dt, 200);
      ai.cd -= dt;
      if (ai.charge > 0) {
        ai.charge -= dt;
        g.effects.sight(u.gunWorld(0, tmp3), t.pos, '#ffcc33', 0.5);
        if (ai.charge <= 0) u.fire(t, { speed: 900, dmg: 18, size: 1.8, len: 10, color: '#ffcc33', heavy: true, spread: 0.01 });
      } else if (ai.cd <= 0) { ai.cd = 1.8; ai.charge = 0.6; }
      return;
    }
    // tactical
    const want = d > 450 ? tmp.copy(to).multiplyScalar(u.speed) : d < 300 ? tmp.copy(to).multiplyScalar(-u.speed * 0.6) : tmp.copy(to).cross(UP).multiplyScalar(u.speed * 0.6);
    u.steer(want, dt, to.clone());
    tryFire(u, g, t, dt, 0.9, 600);
    ai.droneCd = (ai.droneCd ?? 6) - dt;
    if (ai.droneCd <= 0) { ai.droneCd = 12; for (let k = 0; k < 2; k++) g.spawnUnit('swarm', { pos: u.pos.clone().add(new THREE.Vector3(Math.random() * 20 - 10, 5, Math.random() * 20 - 10)), faction: u.faction }); g.effects.ring(u.pos, 20, '#ffcc33', 0.4); }
    ai.missileCd = (ai.missileCd ?? 3) - dt;
    if (ai.missileCd <= 0 && d < 700) { ai.missileCd = 5; u.fire(t, { kind: 'missile', speed: 200, dmg: 16, homing: true, turn: 2.2, life: 4, size: 1, trail: '#ffcc66', splash: 10 }); }
    if (u.shield <= 0 && (ai.bubbleCd ?? 0) <= 0) { ai.bubble = 3; ai.bubbleCd = 15; g.effects.ring(u.pos, 25, '#ffcc33', 0.5); }
    ai.bubbleCd = (ai.bubbleCd ?? 0) - dt;
    if (ai.bubble > 0) { ai.bubble -= dt; u.invulnerable = ai.bubble > 0; if (Math.random() < 0.4) g.effects.sparks(u.pos, '#ffcc33', 1, 20, 2, 0.3); }
  },

  sentinel(u, dt, g) {
    const P = g.player; const ai = u.ai;
    u.mesh.rotation.y += dt * 0.25;
    const t = g.enemyTarget(u);
    if (t) { const to = dirTo(u, t.pos, tmp2); const d = to.length(); u.vel.lerp(to.multiplyScalar(d > 500 ? u.speed / d : 0), dt); }
    ai.cd -= dt;
    if (t && ai.cd <= 0 && u.pos.distanceTo(t.pos) < 900) { ai.cd = 0.3 / u.rateMult; u.fire(t, { spread: 0.02 }); }
    ai.ring = (ai.ring ?? 5) - dt;
    if (ai.ring <= 0) {
      ai.ring = 6.5;
      const n = 28; const axis = new THREE.Vector3(Math.random() - 0.5, 1, Math.random() - 0.5).normalize();
      const base = new THREE.Vector3(1, 0, 0).cross(axis).normalize();
      for (let k = 0; k < n; k++) {
        const v = base.clone().applyAxisAngle(axis, k / n * Math.PI * 2).multiplyScalar(160);
        g.projectiles.spawn({ kind: 'orb', team: 'enemy', pos: u.pos.clone(), vel: v, life: 5, dmg: 9 * u.dmgMult, radius: 2.4, size: 2.2, color: '#ff5a3c', source: u });
      }
      g.audio.play('enemyHeavy', { pos: u.pos });
      g.effects.ring(u.pos, 40, '#ff5a3c', 0.5, axis);
    }
  },

  brood(u, dt, g) {
    const t = g.enemyTarget(u); const ai = u.ai;
    if (!t) return;
    const to = dirTo(u, t.pos, tmp2); const d = to.length();
    u.steer(d > 320 ? to.multiplyScalar(u.speed / d) : tmp.copy(to).cross(UP).normalize().multiplyScalar(u.speed * 0.6), dt, to.clone());
    ai.spawnCd = (ai.spawnCd ?? 4) - dt;
    ai.children = (ai.children || []).filter(c => c.alive);
    if (ai.spawnCd <= 0 && ai.children.length < 9) {
      ai.spawnCd = 9;
      for (let k = 0; k < 3; k++) { const c = g.spawnUnit('swarm', { pos: u.pos.clone().add(new THREE.Vector3(Math.random() * 30 - 15, Math.random() * 20 - 10, -20)), faction: u.faction }); ai.children.push(c); }
      g.effects.ring(u.pos, 40, '#a6ff3c', 0.6);
      g.audio.play('drone', { pos: u.pos });
    }
    ai.cd -= dt;
    if (ai.cd <= 0 && d < 700) {
      ai.cd = 4;
      for (let k = 0; k < 6; k++) u.fire(t, { kind: 'orb', speed: 140, dmg: 12, homing: true, turn: 1.1, life: 5, size: 2.4, radius: 2.6, color: '#a6ff3c', spread: 0.35, sound: k === 0, spore: true, splash: 12 });
    }
  },

  capital(u, dt, g) {
    const ai = u.ai;
    if (ai.moveTo) { const to = dirTo(u, ai.moveTo, tmp2); const d = to.length(); u.steer(d > 20 ? to.multiplyScalar(u.speed / d) : tmp.set(0, 0, 0), dt, ai.face || null, false); }
    else u.vel.multiplyScalar(0.95);
    if (ai.shielded) { u.invulnerable = true; }
    const P = g.player;
    ai.flak = (ai.flak ?? 1) - dt;
    if (P.alive && ai.flak <= 0 && u.pos.distanceTo(P.pos) < 650) {
      ai.flak = 0.35;
      const from = u.pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * u.radius, u.radius * 0.3, (Math.random() - 0.5) * u.radius * 1.6));
      const aim = P.pos.clone().addScaledVector(P.vel, from.distanceTo(P.pos) / 380).sub(from).normalize();
      aim.x += (Math.random() - 0.5) * 0.1; aim.y += (Math.random() - 0.5) * 0.1; aim.normalize();
      g.projectiles.spawn({ kind: 'bolt', team: 'enemy', pos: from, vel: aim.multiplyScalar(380), life: 2.5, dmg: 6 * u.dmgMult, radius: 1.6, size: 1.4, len: 4, color: '#ff7a4a', source: u });
    }
  },

  carrier(u, dt, g) {
    BEHAVIORS.capital(u, dt, g);
    const ai = u.ai;
    ai.launch = (ai.launch ?? 6) - dt;
    ai.fighters = (ai.fighters || []).filter(f => f.alive);
    if (ai.launch <= 0 && ai.fighters.length < 6 && !ai.disabledHangar) {
      ai.launch = 16;
      for (let k = 0; k < 3; k++) {
        const pos = u.pos.clone().add(new THREE.Vector3(0, -8, 40).applyQuaternion(u.quat)).add(new THREE.Vector3(k * 10 - 10, 0, 0));
        const f = g.spawnUnit(k === 1 ? 'kamikaze' : 'interceptor', { pos, faction: u.faction, vel: new THREE.Vector3(0, 0, 120).applyQuaternion(u.quat) });
        ai.fighters.push(f);
      }
      g.hud.toast('CARRIER LAUNCHING FIGHTERS', 'warn', 1.5);
      g.effects.ring(u.pos.clone().add(new THREE.Vector3(0, -8, 40).applyQuaternion(u.quat)), 20, '#ff7a3a', 0.5);
    }
  },

  turret(u, dt, g) {
    const P = g.player; const ai = u.ai;
    const t = g.enemyTarget(u);
    if (!t) return;
    const to = dirTo(u, t.pos, tmp2); const d = to.length();
    if (d > 800) return;
    u.faceTowards(to, dt, 1.2);
    ai.cd -= dt;
    if (ai.charge > 0) {
      ai.charge -= dt; ai.shots = ai.shots ?? 0;
      if (ai.charge <= 0) { for (let k = 0; k < 4; k++) setTimeout(() => { if (u.alive && t.alive) u.fire(t, { weapon: { dmg: 7, speed: 420, spread: 0.03 }, dmg: 7, color: '#ff4a2a' }); }, k * 90); }
      else if (Math.random() < 0.5) g.effects.sparks(u.gunWorld(0, tmp3), '#ff4a2a', 1, 20, 2, 0.2);
    } else if (ai.cd <= 0 && u.inFront(t.pos, 0.95)) { ai.cd = 2.5; ai.charge = 0.5; }
  },

  freighter(u, dt, g) {
    const ai = u.ai;
    if (!ai.path || ai.wp == null) { u.vel.multiplyScalar(0.9); return; }
    const wp = ai.path[ai.wp];
    const to = dirTo(u, wp, tmp2); const d = to.length();
    u.steer(to.multiplyScalar(u.speed / Math.max(1, d)), dt, null, false);
    if (d < 40) { ai.wp++; if (ai.wp >= ai.path.length) { ai.wp = null; g.unitRetreat(u, 'jumped'); } }
  },

  mine(u, dt, g) {
    const P = g.player; const ai = u.ai;
    u.mesh.rotation.y += dt; u.mesh.rotation.x += dt * 0.5;
    if (!P.alive) return;
    const d = u.pos.distanceTo(P.pos);
    if (ai.armed != null) { ai.armed -= dt; if (Math.random() < 0.5) g.effects.sparks(u.pos, '#ff2a2a', 1, 10, 2, 0.2); if (ai.armed <= 0) g.detonate(u, 45, 40); }
    else if (d < 50) { ai.armed = 0.6; g.audio.play('warning', { pos: u.pos }); }
  },

  wingman(u, dt, g) {
    const ai = u.ai; const P = g.player;
    let t = ai.target;
    if (!t || !t.alive || ai.retarget <= 0) { t = ai.target = g.nearestEnemy(u.pos, 900, null, null, true); ai.retarget = 3; }
    ai.retarget -= dt;
    if (!t) { // formate on the player
      const slot = tmp.set(ai.side * 30, 8, -25).applyQuaternion(P.quat).add(P.pos);
      const to = dirTo(u, slot, tmp2); const d = to.length();
      u.steer(to.multiplyScalar(Math.min(u.speed * 1.4, d * 2) / Math.max(1, d)).addScaledVector(P.vel, 0.5), dt);
      return;
    }
    u.target = t;
    const to = dirTo(u, t.pos, tmp2); const d = to.length();
    if (ai.state === 'break') { ai.timer -= dt; u.steer(tmp.copy(ai.away).multiplyScalar(u.speed), dt); if (ai.timer <= 0) ai.state = 'attack'; return; }
    u.steer(to.multiplyScalar(u.speed / Math.max(1, d)), dt);
    tryFire(u, g, t, dt, 0.95, 500);
    if (d < 70) { ai.state = 'break'; ai.timer = 1.5; ai.away = u.forward.clone().add(new THREE.Vector3(Math.random() - 0.5, 0.4, Math.random() - 0.5)).normalize(); }
  },

  pdrone(u, dt, g) {
    const ai = u.ai; const P = g.player;
    ai.life -= dt;
    if (ai.life <= 0 || !P.alive) { g.removeUnit(u, 'expire'); return; }
    let t = ai.target;
    if (!t || !t.alive || (ai.retarget = (ai.retarget || 0) - dt) <= 0) { t = ai.target = g.nearestEnemy(P.pos, 450, null, null, true); ai.retarget = 1; }
    if (!t) {
      const a = ai.t * 2 + ai.phase;
      const slot = tmp.set(Math.cos(a) * 14, 5 + Math.sin(a * 1.3) * 3, Math.sin(a) * 14).add(P.pos);
      const to = dirTo(u, slot, tmp2);
      u.steer(to.multiplyScalar(6).addScaledVector(P.vel, 1), dt);
      return;
    }
    const to = dirTo(u, t.pos, tmp2); const d = to.length();
    const orbit = tmp.copy(to).cross(UP).normalize().multiplyScalar(u.speed * 0.6);
    u.steer(to.multiplyScalar((d > 60 ? u.speed : 0) / Math.max(1, d)).add(orbit), dt, tmp3.copy(t.pos).sub(u.pos));
    ai.cd -= dt;
    if (ai.cd <= 0 && d < 300) { ai.cd = 0.22; u.fire(t, { weapon: { dmg: ai.dmg, speed: 560, spread: 0.02 }, dmg: ai.dmg, color: '#7dffcf', sound: false, size: 0.8 }); }
  },

  battleship(u, dt, g) {
    const ai = u.ai;
    if (ai.moveTo) { const to = dirTo(u, ai.moveTo, tmp2); const d = to.length(); u.steer(d > 10 ? to.multiplyScalar(ai.speed / d) : tmp.set(0, 0, 0), dt, null, false); }
    else u.vel.multiplyScalar(0.96);
    ai.flak = (ai.flak ?? 0.5) - dt;
    if (ai.flak <= 0) {
      ai.flak = 0.4;
      const e = g.nearestEnemy(u.pos, 600, null, null, true);
      if (e) {
        const from = u.pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 40, 20, (Math.random() - 0.5) * 120).applyQuaternion(u.quat));
        const aim = e.pos.clone().addScaledVector(e.vel, from.distanceTo(e.pos) / 450).sub(from).normalize();
        g.projectiles.spawn({ kind: 'bolt', team: 'ally', pos: from, vel: aim.multiplyScalar(450), life: 2, dmg: 7, radius: 1.5, size: 1.2, len: 4, color: '#4fdcff', source: u });
      }
    }
  },

  trader(u, dt, g) { u.vel.multiplyScalar(0.95); u.mesh.rotation.z += dt * 0.1; },

  decoy(u, dt, g) {
    u.ai.life -= dt;
    u.mesh.visible = Math.sin(g.time * 40) > -0.6;
    u.vel.multiplyScalar(1 - 0.5 * dt);
    if (u.ai.life <= 0) g.removeUnit(u, 'expire');
  },
};

// ---------------------------------------------------------------------------
// Formations — the Space Invaders DNA: blocks of drones advancing in lockstep
// ---------------------------------------------------------------------------
export class Formation {
  constructor(game, type, count, center, target) {
    this.game = game; this.type = type; this.target = target;
    this.center = center.clone(); this.vel = new THREE.Vector3();
    this.heading = new THREE.Vector3().copy(target.pos).sub(center).normalize();
    this.members = []; this.offsets = [];
    this.broken = false; this.time = 0; this.sweep = 0; this.sweepDir = 1; this.initial = count;
    this.cols = Math.max(3, Math.ceil(Math.sqrt(count * 2)));
    for (let i = 0; i < count; i++) this.offsets.push(this._offset(i, count));
  }
  _offset(i, n) {
    const s = 24;
    switch (this.type) {
      case 'grid': { const c = this.cols; const row = Math.floor(i / c), col = i % c; return new THREE.Vector3((col - (c - 1) / 2) * s, (row % 2) * 6, -row * s); }
      case 'vee': { const side = i % 2 ? 1 : -1, k = Math.ceil(i / 2); return new THREE.Vector3(side * k * s, 0, -k * s * 0.8); }
      case 'ring': { const a = i / n * Math.PI * 2; return new THREE.Vector3(Math.cos(a) * 70, Math.sin(a) * 70, 0); }
      case 'column': return new THREE.Vector3(Math.sin(i) * 8, Math.cos(i) * 8, -i * s);
      case 'pincer': { const side = i % 2 ? 1 : -1; const k = Math.floor(i / 2); return new THREE.Vector3(side * (120 + k * 4), (k % 3 - 1) * 20, -k * 18); }
      default: return new THREE.Vector3((Math.random() - 0.5) * 160, (Math.random() - 0.5) * 80, (Math.random() - 0.5) * 120);
    }
  }
  add(u, slot) { u.formation = this; u.slot = slot; this.members.push(u); }
  isFrontRow(slot) { return this.type === 'grid' ? slot < this.cols : slot < 3; }
  slotPos(i, out) {
    const f = this.heading;
    const right = tmp.copy(UP).cross(f).normalize();
    const up = tmp3.copy(f).cross(right).normalize();
    const o = this.offsets[i] || this.offsets[0];
    let x = o.x, y = o.y, z = o.z;
    if (this.type === 'ring') { const a = this.time * 0.8; const c = Math.cos(a), s = Math.sin(a); const nx = x * c - y * s; y = x * s + y * c; x = nx; }
    if (this.type === 'grid') x += this.sweep;
    return out.copy(this.center).addScaledVector(right, x).addScaledVector(up, y).addScaledVector(f, z);
  }
  update(dt) {
    if (this.broken) return;
    const g = this.game; this.time += dt;
    const t = this.target;
    if (!t || !t.alive) { this.target = g.player; }
    const to = tmp2.copy(this.target.pos).sub(this.center); const d = to.length();
    this.heading.lerp(to.divideScalar(d || 1), Math.min(1, dt * 0.5)).normalize();
    const alive = this.members.filter(m => m.alive).length;
    if (d < 300 || alive < this.initial * 0.45 || this.time > 40 || alive === 0) { this.break(); return; }
    if (this.type === 'grid') {
      // lockstep: sweep sideways; on each edge, step forward
      this.sweep += this.sweepDir * 55 * dt;
      if (Math.abs(this.sweep) > 110) { this.sweepDir *= -1; this.sweep = Math.sign(this.sweep) * 110; this.center.addScaledVector(this.heading, 45); g.audio.play('enemyHeavy', { pos: this.center, volume: 0.3 }); }
      this.vel.copy(this.heading).multiplyScalar(14 + (1 - alive / this.initial) * 40); // speeds up as it thins out
    } else {
      this.vel.copy(this.heading).multiplyScalar(this.type === 'pincer' ? 70 : 85);
    }
    this.center.addScaledVector(this.vel, dt);
  }
  break() { this.broken = true; for (const m of this.members) if (m.formation === this) m.formation = null; }
}
