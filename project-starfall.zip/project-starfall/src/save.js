// ============================================================================
// Versioned, validated, recoverable save system (localStorage).
// Storage is injectable so the logic can be unit-tested in Node.
// ============================================================================
import {
  SAVE_VERSION, SHIPS, WEAPONS, SECONDARIES, ABILITIES, UPGRADE_BRANCHES, UPGRADE_MAX_TIER,
  MODS, COSMETICS, DEFAULT_COSMETICS, DEFAULT_EQUIP, REGION_ORDER, CAMPAIGN, COSMETIC_TYPES,
} from './data.js';

export const SAVE_KEY = 'starfall_save_v';
export const BACKUP_KEY = 'starfall_save_backup';
export const CORRUPT_PREFIX = 'starfall_save_corrupt_';

export function defaultSettings() {
  return {
    masterVolume: 0.8, musicVolume: 0.55, sfxVolume: 0.8,
    resolutionScale: 1, shadows: 'low', particles: 'high', effects: 'high', renderDistance: 'high', fpsCap: 0,
    reduceShake: false, reduceFlashing: false, mouseSensitivity: 1, invertY: false, showFps: false,
    damageNumbers: true, skipIntros: false, aimAssist: true, tutorialSeen: false, mouseMode: 'aim',
    difficulty: 'auto', cameraLean: true, autoQuality: true, mouseAimDefault: true,
  };
}

export function defaultSave(now = Date.now()) {
  const upgrades = {};
  for (const k of Object.keys(UPGRADE_BRANCHES)) upgrades[k] = 0;
  const loadouts = {};
  for (const [id, s] of Object.entries(SHIPS)) loadouts[id] = JSON.parse(JSON.stringify(s.loadout));
  const equipped = {};
  for (const id of Object.keys(SHIPS)) equipped[id] = { ...DEFAULT_EQUIP };
  const threat = {};
  for (const r of REGION_ORDER) threat[r] = 1;
  return {
    version: SAVE_VERSION,
    createdAt: now,
    updatedAt: now,
    profile: { callsign: 'Starfall-1', level: 1, xp: 0, totalXp: 0 },
    currencies: { credits: 500, alloy: 0, cores: 0, tokens: 0 },
    ships: { owned: ['warden'], selected: 'warden', loadouts },
    arsenal: {
      weapons: ['pulse', 'scatter'],
      secondaries: ['missiles'],
      abilities: ['aegis'],
    },
    upgrades,
    mods: { owned: [], equipped: {} },
    cosmetics: { owned: DEFAULT_COSMETICS.slice(), equipped, seen: [] },
    achievements: {},
    daily: {
      lastClaimDay: null, streak: 0, bestStreak: 0, lastSeen: now, highestDaySeen: null,
      clockWarning: false, missionDay: null, challengeDay: null, challengeBest: {}, boosts: { xp2: 0 },
    },
    events: { progress: {}, claimed: {} },
    campaign: { completed: [], phantomEscaped: false, choices: {}, endings: [] },
    universe: {
      threat, history: [], followUps: [], missionCounter: 0,
      contracts: { day: null, list: [], refreshes: 0 },
      encountered: { enemies: {}, bosses: {} }, discoveries: [],
    },
    stats: {
      kills: 0, deaths: 0, missionsWon: 0, missionsLost: 0, missionsPlayed: 0, retreats: 0,
      bossKills: 0, bossesDefeated: {}, bestCombo: 0, bestWave: 0, playTime: 0, damageDealt: 0,
      flawless: 0, secondaryKills: 0, aceKills: 0, discoveries: 0, dailyChallenges: 0, eventMissions: 0,
      experimentalWins: 0, bossRushWins: 0, enemyKills: {}, highScore: 0, campaignDone: 0,
    },
    records: { endless: [], bossrush: [], daily: [], contracts: [], experimental: [], campaign: [] },
    settings: defaultSettings(),
  };
}

// ---------------------------------------------------------------------------
// Migrations (old version -> new version). Each takes raw object, returns raw.
// ---------------------------------------------------------------------------
const MIGRATIONS = {
  1: s => { // v1 stored weapons at top-level `weapons` array
    s.arsenal = s.arsenal || {};
    if (Array.isArray(s.weapons)) { s.arsenal.weapons = s.weapons; delete s.weapons; }
    s.version = 2; return s;
  },
  2: s => { // v2 had no universe/followUps & a single equipped cosmetic set
    s.universe = s.universe || {};
    if (s.cosmetics && s.cosmetics.equipped && typeof s.cosmetics.equipped.paint === 'string') {
      const single = s.cosmetics.equipped; const eq = {};
      for (const id of Object.keys(SHIPS)) eq[id] = { ...single };
      s.cosmetics.equipped = eq;
    }
    s.version = 3; return s;
  },
};

export function migrate(raw) {
  let s = raw;
  let v = Number(s.version) || 1;
  const applied = [];
  while (v < SAVE_VERSION && MIGRATIONS[v]) {
    s = MIGRATIONS[v](s);
    applied.push(v);
    v = s.version;
  }
  return { save: s, applied };
}

// ---------------------------------------------------------------------------
// Validation helpers: each sanitizer returns a safe value and reports issues.
// ---------------------------------------------------------------------------
const isObj = v => v !== null && typeof v === 'object' && !Array.isArray(v);
function num(v, def, min = -Infinity, max = Infinity, issues, path) {
  if (typeof v !== 'number' || !Number.isFinite(v)) { if (v !== undefined) issues.push(`${path}: invalid number`); return def; }
  if (v < min || v > max) { issues.push(`${path}: out of range`); return Math.min(max, Math.max(min, v)); }
  return v;
}
function bool(v, def) { return typeof v === 'boolean' ? v : def; }
function str(v, def, allowed) {
  if (typeof v !== 'string') return def;
  if (allowed && !allowed.includes(v)) return def;
  return v;
}
function idList(v, valid, def, issues, path) {
  if (!Array.isArray(v)) { if (v !== undefined) issues.push(`${path}: not a list`); return def.slice(); }
  const out = [];
  for (const id of v) if (typeof id === 'string' && valid.includes(id) && !out.includes(id)) out.push(id);
  if (out.length !== v.length) issues.push(`${path}: removed unknown entries`);
  for (const d of def) if (!out.includes(d)) out.push(d);
  return out;
}

export function sanitize(raw, now = Date.now()) {
  const issues = [];
  const d = defaultSave(now);
  if (!isObj(raw)) return { save: d, issues: ['root: not an object'], fatal: true };
  const s = d; // build on top of defaults

  s.createdAt = num(raw.createdAt, d.createdAt, 0, Infinity, issues, 'createdAt');
  s.updatedAt = num(raw.updatedAt, d.updatedAt, 0, Infinity, issues, 'updatedAt');

  const p = isObj(raw.profile) ? raw.profile : {};
  s.profile.callsign = str(p.callsign, d.profile.callsign).slice(0, 20);
  s.profile.level = Math.floor(num(p.level, 1, 1, 50, issues, 'profile.level'));
  s.profile.xp = num(p.xp, 0, 0, 1e9, issues, 'profile.xp');
  s.profile.totalXp = num(p.totalXp, 0, 0, 1e12, issues, 'profile.totalXp');

  const c = isObj(raw.currencies) ? raw.currencies : {};
  for (const k of Object.keys(d.currencies)) s.currencies[k] = Math.floor(num(c[k], d.currencies[k], 0, 1e9, issues, `currencies.${k}`));

  const sh = isObj(raw.ships) ? raw.ships : {};
  const shipIds = Object.keys(SHIPS);
  s.ships.owned = idList(sh.owned, shipIds, ['warden'], issues, 'ships.owned');
  s.ships.selected = s.ships.owned.includes(sh.selected) ? sh.selected : 'warden';

  const ar = isObj(raw.arsenal) ? raw.arsenal : {};
  s.arsenal.weapons = idList(ar.weapons, Object.keys(WEAPONS), d.arsenal.weapons, issues, 'arsenal.weapons');
  s.arsenal.secondaries = idList(ar.secondaries, Object.keys(SECONDARIES), d.arsenal.secondaries, issues, 'arsenal.secondaries');
  s.arsenal.abilities = idList(ar.abilities, Object.keys(ABILITIES), d.arsenal.abilities, issues, 'arsenal.abilities');
  // Owning a ship grants its default loadout items
  for (const id of s.ships.owned) {
    const lo = SHIPS[id].loadout;
    for (const w of lo.primary) if (!s.arsenal.weapons.includes(w)) s.arsenal.weapons.push(w);
    if (!s.arsenal.secondaries.includes(lo.secondary)) s.arsenal.secondaries.push(lo.secondary);
    if (!s.arsenal.abilities.includes(lo.ability)) s.arsenal.abilities.push(lo.ability);
  }

  const rl = isObj(sh.loadouts) ? sh.loadouts : {};
  for (const id of shipIds) {
    const l = isObj(rl[id]) ? rl[id] : {};
    const def = d.ships.loadouts[id];
    let prim = Array.isArray(l.primary) ? l.primary.filter(w => s.arsenal.weapons.includes(w)).slice(0, SHIPS[id].primarySlots) : def.primary.slice();
    while (prim.length < SHIPS[id].primarySlots) {
      const fill = s.arsenal.weapons.find(w => !prim.includes(w)) || 'pulse';
      prim.push(fill);
    }
    s.ships.loadouts[id] = {
      primary: prim,
      secondary: s.arsenal.secondaries.includes(l.secondary) ? l.secondary : def.secondary,
      ability: s.arsenal.abilities.includes(l.ability) ? l.ability : def.ability,
    };
  }

  const up = isObj(raw.upgrades) ? raw.upgrades : {};
  for (const k of Object.keys(UPGRADE_BRANCHES)) s.upgrades[k] = Math.floor(num(up[k], 0, 0, UPGRADE_MAX_TIER, issues, `upgrades.${k}`));

  const md = isObj(raw.mods) ? raw.mods : {};
  s.mods.owned = idList(md.owned, Object.keys(MODS), [], issues, 'mods.owned');
  s.mods.equipped = {};
  if (isObj(md.equipped)) {
    for (const [branch, mod] of Object.entries(md.equipped)) {
      if (MODS[mod] && MODS[mod].branch === branch && s.mods.owned.includes(mod)) s.mods.equipped[branch] = mod;
    }
  }

  const cs = isObj(raw.cosmetics) ? raw.cosmetics : {};
  s.cosmetics.owned = idList(cs.owned, Object.keys(COSMETICS), DEFAULT_COSMETICS, issues, 'cosmetics.owned');
  s.cosmetics.seen = Array.isArray(cs.seen) ? cs.seen.filter(x => COSMETICS[x]) : [];
  const ceq = isObj(cs.equipped) ? cs.equipped : {};
  for (const id of shipIds) {
    const e = isObj(ceq[id]) ? ceq[id] : {};
    for (const t of COSMETIC_TYPES) {
      const v = e[t];
      s.cosmetics.equipped[id][t] = (COSMETICS[v] && COSMETICS[v].type === t && s.cosmetics.owned.includes(v)) ? v : DEFAULT_EQUIP[t];
    }
  }

  if (isObj(raw.achievements)) for (const [k, v] of Object.entries(raw.achievements)) if (typeof v === 'number') s.achievements[k] = v;

  const dy = isObj(raw.daily) ? raw.daily : {};
  s.daily.lastClaimDay = Number.isInteger(dy.lastClaimDay) ? dy.lastClaimDay : null;
  s.daily.highestDaySeen = Number.isInteger(dy.highestDaySeen) ? dy.highestDaySeen : s.daily.lastClaimDay;
  s.daily.streak = Math.floor(num(dy.streak, 0, 0, 100000, issues, 'daily.streak'));
  s.daily.bestStreak = Math.max(s.daily.streak, Math.floor(num(dy.bestStreak, 0, 0, 100000, issues, 'daily.bestStreak')));
  s.daily.lastSeen = num(dy.lastSeen, now, 0, Infinity, issues, 'daily.lastSeen');
  s.daily.clockWarning = bool(dy.clockWarning, false);
  s.daily.missionDay = Number.isInteger(dy.missionDay) ? dy.missionDay : null;
  s.daily.challengeDay = Number.isInteger(dy.challengeDay) ? dy.challengeDay : null;
  s.daily.challengeBest = isObj(dy.challengeBest) ? Object.fromEntries(Object.entries(dy.challengeBest).filter(([, v]) => typeof v === 'number')) : {};
  s.daily.boosts = { xp2: Math.floor(num(isObj(dy.boosts) ? dy.boosts.xp2 : 0, 0, 0, 100, issues, 'daily.boosts.xp2')) };

  const ev = isObj(raw.events) ? raw.events : {};
  s.events.progress = isObj(ev.progress) ? JSON.parse(JSON.stringify(ev.progress)) : {};
  s.events.claimed = isObj(ev.claimed) ? JSON.parse(JSON.stringify(ev.claimed)) : {};

  const cp = isObj(raw.campaign) ? raw.campaign : {};
  const cids = CAMPAIGN.map(c => c.id);
  s.campaign.completed = idList(cp.completed, cids, [], issues, 'campaign.completed');
  s.campaign.phantomEscaped = bool(cp.phantomEscaped, false);
  // story choices: only known choice ids and options survive validation
  const CH = { ashkar: ['colony', 'relay'], vant: ['spare', 'finish'], lattice: ['silence', 'chorus'] };
  const rch = isObj(cp.choices) ? cp.choices : {};
  s.campaign.choices = {};
  for (const [k, opts] of Object.entries(CH)) if (opts.includes(rch[k])) s.campaign.choices[k] = rch[k];
  s.campaign.endings = Array.isArray(cp.endings) ? cp.endings.filter(e => e === 'silence' || e === 'chorus').filter((e, i, a) => a.indexOf(e) === i) : [];

  const un = isObj(raw.universe) ? raw.universe : {};
  if (isObj(un.threat)) for (const r of REGION_ORDER) s.universe.threat[r] = num(un.threat[r], 1, 0.5, 3, issues, `universe.threat.${r}`);
  s.universe.history = Array.isArray(un.history) ? un.history.filter(x => typeof x === 'string').slice(-12) : [];
  s.universe.followUps = Array.isArray(un.followUps) ? un.followUps.filter(isObj).slice(0, 6) : [];
  s.universe.missionCounter = Math.floor(num(un.missionCounter, 0, 0, 1e9, issues, 'universe.missionCounter'));
  if (isObj(un.contracts)) {
    s.universe.contracts.day = Number.isInteger(un.contracts.day) ? un.contracts.day : null;
    s.universe.contracts.list = Array.isArray(un.contracts.list) ? un.contracts.list.filter(isObj).slice(0, 8) : [];
    s.universe.contracts.refreshes = Math.floor(num(un.contracts.refreshes, 0, 0, 1e6, issues, 'contracts.refreshes'));
  }
  if (isObj(un.encountered)) {
    s.universe.encountered.enemies = isObj(un.encountered.enemies) ? { ...un.encountered.enemies } : {};
    s.universe.encountered.bosses = isObj(un.encountered.bosses) ? { ...un.encountered.bosses } : {};
  }
  s.universe.discoveries = Array.isArray(un.discoveries) ? un.discoveries.filter(x => typeof x === 'string') : [];

  const st = isObj(raw.stats) ? raw.stats : {};
  for (const [k, v] of Object.entries(d.stats)) {
    if (typeof v === 'number') s.stats[k] = num(st[k], v, 0, 1e15, issues, `stats.${k}`);
    else if (isObj(v)) s.stats[k] = isObj(st[k]) ? Object.fromEntries(Object.entries(st[k]).filter(([, x]) => typeof x === 'number')) : {};
  }

  const rc = isObj(raw.records) ? raw.records : {};
  for (const k of Object.keys(d.records)) s.records[k] = Array.isArray(rc[k]) ? rc[k].filter(isObj).slice(0, 20) : [];

  const se = isObj(raw.settings) ? raw.settings : {};
  const ds = defaultSettings();
  s.settings.masterVolume = num(se.masterVolume, ds.masterVolume, 0, 1, issues, 'settings.masterVolume');
  s.settings.musicVolume = num(se.musicVolume, ds.musicVolume, 0, 1, issues, 'settings.musicVolume');
  s.settings.sfxVolume = num(se.sfxVolume, ds.sfxVolume, 0, 1, issues, 'settings.sfxVolume');
  s.settings.resolutionScale = num(se.resolutionScale, ds.resolutionScale, 0.5, 1.5, issues, 'settings.resolutionScale');
  s.settings.shadows = str(se.shadows, ds.shadows, ['off', 'low', 'high']);
  s.settings.particles = str(se.particles, ds.particles, ['low', 'medium', 'high']);
  s.settings.effects = str(se.effects, ds.effects, ['low', 'medium', 'high']);
  s.settings.renderDistance = str(se.renderDistance, ds.renderDistance, ['low', 'medium', 'high']);
  s.settings.fpsCap = [0, 30, 60, 120].includes(se.fpsCap) ? se.fpsCap : 0;
  s.settings.mouseSensitivity = num(se.mouseSensitivity, 1, 0.2, 3, issues, 'settings.mouseSensitivity');
  s.settings.mouseMode = str(se.mouseMode, 'aim', ['aim', 'direct', 'stick']);
  // one-time switch of existing saves to the new mouse-aim default (players can still pick the old modes)
  if (se.mouseAimDefault !== true) s.settings.mouseMode = 'aim';
  s.settings.mouseAimDefault = true;
  s.settings.difficulty = str(se.difficulty, 'auto', ['auto', 'relaxed', 'standard', 'ace']);
  for (const k of ['reduceShake', 'reduceFlashing', 'invertY', 'showFps', 'damageNumbers', 'skipIntros', 'aimAssist', 'tutorialSeen', 'cameraLean', 'autoQuality']) s.settings[k] = bool(se[k], ds[k]);

  s.version = SAVE_VERSION;
  return { save: s, issues, fatal: false };
}

// ---------------------------------------------------------------------------
// SaveManager — load/save with backup + corruption quarantine
// ---------------------------------------------------------------------------
export function memoryStorage() {
  const m = new Map();
  return {
    getItem: k => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => { m.set(k, String(v)); },
    removeItem: k => { m.delete(k); },
    key: i => Array.from(m.keys())[i] ?? null,
    get length() { return m.size; },
    _map: m,
  };
}

export class SaveManager {
  constructor(storage, now = () => Date.now()) {
    this.storage = storage;
    this.now = now;
    this.data = null;
    this.status = { source: null, issues: [], recovered: false, quarantined: null, migrated: [], writeError: null };
    this._saveCount = 0;
  }

  _tryParse(text) {
    if (text == null) return { ok: false, missing: true };
    try {
      const obj = JSON.parse(text);
      if (!isObj(obj)) return { ok: false, error: 'not an object' };
      return { ok: true, obj };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  load() {
    let primaryText = null;
    try { primaryText = this.storage.getItem(SAVE_KEY); } catch (e) { this.status.writeError = 'storage unavailable'; }
    const primary = this._tryParse(primaryText);
    if (primary.ok) {
      const m = migrate(primary.obj);
      const r = sanitize(m.save, this.now());
      this.data = r.save;
      this.status = { source: 'primary', issues: r.issues, recovered: false, quarantined: null, migrated: m.applied, writeError: null };
      if (m.applied.length || r.issues.length) this.save(); // persist repaired form
      return this.data;
    }
    // primary missing or corrupt -> try backup
    if (!primary.missing) this._quarantine(primaryText);
    let backupText = null;
    try { backupText = this.storage.getItem(BACKUP_KEY); } catch (e) { /* ignore */ }
    const backup = this._tryParse(backupText);
    if (backup.ok) {
      const m = migrate(backup.obj);
      const r = sanitize(m.save, this.now());
      this.data = r.save;
      this.status = { source: 'backup', issues: r.issues, recovered: true, quarantined: this.status.quarantined, migrated: m.applied, writeError: null };
      this.save();
      return this.data;
    }
    this.data = defaultSave(this.now());
    this.status = { source: primary.missing ? 'new' : 'reset-after-corruption', issues: [], recovered: !primary.missing, quarantined: this.status.quarantined, migrated: [], writeError: null };
    this.save();
    return this.data;
  }

  _quarantine(text) {
    const key = CORRUPT_PREFIX + this.now();
    try { this.storage.setItem(key, text); this.status.quarantined = key; } catch (e) { /* storage full */ }
  }

  save() {
    if (!this.data) return false;
    this.data.updatedAt = this.now();
    const text = JSON.stringify(this.data);
    try {
      // Keep the previous valid save as a backup every few writes.
      this._saveCount++;
      if (this._saveCount % 5 === 1) {
        const prev = this.storage.getItem(SAVE_KEY);
        if (prev && this._tryParse(prev).ok) this.storage.setItem(BACKUP_KEY, prev);
        else this.storage.setItem(BACKUP_KEY, text);
      }
      this.storage.setItem(SAVE_KEY, text);
      this.status.writeError = null;
      return true;
    } catch (e) {
      this.status.writeError = e.message || 'write failed';
      return false;
    }
  }

  reset() {
    try { this.storage.removeItem(SAVE_KEY); this.storage.removeItem(BACKUP_KEY); } catch (e) { /* ignore */ }
    const keepSettings = this.data ? this.data.settings : defaultSettings();
    this.data = defaultSave(this.now());
    this.data.settings = { ...keepSettings, tutorialSeen: false };
    this._saveCount = 0;
    this.save();
    return this.data;
  }

  exportString() { return btoa(unescape(encodeURIComponent(JSON.stringify(this.data)))); }
  importString(b64) {
    const text = decodeURIComponent(escape(atob(b64.trim())));
    const parsed = this._tryParse(text);
    if (!parsed.ok) throw new Error('Invalid save data');
    const m = migrate(parsed.obj);
    const r = sanitize(m.save, this.now());
    this.data = r.save;
    this.save();
    return r.issues;
  }
}
