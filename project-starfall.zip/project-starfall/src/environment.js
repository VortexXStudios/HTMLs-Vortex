// ============================================================================
// Space environments: nebula sky, layered starfields, planets, asteroid fields,
// region set-pieces, ambient dust and seasonal particles.
// ============================================================================
import * as THREE from 'three';
import { REGIONS } from './data.js';
import { EVENTS } from './events.js';
import { planetTexture, glowSprite, galaxyTexture, cloudPuffTexture, fbm } from './textures.js';
import { buildWreckPiece, buildRuinPiece } from './models.js';
import { RNG } from './rng.js';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';

export const ARENA_RADIUS = 1100;

// Uniform spatial hash for asteroid queries (projectiles, collisions)
export class AsteroidGrid {
  constructor(cell = 90) { this.cell = cell; this.map = new Map(); }
  key(ix, iy, iz) { return (ix + 512) * 1048576 + (iy + 512) * 1024 + (iz + 512); }
  rebuild(a) {
    for (const v of this.map.values()) v.length = 0;
    if (!a) return;
    const c = this.cell;
    for (let i = 0; i < a.count; i++) {
      if (!a.alive[i]) continue;
      const x = a.pos[i * 3], y = a.pos[i * 3 + 1], z = a.pos[i * 3 + 2], r = a.radius[i];
      const x0 = Math.floor((x - r) / c), x1 = Math.floor((x + r) / c), y0 = Math.floor((y - r) / c), y1 = Math.floor((y + r) / c), z0 = Math.floor((z - r) / c), z1 = Math.floor((z + r) / c);
      for (let ix = x0; ix <= x1; ix++) for (let iy = y0; iy <= y1; iy++) for (let iz = z0; iz <= z1; iz++) {
        const k = this.key(ix, iy, iz);
        let arr = this.map.get(k); if (!arr) { arr = []; this.map.set(k, arr); }
        arr.push(i);
      }
    }
  }
  query(x, y, z) { const c = this.cell; const arr = this.map.get(this.key(Math.floor(x / c), Math.floor(y / c), Math.floor(z / c))); return arr && arr.length ? arr : null; }
}

const NOISE_GLSL = `
  float hash3(vec3 p){ p = fract(p*0.3183099+0.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
  float noise3(vec3 x){ vec3 i=floor(x); vec3 f=fract(x); f=f*f*(3.0-2.0*f);
    return mix(mix(mix(hash3(i+vec3(0,0,0)),hash3(i+vec3(1,0,0)),f.x),mix(hash3(i+vec3(0,1,0)),hash3(i+vec3(1,1,0)),f.x),f.y),
               mix(mix(hash3(i+vec3(0,0,1)),hash3(i+vec3(1,0,1)),f.x),mix(hash3(i+vec3(0,1,1)),hash3(i+vec3(1,1,1)),f.x),f.y),f.z); }
  float fbm3(vec3 p){ float s=0.0; float a=0.5; for(int i=0;i<6;i++){ s+=a*noise3(p); p=p*2.03+vec3(1.7,9.2,3.1); a*=0.5;} return s; }
`;

function skyMaterial(colors, seed) {
  return new THREE.ShaderMaterial({
    uniforms: {
      c1: { value: new THREE.Color(colors[0]) }, c2: { value: new THREE.Color(colors[1]) }, c3: { value: new THREE.Color(colors[2]) },
      uSeed: { value: seed }, uBright: { value: 1.0 }, uTime: { value: 0 },
    },
    vertexShader: `varying vec3 vDir; void main(){ vDir = normalize(position); vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }`,
    fragmentShader: `
      uniform vec3 c1; uniform vec3 c2; uniform vec3 c3; uniform float uSeed; uniform float uBright; uniform float uTime;
      varying vec3 vDir;
      ${NOISE_GLSL}
      void main(){
        vec3 d = normalize(vDir);
        vec3 q = d*1.6 + vec3(uSeed);
        float n = fbm3(q + fbm3(q*1.3)*0.8);
        float n2 = fbm3(d*3.5 + n*1.8 + uSeed*1.7);
        float lane = fbm3(d*5.0 + vec3(3.0,1.0,uSeed));
        vec3 col = c1;
        col = mix(col, c2, smoothstep(0.38, 0.85, n) * 0.9);
        col = mix(col, c3, smoothstep(0.55, 0.95, n2) * smoothstep(0.42, 0.9, n) * 0.85);
        col *= 0.55 + 0.45*smoothstep(0.25, 0.62, lane);
        // galactic band
        float band = exp(-pow(d.y*3.2 + sin(d.x*2.0+uSeed)*0.3, 2.0));
        col += c2 * band * 0.12 * n;
        // dense faint stars
        vec3 sp = floor(d*700.0);
        float s = hash3(sp + uSeed);
        col += vec3(pow(s, 220.0)) * 1.2;
        gl_FragColor = vec4(col * uBright, 1.0);
      }`,
    side: THREE.BackSide, depthWrite: false, fog: false,
  });
}

function starLayer(count, radius, size, seed, warm = 0.3) {
  const rng = new RNG(seed);
  const pos = new Float32Array(count * 3), col = new Float32Array(count * 3), sz = new Float32Array(count);
  const c = new THREE.Color();
  for (let i = 0; i < count; i++) {
    const u = rng.next() * 2 - 1, t = rng.next() * Math.PI * 2;
    const r = Math.sqrt(1 - u * u);
    pos[i * 3] = r * Math.cos(t) * radius; pos[i * 3 + 1] = u * radius; pos[i * 3 + 2] = r * Math.sin(t) * radius;
    const k = rng.next();
    if (k < warm * 0.5) c.setHSL(0.08, 0.7, 0.75); else if (k < warm) c.setHSL(0.13, 0.4, 0.85); else if (k > 0.85) c.setHSL(0.6, 0.6, 0.8); else c.setHSL(0, 0, 0.92);
    col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
    sz[i] = size * (0.4 + Math.pow(rng.next(), 4) * 2.2);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  g.setAttribute('size', new THREE.BufferAttribute(sz, 1));
  const m = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 }, uScale: { value: 1 } },
    vertexShader: `attribute float size; attribute vec3 color; varying vec3 vColor; varying float vTw; uniform float uTime; uniform float uScale;
      void main(){ vColor = color; vec4 mv = modelViewMatrix * vec4(position,1.0);
        vTw = 0.75 + 0.25*sin(uTime*2.0 + position.x*0.13 + position.y*0.07);
        gl_PointSize = size * uScale; gl_Position = projectionMatrix * mv; gl_Position.z = gl_Position.w * 0.9999; }`,
    fragmentShader: `varying vec3 vColor; varying float vTw; void main(){ vec2 c = gl_PointCoord-0.5; float d = length(c); float a = smoothstep(0.5,0.0,d); a = a*a; gl_FragColor = vec4(vColor*vTw*1.6, a); }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false,
  });
  const p = new THREE.Points(g, m);
  p.frustumCulled = false;
  return p;
}

function atmosphereMesh(radius, color) {
  const g = new THREE.SphereGeometry(radius * 1.06, 48, 32);
  const m = new THREE.ShaderMaterial({
    uniforms: { uColor: { value: new THREE.Color(color) } },
    vertexShader: `varying vec3 vN; varying vec3 vV; void main(){ vN = normalize(normalMatrix*normal); vec4 mv = modelViewMatrix*vec4(position,1.0); vV = normalize(-mv.xyz); gl_Position = projectionMatrix*mv; }`,
    fragmentShader: `uniform vec3 uColor; varying vec3 vN; varying vec3 vV; void main(){ float f = pow(1.0 - abs(dot(vN, vV)), 3.0); gl_FragColor = vec4(uColor*f*2.2, f); }`,
    side: THREE.BackSide, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
  });
  return new THREE.Mesh(g, m);
}

// Asteroid geometry: displaced icosahedron, several variants
const asteroidGeoCache = [];
function asteroidGeometry(variant) {
  if (asteroidGeoCache[variant]) return asteroidGeoCache[variant];
  const base = new THREE.IcosahedronGeometry(1, 4);
  base.deleteAttribute('normal'); base.deleteAttribute('uv');
  const g = mergeVertices(base);
  const p = g.attributes.position; const v = new THREE.Vector3();
  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i);
    const n = fbm(v.x * 1.7 + variant * 5, v.y * 1.7 + v.z * 1.3, 4, variant * 11);
    const crater = Math.max(0, fbm(v.x * 3 + 9, v.z * 3 + v.y, 3, variant) - 0.62) * 1.6;
    v.multiplyScalar(0.72 + n * 0.55 - crater);
    v.x *= 1 + (variant % 3) * 0.15; v.z *= 1 - (variant % 2) * 0.12;
    p.setXYZ(i, v.x, v.y, v.z);
  }
  g.computeVertexNormals();
  asteroidGeoCache[variant] = g;
  return g;
}

export class Environment {
  constructor(scene, renderer) {
    this.scene = scene;
    this.renderer = renderer;
    this.group = new THREE.Group();
    this.dynamic = [];
    this.asteroids = null;
    this.obstacles = [];
    this.ambientParticles = null;
    this.eventParticles = null;
    this.time = 0;
    this.envMap = null;
  }

  build(regionId, opts = {}) {
    this.dispose();
    const R = REGIONS[regionId] || REGIONS.belt;
    this.region = regionId; this.def = R;
    const ev = opts.event ? EVENTS[opts.event] : null;
    const settings = opts.settings || {};
    const quality = settings.particles || 'high';
    const seed = (opts.seed || 1) % 1000;
    const rng = new RNG('env-' + regionId + seed);
    let sky = R.sky.slice();
    if (ev && ev.skyTint) sky = sky.map((c, i) => new THREE.Color(c).lerp(new THREE.Color(ev.skyTint[i]), 0.45).getStyle());
    this.skyColors = sky;
    this.scene.add(this.group);

    // --- Sky & stars
    const skyMat = skyMaterial(sky, seed * 0.37 + regionId.length);
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(9000, 48, 32), skyMat);
    this.sky.renderOrder = -10;
    this.group.add(this.sky);
    const sc = { low: 0.4, medium: 0.7, high: 1 }[quality] || 1;
    this.stars = [starLayer(Math.round(2600 * sc), 8500, 1.8, seed + 1), starLayer(Math.round(500 * sc), 8200, 3.6, seed + 2, 0.5)];
    for (const s of this.stars) this.group.add(s);

    // --- Galaxies
    for (let i = 0; i < 3; i++) {
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: galaxyTexture(seed + i, rng.pick(['#b8a0ff', '#a0d8ff', '#ffc8a0'])), blending: THREE.AdditiveBlending, depthWrite: false, fog: false, transparent: true, opacity: 0.7 }));
      const dir = new THREE.Vector3(rng.range(-1, 1), rng.range(-0.6, 0.8), rng.range(-1, 1)).normalize();
      sp.position.copy(dir.multiplyScalar(4600));
      const s = rng.range(300, 650); sp.scale.set(s, s, 1);
      sp.material.rotation = rng.range(0, Math.PI);
      this.group.add(sp);
    }

    // --- Lighting
    const sunDir = new THREE.Vector3(...R.sunDir).normalize();
    this.sunDir = sunDir;
    this.hemi = new THREE.HemisphereLight(new THREE.Color(sky[1]).lerp(new THREE.Color('#ffffff'), 0.4), new THREE.Color(sky[0]).multiplyScalar(0.6), 0.9);
    this.group.add(this.hemi);
    this.ambient = new THREE.AmbientLight(0xffffff, 0.12);
    this.group.add(this.ambient);
    this.sun = new THREE.DirectionalLight(new THREE.Color(R.sun), 2.6);
    this.sun.position.copy(sunDir).multiplyScalar(500);
    this.sun.castShadow = settings.shadows !== 'off';
    const shRes = settings.shadows === 'high' ? 2048 : 1024;
    this.sun.shadow.mapSize.set(shRes, shRes);
    const sc2 = this.sun.shadow.camera; sc2.left = -160; sc2.right = 160; sc2.top = 160; sc2.bottom = -160; sc2.near = 10; sc2.far = 1200;
    this.sun.shadow.bias = -0.0008; this.sun.shadow.normalBias = 0.5;
    this.group.add(this.sun); this.group.add(this.sun.target);
    // Rim light opposite the sun for cinematic silhouettes
    this.rim = new THREE.DirectionalLight(new THREE.Color(sky[2]), 0.9);
    this.rim.position.copy(sunDir).multiplyScalar(-400).add(new THREE.Vector3(0, 200, 0));
    this.group.add(this.rim);
    // Sun glare sprite
    const sunSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowSprite(R.sun, 'sun'), blending: THREE.AdditiveBlending, depthWrite: false, fog: false, transparent: true }));
    sunSprite.position.copy(sunDir).multiplyScalar(4400); sunSprite.scale.set(950, 950, 1);
    sunSprite.material.color.setScalar(1.6);
    this.group.add(sunSprite);

    // --- Planet
    if (R.planet) {
      const pd = R.planet;
      const tex = planetTexture(pd, seed + 3);
      const pm = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.95, metalness: 0, fog: false, emissive: pd.lava ? new THREE.Color('#ff5a1a') : new THREE.Color(0), emissiveMap: pd.lava ? tex : null, emissiveIntensity: pd.lava ? 0.9 : 0 });
      const planet = new THREE.Mesh(new THREE.SphereGeometry(pd.size, 64, 40), pm);
      planet.position.set(...pd.pos);
      planet.rotation.z = 0.3;
      this.planet = planet;
      this.group.add(planet);
      if (pd.atmo) { const atm = atmosphereMesh(pd.size, pd.atmo); atm.position.copy(planet.position); this.group.add(atm); }
      if (pd.ring) {
        const rg = new THREE.RingGeometry(pd.size * 1.35, pd.size * 2.2, 128, 1);
        const rc = document.createElement('canvas'); rc.width = 512; rc.height = 1; const rx = rc.getContext('2d');
        for (let x = 0; x < 512; x++) { const a = (0.3 + 0.7 * fbm(x / 20, 0.5, 4, 2)) * (x > 30 && x < 500 ? 1 : 0); rx.fillStyle = `rgba(200,170,140,${a * 0.75})`; rx.fillRect(x, 0, 1, 1); }
        const rt = new THREE.CanvasTexture(rc); rt.colorSpace = THREE.SRGBColorSpace;
        // remap UVs radially
        const uv = rg.attributes.uv, pp = rg.attributes.position;
        for (let i = 0; i < uv.count; i++) { const r = Math.hypot(pp.getX(i), pp.getY(i)); uv.setXY(i, (r - pd.size * 1.35) / (pd.size * 0.85), 0.5); }
        const ring = new THREE.Mesh(rg, new THREE.MeshBasicMaterial({ map: rt, transparent: true, side: THREE.DoubleSide, depthWrite: false, fog: false }));
        ring.position.copy(planet.position); ring.rotation.x = Math.PI / 2.3; ring.rotation.y = 0.2;
        this.group.add(ring);
      }
    }

    // --- Nebula volume puffs (near-field depth)
    const puffs = R.fog > 0.0015 ? 60 : 24;
    const puffTex = cloudPuffTexture();
    for (let i = 0; i < puffs * sc; i++) {
      const m = new THREE.SpriteMaterial({ map: puffTex, color: new THREE.Color(rng.pick(sky.slice(1))), transparent: true, opacity: rng.range(0.05, 0.16), depthWrite: false, blending: THREE.AdditiveBlending, fog: false });
      const s = new THREE.Sprite(m);
      const dir = new THREE.Vector3(rng.range(-1, 1), rng.range(-0.5, 0.5), rng.range(-1, 1)).normalize();
      s.position.copy(dir.multiplyScalar(rng.range(1400, 4000)));
      const k = rng.range(700, 2200); s.scale.set(k, k, 1);
      m.rotation = rng.range(0, 6);
      this.group.add(s);
    }

    // --- Fog
    const fogMult = { low: 1.6, medium: 1.2, high: 1 }[settings.renderDistance] || 1;
    this.fogBase = R.fog * fogMult * (ev?.fogBoost || 1);
    this.scene.fog = new THREE.FogExp2(new THREE.Color(sky[0]).lerp(new THREE.Color(sky[1]), 0.25), this.fogBase);
    this.scene.background = new THREE.Color(sky[0]);

    // --- Asteroids
    let count = Math.round(R.asteroids * (opts.denseField ? 1.8 : 1) * (opts.asteroidMult || 1) * (quality === 'low' ? 0.6 : 1));
    if (opts.noAsteroids) count = 0;
    if (count > 0) this._buildAsteroids(count, R, rng, ev, opts.storm);

    // --- Region set pieces
    if (regionId === 'city') this._buildRuins(rng);
    if (regionId === 'graveyard') this._buildWrecks(rng);
    if (regionId === 'megastructure') this._buildRings(rng);
    if (regionId === 'frontier') this._buildFortress(rng);

    // --- Ambient dust (speed perception)
    this.ambientParticles = this._buildCameraParticles(quality === 'low' ? 500 : 1400, 'dust', sky[2]);
    if (ev && ev.particles) this.eventParticles = this._buildCameraParticles(quality === 'low' ? 120 : ev.particles === 'wisps' ? 220 : 500, ev.particles, ev.particles === 'wisps' ? ev.colors.b : ev.colors.a);

    // --- Environment map for metallic reflections (needs half-float render targets; skipped on GPUs without them)
    const floatOk = this.renderer.extensions.has('EXT_color_buffer_float') || this.renderer.extensions.has('EXT_color_buffer_half_float');
    if (floatOk) try {
      const pmrem = new THREE.PMREMGenerator(this.renderer);
      const envScene = new THREE.Scene();
      const envSky = new THREE.Mesh(new THREE.SphereGeometry(100, 32, 16), skyMaterial(sky.map(c => new THREE.Color(c).multiplyScalar(2.2).getStyle()), seed));
      envScene.add(envSky);
      const sunBall = new THREE.Mesh(new THREE.SphereGeometry(8, 8, 8), new THREE.MeshBasicMaterial({ color: new THREE.Color(R.sun).multiplyScalar(8) }));
      sunBall.position.copy(sunDir).multiplyScalar(80); envScene.add(sunBall);
      this.envRT = pmrem.fromScene(envScene, 0.04);
      this.envMap = this.envRT.texture;
      this.scene.environment = this.envMap;
      pmrem.dispose(); envSky.geometry.dispose(); envSky.material.dispose(); sunBall.geometry.dispose(); sunBall.material.dispose();
    } catch (e) { console.warn('env map failed', e); }
    return this;
  }

  _buildAsteroids(count, R, rng, ev, storm) {
    const variants = 4;
    const icy = ev && ev.icyAsteroids;
    const mat = new THREE.MeshStandardMaterial({ color: icy ? '#cfe8ff' : (this.region === 'volcanic' ? '#3a2a24' : '#77706a'), roughness: icy ? 0.3 : 0.95, metalness: icy ? 0.2 : 0.05, flatShading: false, emissive: this.region === 'volcanic' ? new THREE.Color('#401004') : new THREE.Color(0) });
    const per = Math.ceil(count / variants);
    const data = { count: 0, meshes: [], pos: new Float32Array(count * 3), vel: new Float32Array(count * 3), radius: new Float32Array(count), scale: new Float32Array(count), axis: [], spin: new Float32Array(count), quat: [], hp: new Float32Array(count), alive: new Uint8Array(count), mesh: [], index: new Uint16Array(count) };
    const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), p = new THREE.Vector3();
    let n = 0;
    for (let v = 0; v < variants; v++) {
      const im = new THREE.InstancedMesh(asteroidGeometry(v), mat, per);
      im.castShadow = true; im.receiveShadow = true;
      im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      data.meshes.push(im);
      for (let k = 0; k < per && n < count; k++, n++) {
        // distribution
        let x, y, z;
        if (this.region === 'belt') {
          const a = rng.range(0, Math.PI * 2), r = rng.range(150, ARENA_RADIUS * 1.15);
          x = Math.cos(a) * r; z = Math.sin(a) * r; y = rng.range(-90, 90) * (1 + r / 900);
        } else {
          const dir = new THREE.Vector3(rng.range(-1, 1), rng.range(-1, 1), rng.range(-1, 1)).normalize();
          const r = rng.range(220, ARENA_RADIUS * 1.2); x = dir.x * r; y = dir.y * r * 0.6; z = dir.z * r;
        }
        const big = rng.chance(0.07);
        const sc = (big ? rng.range(30, 60) : rng.range(3, 20)) * R.asteroidScale;
        data.pos.set([x, y, z], n * 3);
        if (storm) data.vel.set([rng.range(-10, 10), rng.range(-5, 5), rng.range(60, 120)], n * 3);
        else data.vel.set([rng.range(-2, 2), rng.range(-1, 1), rng.range(-2, 2)], n * 3);
        data.scale[n] = sc; data.radius[n] = sc * 0.82;
        data.axis.push(new THREE.Vector3(rng.range(-1, 1), rng.range(-1, 1), rng.range(-1, 1)).normalize());
        data.spin[n] = rng.range(-0.5, 0.5) / Math.max(1, sc * 0.1);
        data.quat.push(new THREE.Quaternion().setFromAxisAngle(data.axis[n], rng.range(0, 6)));
        data.hp[n] = sc < 9 ? sc * 6 : Infinity; data.alive[n] = 1;
        data.mesh[n] = v; data.index[n] = k;
        p.set(x, y, z); s.setScalar(sc); m4.compose(p, data.quat[n], s); im.setMatrixAt(k, m4);
      }
      im.count = Math.min(per, count - v * per);
      this.group.add(im);
    }
    data.count = n;
    data.storm = !!storm;
    this.asteroids = data;
  }

  _buildRuins(rng) {
    for (let i = 0; i < 14; i++) {
      const piece = buildRuinPiece(rng);
      const dir = new THREE.Vector3(rng.range(-1, 1), rng.range(-0.4, 0.4), rng.range(-1, 1)).normalize();
      const r = rng.range(250, 1000);
      piece.position.copy(dir.multiplyScalar(r));
      piece.rotation.set(rng.range(0, 6), rng.range(0, 6), rng.range(0, 6));
      piece.userData.spin = new THREE.Vector3(rng.range(-0.02, 0.02), rng.range(-0.02, 0.02), rng.range(-0.02, 0.02));
      this.group.add(piece); this.dynamic.push(piece);
      this.obstacles.push({ pos: piece.position, radius: piece.userData.radius || 50 });
    }
    // distant broken ring of the city
    const ringGeo = new THREE.TorusGeometry(2600, 60, 8, 64, Math.PI * 1.3);
    const ring = new THREE.Mesh(ringGeo, new THREE.MeshStandardMaterial({ color: '#3a3f4a', metalness: 0.8, roughness: 0.5, emissive: '#ff8a3a', emissiveIntensity: 0.05 }));
    ring.rotation.set(1.2, 0.3, 0); ring.position.set(0, -300, -1800);
    this.group.add(ring);
  }

  _buildWrecks(rng) {
    for (let i = 0; i < 12; i++) {
      const w = buildWreckPiece(rng);
      const dir = new THREE.Vector3(rng.range(-1, 1), rng.range(-0.5, 0.5), rng.range(-1, 1)).normalize();
      w.position.copy(dir.multiplyScalar(rng.range(260, 1050)));
      w.rotation.set(rng.range(0, 6), rng.range(0, 6), rng.range(0, 6));
      w.userData.spin = new THREE.Vector3(rng.range(-0.01, 0.01), rng.range(-0.01, 0.01), rng.range(-0.01, 0.01));
      this.group.add(w); this.dynamic.push(w);
      this.obstacles.push({ pos: w.position, radius: w.userData.radius || 40 });
    }
  }

  _buildRings(rng) {
    const mat = new THREE.MeshStandardMaterial({ color: '#1a2a3a', metalness: 0.9, roughness: 0.3, emissive: '#4ff0ff', emissiveIntensity: 0.0 });
    const glow = new THREE.MeshBasicMaterial({ color: new THREE.Color('#4ff0ff').multiplyScalar(2.2), fog: false });
    for (let i = 0; i < 4; i++) {
      const R = 1400 + i * 450;
      const g = new THREE.Group();
      const ring = new THREE.Mesh(new THREE.TorusGeometry(R, 22 + i * 6, 6, 96), mat);
      const line = new THREE.Mesh(new THREE.TorusGeometry(R, 3, 4, 128), glow);
      line.position.z = 18;
      g.add(ring, line);
      for (let k = 0; k < 12; k++) {
        const a = k / 12 * Math.PI * 2;
        const node = new THREE.Mesh(new THREE.OctahedronGeometry(40 + i * 8, 0), mat);
        node.position.set(Math.cos(a) * R, Math.sin(a) * R, 0); g.add(node);
      }
      g.rotation.set(rng.range(0, Math.PI), rng.range(0, Math.PI), 0);
      g.userData.spin = new THREE.Vector3(0, 0, (i % 2 ? 1 : -1) * 0.02 / (i + 1));
      g.userData.local = true;
      this.group.add(g); this.dynamic.push(g);
    }
  }

  _buildFortress(rng) {
    // distant planetary defense platforms with blinking lights
    for (let i = 0; i < 6; i++) {
      const g = new THREE.Group();
      const base = new THREE.Mesh(new THREE.CylinderGeometry(60, 80, 30, 8), new THREE.MeshStandardMaterial({ color: '#3a3a44', metalness: 0.8, roughness: 0.4 }));
      const spire = new THREE.Mesh(new THREE.ConeGeometry(14, 160, 6), base.material);
      spire.position.y = 90;
      const light = new THREE.Mesh(new THREE.SphereGeometry(6, 8, 8), new THREE.MeshBasicMaterial({ color: new THREE.Color('#ff3b3b').multiplyScalar(3) }));
      light.position.y = 175;
      g.add(base, spire, light);
      const dir = new THREE.Vector3(rng.range(-1, 1), rng.range(-0.3, 0.1), rng.range(-1, 1)).normalize();
      g.position.copy(dir.multiplyScalar(rng.range(1500, 2600)));
      g.userData.blink = light;
      this.group.add(g); this.dynamic.push(g);
    }
  }

  _buildCameraParticles(count, kind, color) {
    const box = kind === 'dust' ? 360 : 260;
    const pos = new Float32Array(count * 3), col = new Float32Array(count * 3), seed = new Float32Array(count);
    const c = new THREE.Color(color);
    const palette = kind === 'confetti' ? ['#ff5ce1', '#ffd04a', '#4ff0ff', '#7dff6a', '#ff6a3a'].map(x => new THREE.Color(x)) : null;
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * box * 2; pos[i * 3 + 1] = (Math.random() - 0.5) * box * 2; pos[i * 3 + 2] = (Math.random() - 0.5) * box * 2;
      const cc = palette ? palette[i % palette.length] : c;
      const k = kind === 'dust' ? 0.35 : 1;
      col[i * 3] = cc.r * k + (kind === 'dust' ? 0.25 : 0); col[i * 3 + 1] = cc.g * k + (kind === 'dust' ? 0.25 : 0); col[i * 3 + 2] = cc.b * k + (kind === 'dust' ? 0.25 : 0);
      seed[i] = Math.random() * 100;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    g.setAttribute('seed', new THREE.BufferAttribute(seed, 1));
    const sizes = { dust: 2.2, snow: 3.2, wisps: 4.5, petals: 4.5, embers: 3, confetti: 3.5, motes: 3 };
    const motion = { dust: 0, snow: 1, wisps: 2, petals: 3, embers: 4, confetti: 3, motes: 5 }[kind] || 0;
    const m = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uCam: { value: new THREE.Vector3() }, uBox: { value: box }, uSize: { value: sizes[kind] || 3 }, uMotion: { value: motion }, uPixel: { value: window.innerHeight / 2 } },
      vertexShader: `attribute vec3 color; attribute float seed; uniform float uTime; uniform vec3 uCam; uniform float uBox; uniform float uSize; uniform float uMotion; uniform float uPixel;
        varying vec3 vColor; varying float vA;
        void main(){
          vec3 p = position;
          float t = uTime;
          if (uMotion == 1.0) { p.y -= t*14.0; p.x += sin(t*0.5+seed)*12.0; }
          else if (uMotion == 2.0) { p += vec3(sin(t*0.7+seed)*18.0, cos(t*0.5+seed*1.3)*14.0 + t*4.0, sin(t*0.3+seed*0.7)*18.0); }
          else if (uMotion == 3.0) { p.y -= t*9.0; p.x += sin(t*1.3+seed)*20.0; p.z += cos(t*1.1+seed)*12.0; }
          else if (uMotion == 4.0) { p.y += t*16.0; p.x += sin(t*2.0+seed)*6.0; }
          else if (uMotion == 5.0) { p += vec3(sin(t*0.4+seed), cos(t*0.33+seed), sin(t*0.25+seed*2.0))*20.0; }
          vec3 rel = mod(p - uCam + uBox, uBox*2.0) - uBox;
          vec4 mv = modelViewMatrix * vec4(uCam + rel, 1.0);
          float dist = length(rel);
          vA = smoothstep(uBox, uBox*0.5, dist) * smoothstep(4.0, 24.0, dist);
          if (uMotion == 2.0 || uMotion == 5.0) vA *= 0.6 + 0.4*sin(t*3.0+seed*5.0);
          vColor = color;
          gl_PointSize = uSize * uPixel / max(1.0, -mv.z);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `varying vec3 vColor; varying float vA; uniform float uMotion;
        void main(){ vec2 c = gl_PointCoord - 0.5; float d = length(c);
          float a = smoothstep(0.5, 0.1, d);
          if (uMotion == 3.0) { a = step(abs(c.x*1.6+c.y*0.4), 0.3) * step(abs(c.y), 0.45); }
          gl_FragColor = vec4(vColor * (uMotion==0.0 ? 1.0 : 1.2), a * vA * (uMotion==0.0 ? 1.0 : 0.6)); }`,
      transparent: true, depthWrite: false, blending: kind === 'petals' || kind === 'confetti' ? THREE.NormalBlending : THREE.AdditiveBlending,
    });
    const pts = new THREE.Points(g, m);
    pts.frustumCulled = false;
    this.group.add(pts);
    return pts;
  }

  update(dt, camera, focus) {
    this.time += dt;
    for (const s of this.stars || []) { s.material.uniforms.uTime.value = this.time; s.position.copy(camera.position); }
    if (this.sky) this.sky.position.copy(camera.position);
    for (const p of [this.ambientParticles, this.eventParticles]) {
      if (!p) continue;
      p.material.uniforms.uTime.value = this.time;
      p.material.uniforms.uCam.value.copy(camera.position);
      p.material.uniforms.uPixel.value = window.innerHeight / 2;
    }
    if (focus && this.sun) {
      this.sun.target.position.copy(focus);
      this.sun.position.copy(focus).addScaledVector(this.sunDir, 500);
    }
    for (const d of this.dynamic) {
      if (d.userData.spin) { d.rotation.x += d.userData.spin.x * dt; d.rotation.y += d.userData.spin.y * dt; d.rotation.z += d.userData.spin.z * dt; }
      if (d.userData.blink) d.userData.blink.visible = Math.sin(this.time * 3 + d.position.x) > 0;
    }
    if (this.planet) this.planet.rotation.y += dt * 0.004;
    this._updateAsteroids(dt);
  }

  _updateAsteroids(dt) {
    const a = this.asteroids; if (!a) return;
    const m4 = this._m4 || (this._m4 = new THREE.Matrix4());
    const p = this._p || (this._p = new THREE.Vector3()), s = this._s || (this._s = new THREE.Vector3()), dq = this._dq || (this._dq = new THREE.Quaternion());
    const lim = ARENA_RADIUS * 1.25;
    for (let i = 0; i < a.count; i++) {
      const im = a.meshes[a.mesh[i]];
      if (!a.alive[i]) continue;
      a.pos[i * 3] += a.vel[i * 3] * dt; a.pos[i * 3 + 1] += a.vel[i * 3 + 1] * dt; a.pos[i * 3 + 2] += a.vel[i * 3 + 2] * dt;
      if (a.storm) { // wrap storm rocks back to the far side
        if (a.pos[i * 3 + 2] > lim) { a.pos[i * 3 + 2] = -lim; a.pos[i * 3] = (Math.random() - 0.5) * lim * 1.6; a.pos[i * 3 + 1] = (Math.random() - 0.5) * lim * 0.8; }
      }
      dq.setFromAxisAngle(a.axis[i], a.spin[i] * dt);
      a.quat[i].multiply(dq);
      p.set(a.pos[i * 3], a.pos[i * 3 + 1], a.pos[i * 3 + 2]); s.setScalar(a.scale[i]);
      m4.compose(p, a.quat[i], s);
      im.setMatrixAt(a.index[i], m4);
    }
    for (const im of a.meshes) im.instanceMatrix.needsUpdate = true;
  }

  destroyAsteroid(i) {
    const a = this.asteroids;
    a.alive[i] = 0;
    const im = a.meshes[a.mesh[i]];
    const m4 = new THREE.Matrix4().makeScale(0, 0, 0);
    im.setMatrixAt(a.index[i], m4); im.instanceMatrix.needsUpdate = true;
    // Respawn later far away so the field never fully depletes
    setTimeout(() => {
      if (this.asteroids !== a) return;
      const dir = new THREE.Vector3(Math.random() - 0.5, (Math.random() - 0.5) * 0.5, Math.random() - 0.5).normalize().multiplyScalar(ARENA_RADIUS * 1.1);
      a.pos[i * 3] = dir.x; a.pos[i * 3 + 1] = dir.y; a.pos[i * 3 + 2] = dir.z; a.hp[i] = a.scale[i] * 6; a.alive[i] = 1;
    }, 20000);
  }

  setFogMultiplier(k) { if (this.scene.fog) this.scene.fog.density = this.fogBase * k; }

  dispose() {
    if (!this.group) return;
    this.scene.remove(this.group);
    this.group.traverse(o => {
      if (o.geometry && !asteroidGeoCache.includes(o.geometry)) o.geometry.dispose();
      if (o.material) {
        const mats = Array.isArray(o.material) ? o.material : [o.material];
        for (const m of mats) m.dispose(); // textures are cached & shared — keep them
      }
    });
    if (this.envRT) { this.envRT.dispose(); this.envRT = null; } this.envMap = null;
    this.scene.environment = null;
    this.group = new THREE.Group();
    this.dynamic = []; this.obstacles = []; this.asteroids = null; this.ambientParticles = null; this.eventParticles = null; this.planet = null;
  }
}
