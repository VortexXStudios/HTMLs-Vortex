// ============================================================================
// Calendar-driven seasonal events. Data-driven: add an entry to EVENTS to
// create a new event without touching the core game.
// ============================================================================
import { hashString } from './rng.js';
import { dayIndex } from './daily.js';

// Month is 1-12. Ranges may wrap across new year.
export const EVENTS = {
  halloween: {
    name: 'Hallowed Void', icon: 'ev_halloween', tagline: 'The dead lanes are restless.',
    range: { from: [10, 18], to: [11, 3] },
    colors: { a: '#ff7a1a', b: '#7dff6a', bg: '#140a04' },
    particles: 'wisps', skyTint: ['#120806', '#3a1a08', '#4aff6a'], fogBoost: 1.3,
    enemyVariant: 'ghost', variantChance: 0.45,
    boss: 'hollow', hazard: 'mines',
    description: 'Ghostly enemy variants haunt every sector. Face the Hollow Warden and earn haunted cosmetics.',
    chain: [
      { id: 'hw1', title: 'Whispers in the Boneyard', region: 'graveyard', objective: 'derelict', difficulty: 1.3, brief: 'A ghost ship is broadcasting a distress call that ended 300 years ago.' },
      { id: 'hw2', title: 'Lantern Hunt', region: 'nebula', objective: 'convoy', difficulty: 1.5, brief: 'Spectral freighters carry soul-lanterns that power the Warden. Steal them.' },
      { id: 'hw3', title: 'The Hollow Warden', region: 'graveyard', objective: 'boss', boss: 'hollow', difficulty: 1.7, brief: 'The Warden has risen. Extinguish its lanterns and send it back to the deep.' },
    ],
    tokenRate: 1.0,
  },
  winter: {
    name: 'Frostfall', icon: 'ev_winter', tagline: 'Space has never been colder.',
    range: { from: [12, 10], to: [1, 6] },
    colors: { a: '#9fe6ff', b: '#ffffff', bg: '#040a14' },
    particles: 'snow', skyTint: ['#06101e', '#2a5a8a', '#cfefff'], fogBoost: 1.1, icyAsteroids: true,
    enemyVariant: 'frost', variantChance: 0.4,
    boss: 'dreadnought', bossVariant: 'cryo', hazard: 'asteroids',
    description: 'Frozen asteroid storms and frostbound enemies. Their hits chill your engines.',
    chain: [
      { id: 'wf1', title: 'Cold Front', region: 'belt', objective: 'survive', difficulty: 1.3, brief: 'A frozen comet shower is sweeping the belt — and the Dominion is using it as cover.' },
      { id: 'wf2', title: 'Supply Run', region: 'belt', objective: 'escort', difficulty: 1.5, brief: 'Escort a frozen-in relief ship while it thaws its engines.' },
      { id: 'wf3', title: 'Cryo Leviathan', region: 'frontier', objective: 'boss', boss: 'dreadnought', bossVariant: 'cryo', difficulty: 1.8, brief: 'A frost-hardened Dreadnought freezes everything in its wake.' },
    ],
    tokenRate: 1.0,
  },
  spring: {
    name: 'Bloomtide', icon: 'ev_spring', tagline: 'Life finds a way — even in vacuum.',
    range: { from: [3, 20], to: [4, 20] },
    colors: { a: '#ff9fd2', b: '#7dff9a', bg: '#100812' },
    particles: 'petals', skyTint: ['#0c0814', '#5a2a6a', '#6affc0'], fogBoost: 1.2, bioluminescent: true,
    enemyVariant: 'bloom', variantChance: 0.4,
    boss: 'swarmqueen', hazard: 'ionstorm',
    description: 'Bioluminescent spore clouds and organic enemies that burst into new life.',
    chain: [
      { id: 'sb1', title: 'Spore Season', region: 'nebula', objective: 'colony', difficulty: 1.3, brief: 'Spore clouds are seeding Vrell broods across the Veil colonies.' },
      { id: 'sb2', title: 'Pollinators', region: 'nebula', objective: 'anomaly', difficulty: 1.5, brief: 'Living pylons are feeding the bloom. Burn them out.' },
      { id: 'sb3', title: 'Queen of Blossoms', region: 'nebula', objective: 'boss', boss: 'swarmqueen', difficulty: 1.8, brief: 'The Swarm Queen has blossomed into something new.' },
    ],
    tokenRate: 1.0,
  },
  summer: {
    name: 'Solar Maximum', icon: 'ev_summer', tagline: 'The star is waking up.',
    range: { from: [6, 21], to: [7, 31] },
    colors: { a: '#ffb02e', b: '#ff5a1a', bg: '#140a02' },
    particles: 'embers', skyTint: ['#140802', '#8a3a0a', '#ffd25a'], fogBoost: 0.9, solarStorms: true,
    enemyVariant: 'solar', variantChance: 0.4,
    boss: 'dreadnought', hazard: 'flares',
    description: 'Solar storms supercharge weapons (+20% damage for everyone) and scorch the battlefield.',
    globalDamage: 1.2,
    chain: [
      { id: 'sm1', title: 'Coronal Ejection', region: 'volcanic', objective: 'survive', difficulty: 1.3, brief: 'A coronal mass ejection is minutes away. Survive it — the Dominion won\'t.' },
      { id: 'sm2', title: 'Heat Sink', region: 'volcanic', objective: 'shieldgen', difficulty: 1.5, brief: 'Dominion solar collectors are drinking the storm. Break them.' },
      { id: 'sm3', title: 'Sunbreaker', region: 'volcanic', objective: 'carrier', difficulty: 1.8, brief: 'A solar-powered carrier is launching scorched fighters.' },
    ],
    tokenRate: 1.0,
  },
  anniversary: {
    name: 'Starfall Day', icon: 'ev_anniversary', tagline: 'Another year defending the Reach.',
    range: { from: [8, 8], to: [8, 15] },
    colors: { a: '#ffd04a', b: '#ff5ce1', bg: '#0c0814' },
    particles: 'confetti', skyTint: null, fogBoost: 1,
    enemyVariant: null, variantChance: 0,
    boss: null, hazard: null, bonusRewards: 1.5,
    description: 'Celebrate the founding of Starfall Wing: +50% rewards on every mission and party cosmetics.',
    chain: [
      { id: 'an1', title: 'Fireworks Display', region: 'city', objective: 'intercept', difficulty: 1.2, brief: 'Pirates want to crash the celebration. Give them a fireworks show.' },
      { id: 'an2', title: 'Victory Lap', region: 'megastructure', objective: 'escape', difficulty: 1.4, brief: 'A ceremonial race through the Lattice — with uninvited guests.' },
    ],
    tokenRate: 1.2,
  },
  anomaly: {
    name: 'Cosmic Anomaly', icon: 'blackhole_blue', tagline: 'Reality is thin today.',
    range: null, rare: true,
    colors: { a: '#6af0ff', b: '#b26bff', bg: '#02040c' },
    particles: 'motes', skyTint: ['#02030a', '#1a0a3a', '#6af0ff'], fogBoost: 1,
    enemyVariant: null, variantChance: 0,
    boss: 'anomaly', hazard: 'gravity',
    description: 'A rare rift has opened. Gravity is unstable everywhere and the Anomaly hungers. Exotic rewards.',
    chain: [
      { id: 'ca1', title: 'Rift Walker', region: 'megastructure', objective: 'anomaly', difficulty: 1.6, brief: 'Step through the rift and close it from the other side.' },
      { id: 'ca2', title: 'What Lies Beyond', region: 'megastructure', objective: 'boss', boss: 'anomaly', difficulty: 2.0, brief: 'Something is reaching through. Push it back.' },
    ],
    tokenRate: 1.5,
  },
};
export const EVENT_ORDER = ['halloween', 'winter', 'spring', 'summer', 'anniversary', 'anomaly'];

function md(m, d) { return m * 100 + d; }

export function inRange(date, range) {
  const v = md(date.getMonth() + 1, date.getDate());
  const a = md(range.from[0], range.from[1]);
  const b = md(range.to[0], range.to[1]);
  return a <= b ? (v >= a && v <= b) : (v >= a || v <= b); // wrap year
}

// Rare event: active 2 days out of ~every 23, deterministic by calendar day.
export function isAnomalyDay(date) {
  const di = dayIndex(date);
  const q = d => (hashString('cosmic-anomaly-' + d) % 23) === 0;
  return q(di) || q(di - 1);
}

// Returns the key used to track per-year progress (handles winter wrap).
export function eventInstanceKey(id, date) {
  const ev = EVENTS[id];
  let year = date.getFullYear();
  if (ev && ev.range && ev.range.from[0] > ev.range.to[0] && (date.getMonth() + 1) <= ev.range.to[0]) year -= 1;
  if (id === 'anomaly') {
    const di = dayIndex(date);
    const start = (hashString('cosmic-anomaly-' + di) % 23) === 0 ? di : di - 1;
    return `anomaly-${start}`;
  }
  return `${id}-${year}`;
}

// When does a range end (local midnight after last day)?
export function eventEndsAt(id, date) {
  const ev = EVENTS[id];
  if (!ev.range) { const d = new Date(date); d.setHours(24, 0, 0, 0); if (isAnomalyDay(d)) d.setDate(d.getDate() + 1); return d.getTime(); }
  let y = date.getFullYear();
  if (ev.range.from[0] > ev.range.to[0] && (date.getMonth() + 1) >= ev.range.from[0]) y += 1;
  return new Date(y, ev.range.to[0] - 1, ev.range.to[1] + 1, 0, 0, 0).getTime();
}

/**
 * Active events for a date. `override` (dev-only) forces a specific event id.
 */
export function getActiveEvents(date = new Date(), override = null) {
  if (override && EVENTS[override]) return [override];
  if (override === 'none') return [];
  const out = [];
  for (const id of EVENT_ORDER) {
    const ev = EVENTS[id];
    if (ev.range && inRange(date, ev.range)) out.push(id);
    else if (ev.rare && isAnomalyDay(date)) out.push(id);
  }
  return out;
}

// Upcoming events (for the event screen calendar)
export function upcomingEvents(date = new Date()) {
  const res = [];
  for (const id of EVENT_ORDER) {
    const ev = EVENTS[id];
    if (!ev.range) continue;
    let y = date.getFullYear();
    let start = new Date(y, ev.range.from[0] - 1, ev.range.from[1]);
    if (start < date && !inRange(date, ev.range)) start = new Date(y + 1, ev.range.from[0] - 1, ev.range.from[1]);
    res.push({ id, start: start.getTime(), active: inRange(date, ev.range) });
  }
  return res.sort((a, b) => a.start - b.start);
}

/** Read dev overrides from URL: ?dev=1&event=halloween&date=2026-12-25 */
export function readDevOverrides(search = (typeof location !== 'undefined' ? location.search : '')) {
  const p = new URLSearchParams(search);
  if (p.get('dev') !== '1') return { dev: false, event: null, date: null };
  const date = p.get('date') ? new Date(p.get('date') + 'T12:00:00') : null;
  return { dev: true, event: p.get('event'), date: date && !isNaN(date) ? date : null, seed: p.get('seed') };
}
