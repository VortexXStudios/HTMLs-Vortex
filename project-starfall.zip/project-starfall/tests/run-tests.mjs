// Run with:  node tests/run-tests.mjs
// Zero-dependency test runner for the pure logic modules.
import { SaveManager, memoryStorage, defaultSave, sanitize, migrate, SAVE_KEY, BACKUP_KEY } from '../src/save.js';
import { dayIndex, nextStreak, claimDaily, getDailyStatus, rewardForStreak, touchClock, msUntilNextDay } from '../src/daily.js';
import { getActiveEvents, inRange, EVENTS, eventInstanceKey, isAnomalyDay } from '../src/events.js';
import { generateMission, generateContracts, composeWave, pickObjective, dailyChallenge, campaignMission, experimentalMission, bossRushMission } from '../src/missions.js';
import { addXp, buyUpgrade, buyShip, buyMod, computeShipStats, checkAchievements, applyMissionResult, canAfford, setLoadout, equipCosmetic, buyCosmetic } from '../src/progression.js';
import { RNG } from '../src/rng.js';
import { SAVE_VERSION, xpForLevel, CAMPAIGN, upgradeCost, OBJECTIVES } from '../src/data.js';

let passed = 0, failed = 0;
const results = [];
function test(name, fn) {
  try { fn(); passed++; results.push(`  ✓ ${name}`); }
  catch (e) { failed++; results.push(`  ✗ ${name}\n      ${e.message}`); }
}
function eq(a, b, msg = '') { if (a !== b) throw new Error(`${msg} expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); }
function ok(v, msg = 'expected truthy') { if (!v) throw new Error(msg); }
const at = (y, m, d, h = 12) => new Date(y, m - 1, d, h).getTime();

// ---------------- SAVE ----------------
test('new save created when storage empty', () => {
  const st = memoryStorage();
  const sm = new SaveManager(st);
  const s = sm.load();
  eq(sm.status.source, 'new');
  eq(s.version, SAVE_VERSION);
  ok(st.getItem(SAVE_KEY));
});
test('save round-trips', () => {
  const st = memoryStorage();
  const a = new SaveManager(st); a.load(); a.data.currencies.credits = 4321; a.data.ships.owned.push('viper'); a.save();
  const b = new SaveManager(st); const s = b.load();
  eq(s.currencies.credits, 4321); ok(s.ships.owned.includes('viper')); eq(b.status.source, 'primary');
});
test('corrupt primary falls back to backup and quarantines', () => {
  const st = memoryStorage();
  const a = new SaveManager(st); a.load(); a.data.currencies.credits = 999; a.save(); // first save writes backup
  st.setItem(BACKUP_KEY, JSON.stringify(a.data));
  st.setItem(SAVE_KEY, '{"broken json');
  const b = new SaveManager(st); const s = b.load();
  eq(b.status.source, 'backup'); eq(s.currencies.credits, 999); ok(b.status.quarantined, 'quarantined key');
  ok(st.getItem(b.status.quarantined).startsWith('{"broken'));
});
test('corrupt primary with no backup does not lose raw data', () => {
  const st = memoryStorage();
  st.setItem(SAVE_KEY, 'garbage!!');
  const b = new SaveManager(st); b.load();
  eq(b.status.source, 'reset-after-corruption');
  eq(st.getItem(b.status.quarantined), 'garbage!!');
});
test('sanitize repairs invalid fields and unknown ids', () => {
  const raw = defaultSave();
  raw.currencies.credits = -50; raw.currencies.alloy = 'lots'; raw.ships.owned = ['warden', 'ufo']; raw.ships.selected = 'ufo';
  raw.upgrades.hull = 99; raw.cosmetics.owned.push('nonexistent'); raw.settings.shadows = 'ultra';
  const { save, issues } = sanitize(raw);
  eq(save.currencies.credits, 0); eq(save.currencies.alloy, 0); eq(save.ships.owned.join(), 'warden'); eq(save.ships.selected, 'warden');
  eq(save.upgrades.hull, 5); ok(!save.cosmetics.owned.includes('nonexistent')); eq(save.settings.shadows, 'low');
  ok(issues.length > 0);
});
test('incomplete save is filled with defaults', () => {
  const { save } = sanitize({ version: 3, currencies: { credits: 10 } });
  eq(save.currencies.credits, 10); eq(save.profile.level, 1); ok(save.ships.loadouts.warden.primary.length === 2);
});
test('migration v1 -> current', () => {
  const v1 = { version: 1, weapons: ['pulse', 'plasma'], currencies: { credits: 77 } };
  const { save, applied } = migrate(JSON.parse(JSON.stringify(v1)));
  eq(applied.join(), '1,2'); eq(save.version, 3);
  const s = sanitize(save).save; ok(s.arsenal.weapons.includes('plasma')); eq(s.currencies.credits, 77);
});
test('reset requires explicit call and keeps settings', () => {
  const st = memoryStorage(); const a = new SaveManager(st); a.load(); a.data.settings.musicVolume = 0.1; a.data.currencies.credits = 9000; a.save();
  a.reset(); eq(a.data.currencies.credits, 500); eq(a.data.settings.musicVolume, 0.1);
});

// ---------------- DAILY ----------------
test('dayIndex uses calendar days', () => {
  eq(dayIndex(at(2026, 10, 28, 0)), dayIndex(at(2026, 10, 28, 23)));
  eq(dayIndex(at(2026, 10, 29, 0)) - dayIndex(at(2026, 10, 28, 23)), 1);
});
test('streak rules: consecutive, grace, halve', () => {
  eq(nextStreak(null, 0, 100), 1); eq(nextStreak(100, 5, 101), 6); eq(nextStreak(100, 5, 102), 6); eq(nextStreak(100, 10, 106), 6); eq(nextStreak(100, 5, 100), 5);
});
test('cannot claim twice on same day (refresh)', () => {
  const s = defaultSave(at(2026, 10, 28, 9));
  ok(claimDaily(s, at(2026, 10, 28, 9))); eq(claimDaily(s, at(2026, 10, 28, 9, 5)), null); eq(claimDaily(s, at(2026, 10, 28, 23)), null);
  ok(claimDaily(s, at(2026, 10, 29, 0, 1))); eq(s.daily.streak, 2);
});
test('clock rollback blocks claims', () => {
  const s = defaultSave(at(2026, 10, 28));
  claimDaily(s, at(2026, 10, 28)); touchClock(s, at(2026, 10, 30));
  const st = getDailyStatus(s, at(2026, 10, 25));
  ok(st.movedBack); ok(!st.canClaim);
  ok(getDailyStatus(s, at(2026, 10, 31)).canClaim);
});
test('reward table grows and day 7 grants cosmetic', () => {
  const r7 = rewardForStreak(7, []); ok(r7.cosmetic, 'cosmetic on day 7');
  ok(rewardForStreak(8, []).credits > rewardForStreak(1, []).credits);
});
test('msUntilNextDay bounded', () => { const ms = msUntilNextDay(at(2026, 10, 28, 23)); ok(ms > 0 && ms <= 3600000); });

// ---------------- EVENTS ----------------
test('halloween active Oct 28, inactive Nov 10', () => {
  ok(getActiveEvents(new Date(2026, 9, 28)).includes('halloween'));
  ok(!getActiveEvents(new Date(2026, 10, 10)).includes('halloween'));
});
test('winter wraps the new year', () => {
  ok(inRange(new Date(2026, 11, 25), EVENTS.winter.range)); ok(inRange(new Date(2027, 0, 3), EVENTS.winter.range)); ok(!inRange(new Date(2027, 0, 20), EVENTS.winter.range));
  eq(eventInstanceKey('winter', new Date(2027, 0, 3)), 'winter-2026');
});
test('dev override forces event', () => { eq(getActiveEvents(new Date(2026, 5, 1), 'winter').join(), 'winter'); eq(getActiveEvents(new Date(2026, 9, 28), 'none').length, 0); });
test('cosmic anomaly is rare', () => {
  let n = 0; for (let i = 0; i < 365; i++) if (isAnomalyDay(new Date(2026, 0, 1 + i))) n++;
  ok(n > 5 && n < 60, `anomaly days per year: ${n}`);
});

// ---------------- MISSIONS ----------------
test('mission generation is deterministic by seed', () => {
  const a = generateMission({ seed: 'abc', history: [] }); const b = generateMission({ seed: 'abc', history: [] });
  eq(JSON.stringify(a), JSON.stringify(b));
});
test('generated missions are well formed', () => {
  for (let i = 0; i < 200; i++) {
    const m = generateMission({ seed: 'w' + i });
    ok(m.region && m.objective && m.faction, 'fields'); ok(OBJECTIVES[m.objective], 'objective valid ' + m.objective);
    ok(m.rewards.credits > 0); ok(Array.isArray(m.modifiers));
    if (m.modifiers.includes('glass')) ok(!m.modifiers.includes('ironclad'), 'conflict');
  }
});
test('objective picker avoids recent repeats', () => {
  const rng = new RNG(5); let repeats = 0;
  for (let i = 0; i < 300; i++) { const o = pickObjective(rng, 'belt', ['intercept', 'colony', 'survive']); if (['intercept', 'colony', 'survive'].includes(o)) repeats++; }
  ok(repeats < 30, `repeats=${repeats}`);
});
test('contract board has 5 distinct objectives', () => {
  const s = defaultSave(); const list = generateContracts(s, 20000, []);
  eq(list.length, 5); eq(new Set(list.map(m => m.objective)).size, 5);
});
test('follow-ups appear on contract board', () => {
  const s = defaultSave(); s.universe.followUps.push({ id: 'f1', kind: 'rescue', region: 'belt', objective: 'escort', title: 'Evac', brief: 'x' });
  const list = generateContracts(s, 20000, []); eq(list[0].title, 'Evac'); eq(list.length, 6);
});
test('wave composition respects budget and alternates formation', () => {
  const rng = new RNG(1); const w = composeWave(rng, { wave: 4, difficulty: 1.2, faction: 'dominion', lastFormation: 'grid' });
  ok(w.groups.length >= 2); ok(w.formation !== 'grid'); ok(w.spent <= w.budget + 6);
});
test('daily challenge fixed per day', () => { eq(JSON.stringify(dailyChallenge(500)), JSON.stringify(dailyChallenge(500))); ok(dailyChallenge(500).region); });
test('campaign mission builds for every chapter', () => { const s = defaultSave(); for (let i = 0; i < CAMPAIGN.length; i++) ok(campaignMission(i, s).title.includes(CAMPAIGN[i].title)); });
test('experimental never pairs giants+tiny', () => { for (let i = 0; i < 100; i++) { const m = experimentalMission(i); ok(!(m.mutators.includes('giants') && m.mutators.includes('tiny'))); } });
test('boss rush uses encountered bosses', () => { const s = defaultSave(); s.universe.encountered.bosses = { swarmqueen: 1, phantom: 2 }; eq(bossRushMission(s).bossList.join(), 'swarmqueen,phantom'); });

// ---------------- PROGRESSION ----------------
test('xp levels up and grants level rewards', () => {
  const s = defaultSave(); const before = s.currencies.credits; addXp(s, xpForLevel(1) + 10);
  eq(s.profile.level, 2); ok(s.currencies.credits > before);
});
test('upgrade purchase spends and changes stats', () => {
  const s = defaultSave(); s.currencies.credits = 10000; s.currencies.alloy = 100;
  const before = computeShipStats(s, 'warden').hull;
  ok(buyUpgrade(s, 'hull').ok); ok(computeShipStats(s, 'warden').hull > before);
  eq(s.currencies.credits, 10000 - upgradeCost('hull', 1).credits);
});
test('cannot buy upgrade without funds', () => { const s = defaultSave(); s.currencies.credits = 0; ok(!buyUpgrade(s, 'hull').ok); eq(s.upgrades.hull, 0); });
test('ship purchase level-gated', () => {
  const s = defaultSave(); s.currencies.credits = 99999; s.currencies.alloy = 999; ok(!buyShip(s, 'viper').ok);
  s.profile.level = 3; ok(buyShip(s, 'viper').ok); ok(s.arsenal.weapons.includes('arc'), 'ship grants loadout');
});
test('mods require tier 3 and are exclusive per branch', () => {
  const s = defaultSave(); s.currencies.credits = 99999; s.currencies.alloy = 999; s.currencies.cores = 9;
  ok(!buyMod(s, 'leech').ok); s.upgrades.hull = 3; ok(buyMod(s, 'leech').ok); ok(buyMod(s, 'laststand').ok);
  eq(s.mods.equipped.hull, 'laststand'); ok(computeShipStats(s, 'warden').mods.has('laststand')); ok(!computeShipStats(s, 'warden').mods.has('leech'));
});
test('loadout swap keeps weapons unique', () => {
  const s = defaultSave(); setLoadout(s, 'warden', 'primary', 'scatter', 0); eq(s.ships.loadouts.warden.primary.join(), 'scatter,pulse');
});
test('cosmetic purchase + equip persists through save cycle', () => {
  const st = memoryStorage(); const sm = new SaveManager(st); sm.load(); sm.data.currencies.credits = 5000;
  ok(buyCosmetic(sm.data, 'paint_crimson').ok); ok(equipCosmetic(sm.data, 'warden', 'paint_crimson')); sm.save();
  const sm2 = new SaveManager(st); eq(sm2.load().cosmetics.equipped.warden.paint, 'paint_crimson');
});
test('achievements unlock once', () => {
  const s = defaultSave(); s.stats.kills = 1; const a = checkAchievements(s); ok(a.some(x => x.achievement.id === 'first_blood')); eq(checkAchievements(s).length, 0);
});
test('mission result grants rewards, history, threat', () => {
  const s = defaultSave(); const m = generateMission({ seed: 'r1', region: 'belt', objective: 'intercept', difficulty: 1.2 });
  const c0 = s.currencies.credits; const t0 = s.universe.threat.belt;
  const r = applyMissionResult(s, m, { outcome: 'victory', kills: 20, score: 5000, time: 200, optionalDone: m.optional, loot: { credits: 50 }, branch: { stationHp: 0.3 } });
  ok(s.currencies.credits > c0); eq(s.universe.history.at(-1), 'intercept'); ok(s.universe.threat.belt > t0); eq(s.stats.missionsWon, 1);
  ok(r.followUps.some(f => f.kind === 'rescue'), 'rescue follow-up');
});
test('defeat gives reduced rewards', () => {
  const s1 = defaultSave(), s2 = defaultSave(); const m = generateMission({ seed: 'r2', difficulty: 1.2 });
  applyMissionResult(s1, m, { outcome: 'victory' }); applyMissionResult(s2, m, { outcome: 'defeat' });
  ok(s1.currencies.credits > s2.currencies.credits); eq(s2.stats.deaths, 1);
});
test('campaign completion unlocks next chapter', () => {
  const s = defaultSave(); const m = campaignMission(0, s); applyMissionResult(s, m, { outcome: 'victory' }); ok(s.campaign.completed.includes('c1'));
});
test('boss first-kill grants cosmetic', () => {
  const s = defaultSave(); const m = generateMission({ seed: 'b', objective: 'boss', boss: 'dreadnought' });
  const r = applyMissionResult(s, m, { outcome: 'victory', bossesKilled: ['dreadnought'] }); ok(r.reward.cosmetic, 'cosmetic dropped'); ok(s.cosmetics.owned.includes(r.reward.cosmetic));
});
test('daily mission bonus only once per day', () => {
  const s = defaultSave(); const m = generateMission({ seed: 'd' }); m.daily = true;
  applyMissionResult(s, m, { outcome: 'victory', today: 100 }); const c = s.currencies.cores; applyMissionResult(s, m, { outcome: 'victory', today: 100 });
  ok(s.currencies.cores - c <= (m.rewards.cores || 0), 'no second bonus');
});

console.log(results.join('\n'));
console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
