// =============================================================================
// Browser QA suite (Playwright + headless Chromium).
//   npm i -D playwright && npx playwright install chromium
//   node tests/browser-qa.mjs                 # all suites
//   SUITES=boot,menus node tests/browser-qa.mjs
// Starts its own static server, drives the real game, and plays missions with
// an autopilot (tests/autopilot.js) at accelerated speed without rendering.
// =============================================================================
import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
// index.html runs the bundled build: rebuild it so the tests exercise the current sources
if (!process.env.NO_BUILD) (await import('child_process')).execFileSync(process.execPath, [path.join(ROOT, 'tools/build.mjs')], { stdio: 'ignore' });
let chromium;
try { ({ chromium } = await import('playwright')); }
catch { const req = createRequire('/opt/npm-tools/node_modules/x.js'); ({ chromium } = req('playwright')); }

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.md': 'text/markdown' };
const server = http.createServer((req, res) => {
  const p = path.join(ROOT, decodeURIComponent(req.url.split('?')[0]));
  if (!p.startsWith(ROOT) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(p)] || 'application/octet-stream' });
  fs.createReadStream(p).pipe(res);
});
await new Promise(r => server.listen(0, r));
const BASE = `http://localhost:${server.address().port}/index.html`;
const SUITES = (process.env.SUITES || 'boot,menus,economy,persistence,daily,events,corruption,objectives,bosses,modes,story,combat,defeat,flow').split(',');

const results = [];
const log = (...a) => console.log(...a);
function record(name, ok, detail = '') { results.push({ name, ok, detail }); log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`); }

const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
const LOW = { version: 3, settings: { resolutionScale: 0.5, effects: 'low', particles: 'low', shadows: 'off', fpsCap: 30 } };

async function newPage(seed = LOW, query = '') {
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  page.errors = [];
  page.on('pageerror', e => page.errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !m.text().includes('ERR_TUNNEL') && !m.text().includes('fonts.g')) page.errors.push(m.text()); });
  if (seed) await page.addInitScript(s => { if (!sessionStorage.getItem('__seeded')) { sessionStorage.setItem('__seeded', '1'); localStorage.clear(); localStorage.setItem('starfall_save_v', JSON.stringify(s)); } }, seed);
  await page.goto(BASE + query);
  await page.addScriptTag({ path: path.join(ROOT, 'tests/autopilot.js') });
  page.cdp = await page.context().newCDPSession(page);
  return page;
}
const skipSplash = async page => { await page.waitForFunction(() => window.__starfall); await page.mouse.click(640, 360); await page.waitForFunction(() => window.__starfall.state === 'title', null, { timeout: 15000 }); };

async function play(page, launchExpr, opts = {}) {
  await page.evaluate(async ({ launchExpr, opts }) => {
    const M = await import('/src/missions.js'); const D = await import('/src/data.js');
    const app = window.__starfall; const save = app.saveManager.data;
    const m = (new Function('M', 'D', 'app', 'save', 'return ' + launchExpr))(M, D, app, save);
    app.launchMission(m);
    window.__qa.begin(opts);
  }, { launchExpr, opts });
  for (let i = 0; i < 1000; i++) {
    const r = await page.evaluate(() => window.__qa.step(120));
    await page.cdp.send('HeapProfiler.collectGarbage'); // accelerated sim starves Blink's idle-time GC
    if (r.done) break;
  }
  const s = await page.evaluate(() => window.__qa.summary());
  if (await page.evaluate(() => window.__starfall.state === 'mission')) await page.evaluate(() => window.__starfall.abandonMission());
  await page.cdp.send('HeapProfiler.collectGarbage');
  return s;
}

try {
  // ------------------------------------------------------------------ boot
  if (SUITES.includes('boot')) {
    const page = await newPage();
    await page.waitForTimeout(2500);
    const splash = await page.evaluate(() => document.querySelector('#splash')?.innerText || '');
    record('splash shows VORTEX STUDIOS PRESENTS...', /V\s*O\s*R\s*T\s*E\s*X/.test(splash.replace(/\n/g, ' ')) && splash.includes('PRESENTS'), splash.replace(/\s+/g, ' ').slice(0, 60));
    await page.waitForFunction(() => window.__starfall?.state === 'title', null, { timeout: 15000 });
    record('splash auto-advances to title', true);
    const title = await page.evaluate(() => document.querySelector('#title').innerText);
    record('title screen renders logo', title.includes('PROJECT') && title.includes('STARFALL'));
    const webgl = await page.evaluate(() => !!window.__starfall.renderer.renderer.getContext());
    record('WebGL renderer initialised', webgl);
    record('no JavaScript errors on boot', page.errors.length === 0, page.errors.slice(0, 3).join(' | '));
    await page.close();
  }

  // ------------------------------------------------------------------ menus
  if (SUITES.includes('menus')) {
    const page = await newPage(); await skipSplash(page);
    await page.click('[data-action=title-play]');
    await page.waitForFunction(() => window.__starfall.state === 'hangar');
    const tabs = ['missions', 'ships', 'upgrades', 'customize', 'shop', 'collection', 'achievements', 'daily', 'events', 'leaderboards', 'settings'];
    const bad = [];
    for (const t of tabs) {
      await page.click(`.navbtn[data-tab=${t}]`);
      const len = await page.evaluate(() => document.querySelector('#content').innerText.length);
      if (len < 40) bad.push(t);
    }
    record('every hangar tab renders content', bad.length === 0, bad.join(','));
    await page.click('.navbtn[data-tab=missions]');
    await page.click('.subtabs [data-sub=modes]');
    const modes = await page.evaluate(() => document.querySelectorAll('.card.mode').length);
    record('game modes listed (endless, boss rush, experimental, daily)', modes === 4, String(modes));
    await page.click('.subtabs [data-sub=campaign]');
    const cards = await page.evaluate(() => document.querySelectorAll('.card.chapter').length);
    record('campaign lists 30 chapters in 3 acts', cards === 30, String(cards));
    await page.click('.subtabs [data-sub=contracts]');
    const contracts = await page.evaluate(() => document.querySelectorAll('.cards .card.mission').length);
    record('contract board offers missions', contracts >= 6, String(contracts));
    await page.click('.cards .card.mission >> nth=2');
    const brief = await page.evaluate(() => document.querySelector('#briefing.on .brief') ? document.querySelector('#briefing').innerText : '');
    record('briefing shows objective, modifiers, rewards & launch', /OBJECTIVE/i.test(brief) && /REWARDS/.test(brief) && /LAUNCH/.test(brief));
    await page.click('[data-action=close-brief]');
    // settings change persists
    await page.click('.navbtn[data-tab=settings]');
    await page.selectOption('select[data-set=particles]', 'medium');
    const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('starfall_save_v')).settings.particles);
    record('settings changes are saved', saved === 'medium', saved);
    record('no JavaScript errors in menus', page.errors.length === 0, page.errors.slice(0, 3).join(' | '));
    await page.close();
  }

  // ------------------------------------------------------------------ economy (purchases through the UI)
  if (SUITES.includes('economy')) {
    const page = await newPage({ ...LOW, currencies: { credits: 20000, alloy: 500, cores: 10, tokens: 100 }, profile: { level: 6, xp: 0, totalXp: 0 } });
    await skipSplash(page);
    await page.click('[data-action=title-play]');
    await page.click('.navbtn[data-tab=upgrades]');
    const before = await page.evaluate(() => window.__starfall.saveManager.data.upgrades.hull);
    const hullBefore = await page.evaluate(async () => (await import('/src/progression.js')).computeShipStats(window.__starfall.saveManager.data, 'warden').hull);
    await page.click('[data-action=buy-upgrade][data-id=hull]');
    const after = await page.evaluate(() => window.__starfall.saveManager.data.upgrades.hull);
    const hullAfter = await page.evaluate(async () => (await import('/src/progression.js')).computeShipStats(window.__starfall.saveManager.data, 'warden').hull);
    record('buying an upgrade raises tier and stat', after === before + 1 && hullAfter > hullBefore, `${hullBefore} -> ${hullAfter}`);
    await page.evaluate(() => { const s = window.__starfall.saveManager.data; s.upgrades.damage = 3; window.__starfall.ui.renderTab(); });
    await page.click('[data-action=buy-mod][data-id=piercing]');
    record('behaviour mod purchasable at tier 3', await page.evaluate(() => window.__starfall.saveManager.data.mods.equipped.damage === 'piercing'));
    await page.click('.navbtn[data-tab=ships]');
    await page.click('[data-action=preview-ship][data-id=viper]');
    await page.click('[data-action=buy-ship][data-id=viper]');
    record('ship can be built and becomes active', await page.evaluate(() => { const s = window.__starfall.saveManager.data; return s.ships.owned.includes('viper') && s.ships.selected === 'viper'; }));
    await page.click('.navbtn[data-tab=shop]');
    await page.click('.subtabs [data-sub=cosmetics]');
    await page.click('[data-action=buy-cos][data-id=paint_crimson]');
    await page.click('.navbtn[data-tab=customize]');
    await page.click('[data-action=equip-cos][data-id=paint_crimson]');
    record('cosmetic purchase & equip', await page.evaluate(() => window.__starfall.saveManager.data.cosmetics.equipped.viper.paint === 'paint_crimson'));
    const pre = await page.evaluate(() => window.__starfall.saveManager.data.currencies.credits);
    await page.evaluate(() => { const s = window.__starfall.saveManager.data; s.currencies.credits = 0; window.__starfall.ui.renderTab(); });
    await page.click('.navbtn[data-tab=upgrades]');
    const disabled = await page.evaluate(() => document.querySelector('[data-action=buy-upgrade][data-id=shield]').disabled);
    record('purchases blocked without funds', disabled, `credits were ${pre}`);
    await page.close();
  }

  // ------------------------------------------------------------------ persistence
  if (SUITES.includes('persistence')) {
    const page = await newPage();
    await skipSplash(page);
    await page.evaluate(() => { const s = window.__starfall.saveManager.data; s.currencies.credits = 7777; s.upgrades.engine = 2; s.cosmetics.owned.push('engine_violet'); s.cosmetics.equipped.warden.engine = 'engine_violet'; window.__starfall.persist(); });
    await page.reload(); await page.waitForFunction(() => window.__starfall);
    const s = await page.evaluate(() => { const d = window.__starfall.saveManager.data; return { c: d.currencies.credits, e: d.upgrades.engine, eq: d.cosmetics.equipped.warden.engine, src: window.__starfall.saveManager.status.source }; });
    record('progress survives a page reload', s.c === 7777 && s.e === 2 && s.eq === 'engine_violet' && s.src === 'primary', JSON.stringify(s));
    await page.close();
  }

  // ------------------------------------------------------------------ daily rewards
  if (SUITES.includes('daily')) {
    const page = await newPage(); await skipSplash(page);
    await page.click('[data-action=title-daily]');
    const c0 = await page.evaluate(() => window.__starfall.saveManager.data.currencies.credits);
    await page.click('[data-action=claim-daily]');
    const c1 = await page.evaluate(() => window.__starfall.saveManager.data.currencies.credits);
    record('daily reward can be claimed', c1 > c0, `${c0} -> ${c1}`);
    await page.reload(); await page.waitForFunction(() => window.__starfall); await skipSplash(page);
    await page.click('[data-action=title-daily]');
    const again = await page.evaluate(() => !!document.querySelector('[data-action=claim-daily]'));
    const streak = await page.evaluate(() => window.__starfall.saveManager.data.daily.streak);
    record('refreshing the page does not allow a second claim', !again && streak === 1, `streak ${streak}`);
    await page.close();
  }

  // ------------------------------------------------------------------ calendar events
  if (SUITES.includes('events')) {
    let page = await newPage(LOW, '?dev=1&date=2026-12-24'); await skipSplash(page);
    const ev1 = await page.evaluate(() => window.__starfall.activeEvents());
    record('winter event active on Dec 24', ev1.includes('winter'), ev1.join(','));
    await page.close();
    page = await newPage(LOW, '?dev=1&date=2026-11-12'); await skipSplash(page);
    const ev2 = await page.evaluate(() => window.__starfall.activeEvents());
    record('no seasonal event on Nov 12', !ev2.some(e => e !== 'anomaly'), ev2.join(',') || 'none');
    await page.close();
    page = await newPage(LOW, '?dev=1&event=summer'); await skipSplash(page);
    const ev3 = await page.evaluate(() => window.__starfall.activeEvents());
    const banner = await page.evaluate(() => document.querySelector('.title-event')?.innerText || '');
    record('developer override forces an event', ev3[0] === 'summer' && banner.includes('Solar'), banner.replace(/\s+/g, ' '));
    await page.close();
    page = await newPage(LOW, '?event=summer'); await skipSplash(page);
    const ev4 = await page.evaluate(() => window.__starfall.activeEvents());
    record('override ignored without dev flag', !ev4.includes('summer'), ev4.join(',') || 'none');
    await page.close();
  }

  // ------------------------------------------------------------------ save corruption
  if (SUITES.includes('corruption')) {
    const page = await browser.newPage();
    page.errors = []; page.on('pageerror', e => page.errors.push(e.message));
    await page.addInitScript(() => { if (!sessionStorage.getItem('c')) { sessionStorage.setItem('c', '1'); localStorage.clear(); localStorage.setItem('starfall_save_v', '{"version":3,"currencies":{"credits":'); } });
    await page.goto(BASE);
    await page.waitForFunction(() => window.__starfall);
    const st = await page.evaluate(() => ({ src: window.__starfall.saveManager.status.source, q: Object.keys(localStorage).filter(k => k.startsWith('starfall_save_corrupt_')).length }));
    record('corrupted save is quarantined, game still boots', st.src === 'reset-after-corruption' && st.q === 1 && page.errors.length === 0, JSON.stringify(st));
    await page.close();
  }

  // ------------------------------------------------------------------ every objective type can be completed
  if (SUITES.includes('objectives')) {
    const objs = (process.env.OBJS || 'intercept,escort,shieldgen,survive,comms,acehunt,colony,convoy,derelict,escape,carrier,anomaly').split(',');
    const errs = [];
    for (const o of objs) {
      const page = await newPage(); await skipSplash(page);
      const r = await play(page, `M.generateMission({ seed: 'qa-${o}', objective: '${o}', region: D.OBJECTIVES['${o}'].regions[0], difficulty: 1.1, modifiers: [] })`, { god: true, power: 4, snap: true, maxSeconds: 480 });
      record(`objective "${o}" can be completed`, r.outcome === 'victory' && !r.errors.length, `${r.outcome || 'unfinished'} in ${r.simTime}s sim (${r.ms}ms real), kills ${r.kills}${r.errors.length ? ' ERR ' + r.errors[0] : ''}${r.status ? ' | ' + r.status : ''}${r.alive ? ' | alive: ' + r.alive : ''}`);
      errs.push(...page.errors);
      await page.close();
    }
    record('no JavaScript errors during missions', errs.length === 0, errs.slice(0, 3).join(' | '));
  }

  // ------------------------------------------------------------------ bosses
  if (SUITES.includes('bosses')) {
    const expected = { dreadnought: 4, swarmqueen: 3, phantom: 3, anomaly: 3, hollow: 3 };
    let page;
    for (const b of (process.env.BOSSES || 'dreadnought,swarmqueen,phantom,anomaly,hollow').split(',')) {
      if (page) await page.close();
      page = await newPage(); await skipSplash(page);
      const r = await play(page, `M.generateMission({ seed: 'qa-boss-${b}', objective: 'boss', boss: '${b}', difficulty: 1, modifiers: [] })`, { god: true, power: 3, snap: true, maxSeconds: 600 });
      const phases = r.phases.filter(p => p.startsWith(b)).length;
      record(`boss "${b}" transitions through phases and can be defeated`, r.outcome === 'victory' && phases >= expected[b] - (b === 'dreadnought' ? 1 : 0) && !r.errors.length, `${r.outcome || 'unfinished'}, phases seen ${r.phases.join(',')}, ${r.simTime}s${r.errors.length ? ' ERR ' + r.errors[0] : ''}`);
    }
    const r = await play(page, `M.generateMission({ seed: 'qa-c4', objective: 'boss', boss: 'phantom', difficulty: 1, modifiers: [], phantomRetreat: true })`, { god: true, power: 3, snap: true, maxSeconds: 400 });
    record('Phantom Ace retreats mid-fight in his first encounter', r.outcome === 'victory', r.outcome);
    const enc = await page.evaluate(() => Object.keys(window.__starfall.saveManager.data.universe.encountered.bosses));
    record('boss encounters are recorded for Boss Rush', enc.includes('hollow') && enc.includes('phantom'), enc.join(','));
    await page.close();
  }

  // ------------------------------------------------------------------ game modes
  if (SUITES.includes('modes')) {
    const errs = [];
    const fresh = async (seed = LOW) => { const pg = await newPage(seed); await skipSplash(pg); return pg; };
    const done = async pg => { errs.push(...pg.errors); await pg.close(); };
    let page = await fresh();
    let r = await play(page, `M.endlessMission(1)`, { god: true, power: 2, snap: true, maxSeconds: 200 });
    const waves = r.waveReached;
    record('Endless Frontier escalates through waves with perk choices', !r.errors.length && (waves || 0) >= 3, `reached wave ${waves}, perks ${r.perks}`);
    await done(page);
    page = await fresh();
    r = await play(page, `M.dailyChallenge(app.today())`, { god: true, power: 3, snap: true, maxSeconds: 400 });
    record('Daily Challenge (6 fixed waves) completes', r.outcome === 'victory', `${r.outcome}, waves ${r.wave}`);
    const best = await page.evaluate(() => { const s = window.__starfall.saveManager.data; return s.daily.challengeBest[window.__starfall.today()] || 0; });
    record('Daily Challenge personal best recorded', best > 0, String(best));
    await done(page);
    page = await fresh();
    r = await play(page, `M.experimentalMission(42)`, { god: true, power: 3, snap: true, maxSeconds: 400 });
    record('Experimental Zone with mutators completes', r.outcome === 'victory' && !r.errors.length, `${r.outcome}${r.errors[0] ? ' ' + r.errors[0] : ''}`);
    await done(page);
    page = await fresh({ ...LOW, universe: { encountered: { bosses: { dreadnought: 1, swarmqueen: 1 } } } });
    r = await play(page, `M.bossRushMission(save, 'normal')`, { god: true, power: 3, snap: true, maxSeconds: 900 });
    record('Boss Rush runs bosses back-to-back with ratings', r.outcome === 'victory', `${r.outcome}, ${r.simTime}s`);
    await done(page);
    page = await fresh();
    r = await play(page, `(${JSON.stringify({ id: 'tutorial', seed: 'tutorial', mode: 'tutorial', title: 'Flight School', brief: '', region: 'belt', objective: 'tutorial', faction: 'dominion', altFaction: null, difficulty: 0.7, tier: 1, modifiers: [], optional: [], elite: null, event: null, variantPool: [], surprise: null, boss: null, waves: 3, parTime: 300, rewardMult: 0.5, mutators: [], rewards: { credits: 150, alloy: 2, xp: 120, cores: 0 } })})`, { god: true, power: 3, snap: true, maxSeconds: 300 });
    record('Flight School tutorial can be completed', r.outcome === 'victory', `${r.outcome}, ${r.status || ''}`);
    await done(page);
    page = await fresh();
    r = await play(page, `M.campaignMission(0, save, [])`, { god: true, power: 3, snap: true, maxSeconds: 500 });
    const c = await page.evaluate(() => window.__starfall.saveManager.data.campaign.completed);
    record('campaign chapter completion unlocks the next chapter', c.includes('c1'), c.join(','));
    await done(page);
    record('no JavaScript errors in game modes', errs.length === 0, errs.slice(0, 3).join(' | '));
  }

  // ------------------------------------------------------------------ losing
  if (SUITES.includes('defeat')) {
    const page = await newPage(); await skipSplash(page);
    await page.evaluate(async () => { const M = await import('/src/missions.js'); window.__starfall.launchMission(M.generateMission({ seed: 'qa-lose', objective: 'survive', region: 'belt', difficulty: 2 })); window.__qa.begin({ maxSeconds: 200 }); window.__starfall.game.player.maxHull = 1; window.__starfall.game.player.hull = 1; window.__starfall.game.player.maxShield = 0; window.__starfall.game.player.shield = 0; });
    for (let i = 0; i < 60; i++) { const r = await page.evaluate(() => window.__qa.step(240)); if (r.done) break; }
    const s = await page.evaluate(() => window.__qa.summary());
    const resultsShown = await page.evaluate(() => document.querySelector('#results.on h1')?.innerText || '');
    record('missions can be lost (ship destroyed)', s.outcome === 'defeat' && /FAILED/.test(resultsShown), `${s.outcome} / "${resultsShown}"`);
    const deaths = await page.evaluate(() => window.__starfall.saveManager.data.stats.deaths);
    record('defeat is recorded in statistics', deaths >= 1, String(deaths));
    await page.close();
  }


  // ------------------------------------------------------------------ story campaign (30 chapters, both choice paths)
  if (SUITES.includes('story')) {
    const PATHS = { A: { ashkar: 'colony', vant: 'spare', lattice: 'silence' }, B: { ashkar: 'relay', vant: 'finish', lattice: 'chorus' } };
    // path B only replays chapters whose content depends on the choices
    const B_ONLY = ['c7', 'c8', 'c9', 'c10', 'c20', 'c21', 'c23', 'c26', 'c29', 'c30'];
    const only = process.env.CHAPTERS ? process.env.CHAPTERS.split(',') : null;
    for (const [pathId, pick] of Object.entries(PATHS)) {
      let choices = {};
      const all = await (async () => { const pg = await newPage(); await skipSplash(pg); const ids = await pg.evaluate(async () => (await import('/src/story.js')).CHAPTERS.map(c => c.id)); await pg.close(); return ids; })();
      for (let i = 0; i < all.length; i++) {
        const id = all[i];
        // choices made before this chapter on this path
        const chBefore = { ...choices };
        if (id === 'c7') chBefore.ashkar = pick.ashkar;
        if ((pathId === 'B' && !B_ONLY.includes(id)) || (only && !only.includes(id))) { if (id === 'c7') choices.ashkar = pick.ashkar; if (id === 'c20') choices.vant = pick.vant; if (id === 'c29') choices.lattice = pick.lattice; continue; }
        const page = await newPage(); await skipSplash(page);
        await page.evaluate(ch => { Object.assign(window.__starfall.saveManager.data.campaign.choices, ch); }, chBefore);
        const r = await play(page, `M.campaignMission(${i}, save, [])`, { god: true, power: 4, snap: true, maxSeconds: 700, prefer: Object.values(pick) });
        const info = await page.evaluate(() => { const a = window.__starfall; return { spoken: a.hud.comms.spoken, choices: { ...a.saveManager.data.campaign.choices }, ending: !!document.querySelector('#ending.on'), endTitle: document.querySelector('#ending h1')?.textContent || '' }; });
        Object.assign(choices, info.choices);
        const ok = r.outcome === 'victory' && !r.errors.length && info.spoken > 0 && (id !== 'c30' || info.ending);
        record(`story ${pathId}: chapter ${i + 1} (${id}) plays through`, ok, `${r.outcome || 'unfinished'} in ${r.simTime}s, ${info.spoken} lines${id === 'c30' ? `, ending "${info.endTitle}"` : ''}${r.errors.length ? ' ERR ' + r.errors[0] : ''}`);
        if (id === 'c20') record(`story ${pathId}: choice "${pick.vant}" recorded after chapter 20`, info.choices.vant === pick.vant, info.choices.vant);
        if (id === 'c29') record(`story ${pathId}: choice "${pick.lattice}" recorded after chapter 29`, info.choices.lattice === pick.lattice, info.choices.lattice);
        if (id === 'c30') record(`story ${pathId}: ending matches the final choice`, info.endTitle === (pick.lattice === 'silence' ? 'SILENCE' : 'CHORUS'), info.endTitle);
        await page.close();
      }
    }
  }

  // ------------------------------------------------------------------ combat feel (difficulty + engagement director)
  if (SUITES.includes('combat')) {
    const run = async diff => {
      const page = await newPage(); await skipSplash(page);
      await page.evaluate(async diff => {
        window.__starfall.saveManager.data.settings.difficulty = diff;
        const M = await import('/src/missions.js'); window.__starfall.launchMission(M.generateMission({ seed: 'qa-feel', objective: 'survive', region: 'belt', difficulty: 1, modifiers: [] }));
        window.__qa.begin({ god: true, snap: false, maxSeconds: 150 }); window.__feel = { maxEng: 0, view: 0, tail: 0, n: 0 };
      }, diff);
      for (let i = 0; i < 40; i++) {
        const r = await page.evaluate(() => {
          const st = window.__qa.step(120); const g = window.__starfall.game, P = g.player, f = window.__feel;
          let eng = 0;
          for (const u of g.units) {
            if (!u.alive || u.team !== 'enemy' || u.structure || u.boss || u.target !== P) continue;
            if (['flank', 'swarm', 'stealth', 'ace'].includes(u.behavior) && !(u.formation && !u.formation.broken) && u.engaged) eng++;
            const v = u.pos.clone().sub(P.pos); const d = v.length(); if (d > 700) continue;
            const dot = v.dot(P.forward) / d; f.n++; if (dot > 0.7) f.view++; if (dot < 0 && d < 400) f.tail++;
          }
          f.maxEng = Math.max(f.maxEng, eng);
          return { done: st.done };
        });
        await page.cdp.send('HeapProfiler.collectGarbage');
        if (r.done) break;
      }
      const out = await page.evaluate(() => { const g = window.__starfall.game, f = window.__feel; return { id: g.tune.id, max: g.tune.maxAttackers, maxEng: f.maxEng, view: f.view / Math.max(1, f.n), tail: f.tail / Math.max(1, f.n), kills: g.stats.kills, errors: window.__qa.errors.length }; });
      await page.close();
      return out;
    };
    const std = await run('standard'), ace = await run('ace'), rel = await run('relaxed');
    record('Standard caps simultaneous attackers at 3', std.id === 'standard' && std.maxEng <= 3 && !std.errors, `max engaged ${std.maxEng}`);
    record('Relaxed caps simultaneous attackers at 2', rel.id === 'relaxed' && rel.maxEng <= 2 && !rel.errors, `max engaged ${rel.maxEng}`);
    record('Standard keeps hunters in view more than Ace', std.view > ace.view + 0.15 && std.tail < ace.tail, `in view ${(std.view * 100).toFixed(0)}% vs ${(ace.view * 100).toFixed(0)}%, on tail ${(std.tail * 100).toFixed(0)}% vs ${(ace.tail * 100).toFixed(0)}%`);
    record('assisted pilot kills more on Standard than Ace', std.kills > ace.kills, `${std.kills} vs ${ace.kills} kills in 150 s`);
    {
      const page = await newPage(); await skipSplash(page);
      const flip = await page.evaluate(async () => {
        const M = await import('/src/missions.js'); const app = window.__starfall; app.launchMission(M.generateMission({ seed: 'qa-flip', objective: 'survive', region: 'belt', difficulty: 1, modifiers: [] }));
        window.__qa.begin({ god: true }); const g = app.game, P = g.player, inp = app.input;
        for (let i = 0; i < 90; i++) g.update(1 / 30); // past the warp-in
        const f0 = P.forward.clone(), sp0 = P.vel.length();
        inp.pressedThisFrame.add('KeyV'); g.update(1 / 30);
        for (let i = 0; i < 20; i++) g.update(1 / 30);
        return { dot: P.forward.dot(f0), velDot: P.vel.clone().normalize().dot(f0), sp0, sp1: P.vel.length() };
      });
      record('quick turn (V) swings the ship ~180° and carries momentum', flip.dot < -0.85 && flip.velDot < -0.5, `facing dot ${flip.dot.toFixed(2)}, velocity dot ${flip.velDot.toFixed(2)}`);
      await page.close();
    }
  }

  // ------------------------------------------------------------------ pause / restart / retreat flow
  if (SUITES.includes('flow')) {
    const page = await newPage(); await skipSplash(page);
    await page.evaluate(async () => { const M = await import('/src/missions.js'); window.__starfall.launchMission(M.generateMission({ seed: 'qa-flow', objective: 'colony', difficulty: 1 })); window.__qa.begin({ god: true, maxSeconds: 60 }); });
    for (let i = 0; i < 4; i++) await page.evaluate(() => window.__qa.step(240));
    const before = await page.evaluate(() => ({ t: window.__starfall.game.time, u: window.__starfall.game.units.length }));
    await page.keyboard.press('Escape');
    const paused = await page.evaluate(() => window.__starfall.paused && document.querySelector('#pause.on') != null);
    record('Escape pauses the mission and shows the pause menu', paused);
    await page.click('[data-action=resume]');
    record('resume returns to the mission', await page.evaluate(() => !window.__starfall.paused));
    await page.evaluate(() => window.__starfall.pause(true));
    await page.click('[data-action=restart]');
    const after = await page.evaluate(() => ({ t: window.__starfall.game.time, u: window.__starfall.game.units.length, state: window.__starfall.state }));
    record('restart cleans up previous mission state', after.state === 'mission' && after.t < 1 && after.u < before.u, `units ${before.u} -> ${after.u}, time ${before.t.toFixed(0)} -> ${after.t.toFixed(1)}`);
    await page.evaluate(() => window.__qa.begin({ god: true, maxSeconds: 30 }));
    await page.evaluate(() => { const g = window.__starfall.game; g.headless = true; g.input.down.add('KeyJ'); for (let i = 0; i < 160; i++) g.update(1 / 30); });
    const ret = await page.evaluate(() => window.__starfall.lastResult?.result.outcome);
    record('holding J performs a tactical retreat with partial rewards', ret === 'retreat', ret);
    await page.close();
  }
} catch (e) {
  record('suite crashed', false, e.message);
} finally {
  await browser.close();
  server.close();
  const failed = results.filter(r => !r.ok);
  log(`\n${results.length - failed.length}/${results.length} checks passed`);
  // partial runs (SUITES=...) merge into the existing report so it always reflects the latest result of every check
  const reportPath = path.join(ROOT, 'tests', 'last-qa-report.json');
  let merged = results;
  if (process.env.SUITES) {
    try {
      const prev = JSON.parse(fs.readFileSync(reportPath, 'utf8')).results || [];
      const names = new Set(results.map(r => r.name));
      merged = [...prev.filter(r => !names.has(r.name)), ...results];
    } catch { /* no previous report */ }
  }
  fs.writeFileSync(reportPath, JSON.stringify({ date: new Date().toISOString(), results: merged }, null, 2));
  process.exit(failed.length ? 1 : 0);
}
