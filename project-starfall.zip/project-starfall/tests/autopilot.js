// In-page QA autopilot: flies the player ship toward objectives/enemies and fires.
// Injected by tests/browser-qa.mjs (Playwright) to play missions headlessly at accelerated speed.
window.__qa = {
  autopilot(g) {
    const P = g.player, inp = g.input;
    if (!P || !P.alive) return;
    inp.down.clear();
    if (g.choice) { g.pickChoice(g.choice.options.find(x => !x.disabled).id); return; }
    let t = null, bd = 1e12;
    for (const u of g.units) {
      if (!g.isTargetable(u) || u.armored || u.invulnerable || (u.passive && u.type !== 'cargo')) continue;
      if (u.team !== 'enemy' && !u.hostile) continue;
      let d = u.pos.distanceToSquared(P.pos);
      if (u.marker) d *= 0.12; // objectives first
      if (d < bd) { bd = d; t = u; }
    }
    const o = g.objective;
    let goal = t ? t.pos : null, mode = 'fight';
    if (o.gates && o.gates[o.idx]) { goal = o.gates[o.idx].pos; mode = 'race'; }
    if (o.gates && o.gi != null && o.gates[o.gi]) { goal = o.gates[o.gi].pos; mode = 'race'; }
    if (o.stage === 'approach' || o.stage === 'scan') { goal = o.wreck.pos; mode = 'go'; }
    if (g.waypoint) { goal = g.waypoint.pos; mode = 'race'; }
    const cores = g.pickups.filter(p => p.type === 'core' || p.type === 'relic');
    if (cores.length) { goal = cores[0].pos; mode = 'go'; }
    if (g.director.trader && g.director.traderState === 'waiting') { goal = g.director.trader.pos; mode = 'go'; if (P.pos.distanceTo(goal) < 130) inp.pressedThisFrame.add('KeyG'); }
    if (o.steps) { // tutorial lessons
      const st = o.steps[o.step]?.title;
      if (st === 'Evasion') inp.pressedThisFrame.add('Space');
      if (st === 'Ability') inp.pressedThisFrame.add('KeyF');
      if (st === 'Lock-on ordnance' && P.weapons.locked) inp.mouse.rightPressed = true;
    }
    // simple obstacle avoidance: if hugging a big hull, climb away from it before continuing
    for (const u of g.units) {
      if (!u.alive || u.radius < 20 || u.intangible) continue; // fly-through gates are not hulls
      const d = u.pos.distanceTo(P.pos);
      if (d < u.radius + 35 && goal) { goal = P.pos.clone().add(P.pos.clone().sub(u.pos).normalize().multiplyScalar(150)).add(P.up.clone().multiplyScalar(80)); mode = 'race'; break; }
    }
    if (!goal) { inp.stick.x = 0.2; inp.stick.y = 0; inp.down.add('KeyW'); inp.mouse.left = false; return; }
    if (this.snap && P.pos.distanceTo(goal) > 5) { // test aid: perfect aim so objective logic (not piloting skill) is what's tested
      // object lookAt convention (+Z toward target) computed directly — cloning the ship mesh would deep-copy its userData (materials/textures)
      const M4 = P.mesh.matrix.constructor;
      this._m = this._m || new M4(); this._q = this._q || new P.quat.constructor();
      this._m.lookAt(goal, P.pos, P.up); this._q.setFromRotationMatrix(this._m);
      P.quat.slerp(this._q, 0.25); P.forward.set(0, 0, 1).applyQuaternion(P.quat);
    }
    const rel = goal.clone().sub(P.pos);
    const dist = rel.length();
    const x = rel.dot(P.right), y = rel.dot(P.up), z = rel.dot(P.forward);
    const k = 2.5 / (Math.abs(z) + 40);
    inp.stick.x = z < 0 ? Math.sign(x || 1) : Math.max(-1, Math.min(1, x * k));
    inp.stick.y = z < 0 ? 0 : Math.max(-1, Math.min(1, -y * k));
    const ang = Math.atan2(Math.hypot(x, y), z);
    if (mode === 'race') { inp.down.add('KeyW'); if (P.boost > 30 && ang < 0.4) inp.down.add('ShiftLeft'); }
    else if (mode === 'go') { if (dist > 60) inp.down.add('KeyW'); else inp.down.add('KeyS'); }
    else { if (dist > 260) inp.down.add('KeyW'); if (dist < 90) inp.down.add('KeyS'); if (dist > 500 && P.boost > 60 && ang < 0.3) inp.down.add('ShiftLeft'); }
    inp.mouse.left = mode === 'fight' ? (ang < 0.12 && dist < 700) : !!(t && P.inCone(t, 0.98) && t.pos.distanceTo(P.pos) < 600);
    if (P.weapons.locked && Math.random() < 0.05) inp.mouse.rightPressed = true;
    if (P.shield < P.maxShield * 0.3 && P.ability.cd <= 0 && Math.random() < 0.1) inp.pressedThisFrame.add('KeyF');
    if (P.weapons.current.overheated && P.weapons.slots.length > 1) inp.pressedThisFrame.add('KeyX');
  },

  begin(opts = {}) {
    const g = window.__starfall.game;
    g.headless = true;
    if (opts.god) g.player.takeDamage = () => 0;
    if (opts.power) g.playerDamageMult *= opts.power;
    // accelerated simulation outruns the real-time audio thread; mute the game's synth during QA runs
    if (opts.audio !== true) { const au = window.__starfall.audio; au.play = () => {}; au.loop = () => {}; au.music?.stop(); }
    this.snap = !!opts.snap;
    this.errors = []; this.phases = new Set(); this.steps = 0; this.t0 = performance.now(); this.maxSeconds = opts.maxSeconds || 300;
  },

  // Advance n fixed steps. Returns { done } when the mission ended or timed out.
  step(n = 300) {
    const app = window.__starfall, g = app.game;
    for (let i = 0; i < n; i++) {
      if (!g.active || g.time >= this.maxSeconds) break;
      try {
        if (g.cinematic) g.endCinematic();
        this.autopilot(g);
        g.update(1 / 30);
        if (g.boss) this.phases.add(g.boss.id + ':' + g.boss.phase);
      } catch (e) { this.errors.push(e.message + ' @ ' + (e.stack || '').split('\n')[1]); if (this.errors.length > 5) return { done: true }; }
      this.steps++;
    }
    return { done: !g.active || g.time >= this.maxSeconds, t: g.time };
  },

  summary() {
    const app = window.__starfall, g = app.game;
    const st = g.objective ? g.objective.status() : null;
    const lr = app.lastResult;
    return {
      ended: !g.active, state: app.state, simTime: Math.round(g.time), steps: this.steps, ms: Math.round(performance.now() - this.t0),
      errors: this.errors, phases: [...this.phases], status: st ? st.lines.map(l => l.text).join(' | ') : null,
      outcome: lr ? lr.result.outcome : null, failReason: lr ? lr.result.failReason : null, credits: lr ? lr.summary.reward.credits : null,
      kills: lr ? lr.result.kills : g.stats?.kills, waveReached: g.objective?.wave ?? (lr ? lr.result.wave : null), perks: (g.perksTaken || []).join('+'),
      alive: g.units ? g.units.filter(u => u.alive && u.team === 'enemy').map(u => `${u.type}${u.untargetable ? '(U)' : ''}${u.invulnerable ? '(I)' : ''}@${Math.round(u.pos.distanceTo(g.player.pos))}/${Math.round(u.pos.length())}`).slice(0, 14).join(' ') : '', wave: lr ? lr.result.wave : null, missionId: lr ? lr.mission.id : null,
    };
  },
};
