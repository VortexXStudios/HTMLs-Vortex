# PROJECT STARFALL
*Vortex Studios presents…* a 3D space-combat arcade game built with **HTML5, CSS3, JavaScript ES modules, Three.js (r170) and the Web Audio API**. It needs no backend and no build step, and it plays offline: Three.js is bundled in `lib/three`.

---

## 1. Launching

ES modules and import maps don't load from `file://`, so serve the folder over HTTP:

```bash
cd project-starfall
python3 -m http.server 8080        # or:  npx serve .   /   npx http-server -p 8080
```
Then open **http://localhost:8080** in a recent Chrome, Edge, Firefox or Safari with hardware acceleration turned on.

* Click once (or press any key) to skip the **VORTEX STUDIOS PRESENTS…** splash. Audio starts after your first click, because browsers block autoplay.
* Google Fonts (Orbitron and Rajdhani) load when you're online. Offline, the game falls back to system fonts and works the same.

### Developer overrides (not shown in normal play)
Add `?dev=1` to the URL to enable them:

| Parameter | Effect |
|---|---|
| `&event=halloween` | Forces a seasonal event (`halloween`, `winter`, `spring`, `summer`, `anniversary`, `anomaly`). Use `none` to disable all events. |
| `&date=2026-12-25` | Pretends today is that date (calendar events, daily rewards). |

Without `dev=1`, both parameters are ignored.

---

## 2. Controls

| Input | Action |
|---|---|
| **Mouse** | Steer. The small circle is your virtual stick. Click the canvas to lock the pointer. |
| **W / S** | Throttle up / brake |
| **A / D** | Strafe |
| **Q / E** | Roll |
| **Shift** | Boost (uses energy) |
| **Space** | Evasive dash (brief invulnerability, uses energy) |
| **V** or **double-tap Space** | Quick turn: a half-second 180° swing that keeps your speed (gamepad: right-stick click; touch: FLIP) |
| **Left mouse** | Fire primary weapon |
| **Right mouse / R** | Fire ordnance. Keep a target under the crosshair until the bracket turns red to lock missiles. |
| **X** (or 1/2) | Swap primary weapon (each weapon has its own heat) |
| **F** | Ship ability |
| **T / Tab** | Cycle hard target lock |
| **G** | Interact (answer hails) |
| **J (hold 3 s)** | Tactical retreat (keeps 40% of rewards) |
| **Esc / P** | Pause (also pauses automatically when the tab loses focus) |
| **1 / 2 / 3** | Pick an option on choice screens (perks, trader) |

**Gamepad:** left stick moves and strafes, right stick steers, RT fires, LT fires ordnance, A boosts, B dashes, Y uses the ability, X targets, RB swaps weapons, Start pauses.

**Touch (phones and tablets):** controls appear automatically on touch screens. Drag anywhere on the left half to steer (the stick appears under your thumb). The right-hand thumb arc has FIRE, MSL (hold on a target to lock), BOOST, DASH, ABIL, SWAP, TGT and THR/BRK (throttle). HAIL appears when a trader calls, HOLD RETREAT sits on the left edge, and ❚❚ (top-left) pauses. Menus, the HUD and the camera adapt to portrait and landscape.

New pilots can open **Tutorial → Flight School**, a 7-lesson guided onboarding.

---

## 3. Gameplay systems

### Combat
* **Difficulty** (Settings → Gameplay): **Relaxed**, **Standard** or **Ace**. *Auto* picks Standard with a mouse and Relaxed on touch screens.
  * Aim assist: bolts snap to the lead point within 16° / 12° / 6° of the crosshair (a few degrees wider on touch). Relaxed and Standard also pull your nose gently toward that target, and small craft have slightly forgiving hitboxes.
  * **Engagement director** (`src/combat.js`): only 2 / 3 / unlimited fighters may press an attack on you at once. The rest hold stations spread across your forward view and take occasional long-range shots. Attack tokens rotate, and a fighter that lingers on your tail loses its token and swings back to the front.
  * Attack runs set up beside and ahead of you, fly straight in for about a second before opening fire (no dodging during that window), and peel off back into your view instead of diving past onto your tail. Enemies also turn and dodge less sharply on Relaxed and Standard.
  * Off-screen enemies within 750 m get an arrow on the screen edge, and attackers mid-run pulse red. The camera can lean toward your locked target (Settings → Gameplay).
  * Ace keeps the original tuning: every fighter hunts you at once.
* **Flight model:** free 3D flight with inertia, boosting, strafing, auto-banking, evasive barrel-roll dashes, and a chase camera that adds boost FOV, recoil and screen shake.
* **7 primary weapons**, each with its own behavior:
  * **Pulse:** twin bolts.
  * **Scatter:** a 9-pellet shotgun.
  * **Plasma:** splash damage that's strong against shields.
  * **Railgun:** hitscan with high crit damage.
  * **Arc Caster:** chain lightning that jumps up to 4 times.
  * **Lance Beam:** damage ramps up while the beam stays on a target.
  * **Gravity Projector:** drags enemies together, then implodes.
* **Per-weapon heat.** Overheating locks that weapon, which pushes you to swap.
* **3 ordnance types:** lock-on Seeker Missiles, Nova Torpedoes, and Hornet Drones.
* **8 abilities:** Aegis (reflects bolts), Overdrive, Repair Drone, EMP, Holo Decoy, Phase Cloak (3× ambush damage), Nova Burst, and Time Dilation.
* **Targeting:** aim assist with a lead indicator, soft and hard target locks, an off-screen threat/objective indicator, a radar with height cues, a damage direction indicator, and damage numbers.
* **Combo system:**
  * Kills in a chain raise your multiplier.
  * Bonuses for weapon variety, precision crits and killing elites.

### Enemies (4 factions × 12 classes + variants)
Iron Dominion, Vrell Swarm, Phantom Syndicate and the Null Choir, each with their own look and roster. Every class behaves differently:

* **Swarm drones** march in **Space-Invaders lockstep grids**. The grid sweeps sideways, steps forward at each edge, and speeds up as it thins out. Drones also fly in vee, ring, column and pincer formations.
* **Interceptors** circle to your flank, make a strafing run, break away, and jink when you aim at them.
* **Bombers** launch **shootable torpedoes**, usually at whatever you're protecting.
* **Snipers** keep their distance and show a red **laser sight for 1.5 s** before firing.
* **Bastions** project shield auras that absorb damage for nearby allies.
* **Menders** heal the most damaged ally and flee from you.
* **Wraiths** cloak, circle behind you, and decloak with a burst.
* **Burners** are kamikazes that beep faster as they close in.
* **Siegebreakers** lob shells at your *predicted* position and mark the impact zone.
* **Named elite aces** come with three personalities (aggressive, evasive, tactical). They retreat when hurt and come back with different tactics.
* **Mini-bosses:** the Sentinel Platform (bullet rings) and the Brood Mother (spawns drones and spores).
* **Capital ships:** cruisers and carriers.
* **Variants:** Armored, Overcharged, Veteran (dodges), Swift and Shielded, plus seasonal ones: Ghostly (phases out), Frostbound (chills your engines), Bloomspawn (splits on death) and Solarborn (explodes on death).

### Bosses (multi-phase, skippable cinematic intros)
1. **The Dreadnought** (4 phases):
   * Shield generators protect it at first, while turrets track you and it launches fighters.
   * Next, sweeping beam batteries come online and its engines become the weak points.
   * With the engines down, it opens to expose its reactor.
   * At low reactor health it begins **"Last Light"**: a 7-second overload you must escape (450 m) or interrupt. Armored hull sections deflect shots.
   * During the winter event, a *Cryo* variant appears.
2. **The Swarm Queen** (3 phases):
   * Rotating rings of drones guard her and periodically launch at you.
   * She then shelters behind hive nodes you must destroy.
   * Finally she evolves: telegraphed charges and kamikaze broods.
3. **The Phantom Ace** (3 phases):
   * Duels you with evasive jinks and walls of bolts that always leave a gap.
   * Then spawns **mirror-image decoys** and swaps places with them.
   * At low health he cloaks and ambushes from behind.
   * He **adapts to how you fight**: flares if you rely on missiles, harder jinking against precision weapons, and a closer or farther range depending on yours.
   * In campaign chapter 4 he retreats and returns in chapter 9.
4. **The Anomaly** (3 phases):
   * Orbiting gravity wells pull your ship and bend projectiles, and shards fire telegraphed beams.
   * Space then "folds": the arena shrinks, fog thickens, momentum drifts and the Anomaly teleports.
   * Finally rifts spit out other factions while expanding gravity pulses sweep the arena, which you dash through.
5. **The Hollow Warden** (Halloween only): a ghost galleon you can only damage while it's manifested. Shooting out its soul lanterns makes it weaker. Its later phases bring wisp storms and a "witching hour" with pumpkin mines.

### Missions and the Mission Director
* **12 objective types:**
  * Intercept, Escort, Shield Breaker, Storm Run, Signal Blackout.
  * Ace Hunt, Colony Defense (multi-vector), Convoy Raid (collect cores).
  * Derelict Signal (scan → ambush → extract), Collapse (gate race: 16 s on the clock, +5 s per gate, falling debris), Carrier Strike (engines → turrets → reactor), Anomaly Breach.
  * Plus boss encounters.
* **Branching outcomes.** Examples:
  * If the reinforcement uplink completes, the Signal Blackout mission turns into a much bigger fight.
  * A neutral trader may offer a trade or a wager — or turn out to be a trap.
  * You can retreat at any time.
* **Optional objectives (risk/reward):** Untouchable, Swift Victory, Ordnance Expert, Elite Bounty, Scavenger, Chain Reaction and Arsenal.
* **11 mission modifiers:** drone carriers, radar jamming, dense fields, regenerating shields, thermal stress, allied wingmen, valuable cargo, hunter packs, a roaming gravity rift, glass cannons and ironclad enemies.
* **Seeded procedural generation** (reproducible). The director:
  * avoids recently played objective *structures*;
  * paces ambient waves through build-up, peak and relief;
  * avoids repeating the exact same wave composition;
  * stages surprises: a neutral trader, a hidden cache, an ambush, or a rare discovery.
* **7 regions**, each with gameplay effects:
  * Asteroid belt: collisions, and rocks block shots.
  * Ruined orbital city: cover.
  * Volcanic orbit: magma flares.
  * Ship graveyard: mines and low visibility.
  * Nebula: fog shortens lock range, and ion storms drain shields.
  * Alien megastructure: gravity wells.
  * Enemy frontier: defense turrets, +25% rewards.
* **An evolving universe.** Regions where you fight get more dangerous and more rewarding. Outcomes create **follow-up contracts**:
  * Retaliation strikes.
  * Evacuation runs.
  * Fleet favors.
  * Reinforcement fleets.
  * Rival aces returning.
  * Discovery rifts.

### Game modes
* **Campaign:** 10 connected chapters with story, a recurring rival and 4 major bosses.
* **Contract Board:** 5 rotating contracts plus special follow-ups. Rotates daily and can be refreshed for credits.
* **Endless Frontier:** escalating waves, a new modifier every 3 waves, a perk choice after every wave (12 roguelite perks), elites every 5 waves, bosses every 10, and a rising score multiplier.
* **Boss Rush:** every boss you've encountered, back to back, on Normal, Hard or Nightmare, with S–C ratings.
* **Experimental Zone:** 3 of 10 mutators, chosen so they can't combine unfairly (e.g. Giants and Micro Swarm never appear together). The mutators: Giants, Micro Swarm, Weapon Roulette, Bent Space, Ricochet Arena, Mirror Squadron, Zero Damping, Glass Cannons, Blood Pact and Chaos Factions.
* **Daily Challenge:** a fixed seed per calendar day, so you can compare your own scores across attempts. Your best score per day is recorded.
* **Daily Op:** one bonus contract per day.

### Progression
* **Account and ships:**
  * Pilot levels (up to 50) with milestone rewards.
  * **4 currencies**: Credits, Alloy, Quantum Cores and Event Tokens.
  * **6 ships**: Interceptor, Gunship, Heavy Armor, Stealth, Artillery and Experimental. Each has a passive trait and a signature loadout.
* **Upgrades:** 10 upgrade branches × 5 tiers, with stat comparisons before you buy. Each branch also unlocks **2 mutually exclusive behavior mods**, for example:
  * piercing railguns,
  * splitting missiles,
  * shield-shock retaliation,
  * an afterburner wake that damages pursuers,
  * a "last stand" bonus,
  * ability recharge on elite kills.
* **Cosmetics:**
  * 55 items: paints (including iridescent exotics), engine glows (including a color-cycling one), wing patterns, emblem decals (made from your icon art), trails and weapon tints.
  * Each ship keeps its own equipped set.
  * **Rarity tiers** (Common → Exotic) show how hard an item is to get, not combat power.
* **Collection and records:**
  * A collection gallery where you can **inspect ships, the bestiary and bosses in 3D** (drag to rotate, scroll to zoom), plus discoveries.
  * 27 achievements.
  * Personal records and statistics.
* **No real-money purchases.**

### Daily rewards and events
* **Daily rewards:**
  * They follow local **calendar days**, not 24-hour windows, so refreshing never grants a second claim.
  * Day 7 of each streak cycle gives a cosmetic, and each later cycle gives more.
  * **Catch-up rules:** one missed day is forgiven; longer breaks halve your streak instead of resetting it.
  * There's a countdown to the next reward.
  * If the system clock moves backwards, claims pause until the date catches up.
* **Seasonal events**, data-driven in `src/events.js`:
  * **Hallowed Void** (Halloween): ghost variants, wisp particles, the Hollow Warden, a 3-mission chain and haunted cosmetics.
  * **Frostfall** (Dec 10 – Jan 6, handles the year wrap): icy asteroids, frost variants, the Cryo Leviathan.
  * **Bloomtide** (spring): spore particles, bloom variants.
  * **Solar Maximum** (summer): +20% damage for everyone, magma flares.
  * **Starfall Day** (anniversary): +50% rewards, confetti.
  * A rare unannounced **Cosmic Anomaly**: about 2 days in every ~23, set by the calendar date.
  * Each event has its own token exchange.

### Audio
Everything is synthesized with Web Audio:
* Every weapon, hit and explosion has its own sound, with random pitch variation and voice limits so repeats don't stack up.
* Distance-based volume, stereo panning and a shared reverb.
* Engine, boost and beam sounds loop while active.
* **Adaptive music** is a procedural sequencer with pad, bass, arpeggio, drum and lead layers that fade in and out with threat level. Menu, combat, boss and event music each have their own progression.
* Master, music and effects volume controls.

### Graphics and performance
* **Visuals:**
  * Physically based materials with a per-region image-based-lighting environment map.
  * Directional sun shadows (Off / Low / High).
  * **Unreal Bloom** post-processing with a color grade: a vignette, chromatic aberration when you take damage, and desaturation during time dilation. If post-processing fails, rendering falls back to direct.
* **Efficiency:**
  * Instanced projectiles, asteroids and debris.
  * Pooled GPU particles with no per-frame allocation.
  * A spatial hash for asteroid collisions.
  * Simulation uses delta time, so gameplay doesn't depend on frame rate.
* **Settings:** resolution scale, shadows, particle density, effects quality, render distance, FPS cap / VSync, an FPS counter, and reduce-shake / reduce-flashing options.
* **Pausing:** the game pauses when the window loses focus.

---

## 4. Save behavior
* Progress is saved to `localStorage` (key `starfall_save_v`) after every meaningful action: purchases, equips, claims, mission results and settings.
* **Versioned format** (v3) with step-by-step migrations from v1 and v2.
* **Validation:**
  * Every field is type-checked and clamped.
  * Unknown IDs are removed.
  * Missing fields are filled with defaults.
  * Loadouts and cosmetics are re-checked against what you own.
* **Recovery:**
  * Every few writes, the previous good save is copied to a **backup key**.
  * If the main save can't be read, the game loads the backup.
  * The unreadable data is set aside under `starfall_save_corrupt_<timestamp>` instead of being overwritten.
  * You see a message when any of this happens.
* **Separation:** temporary mission state lives only in `Game` and touches permanent progress once, through `applyMissionResult()`.
* **Settings → Save Data:** export and import (base64), change callsign, and **Reset all progress** (two confirmations; your settings are kept).
* If storage is blocked (some private modes), the game still runs and tells you progress won't persist.

---

## 5. Known limitations
* **Leaderboards are personal and offline.** Global leaderboards and authoritative anti-cheat (for example against setting the system clock forward for daily rewards) would need a server. Moving the clock backwards is detected and handled; moving it forwards can't be detected offline.
* **Visuals:** all models are procedural (no external 3D assets). The menu art and icons are the provided Vortex Studios sprite sheet.
* **Performance on integrated GPUs:** heavy scenes with bloom may need Effects = Medium/Low or resolution scale 75%.
* **Gamepad mapping** follows the standard layout. Button remapping isn't implemented.
* **Tuning:** balance comes from automated playtests. Difficulty curves may need tuning based on human playtesting.

---

## 6. Tests
```bash
node tests/run-tests.mjs           # 41 unit tests: save validation/migration/recovery, daily rewards & streaks,
                                   # clock rollback, calendar events, mission generation, progression & rewards
npm i -D playwright && npx playwright install chromium
node tests/browser-qa.mjs          # Browser QA: boots the real game in headless Chromium, drives the UI,
                                   # and plays every objective, boss and mode with an autopilot (tests/autopilot.js)
```
The browser suite writes `tests/last-qa-report.json`. Use `SUITES=boot,menus,…` to run a subset; a subset run merges its results into the existing report. The suites are boot, menus, economy, persistence, daily, events, corruption, objectives, bosses, modes, combat, defeat and flow.

### Results of the last test runs (headless Chromium, software WebGL)
* **Unit tests:** 41/41 pass.
* **Browser QA:** 64/64 checks pass in the last full run (`tests/last-qa-report.json`).
* **Boot and menus:**
  * The splash ("VORTEX STUDIOS PRESENTS...") advances to the title screen.
  * WebGL initialises with no JavaScript errors.
  * Every hangar tab renders.
  * Campaign (10 chapters), contracts and briefings render.
  * Settings persist.
* **Economy:** buying an upgrade raises its stat. Behavior mods, ship builds and cosmetic purchase/equip work through the UI. Purchases are blocked without funds.
* **Persistence:** progress survives a reload. A corrupted save is set aside and the game still boots.
* **Daily rewards:** a claim works. A refresh does not allow a second claim.
* **Events:** winter is active on Dec 24, nothing on Nov 12. The developer override works only with `?dev=1`.
* **Mission objectives:** all 12 objective types were played to **victory** by the autopilot: intercept, escort, shield breaker, storm run, signal blackout, ace hunt, colony defense, convoy raid, derelict signal, collapse, carrier strike and anomaly breach. The autopilot ran with invulnerability, boosted damage and auto-aim, so these tests check mission logic, not difficulty.
* **Bosses:** all 5 went through every phase and were defeated. The Phantom's chapter-4 retreat works.
* **Game modes:** Endless reached wave 10 with perk picks (the autopilot's run cap, not a game limit). Daily Challenge, Boss Rush, Experimental Zone, Flight School and campaign unlocks completed.
* **Combat feel** (autopilot steering with the stick like a player, no auto-aim, 150 s of Survive):
  * Standard never had more than 3 fighters attacking at once, Relaxed never more than 2.
  * Fighters hunting the player were in view 54% of the time on Standard vs 14% on Ace (the original tuning), and on the player's tail 18% vs 62%.
  * Kills: 46 on Standard vs 7 on Ace.
  * Quick turn swings the ship 180° and carries its momentum round.
* **Losing and flow:** a mission can be lost and is recorded as a defeat. Pause, resume, restart (which clears the old mission) and the hold-J retreat all work.
* **Memory:** no leak was found. Memory stays flat once the browser's garbage collector runs.
* **Not covered by automated tests:** human-feel balancing, audio quality (headless Chromium mutes output) and frame rate on real GPUs (CI uses software rendering).

---

## Project structure
```
index.html, style.css          UI shell, import map, all styling
src/main.js                    App bootstrap, state machine, loop, focus/visibility handling
src/game.js                    Mission runtime: units, damage, collisions, pickups, camera, results
src/player.js                  Flight model, shields/hull/boost, abilities
src/weapons.js                 Instanced projectile pools, all weapon behaviours, lock-on
src/units.js                   Enemy/ally/structure units, 20+ AI behaviours, formations
src/bosses.js                  Dreadnought, Swarm Queen, Phantom Ace, Anomaly, Hollow Warden
src/objectives.js              12 objectives + boss, boss rush, waves, tutorial
src/director.js                Mission director: pacing, modifiers, surprises, elites
src/missions.js                Seeded procedural mission generation, contracts, modes, wave composition
src/progression.js             XP, currencies, purchases, upgrades, mods, achievements, universe evolution
src/save.js                    Versioned save manager (validation, migration, backup, quarantine)
src/daily.js                   Calendar-day daily rewards & streaks
src/events.js                  Data-driven seasonal events
src/environment.js             Nebula skies, starfields, planets, asteroid fields, region set pieces
src/models.js                  Procedural ships, enemies, structures, bosses
src/effects.js                 Particles, explosions, shockwaves, beams, lightning, trails, shake
src/render.js                  Renderer, bloom/grade post-processing with fallback
src/hud.js                     In-mission HUD & radar
src/ui.js                      Splash, title, hangar, briefing, pause, results
src/menu3d.js                  3D title/hangar/collection display
src/audio.js                   Synthesized SFX & adaptive music
src/input.js                   Keyboard, mouse (pointer lock), gamepad
src/data.js                    All static game data (ships, weapons, enemies, bosses, cosmetics…)
lib/three/                     Three.js r170 + post-processing addons (MIT)
assets/                        Icons, buttons & favicon cropped from the Vortex Studios sheet
tests/                         Unit tests, browser QA suite, autopilot
```

Three.js © 2010–2024 three.js authors, MIT License (`lib/three/LICENSE`).
